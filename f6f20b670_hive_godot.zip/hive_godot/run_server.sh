#!/usr/bin/env sh
# Starts the Hive server without any window (needs Godot 4.3+ as "godot" on your PATH).
cd "$(dirname "$0")"
exec "${GODOT:-godot}" --headless --path . -- --server
