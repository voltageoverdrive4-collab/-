# 🐝 Hive Buzz AI (Godot 4 project)

The Hive's AI assistant + community chat + admin panel, as one Godot project, with a honeycomb theme.
The AI runs on **OpenRouter**. The community chat connects players to each other over **WebRTC**.

* **Buzz AI tab**: ChatGPT-style chats with the Hive assistant. Every chat is saved to your account.
* **The Hive tab**: live community chat with channels and an online list. Messages travel **peer-to-peer over WebRTC data
  channels** (the server only introduces players to each other and keeps the history/moderation copy).
* **Admin tab** (Queen + admins): overview, members (ban / mute / reset password / delete), AI persona + Hive facts + models +
  limits, channels, admin list (Queen only), AI log.
* **Account tab**: change password, export / delete your chats, delete your account.
* Everyone has to **create an account**. Accounts, chats and settings live on the Hive server.

There is no Discord bot in this version.

## How it fits together

One Godot project, two modes:

| Mode | How | What it does |
| --- | --- | --- |
| **App** (default) | press F5 / run the exported game | the window you see: login, chat, admin... |
| **Server** | `run_server.bat` (headless) **or** tick **"Host a server on this computer"** on the login screen | keeps accounts + chat history, talks to OpenRouter (your key never leaves it), relays the WebRTC handshake |

Everybody's app connects to the server's address (`address:8910`). To play with friends, one computer (or a cheap VPS) runs the server.

## Quick start (testing on one computer)

1. Install **Godot 4.3+** and open this folder (`project.godot`).
2. Open **`scripts/server/server_config.gd`** and replace `<open-router-key>` with your OpenRouter key (https://openrouter.ai/keys).
3. Press **F5**. On the login screen tick **"Host a server on this computer"**, pick any username/password and press **Join the hive**.
   The first account you create is a normal member. The **owner (Queen)** account is created automatically the first time the server
   starts: a window shows its username (`queen`) and a random password. **Write it down** (or set `OWNER_PASSWORD` in `server_config.gd`
   before the first start). Log in with it to see the **Admin** tab.
4. Run a second copy of the project (or an export) and log in with the address `127.0.0.1:8910` to try the chat between two players.

## Running the server for your community

* **Windows:** edit `run_server.bat` if needed and double-click it. **Mac/Linux:** `./run_server.sh`.
* Players type your server address in the login screen: `your-ip-or-domain:8910`.
* From home you must **forward TCP port 8910** on your router. A small VPS is the easy, always-on option: install Godot (headless),
  copy the project, set the key (or the environment variable `OPENROUTER_API_KEY`), and run `godot --headless --path . -- --server`.
* Data lives in Godot's user folder: `user://hive_data/db.json` (back it up).
* **Passwords are sent to the server, so use an encrypted connection on the internet:** put the server behind a reverse proxy that
  provides `wss://` (Caddy or nginx with a Let's Encrypt certificate forwarding to port 8910), then players enter
  `wss://your-domain` in the server box.

Optional environment variables for the server: `OPENROUTER_API_KEY`, `HIVE_PORT`, `HIVE_OWNER_USER`, `HIVE_OWNER_PASSWORD`.

## WebRTC (the "RTC" part)

* In **web exports** WebRTC is built into Godot.
* On **desktop** Godot needs the small **WebRTC GDExtension**: download `godot-extension-webrtc` from
  https://github.com/godotengine/webrtc-native/releases and unzip it into the project folder so that `res://webrtc/webrtc.gdextension`
  exists, then reopen the project. (Exports need that folder too.)
* The **The Hive** tab shows the status: `RTC: 2 peers connected`, `RTC: ready (waiting for peers)`, or
  `RTC: unavailable (server relay)`. Without the plugin the chat still works (through the server), just not peer-to-peer.
* How it works: when you send a message it goes to the server (validation, slow-mode, mutes, history) **and** instantly over WebRTC to the
  players you are connected to, who show it right away and de-duplicate it when the server copy arrives. Typing indicators are
  peer-to-peer only. If the server rejects a message (muted, too fast) your app tells your peers to retract it.
  Peers only accept messages from players the server lists as online and only if the sender id matches.
* Players connect through a free public STUN server (`stun.l.google.com`). Players behind very strict NATs may need a TURN server;
  you can add one in `scripts/net/rtc.gd` (`ICE`).

## Making Buzz sound like Hive

**Admin → AI & Bot**: edit the system prompt, the **Facts about Hive** (map codes, rules, staff, events: the starting text contains
the *1V1 With Every Gun* island code and a few basics, **please check and update it**), the allowed models, creativity, and rate limits.
Changes are live immediately.

## Admins

Only the **Queen** can add admins: **Admin → Admins**, type the username of someone who has signed up, **Make admin**.
Admins can moderate and change settings but cannot touch other admins or the Queen.

## Security notes

* Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes; login tokens are stored hashed; accounts are rate limited.
* The OpenRouter key only exists on the server. Never commit your edited `server_config.gd` anywhere public.
* All text shown in chat is plain text (no HTML/BBCode injection); the AI's replies are rendered with a small safe Markdown subset.
* Peer-to-peer messages are convenient, not authoritative: the server copy is the official history and moderation record.

## Files

```
main.tscn / scripts/main.gd          boot (app or --server)
scenes/                              auth, app shell, AI tab, chat tab, admin tab, account tab, bubbles
scripts/server/                      the Hive server (accounts, AI, chat, signalling, admin)
scripts/net/net.gd, rtc.gd           client networking + WebRTC mesh (autoloads)
scripts/ui/                          drawn bee, hex avatars, honey drip, toasts, dialogs, markdown
shaders/honeycomb.gdshader           animated honeycomb background
theme.tres                           the amber/black hive theme
```
