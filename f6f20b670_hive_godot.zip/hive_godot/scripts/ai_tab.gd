extends HBoxContainer
## Buzz AI tab: chat list + conversation + composer.

const BubbleScene = preload("res://scenes/bubble.tscn")
const SUGGESTIONS := [
	"What's the best gun for 1v1s?",
	"How do secret weapons work in 1V1 With Every Gun?",
	"Give me tips to win box fights",
	"Tell me about Hive",
]

@onready var conv_list: VBoxContainer = %ConvList
@onready var title_label: Label = %TitleLabel
@onready var model_pick: OptionButton = %ModelPick
@onready var scroll: ScrollContainer = %Scroll
@onready var msgs: VBoxContainer = %Msgs
@onready var input: TextEdit = %Input
@onready var send_btn: Button = %SendBtn

var convs: Array = []
var current_id := ""
var waiting_id := ""
var typing_bubble: Node = null


func _ready() -> void:
	%NewChatBtn.pressed.connect(_new_chat)
	send_btn.pressed.connect(_send)
	input.gui_input.connect(_on_input_key)
	Net.pushed.connect(_on_push)


func enter() -> void:
	model_pick.clear()
	var models: Array = Net.settings.get("allowed_models", [])
	for m in models:
		model_pick.add_item(str(m))
	for i in model_pick.item_count:
		if model_pick.get_item_text(i) == str(Net.settings.get("default_model", "")):
			model_pick.select(i)
	waiting_id = ""
	send_btn.disabled = false
	await _load_list()
	_new_chat()


func _on_input_key(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.shift_pressed and (e.keycode == KEY_ENTER or e.keycode == KEY_KP_ENTER):
		get_viewport().set_input_as_handled()
		_send()


# ------------------------------------------------------------------ list

func _load_list() -> void:
	var res: Dictionary = await Net.request("conv_list")
	if res["ok"]:
		convs = res["conversations"]
		_render_list()


func _render_list() -> void:
	for c in conv_list.get_children():
		conv_list.remove_child(c)
		c.queue_free()
	for cv: Dictionary in convs:
		var row := HBoxContainer.new()
		var b := Button.new()
		b.text = str(cv["title"])
		b.tooltip_text = str(cv["title"])
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.clip_text = true
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.theme_type_variation = &"ConvButtonActive" if cv["id"] == current_id else &"ConvButton"
		b.pressed.connect(_open_conv.bind(str(cv["id"])))
		var m := MenuButton.new()
		m.text = "..."
		m.flat = true
		var pm := m.get_popup()
		pm.add_item("Rename", 0)
		pm.add_item("Delete", 1)
		pm.id_pressed.connect(_conv_menu.bind(cv))
		row.add_child(b)
		row.add_child(m)
		conv_list.add_child(row)
	if convs.is_empty():
		var l := Label.new()
		l.text = "No chats yet.\nAsk Buzz something!"
		l.theme_type_variation = &"MutedLabel"
		conv_list.add_child(l)


func _conv_menu(id: int, cv: Dictionary) -> void:
	if id == 0:
		Dialogs.ask("Rename chat", str(cv["title"]), _do_rename.bind(cv))
	else:
		Dialogs.confirm("Delete \"%s\"? This can't be undone." % cv["title"], _do_delete.bind(cv))


func _do_rename(text: String, cv: Dictionary) -> void:
	if text == "":
		return
	var res: Dictionary = await Net.request("conv_rename", {"id": cv["id"], "title": text})
	if res["ok"]:
		cv["title"] = text
		if cv["id"] == current_id:
			title_label.text = text
		_render_list()
	else:
		Toasts.say(str(res["error"]), "error")


func _do_delete(cv: Dictionary) -> void:
	var res: Dictionary = await Net.request("conv_delete", {"id": cv["id"]})
	if res["ok"]:
		convs.erase(cv)
		if cv["id"] == current_id:
			_new_chat()
		else:
			_render_list()
	else:
		Toasts.say(str(res["error"]), "error")


# ------------------------------------------------------------------ conversation

func _clear_msgs() -> void:
	for c in msgs.get_children():
		msgs.remove_child(c)
		c.queue_free()
	typing_bubble = null


func _new_chat() -> void:
	current_id = ""
	title_label.text = "New chat"
	_clear_msgs()
	var box := VBoxContainer.new()
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 12)
	var bee := preload("res://scripts/ui/bee_icon.gd").new()
	bee.bobbing = true
	bee.custom_minimum_size = Vector2(120, 120)
	bee.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(bee)
	var h := Label.new()
	h.text = "Bzzz! I'm %s." % str(Net.settings.get("bot_name", "Buzz"))
	h.theme_type_variation = &"HeroLabel"
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(h)
	var p := Label.new()
	p.text = "The Hive assistant. Ask me about guns, 1v1 tips, maps and the community."
	p.theme_type_variation = &"MutedLabel"
	p.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(p)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	for s in SUGGESTIONS:
		var b := Button.new()
		b.text = s
		b.theme_type_variation = &"ChipButton"
		b.custom_minimum_size.x = 250
		b.pressed.connect(_use_suggestion.bind(s))
		grid.add_child(b)
	box.add_child(grid)
	msgs.add_child(box)
	_render_list()


func _use_suggestion(text: String) -> void:
	input.text = text
	_send()


func _open_conv(id: String) -> void:
	var res: Dictionary = await Net.request("conv_get", {"id": id})
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")
		return
	var cv: Dictionary = res["conversation"]
	current_id = id
	title_label.text = str(cv["title"])
	if cv["model"] != "":
		for i in model_pick.item_count:
			if model_pick.get_item_text(i) == cv["model"]:
				model_pick.select(i)
	_clear_msgs()
	for m: Dictionary in cv["messages"]:
		_add_bubble(str(m["role"]), str(m["content"]))
	_render_list()
	_scroll_bottom()


func _add_bubble(role: String, text: String) -> Node:
	var b = BubbleScene.instantiate()
	msgs.add_child(b)
	b.setup(role, text, maxf(260.0, scroll.size.x * 0.7))
	b.grew.connect(_scroll_now)
	_scroll_bottom()
	return b


func _scroll_now() -> void:
	scroll.scroll_vertical = int(scroll.get_v_scroll_bar().max_value)


func _scroll_bottom() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	_scroll_now()


func _send() -> void:
	var text := input.text.strip_edges()
	if text == "" or waiting_id != "":
		return
	if current_id == "":
		var r: Dictionary = await Net.request("conv_new")
		if not r["ok"]:
			Toasts.say(str(r["error"]), "error")
			return
		current_id = str(r["conversation"]["id"])
		convs.push_front(r["conversation"])
		_clear_msgs()
	input.text = ""
	_add_bubble("user", text)
	typing_bubble = _add_bubble("assistant", "")
	typing_bubble.show_thinking()
	waiting_id = current_id
	send_btn.disabled = true
	var model := model_pick.get_item_text(model_pick.selected) if model_pick.item_count > 0 else ""
	var res: Dictionary = await Net.request("ai_send", {"conv_id": current_id, "message": text, "model": model})
	if not res["ok"]:
		if is_instance_valid(typing_bubble):
			typing_bubble.queue_free()
		_finish_wait()
		Toasts.say(str(res["error"]), "error")
		input.text = text
		return
	title_label.text = str(res["title"])
	for cv: Dictionary in convs:
		if cv["id"] == current_id:
			cv["title"] = res["title"]
	_render_list()
	get_tree().create_timer(120.0).timeout.connect(_wait_timeout.bind(current_id))


func _finish_wait() -> void:
	waiting_id = ""
	send_btn.disabled = false
	input.grab_focus()


func _wait_timeout(conv_id: String) -> void:
	if waiting_id == conv_id:
		if is_instance_valid(typing_bubble):
			typing_bubble.show_error("The AI took too long to answer. Please try again.")
		_finish_wait()


func _on_push(ev: String, d: Dictionary) -> void:
	if ev == "ai_done":
		var was := waiting_id == str(d["conv_id"])
		if was:
			_finish_wait()
		if str(d["conv_id"]) == current_id and is_instance_valid(typing_bubble):
			typing_bubble.reveal(str(d["message"]["content"]))
			title_label.text = str(d["title"])
		_load_list()
	elif ev == "ai_error":
		if waiting_id == str(d["conv_id"]):
			_finish_wait()
		if str(d["conv_id"]) == current_id and is_instance_valid(typing_bubble):
			typing_bubble.show_error(str(d["error"]))
