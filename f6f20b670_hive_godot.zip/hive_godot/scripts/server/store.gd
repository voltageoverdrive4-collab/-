extends RefCounted
## The server's database: one JSON file under user://hive_data/

const Defaults = preload("res://scripts/server/defaults.gd")
const DIR := "user://hive_data"
const FILE := "user://hive_data/db.json"

var data: Dictionary = {}
var dirty := false


func load_db() -> void:
	DirAccess.make_dir_recursive_absolute(DIR)
	if FileAccess.file_exists(FILE):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(FILE))
		if parsed is Dictionary:
			data = parsed
	for k in ["users", "tokens", "convs", "chan_msgs"]:
		if not data.has(k) or not (data[k] is Dictionary):
			data[k] = {}
	if not data.has("ai_log") or not (data["ai_log"] is Array):
		data["ai_log"] = []
	if not data.has("channels") or not (data["channels"] is Array) or data["channels"].is_empty():
		data["channels"] = Defaults.channels()
	var merged := Defaults.settings()
	if data.has("settings") and data["settings"] is Dictionary:
		for k in data["settings"]:
			merged[k] = data["settings"][k]
	data["settings"] = merged
	for ch in data["channels"]:
		if not data["chan_msgs"].has(ch["id"]):
			data["chan_msgs"][ch["id"]] = []


func mark() -> void:
	dirty = true


func save_now() -> void:
	dirty = false
	DirAccess.make_dir_recursive_absolute(DIR)
	var tmp := FILE + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_error("Hive server: could not write the database.")
		return
	f.store_string(JSON.stringify(data))
	f.close()
	if FileAccess.file_exists(FILE):
		DirAccess.remove_absolute(FILE)
	DirAccess.rename_absolute(tmp, FILE)
