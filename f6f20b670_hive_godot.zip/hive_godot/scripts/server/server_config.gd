extends RefCounted
## ======================================================================
##  SERVER SETTINGS. Put your OpenRouter key on the line below.
## ======================================================================

const OPENROUTER_API_KEY := "<open-router-key>"

const OPENROUTER_URL := "https://openrouter.ai/api/v1"
const PORT := 8910
const OWNER_USERNAME := "queen"
## Leave the placeholder to get a random owner password printed on first start.
const OWNER_PASSWORD := "<choose-a-strong-password>"
const SITE_URL := "https://hive.local"
const SITE_NAME := "Hive Buzz AI"


static func _env(name: String, fallback: String) -> String:
	var v := OS.get_environment(name)
	return v if v != "" else fallback


static func api_key() -> String:
	var k := _env("OPENROUTER_API_KEY", OPENROUTER_API_KEY).strip_edges()
	return "" if k.begins_with("<") else k


static func port() -> int:
	var p := _env("HIVE_PORT", str(PORT))
	return p.to_int() if p.is_valid_int() else PORT


static func owner_username() -> String:
	return _env("HIVE_OWNER_USER", OWNER_USERNAME)


static func owner_password() -> String:
	var p := _env("HIVE_OWNER_PASSWORD", OWNER_PASSWORD)
	return "" if p.begins_with("<") else p
