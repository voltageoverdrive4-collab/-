extends Node
## The Hive server: accounts, AI (OpenRouter), community chat, WebRTC signalling and admin tools.
## Run it headless:   godot --headless --path . -- --server
## ...or tick "Host a server on this computer" on the login screen.

signal owner_created(username: String, password: String)

const Cfg = preload("res://scripts/server/server_config.gd")
const Sec = preload("res://scripts/server/security.gd")
const Store = preload("res://scripts/server/store.gd")
const Defaults = preload("res://scripts/server/defaults.gd")

const OWNER_OPS := ["admin_admins", "admin_admin_add", "admin_admin_remove"]

class Conn extends RefCounted:
	var ws: WebSocketPeer
	var host := ""
	var user_id := ""
	var rtc := false
	var sec_stamp := 0
	var sec_count := 0

var tcp := TCPServer.new()
var conns: Array = []
var db: Store
var running := false
var _limits := {}
var _clock := 0.0


# =========================================================================
# Lifecycle
# =========================================================================

func start() -> bool:
	if running:
		return true
	db = Store.new()
	db.load_db()
	_ensure_owner()
	var err := tcp.listen(Cfg.port())
	if err != OK:
		_log("Could not listen on port %d (error %d). Is another Hive server already running?" % [Cfg.port(), err])
		return false
	running = true
	_log("🐝 Hive server is buzzing on port %d" % Cfg.port())
	if Cfg.api_key() == "":
		_log("⚠ No OpenRouter key yet. Open scripts/server/server_config.gd and replace <open-router-key>. Everything else works without it.")
	return true


func stop() -> void:
	if db != null and db.dirty:
		db.save_now()
	tcp.stop()
	for c: Conn in conns:
		c.ws.close()
	conns.clear()
	running = false


func _exit_tree() -> void:
	if running and db != null and db.dirty:
		db.save_now()


func _log(text: String) -> void:
	print("[hive] ", text)


func _now() -> int:
	return int(Time.get_unix_time_from_system())


func _process(delta: float) -> void:
	if not running:
		return
	while tcp.is_connection_available():
		var stream := tcp.take_connection()
		var c := Conn.new()
		c.ws = WebSocketPeer.new()
		c.ws.inbound_buffer_size = 262144
		c.ws.outbound_buffer_size = 262144
		c.ws.max_queued_packets = 512
		c.ws.accept_stream(stream)
		c.host = stream.get_connected_host()
		conns.append(c)
	for c: Conn in conns.duplicate():
		c.ws.poll()
		var st := c.ws.get_ready_state()
		if st == WebSocketPeer.STATE_OPEN:
			while c.ws.get_available_packet_count() > 0:
				var pkt := c.ws.get_packet()
				_handle(c, pkt.get_string_from_utf8())
		elif st == WebSocketPeer.STATE_CLOSED:
			_drop(c)
	_clock += delta
	if _clock > 2.0:
		_clock = 0.0
		if db.dirty:
			db.save_now()
		if _limits.size() > 5000:
			_limits.clear()


func _drop(c: Conn) -> void:
	if not conns.has(c):
		return
	conns.erase(c)
	if c.user_id != "":
		_broadcast_presence()


func _ensure_owner() -> void:
	for u in db.data["users"].values():
		if u["role"] == "owner":
			return
	var uname := Cfg.owner_username()
	if not Sec.valid_username(uname):
		uname = "queen"
	var pw := Cfg.owner_password()
	var generated := false
	if pw.length() < 8:
		pw = Sec.random_token(9)
		generated = true
	_new_user(uname, pw, "owner")
	_log("👑 Owner (Queen) account created: " + uname)
	if generated:
		_log("   Owner password (shown once, write it down!): " + pw)
	owner_created.emit(uname, pw if generated else "")


# =========================================================================
# Helpers
# =========================================================================

func _err(msg: String) -> Dictionary:
	return {"ok": false, "error": msg}


func _ok(extra: Dictionary = {}) -> Dictionary:
	var r := extra.duplicate()
	r["ok"] = true
	return r


func _hit(key: String, max_n: int, window_s: float) -> bool:
	var now := Time.get_ticks_msec() / 1000.0
	var e = _limits.get(key)
	if e == null or e[1] <= now:
		e = [0, now + window_s]
		_limits[key] = e
	e[0] += 1
	return e[0] <= max_n


func _num(v: Variant, lo: float, hi: float, fallback: float) -> float:
	if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
		return clampf(float(v), lo, hi)
	if typeof(v) == TYPE_STRING and str(v).is_valid_float():
		return clampf(str(v).to_float(), lo, hi)
	return fallback


func _new_user(username: String, password: String, role: String) -> Dictionary:
	var salt := Sec.random_token(16)
	var u := {
		"id": Sec.random_token(8), "username": username, "role": role, "salt": salt,
		"hash": Sec.hash_password(password, salt), "created": _now(), "banned": false,
		"ban_reason": "", "muted_until": 0, "last_seen": 0,
	}
	db.data["users"][u["id"]] = u
	db.mark()
	return u


func _find_user(name: String) -> Variant:
	var n := name.to_lower()
	for u in db.data["users"].values():
		if str(u["username"]).to_lower() == n:
			return u
	return null


func _is_staff(u: Dictionary) -> bool:
	return u["role"] == "admin" or u["role"] == "owner"


func _can_manage(actor: Dictionary, target: Dictionary) -> bool:
	if actor["id"] == target["id"] or target["role"] == "owner":
		return false
	return actor["role"] == "owner" or target["role"] == "member"


func _public_user(u: Dictionary) -> Dictionary:
	return {"id": u["id"], "username": u["username"], "role": u["role"]}


func _public_settings() -> Dictionary:
	var s: Dictionary = db.data["settings"]
	return {
		"bot_name": s["bot_name"], "ai_enabled": s["ai_enabled"], "default_model": s["default_model"],
		"allowed_models": s["allowed_models"], "registration_open": s["registration_open"],
		"slow_mode_sec": s["slow_mode_sec"], "max_len": s["max_len"],
	}


func _send(c: Conn, msg: Dictionary) -> void:
	if c.ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
		c.ws.send_text(JSON.stringify(msg))


func _push_user(user_id: String, msg: Dictionary) -> void:
	for c: Conn in conns:
		if c.user_id == user_id:
			_send(c, msg)


func _broadcast(msg: Dictionary) -> void:
	for c: Conn in conns:
		if c.user_id != "":
			_send(c, msg)


func _online_list() -> Array:
	var seen := {}
	for c: Conn in conns:
		if c.user_id == "" or not db.data["users"].has(c.user_id):
			continue
		var u: Dictionary = db.data["users"][c.user_id]
		if not seen.has(u["id"]):
			seen[u["id"]] = {"id": u["id"], "username": u["username"], "role": u["role"], "rtc": false}
		if c.rtc:
			seen[u["id"]]["rtc"] = true
	return seen.values()


func _broadcast_presence() -> void:
	_broadcast({"ev": "presence", "users": _online_list()})


func _kick_user(user_id: String, reason: String) -> void:
	for c: Conn in conns.duplicate():
		if c.user_id == user_id:
			_send(c, {"ev": "kicked", "reason": reason})
			c.user_id = ""
			c.ws.close(1000, reason)
	_broadcast_presence()


func _kill_tokens(user_id: String) -> void:
	for k in db.data["tokens"].keys():
		if db.data["tokens"][k]["user_id"] == user_id:
			db.data["tokens"].erase(k)
	db.mark()


func _remove_user(id: String) -> void:
	for k in db.data["convs"].keys():
		if db.data["convs"][k]["user_id"] == id:
			db.data["convs"].erase(k)
	_kill_tokens(id)
	db.data["users"].erase(id)
	_kick_user(id, "This account was deleted.")
	db.mark()


# =========================================================================
# Request handling
# =========================================================================

func _handle(c: Conn, text: String) -> void:
	if text.length() > 200000:
		return
	var now_s := Time.get_ticks_msec() / 1000
	if now_s != c.sec_stamp:
		c.sec_stamp = now_s
		c.sec_count = 0
	c.sec_count += 1
	if c.sec_count > 80:
		return
	var parsed = JSON.parse_string(text)
	if not (parsed is Dictionary):
		return
	var d: Dictionary = parsed
	var res: Dictionary = await _dispatch(c, str(d.get("op", "")), d)
	res["id"] = d.get("id", 0)
	_send(c, res)


func _dispatch(c: Conn, op: String, d: Dictionary) -> Dictionary:
	if op == "register":
		return _op_register(c, d)
	if op == "login":
		return _op_login(c, d)
	if op == "resume":
		return _op_resume(c, d)
	if c.user_id == "" or not db.data["users"].has(c.user_id):
		return _err("Please log in.")
	var u: Dictionary = db.data["users"][c.user_id]
	if u["banned"]:
		return _err("This account has been banned.")
	u["last_seen"] = _now()
	if op.begins_with("admin_"):
		if not _is_staff(u):
			return _err("Admins only.")
		if OWNER_OPS.has(op) and u["role"] != "owner":
			return _err("Only the Queen (owner) can do that.")
	match op:
		"logout": return _op_logout(c, d)
		"conv_list": return _op_conv_list(c, d)
		"conv_new": return _op_conv_new(c, d)
		"conv_get": return _op_conv_get(c, d)
		"conv_rename": return _op_conv_rename(c, d)
		"conv_delete": return _op_conv_delete(c, d)
		"ai_send": return _op_ai_send(c, d, u)
		"change_password": return _op_change_password(c, d, u)
		"export_data": return _op_export(c, d, u)
		"delete_history": return _op_delete_history(c, d)
		"delete_account": return _op_delete_account(c, d, u)
		"channels": return _ok({"channels": db.data["channels"]})
		"chat_history": return _op_chat_history(c, d)
		"chat_send": return _op_chat_send(c, d, u)
		"rtc_join": return _op_rtc_join(c, d)
		"rtc_signal": return _op_rtc_signal(c, d)
		"admin_overview": return _op_admin_overview(c, d)
		"admin_users": return _op_admin_users(c, d)
		"admin_user_ban": return _op_admin_user_ban(c, d, u)
		"admin_user_mute": return _op_admin_user_mute(c, d, u)
		"admin_user_password": return _op_admin_user_password(c, d, u)
		"admin_user_delete": return _op_admin_user_delete(c, d, u)
		"admin_admins": return _op_admin_admins(c, d)
		"admin_admin_add": return _op_admin_admin_add(c, d)
		"admin_admin_remove": return _op_admin_admin_remove(c, d)
		"admin_get_settings": return _ok({"settings": db.data["settings"]})
		"admin_set_settings": return _op_admin_set_settings(c, d)
		"admin_ailog": return _op_admin_ailog(c, d)
		"admin_chan_add": return _op_admin_chan_add(c, d)
		"admin_chan_delete": return _op_admin_chan_delete(c, d)
		"admin_chan_clear": return _op_admin_chan_clear(c, d)
		"admin_msg_delete": return _op_admin_msg_delete(c, d)
	return _err("Unknown request.")


# =========================================================================
# Accounts
# =========================================================================

func _login_ok(c: Conn, u: Dictionary) -> Dictionary:
	c.user_id = u["id"]
	u["last_seen"] = _now()
	var tok := Sec.random_token(24)
	db.data["tokens"][Sec.hash_token(tok)] = {"user_id": u["id"], "expires": _now() + 30 * 86400}
	db.mark()
	_broadcast_presence()
	return _ok({"token": tok, "user": _public_user(u), "settings": _public_settings()})


func _op_register(c: Conn, d: Dictionary) -> Dictionary:
	var s: Dictionary = db.data["settings"]
	if not s["registration_open"]:
		return _err("Registration is closed right now.")
	if not _hit("reg:" + c.host, 8, 3600.0):
		return _err("Too many sign-ups from here. Try again later.")
	var username := str(d.get("username", "")).strip_edges()
	var password := str(d.get("password", ""))
	if not Sec.valid_username(username):
		return _err("Username must be 3-20 letters, numbers or underscores.")
	if password.length() < 8 or password.length() > 128:
		return _err("Password must be at least 8 characters.")
	if Sec.RESERVED.has(username.to_lower()) or _find_user(username) != null:
		return _err("That username is taken.")
	return _login_ok(c, _new_user(username, password, "member"))


func _op_login(c: Conn, d: Dictionary) -> Dictionary:
	var username := str(d.get("username", "")).strip_edges()
	if not _hit("login:" + c.host, 30, 900.0) or not _hit("login:" + c.host + ":" + username.to_lower(), 8, 900.0):
		return _err("Too many tries. Wait a few minutes and try again.")
	var u = _find_user(username)
	var ok := false
	if u != null:
		ok = Sec.verify(str(d.get("password", "")), u["salt"], u["hash"])
	else:
		Sec.pbkdf2("x", PackedByteArray([1]))
	if u == null or not ok:
		return _err("Wrong username or password.")
	if u["banned"]:
		return _err("This account has been banned." + ((" Reason: " + u["ban_reason"]) if u["ban_reason"] != "" else ""))
	return _login_ok(c, u)


func _op_resume(c: Conn, d: Dictionary) -> Dictionary:
	var key := Sec.hash_token(str(d.get("token", "")))
	var t = db.data["tokens"].get(key)
	if t == null or int(t["expires"]) < _now() or not db.data["users"].has(t["user_id"]):
		return _err("Your session expired. Please log in again.")
	var u: Dictionary = db.data["users"][t["user_id"]]
	if u["banned"]:
		return _err("This account has been banned.")
	c.user_id = u["id"]
	_broadcast_presence()
	return _ok({"token": str(d.get("token", "")), "user": _public_user(u), "settings": _public_settings()})


func _op_logout(c: Conn, d: Dictionary) -> Dictionary:
	db.data["tokens"].erase(Sec.hash_token(str(d.get("token", ""))))
	db.mark()
	c.user_id = ""
	c.rtc = false
	_broadcast_presence()
	return _ok()


func _op_change_password(c: Conn, d: Dictionary, u: Dictionary) -> Dictionary:
	if not _hit("pw:" + u["id"], 6, 900.0):
		return _err("Too many tries. Wait a few minutes.")
	if not Sec.verify(str(d.get("current", "")), u["salt"], u["hash"]):
		return _err("Your current password is wrong.")
	var nw := str(d.get("next", ""))
	if nw.length() < 8 or nw.length() > 128:
		return _err("New password must be at least 8 characters.")
	u["salt"] = Sec.random_token(16)
	u["hash"] = Sec.hash_password(nw, u["salt"])
	db.mark()
	return _ok()


func _op_export(c: Conn, d: Dictionary, u: Dictionary) -> Dictionary:
	var mine := []
	for cv in db.data["convs"].values():
		if cv["user_id"] == u["id"]:
			mine.append(cv)
	return _ok({"json": JSON.stringify({"user": _public_user(u), "conversations": mine}, "\t")})


func _op_delete_history(c: Conn, d: Dictionary) -> Dictionary:
	for k in db.data["convs"].keys():
		if db.data["convs"][k]["user_id"] == c.user_id:
			db.data["convs"].erase(k)
	db.mark()
	return _ok()


func _op_delete_account(c: Conn, d: Dictionary, u: Dictionary) -> Dictionary:
	if u["role"] == "owner":
		return _err("The Queen account cannot be deleted.")
	if not Sec.verify(str(d.get("password", "")), u["salt"], u["hash"]):
		return _err("Wrong password.")
	_remove_user(u["id"])
	return _ok()


# =========================================================================
# AI conversations
# =========================================================================

func _my_conv(c: Conn, id: String) -> Variant:
	var cv = db.data["convs"].get(id)
	if cv == null or cv["user_id"] != c.user_id:
		return null
	return cv


func _op_conv_list(c: Conn, d: Dictionary) -> Dictionary:
	var out := []
	for cv in db.data["convs"].values():
		if cv["user_id"] == c.user_id:
			out.append({"id": cv["id"], "title": cv["title"], "updated": cv["updated"], "count": cv["messages"].size()})
	out.sort_custom(func(a, b): return a["updated"] > b["updated"])
	return _ok({"conversations": out})


func _op_conv_new(c: Conn, d: Dictionary) -> Dictionary:
	var n := 0
	for cv in db.data["convs"].values():
		if cv["user_id"] == c.user_id:
			n += 1
	if n >= 100:
		return _err("You have 100 chats already. Delete some old ones first.")
	var now := _now()
	var cv := {"id": Sec.random_token(8), "user_id": c.user_id, "title": "New chat", "model": "", "created": now, "updated": now, "messages": []}
	db.data["convs"][cv["id"]] = cv
	db.mark()
	return _ok({"conversation": {"id": cv["id"], "title": cv["title"], "updated": now, "count": 0}})


func _op_conv_get(c: Conn, d: Dictionary) -> Dictionary:
	var cv = _my_conv(c, str(d.get("id", "")))
	if cv == null:
		return _err("Chat not found.")
	return _ok({"conversation": cv})


func _op_conv_rename(c: Conn, d: Dictionary) -> Dictionary:
	var cv = _my_conv(c, str(d.get("id", "")))
	if cv == null:
		return _err("Chat not found.")
	var t := Sec.clean(str(d.get("title", "")), 60)
	if t == "":
		return _err("Give the chat a name.")
	cv["title"] = t
	db.mark()
	return _ok()


func _op_conv_delete(c: Conn, d: Dictionary) -> Dictionary:
	var cv = _my_conv(c, str(d.get("id", "")))
	if cv == null:
		return _err("Chat not found.")
	db.data["convs"].erase(cv["id"])
	db.mark()
	return _ok()


func _op_ai_send(c: Conn, d: Dictionary, u: Dictionary) -> Dictionary:
	var s: Dictionary = db.data["settings"]
	if not s["ai_enabled"]:
		return _err("The AI is switched off right now.")
	var cv = _my_conv(c, str(d.get("conv_id", "")))
	if cv == null:
		return _err("Chat not found.")
	var text := Sec.clean(str(d.get("message", "")), 4000)
	if text == "":
		return _err("Type a message first.")
	if not _hit("ai:" + u["id"], int(s["ai_rate_max"]), float(s["ai_rate_window_min"]) * 60.0):
		return _err("Easy there, bee! You're asking a lot. Try again in a few minutes.")
	var model := str(d.get("model", ""))
	if not s["allowed_models"].has(model):
		model = cv["model"] if s["allowed_models"].has(cv["model"]) else str(s["default_model"])
	cv["model"] = model
	var umsg := {"id": Sec.random_token(6), "role": "user", "content": text, "t": _now()}
	cv["messages"].append(umsg)
	if cv["messages"].size() == 1:
		cv["title"] = text.replace("\n", " ").substr(0, 40)
	cv["updated"] = _now()
	db.mark()
	_run_ai(u["id"], cv["id"], model)
	return _ok({"user_message": umsg, "title": cv["title"], "model": model})


func _run_ai(user_id: String, conv_id: String, model: String) -> void:
	var s: Dictionary = db.data["settings"]
	var cv = db.data["convs"].get(conv_id)
	if cv == null:
		return
	var msgs := [{"role": "system", "content": Defaults.system_prompt(s)}]
	for m in cv["messages"].slice(-20):
		msgs.append({"role": m["role"], "content": m["content"]})
	var r: Dictionary = await _openrouter({"model": model, "messages": msgs, "temperature": s["temperature"], "max_tokens": int(s["max_tokens"])})
	if not db.data["convs"].has(conv_id):
		return
	if r["ok"]:
		var reply := {"id": Sec.random_token(6), "role": "assistant", "content": r["text"], "t": _now(), "model": model}
		cv["messages"].append(reply)
		if cv["messages"].size() > 400:
			cv["messages"] = cv["messages"].slice(-400)
		cv["updated"] = _now()
		_log_ai("app", user_id, model, str(r["text"]).length())
		db.mark()
		_push_user(user_id, {"ev": "ai_done", "conv_id": conv_id, "message": reply, "title": cv["title"]})
	else:
		_push_user(user_id, {"ev": "ai_error", "conv_id": conv_id, "error": r["error"]})


func _log_ai(source: String, user_id: String, model: String, chars: int) -> void:
	var entries: Array = db.data["ai_log"]
	entries.append({"t": _now(), "source": source, "user_id": user_id, "model": model, "chars": chars})
	if entries.size() > 300:
		entries.pop_front()


func _openrouter(payload: Dictionary) -> Dictionary:
	var key := Cfg.api_key()
	if key == "":
		return {"ok": false, "error": "The AI is not configured yet (the server has no OpenRouter key)."}
	var http := HTTPRequest.new()
	http.timeout = 90.0
	add_child(http)
	var headers := PackedStringArray([
		"Content-Type: application/json", "Authorization: Bearer " + key,
		"HTTP-Referer: " + Cfg.SITE_URL, "X-Title: " + Cfg.SITE_NAME,
	])
	var err := http.request(Cfg.OPENROUTER_URL + "/chat/completions", headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if err != OK:
		http.queue_free()
		return {"ok": false, "error": "The hive could not reach the AI service."}
	var res: Array = await http.request_completed
	http.queue_free()
	var code: int = res[1]
	var body: PackedByteArray = res[3]
	if res[0] != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "error": "The AI service could not be reached. Try again soon."}
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if code != 200:
		push_warning("OpenRouter HTTP %d" % code)
		if code == 401 or code == 403:
			return {"ok": false, "error": "The AI key is not set up correctly. Tell a Hive admin."}
		if code == 402:
			return {"ok": false, "error": "The AI is out of credits right now. Tell a Hive admin."}
		if code == 429:
			return {"ok": false, "error": "The AI is busy right now. Try again in a few seconds."}
		return {"ok": false, "error": "The AI could not answer right now. Try again soon."}
	if parsed is Dictionary and parsed.has("choices") and parsed["choices"] is Array and not parsed["choices"].is_empty():
		var msg = parsed["choices"][0].get("message", {})
		var content = msg.get("content", "") if msg is Dictionary else ""
		if typeof(content) == TYPE_STRING and str(content).strip_edges() != "":
			return {"ok": true, "text": content}
	return {"ok": false, "error": "The model returned an empty answer. Try again or pick another model."}


# =========================================================================
# Community chat + WebRTC signalling
# =========================================================================

func _op_chat_history(c: Conn, d: Dictionary) -> Dictionary:
	var list = db.data["chan_msgs"].get(str(d.get("channel", "")))
	if list == null:
		return _err("No such channel.")
	var before := float(d.get("before", 1.0e18))
	var out := []
	for m in list:
		if float(m["t"]) < before:
			out.append(m)
	return _ok({"messages": out.slice(-50)})


func _op_chat_send(c: Conn, d: Dictionary, u: Dictionary) -> Dictionary:
	var s: Dictionary = db.data["settings"]
	if int(u["muted_until"]) > _now():
		return _err("You are muted for %d more minute(s)." % ceili((int(u["muted_until"]) - _now()) / 60.0))
	var channel := str(d.get("channel", ""))
	var list = db.data["chan_msgs"].get(channel)
	if list == null:
		return _err("No such channel.")
	var text := Sec.clean(str(d.get("text", "")), int(s["max_len"]))
	if text == "":
		return _err("Type a message first.")
	if not _hit("cmb:" + u["id"], 20, 60.0):
		return _err("Slow down, bee!")
	if int(s["slow_mode_sec"]) > 0 and not _hit("cms:" + u["id"], 1, float(s["slow_mode_sec"])):
		return _err("Slow mode: wait a moment before sending again.")
	var msg := {
		"id": Sec.random_token(6), "cid": Sec.clean(str(d.get("cid", "")), 24), "channel": channel,
		"user_id": u["id"], "username": u["username"], "role": u["role"], "text": text, "t": _now(),
	}
	list.append(msg)
	if list.size() > 500:
		list.pop_front()
	db.mark()
	_broadcast({"ev": "chat_message", "msg": msg})
	return _ok({"message": msg})


func _op_rtc_join(c: Conn, d: Dictionary) -> Dictionary:
	c.rtc = bool(d.get("enabled", false))
	_broadcast_presence()
	return _ok()


func _op_rtc_signal(c: Conn, d: Dictionary) -> Dictionary:
	var kind := str(d.get("kind", ""))
	if not ["offer", "answer", "ice"].has(kind) or not (d.get("data") is Dictionary):
		return _err("Bad signal.")
	if not _hit("rtc:" + c.user_id, 300, 10.0):
		return _err("Too many signals.")
	_push_user(str(d.get("to", "")), {"ev": "rtc_signal", "from": c.user_id, "kind": kind, "data": d["data"]})
	return _ok()


# =========================================================================
# Admin
# =========================================================================

func _op_admin_overview(c: Conn, d: Dictionary) -> Dictionary:
	var users: Dictionary = db.data["users"]
	var day := _now() - 86400
	var admins := 0
	var banned := 0
	var new_today := 0
	for u in users.values():
		if _is_staff(u):
			admins += 1
		if u["banned"]:
			banned += 1
		if int(u["created"]) > day:
			new_today += 1
	var ai24 := 0
	for l in db.data["ai_log"]:
		if int(l["t"]) > day:
			ai24 += 1
	var msgs := 0
	for l in db.data["chan_msgs"].values():
		msgs += l.size()
	var rtc_users := 0
	for p in _online_list():
		if p["rtc"]:
			rtc_users += 1
	return _ok({
		"users": users.size(), "admins": admins, "banned": banned, "new_today": new_today,
		"conversations": db.data["convs"].size(), "ai_requests_24h": ai24, "chat_messages": msgs,
		"online": _online_list().size(), "rtc_users": rtc_users, "ai_configured": Cfg.api_key() != "",
	})


func _op_admin_users(c: Conn, d: Dictionary) -> Dictionary:
	var q := str(d.get("q", "")).to_lower()
	var counts := {}
	for cv in db.data["convs"].values():
		counts[cv["user_id"]] = int(counts.get(cv["user_id"], 0)) + 1
	var out := []
	for u in db.data["users"].values():
		if q != "" and not str(u["username"]).to_lower().contains(q):
			continue
		out.append({
			"id": u["id"], "username": u["username"], "role": u["role"], "created": u["created"], "last_seen": u["last_seen"],
			"banned": u["banned"], "ban_reason": u["ban_reason"], "muted_until": u["muted_until"], "chats": counts.get(u["id"], 0),
		})
	out.sort_custom(func(a, b): return int(a["created"]) > int(b["created"]))
	return _ok({"users": out.slice(0, 200)})


func _target(actor: Dictionary, d: Dictionary) -> Variant:
	var t = db.data["users"].get(str(d.get("id", "")))
	if t == null or not _can_manage(actor, t):
		return null
	return t


func _op_admin_user_ban(c: Conn, d: Dictionary, actor: Dictionary) -> Dictionary:
	var t = _target(actor, d)
	if t == null:
		return _err("You cannot manage this user.")
	t["banned"] = bool(d.get("banned", false))
	t["ban_reason"] = Sec.clean(str(d.get("reason", "")), 120) if t["banned"] else ""
	if t["banned"]:
		_kill_tokens(t["id"])
		_kick_user(t["id"], "You have been banned.")
	db.mark()
	return _ok()


func _op_admin_user_mute(c: Conn, d: Dictionary, actor: Dictionary) -> Dictionary:
	var t = _target(actor, d)
	if t == null:
		return _err("You cannot manage this user.")
	var minutes := _num(d.get("minutes", 0), 0, 10080, 0)
	t["muted_until"] = (_now() + int(minutes) * 60) if minutes > 0 else 0
	db.mark()
	return _ok()


func _op_admin_user_password(c: Conn, d: Dictionary, actor: Dictionary) -> Dictionary:
	var t = _target(actor, d)
	if t == null:
		return _err("You cannot manage this user.")
	var pw := str(d.get("password", ""))
	if pw.length() < 8 or pw.length() > 128:
		return _err("Password must be at least 8 characters.")
	t["salt"] = Sec.random_token(16)
	t["hash"] = Sec.hash_password(pw, t["salt"])
	_kill_tokens(t["id"])
	db.mark()
	return _ok()


func _op_admin_user_delete(c: Conn, d: Dictionary, actor: Dictionary) -> Dictionary:
	var t = _target(actor, d)
	if t == null:
		return _err("You cannot manage this user.")
	_remove_user(t["id"])
	return _ok()


func _op_admin_admins(c: Conn, d: Dictionary) -> Dictionary:
	var out := []
	for u in db.data["users"].values():
		if _is_staff(u):
			out.append(_public_user(u))
	return _ok({"admins": out})


func _op_admin_admin_add(c: Conn, d: Dictionary) -> Dictionary:
	var u = _find_user(str(d.get("username", "")).strip_edges())
	if u == null:
		return _err("No account with that username. They need to sign up first.")
	if u["role"] == "owner":
		return _err("That is the Queen already.")
	u["role"] = "admin"
	db.mark()
	_broadcast_presence()
	return _ok()


func _op_admin_admin_remove(c: Conn, d: Dictionary) -> Dictionary:
	var u = db.data["users"].get(str(d.get("id", "")))
	if u == null or u["role"] != "admin":
		return _err("Not an admin.")
	u["role"] = "member"
	db.mark()
	_broadcast_presence()
	return _ok()


func _op_admin_set_settings(c: Conn, d: Dictionary) -> Dictionary:
	var s: Dictionary = db.data["settings"]
	var p: Dictionary = d.get("settings", {}) if d.get("settings") is Dictionary else {}
	if p.has("bot_name"):
		var n := Sec.clean(str(p["bot_name"]), 30)
		if n != "":
			s["bot_name"] = n
	if p.has("ai_enabled"):
		s["ai_enabled"] = bool(p["ai_enabled"])
	if p.has("registration_open"):
		s["registration_open"] = bool(p["registration_open"])
	if p.has("allowed_models") and p["allowed_models"] is Array:
		var list := []
		for m in p["allowed_models"]:
			var ms := Sec.clean(str(m), 80)
			if ms != "" and not list.has(ms) and RegEx.create_from_string("^[\\w.\\-:/]+$").search(ms) != null:
				list.append(ms)
		if not list.is_empty():
			s["allowed_models"] = list.slice(0, 30)
	if p.has("default_model"):
		var dm := Sec.clean(str(p["default_model"]), 80)
		if dm != "":
			s["default_model"] = dm
	if not s["allowed_models"].has(s["default_model"]):
		s["allowed_models"].insert(0, s["default_model"])
	if p.has("temperature"):
		s["temperature"] = _num(p["temperature"], 0.0, 2.0, s["temperature"])
	if p.has("max_tokens"):
		s["max_tokens"] = int(_num(p["max_tokens"], 100, 4000, s["max_tokens"]))
	if p.has("system_prompt"):
		var sp := Sec.clean(str(p["system_prompt"]), 6000)
		if sp != "":
			s["system_prompt"] = sp
	if p.has("group_info"):
		s["group_info"] = str(p["group_info"]).substr(0, 8000)
	if p.has("ai_rate_max"):
		s["ai_rate_max"] = int(_num(p["ai_rate_max"], 1, 200, s["ai_rate_max"]))
	if p.has("ai_rate_window_min"):
		s["ai_rate_window_min"] = int(_num(p["ai_rate_window_min"], 1, 120, s["ai_rate_window_min"]))
	if p.has("slow_mode_sec"):
		s["slow_mode_sec"] = int(_num(p["slow_mode_sec"], 0, 60, s["slow_mode_sec"]))
	if p.has("max_len"):
		s["max_len"] = int(_num(p["max_len"], 50, 2000, s["max_len"]))
	db.mark()
	_broadcast({"ev": "settings", "settings": _public_settings()})
	return _ok({"settings": s})


func _op_admin_ailog(c: Conn, d: Dictionary) -> Dictionary:
	var out := []
	for l in db.data["ai_log"].slice(-100):
		var who := ""
		if db.data["users"].has(l["user_id"]):
			who = db.data["users"][l["user_id"]]["username"]
		out.append({"t": l["t"], "source": l["source"], "user": who, "model": l["model"], "chars": l["chars"]})
	out.reverse()
	return _ok({"log": out})


func _op_admin_chan_add(c: Conn, d: Dictionary) -> Dictionary:
	var chan_name := Sec.clean(str(d.get("name", "")), 24).to_lower()
	var re := RegEx.create_from_string("[^a-z0-9]+")
	chan_name = re.sub(chan_name, "-", true).trim_prefix("-").trim_suffix("-")
	if chan_name == "":
		return _err("Give the channel a name.")
	if db.data["channels"].size() >= 20:
		return _err("Max 20 channels.")
	for ch in db.data["channels"]:
		if ch["id"] == chan_name:
			return _err("That channel exists.")
	db.data["channels"].append({"id": chan_name, "name": chan_name, "description": Sec.clean(str(d.get("description", "")), 60)})
	db.data["chan_msgs"][chan_name] = []
	db.mark()
	_broadcast({"ev": "channels", "channels": db.data["channels"]})
	return _ok({"channels": db.data["channels"]})


func _op_admin_chan_delete(c: Conn, d: Dictionary) -> Dictionary:
	var id := str(d.get("id", ""))
	if id == "general":
		return _err("The general channel stays.")
	var chans: Array = db.data["channels"]
	for i in chans.size():
		if chans[i]["id"] == id:
			chans.remove_at(i)
			db.data["chan_msgs"].erase(id)
			db.mark()
			_broadcast({"ev": "channels", "channels": chans})
			return _ok({"channels": chans})
	return _err("No such channel.")


func _op_admin_chan_clear(c: Conn, d: Dictionary) -> Dictionary:
	var id := str(d.get("id", ""))
	if not db.data["chan_msgs"].has(id):
		return _err("No such channel.")
	db.data["chan_msgs"][id] = []
	db.mark()
	_broadcast({"ev": "chat_clear", "channel": id})
	return _ok()


func _op_admin_msg_delete(c: Conn, d: Dictionary) -> Dictionary:
	var channel := str(d.get("channel", ""))
	var list = db.data["chan_msgs"].get(channel)
	if list == null:
		return _err("No such channel.")
	for i in list.size():
		if list[i]["id"] == str(d.get("id", "")):
			list.remove_at(i)
			db.mark()
			_broadcast({"ev": "chat_delete", "channel": channel, "id": str(d.get("id", ""))})
			return _ok()
	return _err("Message not found.")
