extends RefCounted
## Password hashing (PBKDF2-HMAC-SHA256), tokens and input cleaning.

const RESERVED := ["admin", "administrator", "staff", "moderator", "mod", "hive", "teamhive", "buzz", "system", "owner", "queen", "support"]
const ITERATIONS := 4000


static func random_token(bytes: int = 18) -> String:
	return Crypto.new().generate_random_bytes(bytes).hex_encode()


static func valid_username(u: String) -> bool:
	var re := RegEx.create_from_string("^[A-Za-z0-9_]{3,20}$")
	return re.search(u) != null


static func clean(s: String, max_len: int) -> String:
	var out := ""
	for ch in s:
		var code := ch.unicode_at(0)
		if code < 32 and code != 10 and code != 9:
			continue
		out += ch
	return out.strip_edges().substr(0, max_len)


static func pbkdf2(password: String, salt: PackedByteArray) -> PackedByteArray:
	var crypto := Crypto.new()
	var key := password.to_utf8_buffer()
	var block := salt.duplicate()
	block.append_array(PackedByteArray([0, 0, 0, 1]))
	var u := crypto.hmac_digest(HashingContext.HASH_SHA256, key, block)
	var t := u.duplicate()
	for i in range(1, ITERATIONS):
		u = crypto.hmac_digest(HashingContext.HASH_SHA256, key, u)
		for j in 32:
			t[j] = t[j] ^ u[j]
	return t


static func hash_password(password: String, salt_hex: String) -> String:
	return pbkdf2(password, salt_hex.hex_decode()).hex_encode()


static func verify(password: String, salt_hex: String, hash_hex: String) -> bool:
	var a := hash_password(password, salt_hex)
	if a.length() != hash_hex.length():
		return false
	var diff := 0
	for i in a.length():
		diff |= a.unicode_at(i) ^ hash_hex.unicode_at(i)
	return diff == 0


static func hash_token(token: String) -> String:
	return token.sha256_text()
