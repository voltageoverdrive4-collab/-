extends Control
## Boots either the app (default) or a headless server (godot --headless --path . -- --server).

const HiveServer = preload("res://scripts/server/hive_server.gd")

@onready var ui_root: Control = %UI
@onready var auth: Control = %AuthScreen
@onready var app: Control = %AppScreen

var server: Node = null


func _ready() -> void:
	if OS.get_cmdline_user_args().has("--server") or DisplayServer.get_name() == "headless":
		ui_root.hide()
		server = HiveServer.new()
		add_child(server)
		if not server.start():
			get_tree().quit(1)
		return
	auth.start_server = _host_here
	auth.authenticated.connect(_enter_app)
	app.logged_out.connect(_leave_app)
	Net.closed.connect(_on_net_closed)
	_leave_app()


func _host_here() -> bool:
	if server == null:
		server = HiveServer.new()
		add_child(server)
		server.owner_created.connect(_on_owner_created)
	return server.start()


func _on_owner_created(username: String, password: String) -> void:
	var pw_line := ("Password: " + password + "\n\nWrite this password down: it is only shown once. You can change it in the Account tab.") if password != "" else "Password: the OWNER password from scripts/server/server_config.gd"
	Dialogs.info("Queen (owner) account created", "Username: %s\n%s" % [username, pw_line])


func _enter_app() -> void:
	auth.hide()
	app.show()
	app.enter()


func _leave_app() -> void:
	app.hide()
	auth.show()


func _on_net_closed(reason: String) -> void:
	if app.visible:
		Toasts.say(reason, "error")
		_leave_app()
