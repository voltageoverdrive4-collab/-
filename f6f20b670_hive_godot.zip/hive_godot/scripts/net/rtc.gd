extends Node
## WebRTC mesh (autoload "Rtc") for the community chat.
## Players connect to each other directly with WebRTC data channels (the server only relays the
## handshake). Chat messages and typing indicators then travel peer-to-peer.
## If the WebRTC plugin is not installed, chat transparently falls back to the server relay.

signal message_received(from_id: String, data: Dictionary)
signal status_changed

const ICE := {"iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]}

class Peer extends RefCounted:
	var pc: WebRTCPeerConnection
	var ch: WebRTCDataChannel
	var open := false
	var remote_set := false
	var pending_ice: Array = []
	var age := 0.0

var available := false
var checked := false
var me := ""
var peers := {}   # user_id -> Peer
var _last_users: Array = []
var _resync := 0.0


func _ready() -> void:
	Net.pushed.connect(_on_pushed)
	Net.closed.connect(_on_net_closed)


func _on_net_closed(_reason: String) -> void:
	stop()


func check_available() -> bool:
	if checked:
		return available
	checked = true
	var pc := WebRTCPeerConnection.new()
	available = pc.initialize(ICE) == OK
	pc.close()
	return available


func start() -> void:
	me = str(Net.user.get("id", ""))
	check_available()
	await Net.request("rtc_join", {"enabled": available})
	status_changed.emit()


func stop() -> void:
	for id in peers.keys():
		_close_peer(id)
	peers.clear()
	_last_users = []
	me = ""
	status_changed.emit()


func open_count() -> int:
	var n := 0
	for id in peers:
		var p: Peer = peers[id]
		if p.open:
			n += 1
	return n


func is_open(user_id: String) -> bool:
	return peers.has(user_id) and (peers[user_id] as Peer).open


## Sends a message to every connected peer. Returns how many peers it reached.
func send_all(data: Dictionary) -> int:
	var bytes := JSON.stringify(data).to_utf8_buffer()
	var n := 0
	for id in peers:
		var p: Peer = peers[id]
		if p.open:
			p.ch.put_packet(bytes)
			n += 1
	return n


# ------------------------------------------------------------------ signalling

func _on_pushed(ev: String, d: Dictionary) -> void:
	if ev == "presence":
		_last_users = d.get("users", [])
		_sync()
	elif ev == "rtc_signal":
		_on_signal(str(d.get("from", "")), str(d.get("kind", "")), d.get("data", {}))


func _sync() -> void:
	if not available or me == "":
		return
	var online := {}
	for u in _last_users:
		var id := str(u["id"])
		if id == me or not bool(u.get("rtc", false)):
			continue
		online[id] = true
		if not peers.has(id) and me < id:   # the player with the smaller id makes the offer
			_create_peer(id, true)
	for id in peers.keys():
		if not online.has(id):
			_close_peer(id)
	status_changed.emit()


func _create_peer(id: String, offerer: bool) -> Peer:
	var p := Peer.new()
	p.pc = WebRTCPeerConnection.new()
	if p.pc.initialize(ICE) != OK:
		return null
	p.ch = p.pc.create_data_channel("chat", {"negotiated": true, "id": 1})
	if p.ch == null:
		return null
	p.pc.session_description_created.connect(_on_sdp.bind(id))
	p.pc.ice_candidate_created.connect(_on_ice.bind(id))
	peers[id] = p
	if offerer:
		p.pc.create_offer()
	return p


func _on_sdp(type: String, sdp: String, id: String) -> void:
	if not peers.has(id):
		return
	var p: Peer = peers[id]
	p.pc.set_local_description(type, sdp)
	Net.request("rtc_signal", {"to": id, "kind": type, "data": {"type": type, "sdp": sdp}})


func _on_ice(media: String, index: int, ice_name: String, id: String) -> void:
	Net.request("rtc_signal", {"to": id, "kind": "ice", "data": {"media": media, "index": index, "name": ice_name}})


func _on_signal(from: String, kind: String, data: Dictionary) -> void:
	if not available or from == "" or from == me:
		return
	var p: Peer = peers.get(from)
	if kind == "offer":
		if p != null:
			_close_peer(from)
		p = _create_peer(from, false)
		if p == null:
			return
		p.pc.set_remote_description("offer", str(data.get("sdp", "")))
		p.remote_set = true
		_flush_ice(p)
	elif kind == "answer":
		if p == null:
			return
		p.pc.set_remote_description("answer", str(data.get("sdp", "")))
		p.remote_set = true
		_flush_ice(p)
	elif kind == "ice" and p != null:
		if p.remote_set:
			p.pc.add_ice_candidate(str(data.get("media", "")), int(data.get("index", 0)), str(data.get("name", "")))
		else:
			p.pending_ice.append(data)


func _flush_ice(p: Peer) -> void:
	for data in p.pending_ice:
		p.pc.add_ice_candidate(str(data.get("media", "")), int(data.get("index", 0)), str(data.get("name", "")))
	p.pending_ice.clear()


func _close_peer(id: String) -> void:
	if not peers.has(id):
		return
	var p: Peer = peers[id]
	p.pc.close()
	peers.erase(id)


func _process(delta: float) -> void:
	if not available:
		return
	_resync += delta
	if _resync > 8.0:
		_resync = 0.0
		_sync()
	if peers.is_empty():
		return
	var changed := false
	for id in peers.keys():
		var p: Peer = peers[id]
		p.pc.poll()
		var was := p.open
		p.open = p.ch.get_ready_state() == WebRTCDataChannel.STATE_OPEN
		if p.open != was:
			changed = true
		while p.open and p.ch.get_available_packet_count() > 0:
			var parsed = JSON.parse_string(p.ch.get_packet().get_string_from_utf8())
			if parsed is Dictionary:
				message_received.emit(id, parsed)
		p.age += delta
		var st := p.pc.get_connection_state()
		if st == WebRTCPeerConnection.STATE_FAILED or st == WebRTCPeerConnection.STATE_CLOSED \
				or (st == WebRTCPeerConnection.STATE_DISCONNECTED and p.age > 5.0) or (not p.open and p.age > 25.0):
			_close_peer(id)
			changed = true
	if changed:
		status_changed.emit()
