extends Node
## Client networking (autoload "Net"): one WebSocket to the Hive server.
## Requests:  var res = await Net.request("login", {...})     Pushed events:  Net.pushed(ev, data)

signal opened
signal closed(reason: String)
signal pushed(ev: String, data: Dictionary)

class Waiter extends RefCounted:
	signal done(result: Dictionary)

var ws: WebSocketPeer = null
var state := "idle"   # idle | connecting | open
var url := ""
var user: Dictionary = {}
var settings: Dictionary = {}
var token := ""
var _next := 1
var _pending := {}


func connect_to(address: String) -> void:
	disconnect_now()
	var a := address.strip_edges()
	url = a if (a.begins_with("ws://") or a.begins_with("wss://")) else "ws://" + a
	ws = WebSocketPeer.new()
	ws.inbound_buffer_size = 1048576
	ws.outbound_buffer_size = 262144
	ws.max_queued_packets = 1024
	var err := ws.connect_to_url(url)
	if err != OK:
		ws = null
		state = "idle"
		closed.emit("That server address doesn't look right.")
		return
	state = "connecting"


func disconnect_now() -> void:
	if ws != null:
		ws.close()
	ws = null
	state = "idle"
	user = {}
	_fail_all("Disconnected.")


func _process(_delta: float) -> void:
	if ws == null or state == "idle":
		return
	ws.poll()
	var st := ws.get_ready_state()
	if st == WebSocketPeer.STATE_OPEN:
		if state == "connecting":
			state = "open"
			opened.emit()
		while ws.get_available_packet_count() > 0:
			_on_packet(ws.get_packet().get_string_from_utf8())
	elif st == WebSocketPeer.STATE_CLOSED:
		var was := state
		state = "idle"
		ws = null
		_fail_all("Disconnected from the hive server.")
		closed.emit("Could not reach the hive server." if was == "connecting" else "Disconnected from the hive server.")


func _on_packet(text: String) -> void:
	var parsed = JSON.parse_string(text)
	if not (parsed is Dictionary):
		return
	var d: Dictionary = parsed
	if d.has("id") and _pending.has(int(d["id"])):
		var w: Waiter = _pending[int(d["id"])]
		_pending.erase(int(d["id"]))
		w.done.emit(d)
	elif d.has("ev"):
		pushed.emit(str(d["ev"]), d)


func request(op: String, data: Dictionary = {}) -> Dictionary:
	if state != "open" or ws == null:
		return {"ok": false, "error": "Not connected to the hive server."}
	var id := _next
	_next += 1
	var w := Waiter.new()
	_pending[id] = w
	var msg := data.duplicate()
	msg["id"] = id
	msg["op"] = op
	ws.send_text(JSON.stringify(msg))
	get_tree().create_timer(30.0).timeout.connect(_timeout.bind(id))
	var res: Dictionary = await w.done
	return res


func _timeout(id: int) -> void:
	if _pending.has(id):
		var w: Waiter = _pending[id]
		_pending.erase(id)
		w.done.emit({"ok": false, "error": "The server took too long to answer."})


func _fail_all(msg: String) -> void:
	for id in _pending.keys():
		var w: Waiter = _pending[id]
		_pending.erase(id)
		w.done.emit({"ok": false, "error": msg})
