extends HBoxContainer
## The Hive community chat. Messages go to the server (history + moderation) AND straight to the
## other players over WebRTC data channels when available, so they pop up instantly.

signal unread_changed(has_unread: bool)

const Ui = preload("res://scripts/ui/ui.gd")
const RowScene = preload("res://scenes/chat_row.tscn")

@onready var chan_list: VBoxContainer = %ChanList
@onready var chan_title: Label = %ChanTitle
@onready var chan_desc: Label = %ChanDesc
@onready var rtc_badge: Label = %RtcBadge
@onready var scroll: ScrollContainer = %Scroll
@onready var msgs: VBoxContainer = %Msgs
@onready var typing_label: Label = %TypingLabel
@onready var input: TextEdit = %Input
@onready var send_btn: Button = %SendBtn
@onready var user_list: VBoxContainer = %UserList

var channels: Array = []
var current := ""
var online: Array = []
var rows := {}           # cid -> row
var rows_by_id := {}     # server id -> row
var unread := {}
var typing := {}         # username -> expires (seconds)
var _last_typing := 0.0
var _tick := 0.0


func _ready() -> void:
	send_btn.pressed.connect(_send)
	input.gui_input.connect(_on_key)
	input.text_changed.connect(_on_typed)
	Net.pushed.connect(_on_push)
	Rtc.message_received.connect(_on_rtc)
	Rtc.status_changed.connect(_update_rtc)


func enter() -> void:
	channels = []
	current = ""
	unread.clear()
	online = []
	var res: Dictionary = await Net.request("channels")
	if res["ok"]:
		channels = res["channels"]
		_render_channels()
		if not channels.is_empty():
			_select(str(channels[0]["id"]))
	_update_rtc()


func on_shown() -> void:
	unread.erase(current)
	_emit_unread()
	_render_channels()
	input.grab_focus()
	_scroll_bottom()


func _process(delta: float) -> void:
	_tick += delta
	if _tick < 0.5:
		return
	_tick = 0.0
	var now := Time.get_ticks_msec() / 1000.0
	var names := []
	for n in typing.keys():
		if typing[n] < now:
			typing.erase(n)
		else:
			names.append(n)
	if names.is_empty():
		typing_label.text = ""
	elif names.size() == 1:
		typing_label.text = "%s is typing…" % names[0]
	else:
		typing_label.text = "%s and others are typing…" % names[0]


# ------------------------------------------------------------------ channels

func _render_channels() -> void:
	for c in chan_list.get_children():
		chan_list.remove_child(c)
		c.queue_free()
	for ch: Dictionary in channels:
		var b := Button.new()
		b.text = "# " + str(ch["name"]) + ("   ●" if unread.has(ch["id"]) else "")
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.theme_type_variation = &"ChanButtonActive" if ch["id"] == current else &"ChanButton"
		b.pressed.connect(_select.bind(str(ch["id"])))
		chan_list.add_child(b)


func _select(id: String) -> void:
	current = id
	unread.erase(id)
	_emit_unread()
	var ch := {"name": id, "description": ""}
	for c: Dictionary in channels:
		if c["id"] == id:
			ch = c
	chan_title.text = "# " + str(ch["name"])
	chan_desc.text = str(ch.get("description", ""))
	_render_channels()
	for c in msgs.get_children():
		msgs.remove_child(c)
		c.queue_free()
	rows.clear()
	rows_by_id.clear()
	var res: Dictionary = await Net.request("chat_history", {"channel": id})
	if res["ok"] and current == id:
		for m: Dictionary in res["messages"]:
			_add_row(m)
		_scroll_bottom()


func _emit_unread() -> void:
	unread_changed.emit(not unread.is_empty())


# ------------------------------------------------------------------ messages

func _is_staff() -> bool:
	return Net.user.get("role", "") == "owner" or Net.user.get("role", "") == "admin"


func _add_row(m: Dictionary) -> Node:
	var cid := str(m.get("cid", ""))
	if m.has("id") and rows_by_id.has(m["id"]):
		return rows_by_id[m["id"]]
	if cid != "" and rows.has(cid):
		var existing = rows[cid]
		if m.has("id"):
			existing.confirm(m)
			rows_by_id[m["id"]] = existing
		return existing
	var row = RowScene.instantiate()
	msgs.add_child(row)
	var me_name := str(Net.user.get("username", "")).to_lower()
	var mention: bool = str(m["user_id"]) != str(Net.user.get("id", "")) and str(m["text"]).to_lower().contains("@" + me_name)
	row.setup(m, _is_staff(), mention)
	row.delete_requested.connect(_on_delete_row)
	if cid != "":
		rows[cid] = row
	if m.has("id"):
		rows_by_id[m["id"]] = row
	return row


func _on_delete_row(row: Node) -> void:
	var res: Dictionary = await Net.request("admin_msg_delete", {"channel": row.msg["channel"], "id": row.msg["id"]})
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")


func _scroll_bottom() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	scroll.scroll_vertical = int(scroll.get_v_scroll_bar().max_value)


func _near_bottom() -> bool:
	var bar := scroll.get_v_scroll_bar()
	return bar.max_value - bar.page - scroll.scroll_vertical < 140.0


func _on_key(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.shift_pressed and (e.keycode == KEY_ENTER or e.keycode == KEY_KP_ENTER):
		get_viewport().set_input_as_handled()
		_send()


func _on_typed() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - _last_typing > 2.0 and input.text.strip_edges() != "":
		_last_typing = now
		Rtc.send_all({"type": "typing", "channel": current, "username": Net.user.get("username", "")})


func _send() -> void:
	var text := input.text.strip_edges()
	if text == "" or current == "":
		return
	var max_len := int(Net.settings.get("max_len", 500))
	if text.length() > max_len:
		Toasts.say("That message is too long (max %d characters)." % max_len, "error")
		return
	input.text = ""
	var cid := Ui.rand_id()
	var local := {
		"cid": cid, "channel": current, "user_id": Net.user["id"], "username": Net.user["username"],
		"role": Net.user["role"], "text": text, "t": int(Time.get_unix_time_from_system()), "p2p": true,
	}
	_add_row(local)
	_scroll_bottom()
	Rtc.send_all({"type": "msg", "msg": local})   # instant, peer-to-peer
	var res: Dictionary = await Net.request("chat_send", {"channel": current, "text": text, "cid": cid})
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")
		Rtc.send_all({"type": "retract", "cid": cid})
		if rows.has(cid):
			rows[cid].queue_free()
			rows.erase(cid)


# ------------------------------------------------------------------ incoming

func _on_push(ev: String, d: Dictionary) -> void:
	if ev == "chat_message":
		var m: Dictionary = d["msg"]
		var stick := _near_bottom()
		if m["channel"] == current:
			_add_row(m)
			if stick:
				_scroll_bottom()
		if m["channel"] != current or not is_visible_in_tree():
			if str(m["user_id"]) != str(Net.user.get("id", "")):
				unread[m["channel"]] = true
				_emit_unread()
				_render_channels()
	elif ev == "chat_delete":
		if rows_by_id.has(d["id"]):
			rows_by_id[d["id"]].queue_free()
			rows_by_id.erase(d["id"])
	elif ev == "chat_clear":
		if d["channel"] == current:
			_select(current)
	elif ev == "channels":
		channels = d["channels"]
		var found := false
		for c: Dictionary in channels:
			if c["id"] == current:
				found = true
		if not found and not channels.is_empty():
			_select(str(channels[0]["id"]))
		else:
			_render_channels()
	elif ev == "presence":
		online = d["users"]
		_render_online()
		_update_rtc()


func _on_rtc(from_id: String, data: Dictionary) -> void:
	var known := false
	for u: Dictionary in online:
		if u["id"] == from_id:
			known = true
	if not known:
		return   # ignore anyone the server doesn't list as online (banned, kicked...)
	var kind := str(data.get("type", ""))
	if kind == "msg" and data.get("msg") is Dictionary:
		var m: Dictionary = data["msg"]
		if str(m.get("user_id", "")) != from_id or not m.has("cid") or not m.has("text") or not m.has("channel"):
			return   # the sender must be who they claim to be
		m["text"] = str(m["text"]).substr(0, int(Net.settings.get("max_len", 500)))
		m["username"] = _name_of(from_id, str(m.get("username", "")))
		m["role"] = _role_of(from_id)
		m["t"] = int(Time.get_unix_time_from_system())
		m["p2p"] = true
		m.erase("id")
		if m["channel"] == current:
			var stick := _near_bottom()
			_add_row(m)
			if stick:
				_scroll_bottom()
		elif m["channel"] != current:
			unread[m["channel"]] = true
			_emit_unread()
			_render_channels()
	elif kind == "typing" and str(data.get("channel", "")) == current:
		typing[_name_of(from_id, str(data.get("username", "someone")))] = Time.get_ticks_msec() / 1000.0 + 3.5
	elif kind == "retract":
		var cid := str(data.get("cid", ""))
		if rows.has(cid) and not rows[cid].msg.has("id") and str(rows[cid].msg["user_id"]) == from_id:
			rows[cid].queue_free()
			rows.erase(cid)


func _name_of(user_id: String, fallback: String) -> String:
	for u: Dictionary in online:
		if u["id"] == user_id:
			return str(u["username"])
	return fallback


func _role_of(user_id: String) -> String:
	for u: Dictionary in online:
		if u["id"] == user_id:
			return str(u["role"])
	return "member"


func _render_online() -> void:
	for c in user_list.get_children():
		user_list.remove_child(c)
		c.queue_free()
	for u: Dictionary in online:
		var l := Label.new()
		var extra := ""
		if Rtc.is_open(str(u["id"])):
			extra = "  [P2P]"
		l.text = str(u["username"]) + (("  " + Ui.role_tag(str(u["role"]))) if Ui.role_tag(str(u["role"])) != "" else "") + extra
		l.clip_text = true
		user_list.add_child(l)


func _update_rtc() -> void:
	if not Rtc.available:
		rtc_badge.text = "RTC: unavailable (server relay)"
		rtc_badge.tooltip_text = "Install the WebRTC plugin (see README) to chat peer-to-peer. Chat still works through the server."
		rtc_badge.theme_type_variation = &"WarnLabel"
	else:
		var n := Rtc.open_count()
		rtc_badge.text = ("RTC: %d peer%s connected" % [n, "" if n == 1 else "s"]) if n > 0 else "RTC: ready (waiting for peers)"
		rtc_badge.tooltip_text = "Messages reach connected players directly over WebRTC and are also saved by the server."
		rtc_badge.theme_type_variation = &"OkLabel"
	_render_online()
