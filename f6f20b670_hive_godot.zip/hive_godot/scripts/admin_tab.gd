extends HBoxContainer
## Admin panel: overview, members, AI settings, community channels, admins (owner), AI log.

const Ui = preload("res://scripts/ui/ui.gd")

const PAGES := ["overview", "users", "ai", "community", "admins", "log"]

var page := "overview"


func _ready() -> void:
	%NavOverview.pressed.connect(_go.bind("overview"))
	%NavUsers.pressed.connect(_go.bind("users"))
	%NavAI.pressed.connect(_go.bind("ai"))
	%NavCommunity.pressed.connect(_go.bind("community"))
	%NavAdmins.pressed.connect(_go.bind("admins"))
	%NavLog.pressed.connect(_go.bind("log"))
	%UsersSearch.text_changed.connect(_on_search)
	%AiSaveBtn.pressed.connect(_save_ai)
	%AddChanBtn.pressed.connect(_add_chan)
	%AddAdminBtn.pressed.connect(_add_admin)


func enter() -> void:
	%NavAdmins.visible = Net.user.get("role", "") == "owner"
	_go("overview")


func on_shown() -> void:
	_go(page)


func _go(p: String) -> void:
	page = p
	var navs := {"overview": %NavOverview, "users": %NavUsers, "ai": %NavAI, "community": %NavCommunity, "admins": %NavAdmins, "log": %NavLog}
	var pages := {"overview": %PageOverview, "users": %PageUsers, "ai": %PageAI, "community": %PageCommunity, "admins": %PageAdmins, "log": %PageLog}
	for k in PAGES:
		pages[k].visible = k == p
		navs[k].set_pressed_no_signal(k == p)
	match p:
		"overview": _load_overview()
		"users": _load_users()
		"ai": _load_ai()
		"community": _load_community()
		"admins": _load_admins()
		"log": _load_log()


func _act(op: String, data: Dictionary, ok_msg: String) -> void:
	var res: Dictionary = await Net.request(op, data)
	if res["ok"]:
		Toasts.say(ok_msg, "ok")
		_go(page)
	else:
		Toasts.say(str(res["error"]), "error")


func _btn(text: String, cb: Callable, variation: StringName = &"SmallButton") -> Button:
	var b := Button.new()
	b.text = text
	b.theme_type_variation = variation
	b.pressed.connect(cb)
	return b


func _label(text: String, min_w: float = 0.0, variation: StringName = &"") -> Label:
	var l := Label.new()
	l.text = text
	l.clip_text = true
	l.custom_minimum_size.x = min_w
	if variation != &"":
		l.theme_type_variation = variation
	return l


# ------------------------------------------------------------------ overview

func _tile(grid: Node, value: Variant, caption: String) -> void:
	var p := PanelContainer.new()
	p.theme_type_variation = &"Tile"
	var v := VBoxContainer.new()
	var big := Label.new()
	big.text = str(value)
	big.theme_type_variation = &"BigNumber"
	v.add_child(big)
	v.add_child(_label(caption, 0.0, &"MutedLabel"))
	p.add_child(v)
	grid.add_child(p)


func _load_overview() -> void:
	var res: Dictionary = await Net.request("admin_overview")
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")
		return
	Ui.clear_children(%OverviewGrid)
	var g = %OverviewGrid
	_tile(g, res["users"], "Members")
	_tile(g, res["admins"], "Staff (owner + admins)")
	_tile(g, res["banned"], "Banned")
	_tile(g, res["new_today"], "Joined in 24h")
	_tile(g, res["conversations"], "AI chats saved")
	_tile(g, res["ai_requests_24h"], "AI requests in 24h")
	_tile(g, res["chat_messages"], "Community messages")
	_tile(g, res["online"], "Online now")
	_tile(g, res["rtc_users"], "Online with WebRTC")
	%StatusLabel.text = "OpenRouter key: %s\nWebRTC on this computer: %s" % [
		"configured" if res["ai_configured"] else "MISSING (set it in scripts/server/server_config.gd on the server)",
		"available" if Rtc.available else "not installed (chat uses the server relay)",
	]


# ------------------------------------------------------------------ users

func _on_search(_t: String) -> void:
	_load_users()


func _can_manage(u: Dictionary) -> bool:
	var me := Net.user
	if u["role"] == "owner" or u["id"] == me["id"]:
		return false
	return me["role"] == "owner" or u["role"] == "member"


func _load_users() -> void:
	var res: Dictionary = await Net.request("admin_users", {"q": %UsersSearch.text})
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")
		return
	var list: VBoxContainer = %UsersList
	Ui.clear_children(list)
	for u: Dictionary in res["users"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		row.add_child(_label(str(u["username"]), 150, &"HeadingLabel"))
		row.add_child(_label(Ui.role_tag(str(u["role"])), 60, &"GoldLabel"))
		var status := "Active"
		if u["banned"]:
			status = "BANNED"
		elif int(u["muted_until"]) > int(Time.get_unix_time_from_system()):
			status = "Muted"
		row.add_child(_label(status, 70, &"ErrorLabel" if status == "BANNED" else &""))
		row.add_child(_label("joined " + Ui.ago(u["created"]), 110, &"MutedLabel"))
		row.add_child(_label("seen " + Ui.ago(u["last_seen"]), 110, &"MutedLabel"))
		row.add_child(_label("%d chats" % int(u["chats"]), 70, &"MutedLabel"))
		if _can_manage(u):
			row.add_child(_btn("Unban" if u["banned"] else "Ban", _ban.bind(u)))
			row.add_child(_btn("Mute", _mute.bind(u)))
			row.add_child(_btn("Reset pw", _reset_pw.bind(u)))
			row.add_child(_btn("Delete", _delete_user.bind(u), &"DangerSmall"))
		list.add_child(row)


func _ban(u: Dictionary) -> void:
	if u["banned"]:
		_act("admin_user_ban", {"id": u["id"], "banned": false}, "%s unbanned" % u["username"])
	else:
		Dialogs.ask("Ban %s" % u["username"], "", _do_ban.bind(u), "Optional reason (they will see it):")


func _do_ban(reason: String, u: Dictionary) -> void:
	_act("admin_user_ban", {"id": u["id"], "banned": true, "reason": reason}, "%s banned" % u["username"])


func _mute(u: Dictionary) -> void:
	Dialogs.ask("Mute %s" % u["username"], "60", _do_mute.bind(u), "How many minutes? (0 = unmute)")


func _do_mute(minutes: String, u: Dictionary) -> void:
	_act("admin_user_mute", {"id": u["id"], "minutes": minutes}, "Mute updated")


func _reset_pw(u: Dictionary) -> void:
	Dialogs.ask("New password for %s" % u["username"], "", _do_reset.bind(u), "A temporary password (min 8 characters). Tell them to change it.", true)


func _do_reset(pw: String, u: Dictionary) -> void:
	_act("admin_user_password", {"id": u["id"], "password": pw}, "Password reset")


func _delete_user(u: Dictionary) -> void:
	Dialogs.confirm("Delete %s and all of their chats? This cannot be undone." % u["username"], _act.bind("admin_user_delete", {"id": u["id"]}, "Deleted"))


# ------------------------------------------------------------------ AI + settings

func _load_ai() -> void:
	var res: Dictionary = await Net.request("admin_get_settings")
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")
		return
	var s: Dictionary = res["settings"]
	%AiEnabled.button_pressed = bool(s["ai_enabled"])
	%AiReg.button_pressed = bool(s["registration_open"])
	%AiBotName.text = str(s["bot_name"])
	%AiDefaultModel.text = str(s["default_model"])
	%AiModels.text = "\n".join(PackedStringArray(s["allowed_models"]))
	%AiTemp.value = float(s["temperature"])
	%AiMaxTok.value = float(s["max_tokens"])
	%AiRateMax.value = float(s["ai_rate_max"])
	%AiRateWin.value = float(s["ai_rate_window_min"])
	%AiSlow.value = float(s["slow_mode_sec"])
	%AiMaxLen.value = float(s["max_len"])
	%AiPrompt.text = str(s["system_prompt"])
	%AiInfo.text = str(s["group_info"])


func _save_ai() -> void:
	var models := []
	for part in %AiModels.text.split("\n"):
		var m: String = part.strip_edges()
		if m != "":
			models.append(m)
	var res: Dictionary = await Net.request("admin_set_settings", {"settings": {
		"ai_enabled": %AiEnabled.button_pressed, "registration_open": %AiReg.button_pressed,
		"bot_name": %AiBotName.text, "default_model": %AiDefaultModel.text.strip_edges(), "allowed_models": models,
		"temperature": %AiTemp.value, "max_tokens": %AiMaxTok.value, "ai_rate_max": %AiRateMax.value,
		"ai_rate_window_min": %AiRateWin.value, "slow_mode_sec": %AiSlow.value, "max_len": %AiMaxLen.value,
		"system_prompt": %AiPrompt.text, "group_info": %AiInfo.text,
	}})
	if res["ok"]:
		Toasts.say("Settings saved. Changes are live!", "ok")
	else:
		Toasts.say(str(res["error"]), "error")


# ------------------------------------------------------------------ community

func _load_community() -> void:
	var res: Dictionary = await Net.request("channels")
	if not res["ok"]:
		return
	var list: VBoxContainer = %ChanAdminList
	Ui.clear_children(list)
	for c: Dictionary in res["channels"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_child(_label("# " + str(c["name"]), 0.0, &"HeadingLabel"))
		col.add_child(_label(str(c["description"]), 0.0, &"MutedLabel"))
		row.add_child(col)
		row.add_child(_btn("Clear messages", _clear_chan.bind(c)))
		if c["id"] != "general":
			row.add_child(_btn("Delete", _delete_chan.bind(c), &"DangerSmall"))
		list.add_child(row)


func _clear_chan(c: Dictionary) -> void:
	Dialogs.confirm("Delete ALL messages in #%s?" % c["name"], _act.bind("admin_chan_clear", {"id": c["id"]}, "Channel cleared"))


func _delete_chan(c: Dictionary) -> void:
	Dialogs.confirm("Delete #%s?" % c["name"], _act.bind("admin_chan_delete", {"id": c["id"]}, "Channel deleted"))


func _add_chan() -> void:
	_act("admin_chan_add", {"name": %NewChanName.text, "description": %NewChanDesc.text}, "Channel created")
	%NewChanName.text = ""
	%NewChanDesc.text = ""


# ------------------------------------------------------------------ admins (owner only)

func _load_admins() -> void:
	var res: Dictionary = await Net.request("admin_admins")
	if not res["ok"]:
		return
	var list: VBoxContainer = %AdminsList
	Ui.clear_children(list)
	for u: Dictionary in res["admins"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		row.add_child(_label(str(u["username"]), 180, &"HeadingLabel"))
		row.add_child(_label(Ui.role_tag(str(u["role"])), 80, &"GoldLabel"))
		if u["role"] == "admin":
			row.add_child(_btn("Remove admin", _remove_admin.bind(u), &"DangerSmall"))
		else:
			row.add_child(_label("The one and only Queen", 0.0, &"MutedLabel"))
		list.add_child(row)


func _remove_admin(u: Dictionary) -> void:
	Dialogs.confirm("Remove %s as admin?" % u["username"], _act.bind("admin_admin_remove", {"id": u["id"]}, "Admin removed"))


func _add_admin() -> void:
	_act("admin_admin_add", {"username": %AddAdminName.text}, "Admin added")
	%AddAdminName.text = ""


# ------------------------------------------------------------------ log

func _load_log() -> void:
	var res: Dictionary = await Net.request("admin_ailog")
	if not res["ok"]:
		return
	var list: VBoxContainer = %LogList
	Ui.clear_children(list)
	if res["log"].is_empty():
		list.add_child(_label("Nothing yet.", 0.0, &"MutedLabel"))
	for l: Dictionary in res["log"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row.add_child(_label(Ui.ago(l["t"]), 90, &"MutedLabel"))
		row.add_child(_label(str(l["user"]), 140))
		row.add_child(_label(str(l["model"]), 260))
		row.add_child(_label("%d chars" % int(l["chars"]), 90, &"MutedLabel"))
		list.add_child(row)
