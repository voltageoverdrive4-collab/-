extends ScrollContainer
## Your account: password, data export/delete.

const Ui = preload("res://scripts/ui/ui.gd")


func _ready() -> void:
	%ChangePassBtn.pressed.connect(_change_pass)
	%ExportBtn.pressed.connect(_export)
	%ClearHistBtn.pressed.connect(_clear_history)
	%DeleteAccBtn.pressed.connect(_delete_account)


func enter() -> void:
	%AccName.text = str(Net.user["username"])
	var tag := Ui.role_tag(str(Net.user["role"]))
	%AccRole.text = tag if tag != "" else "MEMBER"
	%DeleteAccBtn.visible = Net.user["role"] != "owner"
	%CurPass.text = ""
	%NewPass.text = ""
	%NewPass2.text = ""


func _change_pass() -> void:
	if %NewPass.text != %NewPass2.text:
		Toasts.say("The new passwords don't match.", "error")
		return
	var res: Dictionary = await Net.request("change_password", {"current": %CurPass.text, "next": %NewPass.text})
	if res["ok"]:
		Toasts.say("Password changed", "ok")
		%CurPass.text = ""
		%NewPass.text = ""
		%NewPass2.text = ""
	else:
		Toasts.say(str(res["error"]), "error")


func _export() -> void:
	var res: Dictionary = await Net.request("export_data")
	if not res["ok"]:
		Toasts.say(str(res["error"]), "error")
		return
	var path := "user://hive_chat_history.json"
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f != null:
		f.store_string(str(res["json"]))
		f.close()
	DisplayServer.clipboard_set(str(res["json"]))
	Dialogs.info("Chat history exported", "Saved to:\n%s\n\nIt was also copied to your clipboard." % ProjectSettings.globalize_path(path))


func _clear_history() -> void:
	Dialogs.confirm("Delete ALL of your saved AI chats? This cannot be undone.", _do_clear)


func _do_clear() -> void:
	var res: Dictionary = await Net.request("delete_history")
	if res["ok"]:
		Toasts.say("Chat history deleted", "ok")
	else:
		Toasts.say(str(res["error"]), "error")


func _delete_account() -> void:
	Dialogs.ask("Delete your account", "", _do_delete, "This deletes your account and all chats forever. Type your password to confirm:", true)


func _do_delete(pw: String) -> void:
	var res: Dictionary = await Net.request("delete_account", {"password": pw})
	if res["ok"]:
		Ui.forget_login()
		Net.disconnect_now()
	else:
		Toasts.say(str(res["error"]), "error")
