extends HBoxContainer
## One AI-chat message (user or Buzz) with a thinking animation and typewriter reveal.

signal grew

const Md = preload("res://scripts/ui/md.gd")

@export var user_style: StyleBox
@export var ai_style: StyleBox

@onready var avatar: Control = %Avatar
@onready var bubble: PanelContainer = %Bubble
@onready var ai_text: RichTextLabel = %AiText
@onready var user_text: Label = %UserText
@onready var typing: Label = %Typing

var role := "assistant"
var raw := ""
var thinking := false
var revealing := false
var _shown := 0.0
var _cps := 300.0
var _t := 0.0


func _ready() -> void:
	ai_text.meta_clicked.connect(_on_meta)


func _on_meta(meta: Variant) -> void:
	var url := str(meta)
	if url.begins_with("http://") or url.begins_with("https://"):
		OS.shell_open(url)


func setup(r: String, text: String, max_w: float = 700.0) -> void:
	role = r
	raw = text
	var me := r == "user"
	avatar.visible = not me
	alignment = BoxContainer.ALIGNMENT_END if me else BoxContainer.ALIGNMENT_BEGIN
	bubble.add_theme_stylebox_override("panel", user_style if me else ai_style)
	bubble.size_flags_horizontal = Control.SIZE_SHRINK_END if me else Control.SIZE_EXPAND_FILL
	user_text.visible = me
	ai_text.visible = not me
	typing.visible = false
	if me:
		user_text.text = text
		var font := user_text.get_theme_font("font")
		var fs := user_text.get_theme_font_size("font_size")
		var sz := font.get_multiline_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, max_w, fs)
		user_text.custom_minimum_size.x = minf(ceilf(sz.x) + 2.0, max_w)
	elif text != "":
		ai_text.text = Md.to_bbcode(text)


func show_thinking() -> void:
	thinking = true
	typing.visible = true
	ai_text.visible = false


func reveal(text: String) -> void:
	raw = text
	thinking = false
	typing.visible = false
	ai_text.visible = true
	revealing = true
	_shown = 0.0
	_cps = maxf(250.0, text.length() / 3.5)


func show_error(msg: String) -> void:
	thinking = false
	revealing = false
	typing.visible = false
	ai_text.visible = true
	ai_text.text = "[color=#ff8a80]" + Md.escape(msg) + "[/color]"


func _process(delta: float) -> void:
	if thinking:
		_t += delta
		typing.text = str(Net.settings.get("bot_name", "Buzz")) + " is buzzing" + ".".repeat(1 + int(_t * 2.5) % 3)
	elif revealing:
		var before := int(_shown)
		_shown += _cps * delta
		if _shown >= raw.length():
			revealing = false
			ai_text.text = Md.to_bbcode(raw)
			grew.emit()
		elif int(_shown) != before:
			ai_text.text = Md.to_bbcode(raw.substr(0, int(_shown)))
			grew.emit()
