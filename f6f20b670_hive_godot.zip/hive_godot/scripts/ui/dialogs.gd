extends Node
## Autoload "Dialogs": ask for text, confirm, or show info.
##   Dialogs.ask("Rename chat", "old name", _on_name)      -> _on_name(text)
##   Dialogs.confirm("Delete it?", _do_delete)

var _ask: ConfirmationDialog
var _field: LineEdit
var _hint: Label
var _ask_cb := Callable()
var _confirm: ConfirmationDialog
var _confirm_cb := Callable()
var _info: AcceptDialog


func _ready() -> void:
	_ask = ConfirmationDialog.new()
	var box := VBoxContainer.new()
	_hint = Label.new()
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint.custom_minimum_size.x = 380
	_field = LineEdit.new()
	box.add_child(_hint)
	box.add_child(_field)
	_ask.add_child(box)
	add_child(_ask)
	_ask.confirmed.connect(_on_ask_ok)
	_field.text_submitted.connect(_on_submit)
	_confirm = ConfirmationDialog.new()
	add_child(_confirm)
	_confirm.confirmed.connect(_on_confirm_ok)
	_info = AcceptDialog.new()
	add_child(_info)


func ask(title_text: String, initial: String, cb: Callable, hint: String = "", secret: bool = false) -> void:
	_ask.title = title_text
	_field.text = initial
	_field.secret = secret
	_hint.text = hint
	_hint.visible = hint != ""
	_ask_cb = cb
	_ask.popup_centered(Vector2i(440, 0))
	_field.grab_focus()
	_field.select_all()


func _on_submit(_t: String) -> void:
	_on_ask_ok()
	_ask.hide()


func _on_ask_ok() -> void:
	if _ask_cb.is_valid():
		_ask_cb.call(_field.text.strip_edges())


func confirm(text: String, cb: Callable) -> void:
	_confirm.dialog_text = text
	_confirm_cb = cb
	_confirm.popup_centered(Vector2i(440, 0))


func _on_confirm_ok() -> void:
	if _confirm_cb.is_valid():
		_confirm_cb.call()


func info(title_text: String, text: String) -> void:
	_info.title = title_text
	_info.dialog_text = text
	_info.popup_centered(Vector2i(460, 0))
