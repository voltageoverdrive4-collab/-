extends Control
## Honey dripping from under the top bar.


func _draw() -> void:
	var w := size.x
	var pts := PackedVector2Array([Vector2(0, 0), Vector2(w, 0)])
	var x := w
	while x >= 0.0:
		var y := 5.0 + 13.0 * pow(maxf(0.0, sin(x * 0.043)), 6.0) + 8.0 * pow(maxf(0.0, sin(x * 0.109 + 1.0)), 8.0)
		pts.append(Vector2(x, minf(y, size.y)))
		x -= 4.0
	draw_colored_polygon(pts, Color(1.0, 0.72, 0.0, 0.95))
