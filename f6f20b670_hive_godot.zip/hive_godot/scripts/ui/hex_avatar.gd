extends Control
## A hexagon with a letter in it (user avatars). Children (like a BeeIcon) draw on top.

@export var letter := "?":
	set(v):
		letter = v
		queue_redraw()
@export var fill := Color("#ffb800"):
	set(v):
		fill = v
		queue_redraw()
@export var text_color := Color("#1a1204"):
	set(v):
		text_color = v
		queue_redraw()


func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x / 1.7320508, size.y / 2.0)
	var pts := PackedVector2Array()
	for i in 6:
		var a := deg_to_rad(60.0 * i - 90.0)
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	draw_colored_polygon(pts, fill)
	if letter != "":
		var font := get_theme_default_font()
		var fs := int(r * 0.95)
		var tw := font.get_string_size(letter, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
		draw_string(font, Vector2(c.x - tw.x / 2.0, c.y + fs * 0.34), letter, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, text_color)
