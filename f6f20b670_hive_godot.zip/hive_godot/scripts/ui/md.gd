extends RefCounted
## Tiny Markdown -> BBCode converter for RichTextLabel.
## Supports: ``` code fences, `inline code`, **bold**, *italic*, # headings, - bullets, [links](url), ---

static var _re_code := RegEx.create_from_string("`([^`]+)`")
static var _re_bold := RegEx.create_from_string("\\*\\*(.+?)\\*\\*")
static var _re_italic := RegEx.create_from_string("(?<![\\*\\w])\\*(?![\\s\\*])([^*\\n]+?)(?<!\\s)\\*(?![\\*\\w])")
static var _re_link := RegEx.create_from_string("\\[lb\\]([^\\]]+)\\]\\(([^)\\s]+)\\)")


## Makes text safe to show inside a RichTextLabel with bbcode on.
static func escape(s: String) -> String:
	return s.replace("[", "[lb]")


static func to_bbcode(src: String) -> String:
	var out := PackedStringArray()
	var code_lines := PackedStringArray()
	var in_code := false
	for raw_line in src.split("\n"):
		var line: String = raw_line.trim_suffix("\r")
		if line.strip_edges().begins_with("```"):
			if in_code:
				out.append(_code_block("\n".join(code_lines)))
				code_lines.clear()
			in_code = not in_code
			continue
		if in_code:
			code_lines.append(line)
		else:
			out.append(_line(line))
	if in_code:   # still streaming/typing: close the block so it renders
		out.append(_code_block("\n".join(code_lines)))
	return "\n".join(out)


static func _code_block(code: String) -> String:
	return "[bgcolor=#0d0d0d][color=#d6e4ff][code]" + escape(code) + "[/code][/color][/bgcolor]"


static func _line(line: String) -> String:
	var s := escape(line)

	var h := 0
	while h < s.length() and h < 6 and s[h] == "#":
		h += 1
	if h > 0 and s.length() > h and s[h] == " ":
		var sizes := [26, 22, 19, 17, 16, 16]
		return "[font_size=%d][b]%s[/b][/font_size]" % [sizes[h - 1], _inline(s.substr(h + 1))]

	var t := s.strip_edges(true, false)
	var indent := s.length() - t.length()
	if t.begins_with("- ") or t.begins_with("* ") or t.begins_with("+ "):
		return " ".repeat(indent) + "  •  " + _inline(t.substr(2))
	if t == "---" or t == "***":
		return "[color=#4a4a4a]────────────────────────────────[/color]"
	return _inline(s)


static func _inline(s: String) -> String:
	s = _re_link.sub(s, "[color=#6ab0ff][url=$2]$1[/url][/color]", true)
	s = _re_code.sub(s, "[bgcolor=#3a3a3a][code]$1[/code][/bgcolor]", true)
	s = _re_bold.sub(s, "[b]$1[/b]", true)
	s = _re_italic.sub(s, "[i]$1[/i]", true)
	return s
