extends RefCounted
## Small shared helpers.

const CFG_PATH := "user://hive_client.cfg"
const COLORS := ["#ffb800", "#ff9500", "#ffd666", "#ff7a45", "#f5c242", "#e8a33d", "#ffcf5a", "#ff8c1a"]


static func rand_id() -> String:
	return Crypto.new().generate_random_bytes(6).hex_encode()


static func avatar_color(username: String) -> Color:
	var n := 0
	for ch in username:
		n = (n * 31 + ch.unicode_at(0)) % 1000003
	return Color(COLORS[n % COLORS.size()])


static func role_tag(role: String) -> String:
	if role == "owner":
		return "QUEEN"
	if role == "admin":
		return "GUARD"
	return ""


static func clock(t: Variant) -> String:
	var off := int(Time.get_time_zone_from_system()["bias"]) * 60
	var d := Time.get_datetime_dict_from_unix_time(int(t) + off)
	return "%02d:%02d" % [d["hour"], d["minute"]]


static func ago(t: Variant) -> String:
	var ts := int(t)
	if ts <= 0:
		return "never"
	var s := int(Time.get_unix_time_from_system()) - ts
	if s < 45:
		return "just now"
	if s < 3600:
		return "%dm ago" % (s / 60)
	if s < 86400:
		return "%dh ago" % (s / 3600)
	if s < 86400 * 30:
		return "%dd ago" % (s / 86400)
	var d := Time.get_datetime_dict_from_unix_time(ts)
	return "%04d-%02d-%02d" % [d["year"], d["month"], d["day"]]


static func load_cfg() -> Dictionary:
	var cf := ConfigFile.new()
	if cf.load(CFG_PATH) != OK:
		return {}
	return {
		"server": cf.get_value("login", "server", ""),
		"username": cf.get_value("login", "username", ""),
		"token": cf.get_value("login", "token", ""),
	}


static func save_cfg(server: String, username: String, token: String) -> void:
	var cf := ConfigFile.new()
	cf.set_value("login", "server", server)
	cf.set_value("login", "username", username)
	cf.set_value("login", "token", token)
	cf.save(CFG_PATH)


static func forget_login() -> void:
	var cfg := load_cfg()
	save_cfg(str(cfg.get("server", "")), str(cfg.get("username", "")), "")


static func clear_children(node: Node) -> void:
	for c in node.get_children():
		node.remove_child(c)
		c.queue_free()
