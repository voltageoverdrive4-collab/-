extends Control
## The Hive bee mascot, drawn with shapes (no image files needed).

@export var bobbing := false


func _process(_d: float) -> void:
	if bobbing:
		queue_redraw()


func _ell(center: Vector2, rx: float, ry: float, rot: float, col: Color, k: float, o: Vector2) -> void:
	var pts := PackedVector2Array()
	for i in 28:
		var a := TAU * i / 28.0
		var p := Vector2(cos(a) * rx, sin(a) * ry).rotated(rot)
		pts.append(o + (center + p) * k)
	draw_colored_polygon(pts, col)


func _draw() -> void:
	var k := minf(size.x, size.y) / 64.0
	var o := (size - Vector2(64, 64) * k) / 2.0
	if bobbing:
		o.y += sin(Time.get_ticks_msec() / 350.0) * 3.0 * k
	var wing := Color(0.81, 0.91, 1.0, 0.8)
	_ell(Vector2(29, 20), 8, 14, deg_to_rad(-22), wing, k, o)
	_ell(Vector2(42, 20), 8, 14, deg_to_rad(22), wing, k, o)
	_ell(Vector2(36, 38), 19, 13, 0.0, Color("#ffb800"), k, o)
	var dark := Color("#1a1204")
	draw_line(o + Vector2(31, 26) * k, o + Vector2(31, 50) * k, dark, 5.0 * k)
	draw_line(o + Vector2(41, 27) * k, o + Vector2(41, 49) * k, dark, 5.0 * k)
	draw_circle(o + Vector2(14, 38) * k, 9.0 * k, Color("#2a1c05"))
	draw_circle(o + Vector2(11, 36) * k, 2.4 * k, Color.WHITE)
	draw_circle(o + Vector2(17, 36) * k, 2.4 * k, Color.WHITE)
	draw_line(o + Vector2(10, 30) * k, o + Vector2(6, 22) * k, Color("#2a1c05"), 2.0 * k)
	draw_line(o + Vector2(16, 29) * k, o + Vector2(17, 20) * k, Color("#2a1c05"), 2.0 * k)
	draw_colored_polygon(PackedVector2Array([o + Vector2(53, 34) * k, o + Vector2(62, 38) * k, o + Vector2(53, 42) * k]), Color("#2a1c05"))
