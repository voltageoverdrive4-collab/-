extends CanvasLayer
## Autoload "Toasts": little messages in the top-right corner.   Toasts.say("Saved!", "ok")

var box: VBoxContainer


func _ready() -> void:
	layer = 100
	box = VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.anchor_left = 1.0
	box.anchor_right = 1.0
	box.offset_left = -380.0
	box.offset_right = -16.0
	box.offset_top = 16.0
	box.add_theme_constant_override("separation", 8)
	add_child(box)


func say(text: String, kind: String = "info") -> void:
	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("#271d0b")
	sb.set_corner_radius_all(10)
	sb.set_border_width_all(1)
	sb.border_width_left = 5
	sb.border_color = {"error": Color("#ff6b5a"), "ok": Color("#7ddc7a")}.get(kind, Color("#ffb800"))
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	sb.shadow_color = Color(0, 0, 0, 0.5)
	sb.shadow_size = 10
	panel.add_theme_stylebox_override("panel", sb)
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.custom_minimum_size.x = 300
	panel.add_child(label)
	box.add_child(panel)
	var tw := create_tween()
	tw.tween_interval(5.0 if kind == "error" else 3.2)
	tw.tween_property(panel, "modulate:a", 0.0, 0.4)
	tw.tween_callback(panel.queue_free)
