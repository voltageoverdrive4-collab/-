extends Control
## The main app: top bar + the four tabs.

signal logged_out

const Ui = preload("res://scripts/ui/ui.gd")

var _names := ["ai", "chat", "admin", "account"]


func _ready() -> void:
	%BtnAI.pressed.connect(show_tab.bind("ai"))
	%BtnChat.pressed.connect(show_tab.bind("chat"))
	%BtnAdmin.pressed.connect(show_tab.bind("admin"))
	%BtnAccount.pressed.connect(show_tab.bind("account"))
	%LogoutBtn.pressed.connect(_logout)
	%ChatTab.unread_changed.connect(_on_unread)
	Net.pushed.connect(_on_push)


func enter() -> void:
	var u := Net.user
	%UserLabel.text = str(u["username"])
	var tag := Ui.role_tag(str(u["role"]))
	%RoleLabel.text = tag
	%RoleLabel.visible = tag != ""
	var staff: bool = u["role"] == "owner" or u["role"] == "admin"
	%BtnAdmin.visible = staff
	%AiTab.enter()
	%ChatTab.enter()
	%AccountTab.enter()
	if staff:
		%AdminTab.enter()
	show_tab("ai")
	Rtc.start()


func show_tab(tab_name: String) -> void:
	var nodes := {"ai": %AiTab, "chat": %ChatTab, "admin": %AdminTab, "account": %AccountTab}
	var buttons := {"ai": %BtnAI, "chat": %BtnChat, "admin": %BtnAdmin, "account": %BtnAccount}
	for k in _names:
		nodes[k].visible = k == tab_name
		buttons[k].set_pressed_no_signal(k == tab_name)
	if tab_name == "chat":
		%ChatTab.on_shown()
	elif tab_name == "admin":
		%AdminTab.on_shown()


func _on_unread(v: bool) -> void:
	%UnreadDot.visible = v


func _logout() -> void:
	await Net.request("logout", {"token": Net.token})
	_leave()


func _leave() -> void:
	Ui.forget_login()
	Rtc.stop()
	Net.disconnect_now()
	logged_out.emit()


func _on_push(ev: String, d: Dictionary) -> void:
	if ev == "kicked":
		Toasts.say(str(d.get("reason", "You were removed from the hive.")), "error")
		_leave()
	elif ev == "settings":
		Net.settings = d["settings"]
