extends Control
## Login / sign-up screen. Also lets you host a server on this computer.

signal authenticated

const Ui = preload("res://scripts/ui/ui.gd")
const ServerCfg = preload("res://scripts/server/server_config.gd")

var start_server := Callable()
var mode := "login"
var busy := false

@onready var server_edit: LineEdit = %ServerEdit
@onready var user_edit: LineEdit = %UserEdit
@onready var pass_edit: LineEdit = %PassEdit
@onready var host_check: CheckBox = %HostCheck
@onready var error_label: Label = %ErrorLabel
@onready var status_label: Label = %StatusLabel
@onready var submit_btn: Button = %SubmitBtn


func _ready() -> void:
	%LoginBtn.pressed.connect(_set_mode.bind("login"))
	%RegisterBtn.pressed.connect(_set_mode.bind("register"))
	submit_btn.pressed.connect(_submit)
	pass_edit.text_submitted.connect(_on_enter)
	user_edit.text_submitted.connect(_on_enter)
	var cfg := Ui.load_cfg()
	var saved := str(cfg.get("server", ""))
	server_edit.text = saved if saved != "" else "127.0.0.1:%d" % ServerCfg.port()
	user_edit.text = str(cfg.get("username", ""))
	_set_mode("login")
	_try_resume.call_deferred()


func _on_enter(_t: String) -> void:
	_submit()


func _set_mode(m: String) -> void:
	mode = m
	%LoginBtn.set_pressed_no_signal(m == "login")
	%RegisterBtn.set_pressed_no_signal(m == "register")
	submit_btn.text = "Log in" if m == "login" else "Join the hive"
	error_label.text = ""


func _connect(addr: String) -> bool:
	Net.connect_to(addr)
	var t := 0.0
	while Net.state == "connecting" and t < 8.0:
		await get_tree().process_frame
		t += get_process_delta_time()
	return Net.state == "open"


func _try_resume() -> void:
	var cfg := Ui.load_cfg()
	var tok := str(cfg.get("token", ""))
	var addr := str(cfg.get("server", ""))
	if tok == "" or addr == "" or busy:
		return
	busy = true
	status_label.text = "Signing you back in…"
	if await _connect(addr):
		var res: Dictionary = await Net.request("resume", {"token": tok})
		if res["ok"]:
			_finish(res, addr)
			return
		Net.disconnect_now()
	busy = false
	status_label.text = ""


func _fail(msg: String) -> void:
	busy = false
	submit_btn.disabled = false
	status_label.text = ""
	error_label.text = msg


func _finish(res: Dictionary, addr: String) -> void:
	Net.user = res["user"]
	Net.settings = res["settings"]
	Net.token = str(res["token"])
	Ui.save_cfg(addr, str(Net.user["username"]), Net.token)
	busy = false
	submit_btn.disabled = false
	status_label.text = ""
	authenticated.emit()


func _submit() -> void:
	if busy:
		return
	var uname := user_edit.text.strip_edges()
	var pw := pass_edit.text
	error_label.text = ""
	if uname == "" or pw == "":
		error_label.text = "Enter a username and password."
		return
	busy = true
	submit_btn.disabled = true
	status_label.text = "Connecting…"
	var addr := server_edit.text.strip_edges()
	if host_check.button_pressed:
		if not start_server.is_valid() or not start_server.call():
			_fail("Could not start the server on this computer (is port %d already in use?)." % ServerCfg.port())
			return
		addr = "127.0.0.1:%d" % ServerCfg.port()
		server_edit.text = addr
	if not await _connect(addr):
		_fail("Could not reach the hive server at %s. Check the address and that the server is running." % addr)
		return
	status_label.text = "Checking your details…"
	var res: Dictionary = await Net.request("register" if mode == "register" else "login", {"username": uname, "password": pw})
	if not res["ok"]:
		_fail(str(res["error"]))
		return
	pass_edit.text = ""
	_finish(res, addr)
