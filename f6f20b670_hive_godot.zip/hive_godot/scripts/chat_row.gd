extends HBoxContainer
## One community-chat message.

signal delete_requested(row: Node)

const Ui = preload("res://scripts/ui/ui.gd")

@onready var avatar = %Avatar
@onready var name_label: Label = %NameLabel
@onready var role_label: Label = %RoleLabel
@onready var time_label: Label = %TimeLabel
@onready var tag_label: Label = %TagLabel
@onready var text_label: Label = %TextLabel
@onready var del_btn: Button = %DelBtn

var msg: Dictionary = {}
var can_delete := false


func _ready() -> void:
	del_btn.pressed.connect(_on_delete)


func _on_delete() -> void:
	delete_requested.emit(self)


func setup(m: Dictionary, deletable: bool, mention: bool) -> void:
	msg = m
	can_delete = deletable
	var uname := str(m["username"])
	avatar.letter = uname.substr(0, 1).to_upper()
	avatar.fill = Ui.avatar_color(uname)
	name_label.text = uname
	var tag := Ui.role_tag(str(m.get("role", "")))
	role_label.text = tag
	role_label.visible = tag != ""
	time_label.text = Ui.clock(m["t"])
	text_label.text = str(m["text"])
	text_label.theme_type_variation = &"MentionLabel" if mention else &""
	_refresh_state()


func confirm(server_msg: Dictionary) -> void:
	msg = server_msg
	_refresh_state()


func _refresh_state() -> void:
	tag_label.visible = bool(msg.get("p2p", false)) and not msg.has("id")
	del_btn.visible = can_delete and msg.has("id")
