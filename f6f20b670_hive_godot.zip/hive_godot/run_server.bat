@echo off
rem Starts the Hive server without any window (needs Godot 4.3+).
rem If "godot" is not on your PATH, put the full path to your Godot .exe below, e.g.
rem   set GODOT="C:\Tools\Godot_v4.3-stable_win64.exe"
set GODOT=godot
%GODOT% --headless --path "%~dp0" -- --server
pause
