extends RefCounted
## Turns project scripts (.gd / .sts) into plain GDScript, and redirects print() to the Studio console.

const CALLS := {
	"print": "StudioRT.out", "prints": "StudioRT.outs", "printt": "StudioRT.outt",
	"print_rich": "StudioRT.out_rich", "print_debug": "StudioRT.out",
	"printerr": "StudioRT.err", "push_error": "StudioRT.err", "push_warning": "StudioRT.warn",
}

const EVENTS := {
	"ready": ["_ready", ""], "process": ["_process", "delta"], "physics": ["_physics_process", "delta"],
	"input": ["_input", "event"], "key": ["_unhandled_key_input", "event"], "draw": ["_draw", ""],
	"enter": ["_enter_tree", ""], "exit": ["_exit_tree", ""],
}

static var _re_extends := RegEx.create_from_string("(?m)^\\s*extends\\b")
static var _re_use := RegEx.create_from_string("^(\\s*)use\\s+\"([^\"]+)\"(?:\\s+as\\s+(\\w+))?\\s*$")
static var _re_on := RegEx.create_from_string("^on\\s+(\\w+)\\s*(?:\\((.*?)\\))?\\s*:\\s*$")
static var _re_to := RegEx.create_from_string("^to\\s+(\\w+)\\s*(?:\\((.*?)\\))?\\s*:\\s*$")
static var _re_say := RegEx.create_from_string("^say\\s+(.+)$")
static var _re_set := RegEx.create_from_string("^set\\s+(.+?)\\s+to\\s+(.+)$")
static var _re_change := RegEx.create_from_string("^change\\s+(.+?)\\s+by\\s+(.+)$")
static var _re_repeat := RegEx.create_from_string("^repeat\\s+(.+?)\\s+times\\s*:\\s*$")
static var _re_wait := RegEx.create_from_string("^wait\\s+(.+?)\\s+seconds?\\s*$")


static func to_gdscript(src: String, ext: String, base: String) -> String:
	var code := src
	if ext == "sts":
		code = transpile_sts(code)
	code = _rewrite(code)
	if _re_extends.search(code) == null:
		code = "extends %s\n%s" % [base, code]
	return code


# --------------------------------------------------------------- Studio Script

static func transpile_sts(src: String) -> String:
	var out := PackedStringArray()
	for raw in src.split("\n"):
		var line: String = raw.trim_suffix("\r")
		var t := line.strip_edges(true, false)
		var indent := line.substr(0, line.length() - t.length())
		var m := _re_on.search(t)
		if m != null and EVENTS.has(m.get_string(1)):
			var ev: Array = EVENTS[m.get_string(1)]
			var args := m.get_string(2)
			if args == "":
				args = ev[1]
			out.append("%sfunc %s(%s):" % [indent, ev[0], args])
			continue
		m = _re_to.search(t)
		if m != null:
			out.append("%sfunc %s(%s):" % [indent, m.get_string(1), m.get_string(2)])
			continue
		m = _re_say.search(t)
		if m != null:
			out.append("%sprint(%s)" % [indent, m.get_string(1)])
			continue
		m = _re_set.search(t)
		if m != null:
			out.append("%s%s = %s" % [indent, m.get_string(1), m.get_string(2)])
			continue
		m = _re_change.search(t)
		if m != null:
			out.append("%s%s += %s" % [indent, m.get_string(1), m.get_string(2)])
			continue
		m = _re_repeat.search(t)
		if m != null:
			out.append("%sfor _i in range(%s):" % [indent, m.get_string(1)])
			continue
		m = _re_wait.search(t)
		if m != null:
			out.append("%sawait get_tree().create_timer(%s).timeout" % [indent, m.get_string(1)])
			continue
		out.append(line)
	return "\n".join(out)


# --------------------------------------------------------------- rewriting

static func _rewrite(src: String) -> String:
	var out := PackedStringArray()
	for raw in src.split("\n"):
		var line: String = raw.trim_suffix("\r")
		var t := line.strip_edges()
		if t.begins_with("class_name "):
			out.append("#" + line)   # class_name would clash when a script is compiled twice
			continue
		var um := _re_use.search(line)
		if um != null:
			var target := um.get_string(2)
			var alias := um.get_string(3)
			if alias == "":
				alias = target.get_basename()
			alias = _identifier(alias)
			out.append("%svar %s = StudioRT.load_script(\"%s\")" % [um.get_string(1), alias, target])
			continue
		out.append(_rewrite_line(line))
	return "\n".join(out)


static func _identifier(s: String) -> String:
	var r := ""
	for ch in s:
		r += ch if _is_ident_char(ch) else "_"
	return r


static func _is_ident_start(c: String) -> bool:
	return (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or c == "_"


static func _is_ident_char(c: String) -> bool:
	return _is_ident_start(c) or (c >= "0" and c <= "9")


static func _rewrite_line(line: String) -> String:
	var res := ""
	var i := 0
	var n := line.length()
	var quote := ""
	while i < n:
		var c := line[i]
		if quote != "":
			res += c
			if c == "\\" and i + 1 < n:
				res += line[i + 1]
				i += 2
				continue
			if c == quote:
				quote = ""
			i += 1
			continue
		if c == "#":
			res += line.substr(i)
			break
		if c == "\"" or c == "'":
			quote = c
			res += c
			i += 1
			continue
		if _is_ident_start(c) and (i == 0 or (not _is_ident_char(line[i - 1]) and line[i - 1] != ".")):
			var j := i
			while j < n and _is_ident_char(line[j]):
				j += 1
			var word := line.substr(i, j - i)
			var after_func := res.rstrip(" \t").ends_with("func")
			if CALLS.has(word) and j < n and line[j] == "(" and not after_func:
				res += CALLS[word]
				i = j
				continue
			if word == "get_tree" and line.substr(j).begins_with("().quit("):
				res += "StudioRT.quit_game"
				i = j + "().quit".length()
				continue
			res += word
			i = j
			continue
		res += c
		i += 1
	return res


# --------------------------------------------------------------- templates

static func template(ext: String, base: String, kind: String) -> String:
	if kind == "empty":
		return "extends %s\n" % base
	if ext == "sts":
		return "extends %s\n\non ready:\n\tsay \"Hello from Studio Script!\"\n\non process(delta):\n\tpass\n" % base
	return "extends %s\n\n\n# Called when the node enters the scene tree for the first time.\nfunc _ready() -> void:\n\tprint(\"Hello from %s!\")\n\n\n# Called every frame. 'delta' is the elapsed time since the previous frame.\nfunc _process(delta: float) -> void:\n\tpass\n" % [base, base]
