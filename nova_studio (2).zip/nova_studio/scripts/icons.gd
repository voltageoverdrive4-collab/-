extends RefCounted
## Tiny procedurally drawn icons (no image files needed).

static var _cache := {}


static func _make(key: String, fn: Callable) -> ImageTexture:
	if _cache.has(key):
		return _cache[key]
	var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	fn.call(img)
	var t := ImageTexture.create_from_image(img)
	_cache[key] = t
	return t


static func _draw_dot(img: Image, c: Color) -> void:
	for y in 16:
		for x in 16:
			var d := Vector2(x + 0.5, y + 0.5).distance_to(Vector2(8, 8))
			if d < 4.6:
				img.set_pixel(x, y, c)
			elif d < 5.6:
				img.set_pixel(x, y, Color(c.r, c.g, c.b, 0.5))


static func _draw_play(img: Image, c: Color) -> void:
	for x in range(4, 14):
		for y in 16:
			if absf(y + 0.5 - 8.0) < (14.0 - x) * 0.85:
				img.set_pixel(x, y, c)


static func _draw_pause(img: Image, c: Color) -> void:
	img.fill_rect(Rect2i(4, 3, 3, 10), c)
	img.fill_rect(Rect2i(9, 3, 3, 10), c)


static func _draw_stop(img: Image, c: Color) -> void:
	img.fill_rect(Rect2i(3, 3, 10, 10), c)


static func dot(c: Color) -> ImageTexture:
	return _make("dot" + c.to_html(), _draw_dot.bind(c))

static func play(c: Color) -> ImageTexture:
	return _make("play" + c.to_html(), _draw_play.bind(c))

static func pause(c: Color) -> ImageTexture:
	return _make("pause" + c.to_html(), _draw_pause.bind(c))

static func stop(c: Color) -> ImageTexture:
	return _make("stop" + c.to_html(), _draw_stop.bind(c))
