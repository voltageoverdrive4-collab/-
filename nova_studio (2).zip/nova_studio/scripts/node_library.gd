extends RefCounted
## Node Library: the common Godot nodes shown in the Create New Node window,
## with a short description and example code for each.

const CATEGORIES = [
	{
		"name": "2D Nodes - Visuals",
		"nodes": [
			{
				"type": "Sprite2D",
				"desc": "Display 2D texture/image",
				"example": "$Sprite2D.texture = preload(\"res://player.png\")\n$Sprite2D.flip_h = true"
			},
			{
				"type": "AnimatedSprite2D",
				"desc": "Animated sprite with frame-based animation",
				"example": "$AnimatedSprite2D.play(\"walk\")\n$AnimatedSprite2D.animation_finished.connect(_on_anim_done)"
			},
			{
				"type": "Node2D",
				"desc": "Base 2D node with transform (position, rotation, scale)",
				"example": "$Node2D.position = Vector2(100, 200)\n$Node2D.rotation_degrees = 45"
			},
			{
				"type": "Polygon2D",
				"desc": "2D polygon shape",
				"example": "$Polygon2D.polygon = PackedVector2Array([Vector2(0,0), Vector2(100,0), Vector2(50,100)])"
			},
			{
				"type": "Line2D",
				"desc": "Draw 2D lines",
				"example": "$Line2D.add_point(Vector2(0, 0))\n$Line2D.width = 5.0"
			},
			{
				"type": "TileMapLayer",
				"desc": "Modern grid-based tile layer for levels (replaces TileMap in newer Godot versions)",
				"example": "$TileMapLayer.set_cell(Vector2i(5, 3), 0, Vector2i(1, 0))"
			},
			{
				"type": "TileMap",
				"desc": "Grid-based tile system for levels (older node, may be missing in newer Godot versions)",
				"example": "$TileMap.set_cell(0, Vector2i(5, 3), 0, Vector2i(1, 0))"
			}
		]
	},
	{
		"name": "2D Physics Nodes",
		"nodes": [
			{
				"type": "CharacterBody2D",
				"desc": "Kinematic body for player/character control",
				"example": "velocity.y += 980 * delta\nmove_and_slide()\nif is_on_floor():\n\tcan_jump = true"
			},
			{
				"type": "RigidBody2D",
				"desc": "Dynamic physics body affected by forces",
				"example": "$RigidBody2D.apply_central_impulse(Vector2(100, 0))\n$RigidBody2D.mass = 10.0"
			},
			{
				"type": "StaticBody2D",
				"desc": "Non-moving physics body (walls, platforms)",
				"example": "# Usually just needs a CollisionShape2D child\n# No movement code needed"
			},
			{
				"type": "Area2D",
				"desc": "Detect overlapping bodies/areas (no physics)",
				"example": "$Area2D.body_entered.connect(_on_body_entered)\n\nfunc _on_body_entered(body):\n\tif body.is_in_group(\"player\"):\n\t\tcollect_item()"
			},
			{
				"type": "CollisionShape2D",
				"desc": "Collision shape for physics bodies",
				"example": "var shape = RectangleShape2D.new()\nshape.size = Vector2(64, 64)\n$CollisionShape2D.shape = shape"
			},
			{
				"type": "CollisionPolygon2D",
				"desc": "Polygon-based collision shape",
				"example": "$CollisionPolygon2D.polygon = PackedVector2Array([Vector2(0,0), Vector2(100,0), Vector2(50,100)])"
			}
		]
	},
	{
		"name": "3D Nodes - Visuals",
		"nodes": [
			{
				"type": "MeshInstance3D",
				"desc": "Display 3D mesh",
				"example": "$MeshInstance3D.mesh = preload(\"res://models/player.obj\")\n$MeshInstance3D.set_surface_override_material(0, material)"
			},
			{
				"type": "Node3D",
				"desc": "Base 3D node with transform",
				"example": "$Node3D.position = Vector3(1, 2, 3)\n$Node3D.rotation_degrees = Vector3(0, 90, 0)"
			},
			{
				"type": "Camera3D",
				"desc": "3D camera for rendering",
				"example": "$Camera3D.make_current()\n$Camera3D.fov = 75.0"
			},
			{
				"type": "DirectionalLight3D",
				"desc": "Directional light source (sun)",
				"example": "$DirectionalLight3D.light_energy = 1.5\n$DirectionalLight3D.shadow_enabled = true"
			},
			{
				"type": "SpotLight3D",
				"desc": "Cone-shaped light",
				"example": "$SpotLight3D.spot_range = 10.0\n$SpotLight3D.spot_angle = 45.0"
			},
			{
				"type": "OmniLight3D",
				"desc": "Point light radiating in all directions",
				"example": "$OmniLight3D.omni_range = 5.0\n$OmniLight3D.light_color = Color.RED"
			}
		]
	},
	{
		"name": "3D Physics Nodes",
		"nodes": [
			{
				"type": "CharacterBody3D",
				"desc": "Kinematic body for 3D character control",
				"example": "move_and_slide()\nif is_on_floor():\n\tjump()"
			},
			{
				"type": "RigidBody3D",
				"desc": "Dynamic 3D physics body",
				"example": "$RigidBody3D.apply_central_impulse(Vector3(0, 10, 0))\n$RigidBody3D.mass = 5.0"
			},
			{
				"type": "StaticBody3D",
				"desc": "Non-moving 3D physics body",
				"example": "# Walls, floors, static obstacles"
			},
			{
				"type": "Area3D",
				"desc": "3D overlap detection area",
				"example": "$Area3D.body_entered.connect(_on_trigger)\n\nfunc _on_trigger(body):\n\ttrigger_event()"
			},
			{
				"type": "CollisionShape3D",
				"desc": "3D collision shape",
				"example": "var shape = BoxShape3D.new()\nshape.size = Vector3(1, 2, 1)\n$CollisionShape3D.shape = shape"
			}
		]
	},
	{
		"name": "UI Control Nodes",
		"nodes": [
			{
				"type": "Label",
				"desc": "Display text",
				"example": "$Label.text = \"Score: %d\" % score\n$Label.add_theme_font_size_override(\"font_size\", 24)"
			},
			{
				"type": "Button",
				"desc": "Clickable button",
				"example": "$Button.pressed.connect(_on_button_pressed)\n$Button.text = \"Start Game\""
			},
			{
				"type": "TextureButton",
				"desc": "Button with textures",
				"example": "$TextureButton.texture_normal = preload(\"res://button.png\")\n$TextureButton.texture_pressed = preload(\"res://button_pressed.png\")"
			},
			{
				"type": "LineEdit",
				"desc": "Single-line text input",
				"example": "$LineEdit.text_submitted.connect(_on_text_entered)\nvar entered = $LineEdit.text"
			},
			{
				"type": "TextEdit",
				"desc": "Multi-line text input",
				"example": "$TextEdit.text = \"Enter description\"\nvar content = $TextEdit.text"
			},
			{
				"type": "Panel",
				"desc": "Container with background",
				"example": "# Usually styled with themes\n# Good for UI backgrounds"
			},
			{
				"type": "ColorRect",
				"desc": "Rectangle with solid color",
				"example": "$ColorRect.color = Color.RED\n$ColorRect.size = Vector2(100, 50)"
			},
			{
				"type": "ProgressBar",
				"desc": "Progress indicator",
				"example": "$ProgressBar.value = health\n$ProgressBar.max_value = 100"
			},
			{
				"type": "CheckBox",
				"desc": "Toggle checkbox",
				"example": "$CheckBox.toggled.connect(_on_toggle)\nvar is_checked = $CheckBox.button_pressed"
			},
			{
				"type": "OptionButton",
				"desc": "Dropdown selection menu",
				"example": "$OptionButton.add_item(\"Easy\")\n$OptionButton.add_item(\"Hard\")\nvar chosen = $OptionButton.selected"
			}
		]
	},
	{
		"name": "UI Container Nodes",
		"nodes": [
			{
				"type": "Control",
				"desc": "Base UI node with anchors and margins",
				"example": "$Control.anchor_left = 0.5\n$Control.anchor_top = 0.5"
			},
			{
				"type": "Container",
				"desc": "Base container for automatic layout (abstract: add one of its children such as VBoxContainer instead)",
				"example": "# Parent class for layout containers"
			},
			{
				"type": "VBoxContainer",
				"desc": "Vertical box layout",
				"example": "# Children arranged vertically\n$VBoxContainer.add_theme_constant_override(\"separation\", 10)"
			},
			{
				"type": "HBoxContainer",
				"desc": "Horizontal box layout",
				"example": "# Children arranged horizontally\n$HBoxContainer.alignment = BoxContainer.ALIGNMENT_CENTER"
			},
			{
				"type": "GridContainer",
				"desc": "Grid layout",
				"example": "$GridContainer.columns = 3\n# Auto-arranges in a 3-column grid"
			},
			{
				"type": "MarginContainer",
				"desc": "Container with margins",
				"example": "$MarginContainer.add_theme_constant_override(\"margin_left\", 10)"
			},
			{
				"type": "ScrollContainer",
				"desc": "Scrollable container",
				"example": "$ScrollContainer.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED"
			},
			{
				"type": "TabContainer",
				"desc": "Tabbed interface",
				"example": "$TabContainer.current_tab = 0\n$TabContainer.set_tab_title(0, \"Inventory\")"
			}
		]
	},
	{
		"name": "Animation and Audio",
		"nodes": [
			{
				"type": "AnimationPlayer",
				"desc": "Play keyframe animations",
				"example": "$AnimationPlayer.play(\"jump\")\n$AnimationPlayer.animation_finished.connect(_on_anim_done)\nawait $AnimationPlayer.animation_finished"
			},
			{
				"type": "AnimationTree",
				"desc": "Advanced animation blending",
				"example": "$AnimationTree.active = true\n$AnimationTree.set(\"parameters/blend/blend_amount\", 0.5)"
			},
			{
				"type": "AudioStreamPlayer",
				"desc": "2D audio playback (non-positional)",
				"example": "$AudioStreamPlayer.stream = preload(\"res://music.ogg\")\n$AudioStreamPlayer.play()"
			},
			{
				"type": "AudioStreamPlayer2D",
				"desc": "2D positional audio",
				"example": "$AudioStreamPlayer2D.stream = preload(\"res://explosion.wav\")\n$AudioStreamPlayer2D.play()"
			},
			{
				"type": "AudioStreamPlayer3D",
				"desc": "3D positional audio",
				"example": "$AudioStreamPlayer3D.stream = sound_effect\n$AudioStreamPlayer3D.play()"
			},
			{
				"type": "Tween",
				"desc": "Animate property values smoothly. Not a node: you create it from code inside a script.",
				"example": "var tween = create_tween()\ntween.tween_property($Sprite, \"position\", Vector2(100, 200), 1.0)"
			}
		]
	},
	{
		"name": "Utility Nodes",
		"nodes": [
			{
				"type": "Timer",
				"desc": "Countdown timer",
				"example": "$Timer.wait_time = 2.0\n$Timer.timeout.connect(_on_timer_done)\n$Timer.start()"
			},
			{
				"type": "Camera2D",
				"desc": "2D camera with smoothing and limits",
				"example": "$Camera2D.make_current()\n$Camera2D.position_smoothing_enabled = true\n$Camera2D.position_smoothing_speed = 5.0"
			},
			{
				"type": "CanvasLayer",
				"desc": "Separate rendering layer (for UI)",
				"example": "$CanvasLayer.layer = 10  # render on top"
			},
			{
				"type": "ParallaxBackground",
				"desc": "Parallax scrolling background",
				"example": "# Add ParallaxLayer children\n$ParallaxLayer.motion_scale = Vector2(0.5, 0.5)"
			},
			{
				"type": "ParallaxLayer",
				"desc": "One scrolling layer inside a ParallaxBackground",
				"example": "$ParallaxLayer.motion_scale = Vector2(0.5, 0.5)"
			},
			{
				"type": "Path2D",
				"desc": "A curved path that other nodes can follow (use with PathFollow2D)",
				"example": "# Add a PathFollow2D as a child of the Path2D"
			},
			{
				"type": "PathFollow2D",
				"desc": "Move nodes along a curved path (child of a Path2D)",
				"example": "$PathFollow2D.progress_ratio += 0.01\n# Moves along the parent Path2D"
			},
			{
				"type": "RayCast2D",
				"desc": "2D ray collision detection",
				"example": "$RayCast2D.target_position = Vector2(0, 100)\nif $RayCast2D.is_colliding():\n\tvar hit = $RayCast2D.get_collider()"
			},
			{
				"type": "VisibleOnScreenNotifier2D",
				"desc": "Detect when node enters/exits screen",
				"example": "$Notifier.screen_entered.connect(_on_screen_enter)\n$Notifier.screen_exited.connect(_on_screen_exit)"
			}
		]
	},
	{
		"name": "Particle Systems",
		"nodes": [
			{
				"type": "GPUParticles2D",
				"desc": "GPU-accelerated 2D particles",
				"example": "$GPUParticles2D.emitting = true\n$GPUParticles2D.amount = 100"
			},
			{
				"type": "CPUParticles2D",
				"desc": "CPU-based 2D particles (better compatibility)",
				"example": "$CPUParticles2D.emitting = true\n$CPUParticles2D.lifetime = 2.0"
			},
			{
				"type": "GPUParticles3D",
				"desc": "GPU-accelerated 3D particles",
				"example": "$GPUParticles3D.emitting = true\n$GPUParticles3D.one_shot = true"
			},
			{
				"type": "CPUParticles3D",
				"desc": "CPU-based 3D particles",
				"example": "$CPUParticles3D.emitting = true"
			}
		]
	},
	{
		"name": "Networking and Misc",
		"nodes": [
			{
				"type": "HTTPRequest",
				"desc": "Make web requests (download data, talk to web APIs)",
				"example": "$HTTPRequest.request_completed.connect(_on_request_done)\n$HTTPRequest.request(\"https://example.com/api\")\n\nfunc _on_request_done(result, code, headers, body):\n\tprint(body.get_string_from_utf8())"
			},
			{
				"type": "Node",
				"desc": "The most basic node: an empty container for scripts and children",
				"example": "# Attach a script to use it as a manager / controller"
			},
			{
				"type": "Marker2D",
				"desc": "An invisible 2D position marker (spawn points, targets)",
				"example": "var spawn = $Marker2D.global_position"
			},
			{
				"type": "Marker3D",
				"desc": "An invisible 3D position marker",
				"example": "var spawn = $Marker3D.global_position"
			},
			{
				"type": "CanvasModulate",
				"desc": "Tints the whole 2D scene with a color",
				"example": "$CanvasModulate.color = Color(0.4, 0.4, 0.6)"
			},
			{
				"type": "WorldEnvironment",
				"desc": "Sets sky, fog and glow for 3D scenes",
				"example": "# Assign an Environment resource in the Inspector"
			}
		]
	}
]


static func find(type: String) -> Dictionary:
	for cat in CATEGORIES:
		for n in cat["nodes"]:
			if n["type"] == type:
				return n
	return {}
