extends Node
## Main scene of an EXPORTED Nova Studio project: rebuilds the saved scene and runs it.

const SceneCodec = preload("res://scripts/scene_codec.gd")


func _ready() -> void:
	var base := "res://studio_project"
	StudioRT.assets_root = base
	StudioRT.reset()
	var dir := DirAccess.open(base + "/scripts")
	if dir != null:
		for f in dir.get_files():
			StudioRT.sources[f] = FileAccess.get_file_as_string(base + "/scripts/" + f)
	var scene = JSON.parse_string(FileAccess.get_file_as_string(base + "/scene.json"))
	if scene is Dictionary and scene.has("root"):
		var root := SceneCodec.build(scene["root"], true)
		add_child(root)
		SceneCodec.ensure_defaults(root, self)
	StudioRT.quit_requested.connect(func(): get_tree().quit())
