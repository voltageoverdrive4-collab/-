extends Control
## Gray 2D editor background with grid + origin axes (drawn behind the scene).

var view: Control   # SceneView (provides zoom / pan)


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#4a4a4a"))
	if view == null:
		return
	var z: float = view.zoom
	var pan: Vector2 = view.pan
	var step := 64.0 * z
	while step < 24.0:
		step *= 2.0
	var line := Color(1, 1, 1, 0.06)
	var x := fposmod(pan.x, step)
	while x < size.x:
		draw_line(Vector2(x, 0), Vector2(x, size.y), line)
		x += step
	var y := fposmod(pan.y, step)
	while y < size.y:
		draw_line(Vector2(0, y), Vector2(size.x, y), line)
		y += step
	draw_line(Vector2(0, pan.y), Vector2(size.x, pan.y), Color(1, 0.3, 0.35, 0.7), 1.5)
	draw_line(Vector2(pan.x, 0), Vector2(pan.x, size.y), Color(0.4, 1, 0.45, 0.7), 1.5)
