extends HSplitContainer
## The "Script" main screen: open-scripts list, method list, code editor, find bar, menus.

signal changed
signal new_script_requested
signal rename_requested(file: String)
signal delete_requested(file: String)
signal prompt_requested(title: String, initial: String, cb: Callable)
signal docs_requested

const ProjectStore = preload("res://scripts/project_store.gd")

enum S { NEW, SAVE, SAVE_ALL, RENAME, DELETE, CLOSE, UNDO, REDO, CUT, COPY, PASTE, ALL, COMMENT, INDENT, DEDENT, DUP, DELLINE, FIND, NEXT, PREV, GOTO }

static var _re_gd_func := RegEx.create_from_string("^\\s*(?:static\\s+)?func\\s+(\\w+)")
static var _re_sts_func := RegEx.create_from_string("^\\s*(?:to|on)\\s+(\\w+)")

@onready var script_list: ItemList = %ScriptList
@onready var script_filter: LineEdit = %ScriptFilter
@onready var method_list: ItemList = %MethodList
@onready var method_filter: LineEdit = %MethodFilter
@onready var code = %CodeEditor
@onready var title_label: Label = %ScriptTitle
@onready var find_bar: HBoxContainer = %FindBar
@onready var find_field: LineEdit = %FindField
@onready var status_pos: Label = %StatusPos

var pid := ""
var open_files: Array = []
var texts := {}
var modified := {}
var current := ""
var class_resolver := Callable()
var _method_timer: Timer


func _ready() -> void:
	_method_timer = Timer.new()
	_method_timer.one_shot = true
	_method_timer.wait_time = 0.4
	_method_timer.timeout.connect(_update_methods)
	add_child(_method_timer)

	_fill(%ScriptMenuFile, [["New Script…", S.NEW], ["Save", S.SAVE], ["Save All", S.SAVE_ALL], "-", ["Rename…", S.RENAME], ["Delete…", S.DELETE], "-", ["Close", S.CLOSE]])
	_fill(%ScriptMenuEdit, [["Undo", S.UNDO], ["Redo", S.REDO], "-", ["Cut", S.CUT], ["Copy", S.COPY], ["Paste", S.PASTE], ["Select All", S.ALL], "-",
		["Toggle Comment", S.COMMENT, KEY_MASK_CTRL | KEY_K], ["Indent", S.INDENT], ["Dedent", S.DEDENT],
		["Duplicate Line", S.DUP, KEY_MASK_CTRL | KEY_MASK_SHIFT | KEY_D], ["Delete Line", S.DELLINE]])
	_fill(%ScriptMenuSearch, [["Find…", S.FIND, KEY_MASK_CTRL | KEY_F], ["Find Next", S.NEXT, KEY_F3], ["Find Previous", S.PREV, KEY_MASK_SHIFT | KEY_F3]])
	_fill(%ScriptMenuGoTo, [["Go to Line…", S.GOTO, KEY_MASK_CTRL | KEY_L]])

	script_list.item_selected.connect(_on_list_selected)
	script_filter.text_changed.connect(_on_script_filter)
	method_list.item_selected.connect(_on_method_selected)
	method_filter.text_changed.connect(_on_script_filter)
	code.text_changed.connect(_on_text_changed)
	code.caret_changed.connect(_on_caret)
	find_field.text_submitted.connect(_on_find_submit)
	%FindNextBtn.pressed.connect(_find.bind(false))
	%FindPrevBtn.pressed.connect(_find.bind(true))
	%FindCloseBtn.pressed.connect(find_bar.hide)
	%DocsBtn.pressed.connect(docs_requested.emit)
	_show_empty()


func _fill(btn: MenuButton, items: Array) -> void:
	var pm := btn.get_popup()
	pm.clear()
	for it in items:
		if it is String:
			pm.add_separator()
		else:
			pm.add_item(it[0], it[1], it[2] if it.size() > 2 else 0)
	pm.id_pressed.connect(_on_menu)


func setup(project_id: String) -> void:
	pid = project_id


# ------------------------------------------------------------------ files

func open_file(f: String) -> void:
	if not open_files.has(f):
		open_files.append(f)
		texts[f] = ProjectStore.read_script(pid, f)
	_show(f)


func _show(f: String) -> void:
	_stash()
	current = f
	code.editable = true
	code.text = texts[f]
	code.clear_undo_history()
	code.set_language(f.get_extension())
	if class_resolver.is_valid():
		code.base_class = class_resolver.call(f)
	title_label.text = f
	refresh_list()
	_update_methods()


func _show_empty() -> void:
	current = ""
	code.text = ""
	code.editable = false
	title_label.text = "No script open. Create one with File → New Script, or double-click a script in the FileSystem."
	refresh_list()
	method_list.clear()


func _stash() -> void:
	if current != "" and texts.has(current):
		texts[current] = code.text


func refresh_list() -> void:
	script_list.clear()
	var q := script_filter.text.strip_edges().to_lower()
	for f in open_files:
		if q != "" and not str(f).to_lower().contains(q):
			continue
		var idx := script_list.add_item(("%s (*)" % f) if modified.has(f) else str(f))
		script_list.set_item_metadata(idx, f)
		if f == current:
			script_list.select(idx)


func save_current() -> void:
	if current == "":
		return
	texts[current] = code.text
	ProjectStore.write_script(pid, current, code.text)
	modified.erase(current)
	refresh_list()


func save_all() -> void:
	_stash()
	for f in open_files:
		if modified.has(f):
			ProjectStore.write_script(pid, f, texts[f])
	modified.clear()
	refresh_list()


func close_file(f: String) -> void:
	_stash()
	if modified.has(f):
		ProjectStore.write_script(pid, f, texts[f])
	open_files.erase(f)
	texts.erase(f)
	modified.erase(f)
	if current == f:
		if open_files.is_empty():
			_show_empty()
		else:
			_show(open_files.back())
	else:
		refresh_list()


func on_renamed(old: String, new_name: String) -> void:
	_stash()
	var i := open_files.find(old)
	if i >= 0:
		open_files[i] = new_name
		texts[new_name] = texts.get(old, "")
		texts.erase(old)
		if modified.has(old):
			modified.erase(old)
			modified[new_name] = true
	if current == old:
		current = new_name
		title_label.text = new_name
		code.set_language(new_name.get_extension())
	refresh_list()


func on_deleted(f: String) -> void:
	open_files.erase(f)
	texts.erase(f)
	modified.erase(f)
	if current == f:
		current = ""
		if open_files.is_empty():
			_show_empty()
		else:
			_show(open_files.back())
	else:
		refresh_list()


# ------------------------------------------------------------------ signals

func _on_list_selected(i: int) -> void:
	var f: String = script_list.get_item_metadata(i)
	if f != current:
		_show(f)


func _on_script_filter(_t: String) -> void:
	refresh_list()
	_update_methods()


func _on_text_changed() -> void:
	if current == "":
		return
	texts[current] = code.text
	if not modified.has(current):
		modified[current] = true
		refresh_list()
	changed.emit()
	_method_timer.start()


func _on_caret() -> void:
	status_pos.text = "%d : %d" % [code.get_caret_line() + 1, code.get_caret_column() + 1]


func _update_methods() -> void:
	method_list.clear()
	if current == "":
		return
	var q := method_filter.text.strip_edges().to_lower()
	var re: RegEx = _re_sts_func if current.get_extension() == "sts" else _re_gd_func
	var lines: PackedStringArray = code.text.split("\n")
	for i in lines.size():
		var m := re.search(lines[i])
		if m == null:
			continue
		var n := m.get_string(1)
		if q != "" and not n.to_lower().contains(q):
			continue
		var idx := method_list.add_item(n)
		method_list.set_item_metadata(idx, i)


func _on_method_selected(i: int) -> void:
	var line: int = method_list.get_item_metadata(i)
	code.set_caret_line(line)
	code.set_caret_column(0)
	code.center_viewport_to_caret()
	code.grab_focus()


# ------------------------------------------------------------------ menus / find

func _on_menu(id: int) -> void:
	match id:
		S.NEW: new_script_requested.emit()
		S.SAVE: save_current()
		S.SAVE_ALL: save_all()
		S.RENAME:
			if current != "":
				rename_requested.emit(current)
		S.DELETE:
			if current != "":
				delete_requested.emit(current)
		S.CLOSE:
			if current != "":
				close_file(current)
		S.UNDO: code.undo()
		S.REDO: code.redo()
		S.CUT: code.cut()
		S.COPY: code.copy()
		S.PASTE: code.paste()
		S.ALL: code.select_all()
		S.COMMENT: code.toggle_comment()
		S.INDENT: code.indent_lines()
		S.DEDENT: code.unindent_lines()
		S.DUP: code.duplicate_lines()
		S.DELLINE: code.delete_lines()
		S.FIND:
			find_bar.show()
			find_field.grab_focus()
			find_field.select_all()
		S.NEXT: _find(false)
		S.PREV: _find(true)
		S.GOTO: prompt_requested.emit("Go to Line", str(code.get_caret_line() + 1), _goto_line)


func _goto_line(text: String) -> void:
	if not text.is_valid_int():
		return
	code.set_caret_line(clampi(text.to_int() - 1, 0, code.get_line_count() - 1))
	code.set_caret_column(0)
	code.center_viewport_to_caret()
	code.grab_focus()


func _on_find_submit(_t: String) -> void:
	_find(false)


func _find(backwards: bool) -> void:
	var q := find_field.text
	if q == "" or current == "":
		return
	var line: int = code.get_caret_line()
	var col: int = code.get_caret_column()
	if code.has_selection():
		if backwards:
			line = code.get_selection_from_line()
			col = code.get_selection_from_column()
		else:
			line = code.get_selection_to_line()
			col = code.get_selection_to_column()
	var flags := TextEdit.SEARCH_BACKWARDS if backwards else 0
	var r: Vector2i = code.search(q, flags, line, col)
	if r.x == -1:   # wrap around
		var last: int = code.get_line_count() - 1
		r = code.search(q, flags, last if backwards else 0, code.get_line(last).length() if backwards else 0)
	if r.x != -1:
		code.select(r.y, r.x, r.y, r.x + q.length())
		code.center_viewport_to_caret()
