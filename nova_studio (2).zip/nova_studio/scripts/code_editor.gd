extends CodeEdit
## Script editor widget: GDScript / Studio Script highlighting (Godot colours), completion, comment toggle.

const CTRL_WORDS := ["if", "elif", "else", "for", "while", "match", "break", "continue", "pass", "return", "await"]
const KEYWORDS := ["var", "func", "const", "signal", "class", "extends", "class_name", "enum", "static", "is", "as", "in",
	"and", "or", "not", "self", "true", "false", "null", "preload", "super", "assert", "breakpoint", "void", "PI", "TAU", "INF", "NAN"]
const STS_WORDS := ["on", "to", "say", "set", "change", "repeat", "times", "wait", "seconds", "use"]
const BASE_TYPES := ["int", "float", "bool", "String", "StringName", "Vector2", "Vector2i", "Vector3", "Vector3i", "Vector4",
	"Color", "Rect2", "Transform2D", "Transform3D", "Basis", "Quaternion", "Array", "Dictionary", "NodePath", "RID",
	"Callable", "Signal", "Variant", "PackedByteArray", "PackedStringArray", "PackedVector2Array", "PackedFloat32Array", "PackedInt32Array"]
const BUILTINS := ["print", "prints", "printerr", "print_rich", "push_error", "push_warning", "range", "len", "str", "abs", "absf",
	"absi", "min", "max", "mini", "maxi", "minf", "maxf", "clamp", "clampf", "clampi", "lerp", "lerpf", "randf", "randi",
	"randi_range", "randf_range", "randomize", "sin", "cos", "tan", "sqrt", "pow", "floor", "ceil", "round", "sign", "snapped",
	"wrapf", "wrapi", "deg_to_rad", "rad_to_deg", "typeof", "is_instance_valid", "load", "var_to_str", "str_to_var",
	"move_toward", "smoothstep", "fmod", "fposmod", "posmod", "atan2", "asin", "acos", "is_equal_approx", "is_zero_approx"]

static var _re_dot := RegEx.create_from_string("(\\w+)\\.\\w*$")
static var _re_symbols := RegEx.create_from_string("(?m)^[ \\t]*(?:static[ \\t]+)?(var|func|const|signal)[ \\t]+(\\w+)")

var base_class := "Node"
var _hl_gd: CodeHighlighter
var _hl_sts: CodeHighlighter
var _members_cache := {}


func _ready() -> void:
	gutters_draw_line_numbers = true
	gutters_draw_fold_gutter = true
	line_folding = true
	indent_use_spaces = false
	indent_size = 4
	indent_automatic = true
	auto_brace_completion_enabled = true
	auto_brace_completion_highlight_matching = true
	code_completion_enabled = true
	code_completion_prefixes = ["."]
	highlight_current_line = true
	highlight_all_occurrences = true
	draw_tabs = true
	minimap_draw = true
	caret_blink = true
	scroll_smooth = true
	delimiter_strings = ["' '", "\" \""]
	delimiter_comments = ["#"]

	var f := SystemFont.new()
	f.font_names = PackedStringArray(["JetBrains Mono", "Cascadia Mono", "Consolas", "Menlo", "DejaVu Sans Mono", "monospace"])
	add_theme_font_override("font", f)
	add_theme_font_size_override("font_size", 15)
	add_theme_color_override("background_color", Color("#1d1d1f"))
	add_theme_color_override("font_color", Color("#d4d7dd"))
	add_theme_color_override("font_readonly_color", Color("#8a8f98"))
	add_theme_color_override("caret_color", Color("#ffffff"))
	add_theme_color_override("current_line_color", Color(1, 1, 1, 0.05))
	add_theme_color_override("line_number_color", Color("#5f6672"))
	add_theme_color_override("selection_color", Color(0.3, 0.5, 0.9, 0.35))
	add_theme_color_override("word_highlighted_color", Color(1, 1, 1, 0.08))
	add_theme_color_override("completion_background_color", Color("#2a2c31"))
	add_theme_color_override("completion_selected_color", Color(1, 1, 1, 0.1))

	_hl_gd = _make_highlighter(false)
	_hl_sts = _make_highlighter(true)
	syntax_highlighter = _hl_gd
	code_completion_requested.connect(_on_completion)


func set_language(ext: String) -> void:
	syntax_highlighter = _hl_sts if ext == "sts" else _hl_gd


func _make_highlighter(sts: bool) -> CodeHighlighter:
	var h := CodeHighlighter.new()
	h.number_color = Color("#a1ffe0")
	h.symbol_color = Color("#abc9ff")
	h.function_color = Color("#57b3ff")
	h.member_variable_color = Color("#bce0ff")
	for k in CTRL_WORDS:
		h.add_keyword_color(k, Color("#ff8ccc"))
	for k in KEYWORDS:
		h.add_keyword_color(k, Color("#ff7085"))
	if sts:
		for k in STS_WORDS:
			h.add_keyword_color(k, Color("#ff7085"))
	for c in ClassDB.get_class_list():
		h.add_keyword_color(c, Color("#8fffdb"))
	for t in BASE_TYPES:
		h.add_keyword_color(t, Color("#42ffc2"))
	for b in BUILTINS:
		h.add_keyword_color(b, Color("#57b3ff"))
	h.add_color_region("\"\"\"", "\"\"\"", Color("#ffeda1"), false)
	h.add_color_region("\"", "\"", Color("#ffeda1"), true)
	h.add_color_region("'", "'", Color("#ffeda1"), true)
	h.add_color_region("##", "", Color("#9db0cc"), true)
	h.add_color_region("#", "", Color(0.8, 0.81, 0.82, 0.5), true)
	return h


# ------------------------------------------------------------------ completion

func _members(cls: String) -> Array:
	if _members_cache.has(cls):
		return _members_cache[cls]
	var out := []
	var seen := {}
	if ClassDB.class_exists(cls):
		for m in ClassDB.class_get_method_list(cls):
			var n: String = m["name"]
			if not seen.has(n):
				seen[n] = true
				out.append([n, "func"])
		for p in ClassDB.class_get_property_list(cls):
			var n2: String = p["name"]
			if not seen.has(n2) and not n2.contains("/") and (int(p["usage"]) & PROPERTY_USAGE_EDITOR) != 0:
				seen[n2] = true
				out.append([n2, "prop"])
		for s in ClassDB.class_get_signal_list(cls):
			var n3: String = s["name"]
			if not seen.has(n3):
				seen[n3] = true
				out.append([n3, "signal"])
	_members_cache[cls] = out
	return out


func _add_member(item: Array) -> void:
	var n: String = item[0]
	match item[1]:
		"func": add_code_completion_option(CodeEdit.KIND_FUNCTION, n + "()", n + "(", Color("#57b3ff"))
		"signal": add_code_completion_option(CodeEdit.KIND_SIGNAL, n, n, Color("#ffb86b"))
		_: add_code_completion_option(CodeEdit.KIND_MEMBER, n, n, Color("#bce0ff"))


func _on_completion() -> void:
	var line := get_line(get_caret_line()).substr(0, get_caret_column())
	var m := _re_dot.search(line)
	if m != null:
		var recv := m.get_string(1)
		if recv == "StudioRT":
			for n in ["out", "outs", "err", "warn", "load_script", "quit_game"]:
				add_code_completion_option(CodeEdit.KIND_FUNCTION, n + "()", n + "(", Color("#57b3ff"))
		else:
			for it in _members(recv if ClassDB.class_exists(recv) else base_class):
				_add_member(it)
	else:
		for k in CTRL_WORDS + KEYWORDS:
			add_code_completion_option(CodeEdit.KIND_PLAIN_TEXT, k, k, Color("#ff7085"))
		for b in BUILTINS:
			add_code_completion_option(CodeEdit.KIND_FUNCTION, b + "()", b + "(", Color("#57b3ff"))
		for t in BASE_TYPES:
			add_code_completion_option(CodeEdit.KIND_CLASS, t, t, Color("#42ffc2"))
		for c in ClassDB.get_class_list():
			add_code_completion_option(CodeEdit.KIND_CLASS, c, c, Color("#8fffdb"))
		for sm in _re_symbols.search_all(text):
			var kind := sm.get_string(1)
			var nm := sm.get_string(2)
			add_code_completion_option(CodeEdit.KIND_FUNCTION if kind == "func" else CodeEdit.KIND_VARIABLE, nm, nm, Color("#bce0ff"))
		for it in _members(base_class):
			_add_member(it)
	update_code_completion_options(true)


# ------------------------------------------------------------------ editing helpers

func toggle_comment() -> void:
	var from := get_caret_line()
	var to := from
	if has_selection():
		from = get_selection_from_line()
		to = get_selection_to_line()
		if get_selection_to_column() == 0 and to > from:
			to -= 1
	var all_commented := true
	for l in range(from, to + 1):
		var t := get_line(l).strip_edges()
		if t != "" and not t.begins_with("#"):
			all_commented = false
	begin_complex_operation()
	for l in range(from, to + 1):
		var line := get_line(l)
		if line.strip_edges() == "":
			continue
		var idx := line.length() - line.strip_edges(true, false).length()
		if all_commented:
			var rest := line.substr(idx + 1)
			if rest.begins_with(" "):
				rest = rest.substr(1)
			set_line(l, line.substr(0, idx) + rest)
		else:
			set_line(l, line.substr(0, idx) + "# " + line.substr(idx))
	end_complex_operation()
