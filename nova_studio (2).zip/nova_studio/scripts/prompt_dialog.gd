extends ConfirmationDialog
## Generic "type a value" dialog. Usage: dialog.ask("Rename", "old", func(text): ...)

var _cb := Callable()

@onready var field: LineEdit = $Box/Field
@onready var hint: Label = $Box/Hint


func _ready() -> void:
	confirmed.connect(_ok)
	field.text_submitted.connect(_submit)


func ask(title_text: String, initial: String, cb: Callable, hint_text := "") -> void:
	title = title_text
	field.text = initial
	hint.text = hint_text
	hint.visible = hint_text != ""
	_cb = cb
	popup_centered(Vector2i(440, 0))
	field.grab_focus()
	field.select_all()


func _submit(_t: String) -> void:
	_ok()
	hide()


func _ok() -> void:
	if _cb.is_valid():
		_cb.call(field.text.strip_edges())
