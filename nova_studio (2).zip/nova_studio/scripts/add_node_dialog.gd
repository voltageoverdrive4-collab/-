extends ConfirmationDialog
## "Create New Node": the Node Library (common nodes with descriptions + example code)
## and the full list of every Godot node class.

signal node_chosen(type: String)

const Icons = preload("res://scripts/icons.gd")
const NodeLibrary = preload("res://scripts/node_library.gd")

@onready var search: LineEdit = %Search
@onready var tree: Tree = %Matches
@onready var desc: RichTextLabel = %Description
@onready var copy_btn: Button = %CopyExample
@onready var recent_list: ItemList = %Recent

var _base := "Node"
var _example := ""


func _ready() -> void:
	confirmed.connect(_on_confirmed)
	search.text_changed.connect(_on_search)
	tree.item_selected.connect(_on_selected)
	tree.item_activated.connect(_on_activated)
	recent_list.item_activated.connect(_on_recent)
	copy_btn.pressed.connect(_on_copy)


func open(base: String = "Node") -> void:
	_base = base
	search.text = ""
	_fill()
	popup_centered(Vector2i(980, 700))
	search.grab_focus()


# ------------------------------------------------------------------ helpers

func _hidden_class(c: String) -> bool:
	return c.begins_with("Editor") or c.begins_with("OpenXR") or c.begins_with("XR")


func _creatable(type: String) -> bool:
	if not ClassDB.class_exists(type) or not ClassDB.can_instantiate(type):
		return false
	return type == "Node" or ClassDB.is_parent_class(type, "Node")


func _reason(type: String) -> String:
	if not ClassDB.class_exists(type):
		return "This node type doesn't exist in your version of Godot."
	if type != "Node" and not ClassDB.is_parent_class(type, "Node"):
		return "This is not a node. It is created from code inside a script."
	return "This is an abstract base class and can't be created directly. Add one of its child types instead."


func _color_for(c: String) -> Color:
	if not ClassDB.class_exists(c):
		return Color("#777777")
	if ClassDB.is_parent_class(c, "Control"):
		return Color("#6bd16b")
	if ClassDB.is_parent_class(c, "Node3D"):
		return Color("#ff6b7a")
	if ClassDB.is_parent_class(c, "Node2D"):
		return Color("#5aa0ff")
	return Color("#d0d4da")


func _header(parent: TreeItem, text: String) -> TreeItem:
	var it := tree.create_item(parent)
	it.set_text(0, text)
	it.set_selectable(0, false)
	it.set_custom_color(0, Color("#8ec5ff"))
	return it


func _add_entry(parent: TreeItem, type: String, lib: Dictionary) -> void:
	var it := tree.create_item(parent)
	var ok := _creatable(type)
	it.set_text(0, type if ok else type + "   (disabled)")
	it.set_metadata(0, {"type": type, "lib": lib})
	it.set_icon(0, Icons.dot(_color_for(type)))
	if not ok:
		it.set_custom_color(0, Color(1, 1, 1, 0.4))


func _fill() -> void:
	tree.clear()
	tree.hide_root = true
	get_ok_button().disabled = true
	desc.text = "Select a node to see what it does and an example of how to use it."
	copy_btn.visible = false
	var root := tree.create_item()
	var q := search.text.strip_edges().to_lower()
	if q == "":
		var lib := _header(root, "★  Node Library  (common nodes with examples)")
		for cat in NodeLibrary.CATEGORIES:
			var ci := _header(lib, cat["name"])
			for n in cat["nodes"]:
				_add_entry(ci, n["type"], n)
		var all := _header(root, "All Godot nodes  (full class list)")
		_build(all, _base)
		all.collapsed = true
		return
	var seen := {}
	for cat in NodeLibrary.CATEGORIES:
		for n in cat["nodes"]:
			if str(n["type"]).to_lower().contains(q) or str(n["desc"]).to_lower().contains(q):
				_add_entry(root, n["type"], n)
				seen[n["type"]] = true
	var classes := [_base]
	for c in ClassDB.get_inheriting_classes_from_class(_base):
		classes.append(c)
	classes.sort()
	for c in classes:
		if not seen.has(c) and not _hidden_class(c) and str(c).to_lower().contains(q):
			_add_entry(root, c, {})


func _build(parent: TreeItem, cls: String) -> void:
	var it := tree.create_item(parent)
	var ok := _creatable(cls)
	it.set_text(0, cls if ok else cls + "   (disabled)")
	it.set_metadata(0, {"type": cls, "lib": NodeLibrary.find(cls)})
	it.set_icon(0, Icons.dot(_color_for(cls)))
	if not ok:
		it.set_custom_color(0, Color(1, 1, 1, 0.4))
	it.collapsed = parent != null and parent.get_parent() != null
	var kids := []
	for c in ClassDB.get_inheriting_classes_from_class(cls):
		if ClassDB.get_parent_class(c) == cls and not _hidden_class(c):
			kids.append(c)
	kids.sort()
	for k in kids:
		_build(it, k)


# ------------------------------------------------------------------ signals

func _on_search(_t: String) -> void:
	_fill()


func _on_selected() -> void:
	var it := tree.get_selected()
	if it == null:
		return
	var meta = it.get_metadata(0)
	if not (meta is Dictionary):
		return
	var t: String = meta["type"]
	var lib: Dictionary = meta.get("lib", {})
	var txt := "[b][color=#8ec5ff]%s[/color][/b]" % t
	if ClassDB.class_exists(t):
		var chain := PackedStringArray()
		var cur := ClassDB.get_parent_class(t)
		while cur != "":
			chain.append(cur)
			cur = ClassDB.get_parent_class(cur)
		if not chain.is_empty():
			txt += "   <   " + "   <   ".join(chain)
	if lib.has("desc"):
		txt += "\n" + str(lib["desc"]).replace("[", "[lb]")
	var ok := _creatable(t)
	if not ok:
		txt += "\n[color=#ff9a9a][b]Disabled:[/b] %s[/color]" % _reason(t)
	_example = str(lib.get("example", ""))
	if _example != "":
		txt += "\n\n[b]Example[/b]\n[bgcolor=#101010][color=#d6e4ff][code]%s[/code][/color][/bgcolor]" % _example.replace("[", "[lb]")
	desc.text = txt
	copy_btn.visible = _example != ""
	copy_btn.text = "Copy example"
	get_ok_button().disabled = not ok


func _on_copy() -> void:
	DisplayServer.clipboard_set(_example)
	copy_btn.text = "Copied!"
	await get_tree().create_timer(1.0).timeout
	if is_instance_valid(copy_btn):
		copy_btn.text = "Copy example"


func _selected_type() -> String:
	var it := tree.get_selected()
	if it == null:
		return ""
	var meta = it.get_metadata(0)
	return str(meta["type"]) if meta is Dictionary else ""


func _on_activated() -> void:
	var t := _selected_type()
	if t != "" and _creatable(t):
		_emit(t)
		hide()


func _on_recent(i: int) -> void:
	_emit(recent_list.get_item_text(i))
	hide()


func _on_confirmed() -> void:
	var t := _selected_type()
	if t != "" and _creatable(t):
		_emit(t)


func _emit(cls: String) -> void:
	for i in recent_list.item_count:
		if recent_list.get_item_text(i) == cls:
			recent_list.remove_item(i)
			break
	recent_list.add_item(cls, Icons.dot(_color_for(cls)))
	node_chosen.emit(cls)
