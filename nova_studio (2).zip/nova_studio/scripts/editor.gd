extends Control
## Nova Studio editor: one instance per open project (editor.tscn is created every time you open one).

const ProjectStore = preload("res://scripts/project_store.gd")
const SceneCodec = preload("res://scripts/scene_codec.gd")
const ScriptTools = preload("res://scripts/script_tools.gd")
const Icons = preload("res://scripts/icons.gd")
const NodeLibrary = preload("res://scripts/node_library.gd")
const SelfCheck = preload("res://scripts/self_check.gd")

enum M { SAVE, UNDO, REDO, ADD, QUICK, DUP, DEL, NEW_SCRIPT, HOME, SETTINGS, EXPORT, OPEN_FOLDER, RELOAD, RUN, STOP, CLEAR,
	BOTTOM, FIT, DOCS, ABOUT, IMPORT_IMAGE, T_ADD, T_ATTACH, T_OPEN, T_CLEAR, T_RENAME, T_DUP, T_UP, T_DOWN, T_DEL,
	F_NEW, F_OPEN, F_RENAME, F_DELETE, F_IMPORT }

@onready var menu_scene: MenuButton = %MenuScene
@onready var menu_project: MenuButton = %MenuProject
@onready var menu_debug: MenuButton = %MenuDebug
@onready var menu_editor: MenuButton = %MenuEditor
@onready var menu_help: MenuButton = %MenuHelp
@onready var scene_more: MenuButton = %SceneMore
@onready var tab_2d: Button = %Tab2D
@onready var tab_3d: Button = %Tab3D
@onready var tab_script: Button = %TabScript
@onready var tab_game: Button = %TabGame
@onready var play_btn: Button = %PlayBtn
@onready var pause_btn: Button = %PauseBtn
@onready var stop_btn: Button = %StopBtn
@onready var scene_tree: Tree = %SceneTree
@onready var root_chooser: Control = %RootChooser
@onready var scene_filter: LineEdit = %SceneFilter
@onready var add_btn: Button = %AddNodeBtn
@onready var attach_btn: Button = %AttachBtn
@onready var file_tree: Tree = %FileTree
@onready var file_filter: LineEdit = %FileFilter
@onready var view_area: Control = %View2D
@onready var script_screen = %ScriptScreen
@onready var game_screen: Control = %GameScreen
@onready var scene_view = %SceneView
@onready var grid_bg: Control = %GridBg
@onready var edit_vp: SubViewport = %EditViewport
@onready var frame: Control = %SceneFrame
@onready var game_vp: SubViewport = %GameViewport
@onready var game_aspect: AspectRatioContainer = %GameAspect
@onready var game_backdrop: ColorRect = %GameBackdrop
@onready var game_hint: Label = %GameHint
@onready var scene_tab_label: Label = %SceneTabLabel
@onready var zoom_label: Label = %ZoomLabel
@onready var view_hint: Label = %ViewHint
@onready var output = %OutputPanel
@onready var inspector = %InspectorPanel
@onready var add_dialog = %AddNodeDialog
@onready var script_dialog = %ScriptDialog
@onready var settings_dialog = %SettingsDialog
@onready var prompt = %PromptDialog
@onready var docs = %DocsWindow
@onready var confirm: ConfirmationDialog = %ConfirmDialog
@onready var export_dialog: FileDialog = %ExportDialog
@onready var image_dialog: FileDialog = %ImageDialog
@onready var tree_menu: PopupMenu = %TreeMenu
@onready var file_menu: PopupMenu = %FileMenu
@onready var autosave: Timer = %AutoSave

var pid := ""
var meta := {}
var scene_root: Node = null
var selected: Node = null
var screen := "2d"
var undo_stack: Array = []
var redo_stack: Array = []
var play_root: Node = null
var running := false

var _adding_root := false
var _script_attach := false
var _pending_image := {}
var _rename_target := ""
var _delete_target := ""
var _confirm_cb := Callable()
var _saved_fps := 0
var _saved_phys := 60
var _engine_saved := false
var _problems: Array = []
var quick_menu: PopupMenu


func _ready() -> void:
	pid = StudioRT.current_project
	meta = ProjectStore.load_meta(pid)
	if meta.is_empty():
		get_tree().change_scene_to_file("res://home.tscn")
		return
	StudioRT.assets_root = ProjectStore.dir_of(pid)
	_setup_menus()
	_build_quick_menu()
	_connect_ui()
	play_btn.icon = Icons.play(Color("#7ee787"))
	pause_btn.icon = Icons.pause(Color("#e6e6e6"))
	stop_btn.icon = Icons.stop(Color("#ff7b72"))
	scene_tree.set_column_expand(1, false)
	scene_tree.set_column_custom_minimum_width(1, 90)
	if scene_view.has_method("setup"):
		scene_view.setup(edit_vp, grid_bg, frame)
		grid_bg.set("view", scene_view)
	PhysicsServer2D.space_set_active(edit_vp.find_world_2d().space, false)   # nothing falls while editing
	PhysicsServer3D.space_set_active(edit_vp.find_world_3d().space, false)
	_apply_settings()
	if script_screen.has_method("setup"):
		script_screen.setup(pid)
		script_screen.set("class_resolver", _class_for_script)
	_load_scene()
	_rebuild_files()
	_show_screen("3d" if scene_root is Node3D else "2d")
	_log("Project '%s' opened." % meta["name"], "editor")
	_self_check()
	call_deferred("_fit_view")


## Connects a signal, but reports a readable problem instead of crashing the whole setup.
func _link(obj: Object, sig: String, cb: Callable) -> void:
	if obj == null:
		_problems.append("A node needed for '%s' is missing from editor.tscn." % sig)
	elif not obj.has_signal(sig):
		_problems.append("%s has no signal '%s' (its script probably failed to compile)." % [obj, sig])
	elif not cb.is_valid():
		_problems.append("Handler for '%s' on %s is missing." % [sig, obj])
	else:
		obj.connect(sig, cb)


func _log(text: String, kind: String = "info") -> void:
	if output != null and output.has_method("add"):
		output.add(text, kind)
	else:
		print("[Nova Studio] ", text)


func _self_check() -> void:
	for p in _problems:
		_log("Setup problem: " + str(p), "error")
	var bad := SelfCheck.broken_scripts()
	if not bad.is_empty():
		_log("These scripts have errors and won't work: %s. Open Godot's Debugger > Errors to read the red message." % ", ".join(bad), "error")
	elif _problems.is_empty():
		_log("Editor ready. Add nodes with the + button, the Create Root Node buttons, or Scene > Quick Add Node.", "editor")


func _sv(prop: String, value: Variant) -> void:
	if prop in scene_view:
		scene_view.set(prop, value)


func _exit_tree() -> void:
	_restore_engine()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST and pid != "":
		save_project()


# =========================================================================
# Setup
# =========================================================================

func _fill(btn: MenuButton, items: Array) -> void:
	var pm := btn.get_popup()
	pm.clear()
	for it in items:
		if it is String:
			pm.add_separator()
		else:
			pm.add_item(it[0], it[1], it[2] if it.size() > 2 else 0)
	pm.id_pressed.connect(_on_menu)


func _setup_menus() -> void:
	_fill(menu_scene, [["Save Scene", M.SAVE, KEY_MASK_CTRL | KEY_S], ["Undo", M.UNDO], ["Redo", M.REDO], "-",
		["Add Child Node…", M.ADD], ["Quick Add Node ▸", M.QUICK], ["Duplicate Node", M.DUP], ["Delete Node", M.DEL], "-",
		["New Script…", M.NEW_SCRIPT], "-", ["Close Project (Home)", M.HOME]])
	_fill(menu_project, [["Project Settings…", M.SETTINGS], ["Export Project (.zip)…", M.EXPORT], "-",
		["Import Image…", M.IMPORT_IMAGE], ["Open Project Folder", M.OPEN_FOLDER], "-", ["Reload Saved Scene", M.RELOAD]])
	_fill(menu_debug, [["Run Project", M.RUN, KEY_F5], ["Stop", M.STOP, KEY_F8], "-", ["Clear Output", M.CLEAR]])
	_fill(menu_editor, [["Toggle Output Panel", M.BOTTOM], ["Fit 2D View", M.FIT]])
	_fill(menu_help, [["Script Docs (Studio Script)", M.DOCS, KEY_F1], ["About", M.ABOUT]])
	_fill(scene_more, [["Rename", M.T_RENAME], ["Duplicate", M.T_DUP], ["Move Up", M.T_UP], ["Move Down", M.T_DOWN], "-",
		["Clear Script", M.T_CLEAR], ["Delete", M.T_DEL]])


func _connect_ui() -> void:
	_link(tab_2d, "pressed", _show_screen.bind("2d"))
	_link(tab_3d, "pressed", _show_screen.bind("3d"))
	_link(tab_script, "pressed", _show_screen.bind("script"))
	_link(tab_game, "pressed", _show_screen.bind("game"))
	_link(play_btn, "pressed", play)
	_link(pause_btn, "toggled", _on_pause)
	_link(stop_btn, "pressed", stop)
	_link(add_btn, "pressed", _open_add_dialog)
	_link(attach_btn, "pressed", _on_attach_pressed)
	_link(scene_filter, "text_changed", _on_scene_filter)
	_link(scene_tree, "item_selected", _on_tree_selected)
	_link(scene_tree, "item_activated", _rename_selected_in_tree)
	_link(scene_tree, "item_edited", _on_tree_edited)
	_link(scene_tree, "item_mouse_selected", _on_tree_mouse)
	scene_tree.set_drag_forwarding(_tree_drag, _tree_can_drop, _tree_drop)
	scene_tree.drop_mode_flags = Tree.DROP_MODE_INBETWEEN | Tree.DROP_MODE_ON_ITEM
	_link(get_node_or_null("%Root2D"), "pressed", _create_root.bind("Node2D"))
	_link(get_node_or_null("%Root3D"), "pressed", _create_root.bind("Node3D"))
	_link(get_node_or_null("%RootUI"), "pressed", _create_root.bind("Control"))
	_link(get_node_or_null("%RootOther"), "pressed", _open_add_root)
	_link(file_tree, "item_activated", _on_file_activated)
	_link(file_tree, "item_mouse_selected", _on_file_mouse)
	_link(file_filter, "text_changed", _on_file_filter)
	_link(get_node_or_null("%FileNewBtn"), "pressed", _new_script_dialog.bind(false))
	_link(get_node_or_null("%FileImportBtn"), "pressed", _import_image)
	_link(scene_view, "picked", _on_view_picked)
	_link(scene_view, "about_to_edit", checkpoint)
	_link(scene_view, "edited", _on_view_edited)
	_link(scene_view, "live_changed", _on_view_live)
	_link(scene_view, "viewport_resized", _on_viewport_resized)
	_link(get_node_or_null("%SnapBtn"), "toggled", _on_snap)
	_link(get_node_or_null("%FitBtn"), "pressed", _fit_view)
	_link(get_node_or_null("%ZoomIn"), "pressed", _zoom_step.bind(1.25))
	_link(get_node_or_null("%ZoomOut"), "pressed", _zoom_step.bind(0.8))
	_link(inspector, "about_to_change", checkpoint)
	_link(inspector, "changed", _on_inspector_changed)
	_link(inspector, "script_chosen", _on_script_chosen)
	_link(inspector, "open_script_requested", _open_script)
	_link(inspector, "rename_requested", _on_inspector_rename)
	_link(inspector, "image_requested", _on_image_requested)
	_link(add_dialog, "node_chosen", _on_node_chosen)
	_link(script_dialog, "created", _on_script_created)
	_link(settings_dialog, "applied", _on_settings_applied)
	_link(settings_dialog, "export_requested", _export_open)
	_link(export_dialog, "file_selected", _on_export_path)
	_link(image_dialog, "file_selected", _on_image_selected)
	_link(script_screen, "changed", mark_dirty)
	_link(script_screen, "new_script_requested", _new_script_dialog.bind(false))
	_link(script_screen, "rename_requested", _rename_script)
	_link(script_screen, "delete_requested", _delete_script)
	_link(script_screen, "prompt_requested", _prompt_relay)
	_link(script_screen, "docs_requested", _open_docs)
	_link(autosave, "timeout", save_project)
	_link(confirm, "confirmed", _on_confirm)
	_link(tree_menu, "id_pressed", _on_menu)
	_link(file_menu, "id_pressed", _on_menu)
	_link(get_node_or_null("%OutputTab"), "toggled", _toggle_bottom)
	_link(StudioRT, "message", Callable(output, "add"))
	_link(StudioRT, "quit_requested", _on_game_quit)


func _apply_settings() -> void:
	var s := ProjectStore.default_settings()
	s.merge(meta.get("settings", {}), true)
	meta["settings"] = s
	var sz := Vector2(float(s["window_width"]), float(s["window_height"]))
	frame.position = Vector2.ZERO
	frame.size = sz
	game_aspect.ratio = sz.x / maxf(sz.y, 1.0)
	game_vp.size_2d_override = Vector2i(sz)
	game_vp.size_2d_override_stretch = true
	game_backdrop.color = Color.from_string(str(s["bg_color"]), Color("#2b2b2b"))
	scene_tab_label.text = "%s" % meta["name"]
	scene_view.queue_redraw()


func _fit_view() -> void:
	if not scene_view.has_method("fit"):
		return
	scene_view.fit()
	zoom_label.text = "%d%%" % int(scene_view.zoom * 100.0)


func _zoom_step(f: float) -> void:
	if not scene_view.has_method("_zoom_at"):
		return
	scene_view._zoom_at(scene_view.size / 2.0, f)
	zoom_label.text = "%d%%" % int(scene_view.zoom * 100.0)


func _on_snap(on: bool) -> void:
	scene_view.snap = on


# =========================================================================
# Screens / run
# =========================================================================

func _show_screen(s: String) -> void:
	screen = s
	view_area.visible = s == "2d" or s == "3d"
	script_screen.visible = s == "script"
	game_screen.visible = s == "game"
	tab_2d.set_pressed_no_signal(s == "2d")
	tab_3d.set_pressed_no_signal(s == "3d")
	tab_script.set_pressed_no_signal(s == "script")
	tab_game.set_pressed_no_signal(s == "game")
	if (s == "2d" or s == "3d") and scene_view.has_method("set_mode"):
		scene_view.set_mode(s)
		view_hint.text = "Wheel zoom · Right/Middle drag pan · Click select · Drag move · Handles resize · Arrows nudge" if s == "2d" else "Right drag orbit · Middle drag pan · Wheel zoom · Click select · Drag move"
		zoom_label.visible = s == "2d"


func _toggle_bottom(on: bool) -> void:
	output.visible = on


func play() -> void:
	if scene_root == null:
		_log("Nothing to run yet. Create a root node first (2D Scene, 3D Scene, User Interface…).", "warn")
		return
	save_project()
	stop(false)
	StudioRT.reset()
	for f in ProjectStore.list_scripts(pid):
		StudioRT.sources[f] = ProjectStore.read_script(pid, f)
	_apply_engine()
	play_root = SceneCodec.build(SceneCodec.node_to_dict(scene_root), true)
	game_vp.add_child(play_root)
	SceneCodec.ensure_defaults(play_root, game_vp)
	game_hint.visible = false
	_sv("show_gizmos", false)   # no outlines while the game runs
	scene_view.queue_redraw()
	running = true
	pause_btn.set_pressed_no_signal(false)
	_show_screen("game")
	_log("▶ Running '%s'" % meta["name"], "editor")


func stop(announce: bool = true) -> void:
	for c in game_vp.get_children():
		if c != game_backdrop:
			game_vp.remove_child(c)
			c.queue_free()
	play_root = null
	if running and announce:
		_log("■ Stopped", "editor")
	running = false
	game_hint.visible = true
	_sv("show_gizmos", true)
	scene_view.queue_redraw()
	_restore_engine()


func _on_pause(on: bool) -> void:
	if play_root != null:
		play_root.process_mode = Node.PROCESS_MODE_DISABLED if on else Node.PROCESS_MODE_INHERIT


func _on_game_quit() -> void:
	call_deferred("stop")


func _apply_engine() -> void:
	if not _engine_saved:
		_saved_fps = Engine.max_fps
		_saved_phys = Engine.physics_ticks_per_second
		_engine_saved = true
	var s: Dictionary = meta["settings"]
	Engine.max_fps = int(s["max_fps"])
	Engine.physics_ticks_per_second = int(s["physics_fps"])


func _restore_engine() -> void:
	if _engine_saved:
		Engine.max_fps = _saved_fps
		Engine.physics_ticks_per_second = _saved_phys
		_engine_saved = false


# =========================================================================
# Save / load / undo
# =========================================================================

func mark_dirty() -> void:
	autosave.start()
	scene_tab_label.text = "%s (*)" % meta["name"]


func save_project() -> void:
	var data := {}
	if scene_root != null:
		data["root"] = SceneCodec.node_to_dict(scene_root)
	ProjectStore.write_scene(pid, data)
	script_screen.save_all()
	ProjectStore.save_meta(meta)
	scene_tab_label.text = "%s" % meta["name"]


func _load_scene() -> void:
	var d := ProjectStore.load_scene(pid)
	if d.has("root"):
		scene_root = SceneCodec.build(d["root"], false)
		frame.add_child(scene_root)
	_sv("scene_root", scene_root)
	_rebuild_scene_tree()
	select(null)


func _snapshot() -> String:
	return JSON.stringify(SceneCodec.node_to_dict(scene_root)) if scene_root != null else ""


func checkpoint() -> void:
	var snap := _snapshot()
	if undo_stack.is_empty() or undo_stack.back() != snap:
		undo_stack.append(snap)
		if undo_stack.size() > 100:
			undo_stack.pop_front()
	redo_stack.clear()


func undo() -> void:
	if undo_stack.is_empty():
		return
	redo_stack.append(_snapshot())
	_restore(undo_stack.pop_back())


func redo() -> void:
	if redo_stack.is_empty():
		return
	undo_stack.append(_snapshot())
	_restore(redo_stack.pop_back())


func _restore(snap: String) -> void:
	var sel_path := NodePath("")
	if selected != null and scene_root != null and (selected == scene_root or scene_root.is_ancestor_of(selected)):
		sel_path = scene_root.get_path_to(selected)
	if scene_root != null:
		frame.remove_child(scene_root)
		scene_root.queue_free()
		scene_root = null
	if snap != "":
		scene_root = SceneCodec.build(JSON.parse_string(snap), false)
		frame.add_child(scene_root)
	_sv("scene_root", scene_root)
	var sel: Node = null
	if scene_root != null and not sel_path.is_empty():
		sel = scene_root.get_node_or_null(sel_path)
	_rebuild_scene_tree()
	select(sel)
	mark_dirty()


# =========================================================================
# Menus
# =========================================================================

func _on_menu(id: int) -> void:
	match id:
		M.SAVE:
			save_project()
			_log("Project saved.", "editor")
		M.UNDO: undo()
		M.REDO: redo()
		M.ADD, M.T_ADD: _open_add_dialog()
		M.QUICK: _show_quick()
		M.DUP, M.T_DUP: _duplicate()
		M.DEL, M.T_DEL: _delete_selected()
		M.NEW_SCRIPT, M.F_NEW: _new_script_dialog(false)
		M.HOME:
			save_project()
			stop(false)
			get_tree().change_scene_to_file("res://home.tscn")
		M.SETTINGS: settings_dialog.open(meta)
		M.EXPORT: _export_open()
		M.OPEN_FOLDER: OS.shell_show_in_file_manager(ProjectSettings.globalize_path(ProjectStore.dir_of(pid)))
		M.RELOAD:
			_restore_from_disk()
		M.RUN: play()
		M.STOP: stop()
		M.CLEAR: output.clear_log()
		M.BOTTOM: %OutputTab.button_pressed = not %OutputTab.button_pressed
		M.FIT: _fit_view()
		M.DOCS: _open_docs()
		M.ABOUT: _log("Nova Studio 1.0, built with Godot %s." % Engine.get_version_info()["string"], "editor")
		M.IMPORT_IMAGE, M.F_IMPORT: _import_image()
		M.T_ATTACH: _on_attach_pressed()
		M.T_OPEN:
			if selected != null:
				_open_script(str(selected.get_meta("studio_script", "")))
		M.T_CLEAR:
			if selected != null:
				attach_script(selected, "")
		M.T_RENAME: _rename_selected_in_tree()
		M.T_UP: _move_selected(-1)
		M.T_DOWN: _move_selected(1)
		M.F_OPEN:
			var d = _selected_file()
			if d != null and d["kind"] == "script":
				_open_script(d["name"])
		M.F_RENAME:
			var d2 = _selected_file()
			if d2 != null and d2["kind"] == "script":
				_rename_script(d2["name"])
		M.F_DELETE:
			var d3 = _selected_file()
			if d3 != null and d3["kind"] == "script":
				_delete_script(d3["name"])


func _restore_from_disk() -> void:
	checkpoint()
	var d := ProjectStore.load_scene(pid)
	_restore(JSON.stringify(d["root"]) if d.has("root") else "")


func _open_docs() -> void:
	docs.open()


func _prompt_relay(title: String, initial: String, cb: Callable) -> void:
	prompt.ask(title, initial, cb)


func _unhandled_key_input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed):
		return
	if screen == "script" or screen == "game":
		return
	var ctrl: bool = event.ctrl_pressed or event.meta_pressed
	match event.keycode:
		KEY_DELETE:
			_delete_selected()
		KEY_F2:
			_rename_selected_in_tree()
		KEY_Z:
			if ctrl:
				if event.shift_pressed:
					redo()
				else:
					undo()
		KEY_Y:
			if ctrl:
				redo()
		KEY_D:
			if ctrl:
				_duplicate()
		KEY_A:
			if ctrl:
				_open_add_dialog()
		_:
			return
	get_viewport().set_input_as_handled()


# =========================================================================
# Scene tree dock
# =========================================================================

func _node_color(n: Node) -> Color:
	if n is Control:
		return Color("#6bd16b")
	if n is Node3D:
		return Color("#ff6b7a")
	if n is Node2D:
		return Color("#5aa0ff")
	return Color("#d0d4da")


func _on_scene_filter(_t: String) -> void:
	_rebuild_scene_tree()


func _rebuild_scene_tree() -> void:
	scene_tree.clear()
	root_chooser.visible = scene_root == null
	scene_tree.visible = scene_root != null
	if scene_root == null:
		return
	_add_tree_item(null, scene_root, scene_filter.text.strip_edges().to_lower())
	_highlight(selected)


func _add_tree_item(parent: TreeItem, n: Node, q: String) -> bool:
	var item := scene_tree.create_item(parent)
	item.set_text(0, String(n.name))
	item.set_icon(0, Icons.dot(_node_color(n)))
	item.set_metadata(0, n)
	var sc := str(n.get_meta("studio_script", ""))
	if sc != "":
		item.set_text(1, sc)
		item.set_custom_color(1, Color("#8aa0c0"))
	var any := q == "" or String(n.name).to_lower().contains(q)
	for c in n.get_children():
		if _add_tree_item(item, c, q):
			any = true
	if not any and parent != null:
		parent.remove_child(item)
		item.free()
	return any


func _find_item(n: Node) -> TreeItem:
	var root := scene_tree.get_root()
	if root == null or n == null:
		return null
	var stack := [root]
	while not stack.is_empty():
		var it: TreeItem = stack.pop_back()
		if it.get_metadata(0) == n:
			return it
		for c in it.get_children():
			stack.append(c)
	return null


func _highlight(n: Node) -> void:
	var it := _find_item(n)
	if it != null:
		it.select(0)
		scene_tree.scroll_to_item(it)


func _on_tree_selected() -> void:
	var it := scene_tree.get_selected()
	if it == null:
		return
	var n: Node = it.get_metadata(0)
	if scene_tree.get_selected_column() == 1 and n.has_meta("studio_script"):
		_open_script(str(n.get_meta("studio_script")))
	select(n, true)


func _on_tree_mouse(_pos: Vector2, btn: int) -> void:
	if btn != MOUSE_BUTTON_RIGHT or selected == null:
		return
	tree_menu.clear()
	tree_menu.add_item("Add Child Node…", M.T_ADD)
	if selected.has_meta("studio_script"):
		tree_menu.add_item("Open Script", M.T_OPEN)
		tree_menu.add_item("Clear Script", M.T_CLEAR)
	else:
		tree_menu.add_item("Attach Script…", M.T_ATTACH)
	tree_menu.add_separator()
	tree_menu.add_item("Rename", M.T_RENAME)
	tree_menu.add_item("Duplicate", M.T_DUP)
	tree_menu.add_item("Move Up", M.T_UP)
	tree_menu.add_item("Move Down", M.T_DOWN)
	tree_menu.add_separator()
	tree_menu.add_item("Delete Node", M.T_DEL)
	tree_menu.popup(Rect2i(Vector2i(get_global_mouse_position()), Vector2i.ZERO))


func _rename_selected_in_tree() -> void:
	var it := scene_tree.get_selected()
	if it == null:
		return
	it.set_editable(0, true)
	scene_tree.edit_selected(true)


func _on_tree_edited() -> void:
	var it := scene_tree.get_edited()
	if it == null:
		return
	var n: Node = it.get_metadata(0)
	var new_name := it.get_text(0).strip_edges()
	it.set_editable(0, false)
	if new_name != "" and new_name != String(n.name):
		checkpoint()
		n.name = new_name
		mark_dirty()
	call_deferred("_after_rename", n)


func _after_rename(n: Node) -> void:
	_rebuild_scene_tree()
	select(n)


func _tree_drag(at: Vector2) -> Variant:
	var it := scene_tree.get_item_at_position(at)
	if it == null:
		return null
	var n: Node = it.get_metadata(0)
	if n == scene_root:
		return null
	var l := Label.new()
	l.text = String(n.name)
	scene_tree.set_drag_preview(l)
	return {"node": n}


func _tree_can_drop(at: Vector2, data: Variant) -> bool:
	return data is Dictionary and data.has("node") and scene_tree.get_item_at_position(at) != null


func _tree_drop(at: Vector2, data: Variant) -> void:
	var target_item := scene_tree.get_item_at_position(at)
	if target_item == null:
		return
	var section := scene_tree.get_drop_section_at_position(at)
	var n: Node = data["node"]
	var t: Node = target_item.get_metadata(0)
	if t == n or n.is_ancestor_of(t):
		return
	checkpoint()
	var new_parent: Node = t
	var idx := -1
	if section != 0 and t != scene_root:
		new_parent = t.get_parent()
		idx = t.get_index() + (1 if section > 0 else 0)
		if new_parent == n.get_parent() and n.get_index() < t.get_index():
			idx -= 1
	n.reparent(new_parent, true)
	if idx >= 0:
		new_parent.move_child(n, clampi(idx, 0, new_parent.get_child_count() - 1))
	_rebuild_scene_tree()
	select(n)
	mark_dirty()


# =========================================================================
# Selection and node operations
# =========================================================================

func select(n: Node, from_tree: bool = false) -> void:
	selected = n if (n != null and is_instance_valid(n)) else null
	_sv("selected", selected)
	scene_view.queue_redraw()
	if inspector.has_method("inspect"):
		inspector.scripts = ProjectStore.list_scripts(pid)
		inspector.current_script = str(selected.get_meta("studio_script", "")) if selected != null else ""
		inspector.inspect(selected)
	attach_btn.disabled = selected == null
	attach_btn.tooltip_text = "Open script" if (selected != null and selected.has_meta("studio_script")) else "Attach a new script to the selected node"
	if not from_tree:
		_highlight(selected)


func _on_view_picked(n: Node) -> void:
	select(n)


func _on_view_edited() -> void:
	mark_dirty()
	inspector.refresh_values()


func _on_viewport_resized(sz: Vector2i) -> void:
	var st: Dictionary = meta["settings"]
	st["window_width"] = sz.x
	st["window_height"] = sz.y
	_apply_settings()
	mark_dirty()
	_log("Game viewport size set to %d × %d" % [sz.x, sz.y], "editor")


func _on_view_live() -> void:
	inspector.refresh_values()


func _on_inspector_changed(_prop: String) -> void:
	mark_dirty()
	scene_view.queue_redraw()


func _on_inspector_rename(new_name: String) -> void:
	if selected == null:
		return
	checkpoint()
	selected.name = new_name
	_rebuild_scene_tree()
	select(selected)
	mark_dirty()


func _open_add_dialog() -> void:
	_adding_root = false
	if add_dialog.has_method("open"):
		add_dialog.open("Node")
	else:
		_log("The Create New Node window failed to load, so the quick menu is used instead.", "warn")
		_show_quick()


func _open_add_root() -> void:
	_adding_root = true
	if add_dialog.has_method("open"):
		add_dialog.open("Node")
	else:
		_log("The Create New Node window failed to load, so the quick menu is used instead.", "warn")
		_show_quick()


func _build_quick_menu() -> void:
	quick_menu = PopupMenu.new()
	quick_menu.name = "QuickAdd"
	add_child(quick_menu)
	for ci in NodeLibrary.CATEGORIES.size():
		var cat: Dictionary = NodeLibrary.CATEGORIES[ci]
		var sub := PopupMenu.new()
		sub.name = "Cat%d" % ci
		quick_menu.add_child(sub)
		for ni in cat["nodes"].size():
			var t: String = cat["nodes"][ni]["type"]
			sub.add_item(t if _can_make(t) else t + " (disabled)", ni)
			sub.set_item_disabled(ni, not _can_make(t))
		sub.id_pressed.connect(_on_quick_pick.bind(ci))
		if quick_menu.has_method("add_submenu_node_item"):
			quick_menu.call("add_submenu_node_item", cat["name"], sub)
		else:
			quick_menu.call("add_submenu_item", cat["name"], sub.name)


func _can_make(type: String) -> bool:
	if not ClassDB.class_exists(type) or not ClassDB.can_instantiate(type):
		return false
	return type == "Node" or ClassDB.is_parent_class(type, "Node")


func _show_quick() -> void:
	quick_menu.popup(Rect2i(Vector2i(get_global_mouse_position()), Vector2i.ZERO))


func _on_quick_pick(id: int, ci: int) -> void:
	var t: String = NodeLibrary.CATEGORIES[ci]["nodes"][id]["type"]
	_adding_root = scene_root == null
	_on_node_chosen(t)


func _on_node_chosen(type: String) -> void:
	if not _can_make(type):
		_log("'%s' can't be created as a node here." % type, "warn")
		return
	checkpoint()
	var n := SceneCodec.create(type)
	if scene_root == null or _adding_root:
		_set_root(n)
		_show_screen("3d" if n is Node3D else "2d")
		call_deferred("_fit_view")
	else:
		var parent: Node = selected if selected != null else scene_root
		parent.add_child(n, true)
		_place_at_view_center(n)
	_adding_root = false
	_rebuild_scene_tree()
	select(n)
	mark_dirty()


func _create_root(type: String) -> void:
	_adding_root = true
	_on_node_chosen(type)


func _set_root(n: Node) -> void:
	if scene_root != null:
		frame.remove_child(scene_root)
		scene_root.queue_free()
	if n is Control:
		(n as Control).set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	frame.add_child(n)
	n.name = "Main"
	scene_root = n
	_sv("scene_root", n)


func _place_at_view_center(n: Node) -> void:
	if not scene_view.has_method("view_center_world"):
		return
	var c: Vector2 = scene_view.view_center_world()
	if n is Control:
		if not (n.get_parent() is Container):
			(n as Control).global_position = c - (n as Control).size / 2.0
	elif n is Node2D:
		(n as Node2D).global_position = c


func _delete_selected() -> void:
	var n := selected
	if n == null:
		return
	checkpoint()
	if n == scene_root:
		frame.remove_child(n)
		scene_root = null
		_sv("scene_root", null)
	else:
		n.get_parent().remove_child(n)
	n.queue_free()
	select(null)
	_rebuild_scene_tree()
	mark_dirty()


func _duplicate() -> void:
	if selected == null or selected == scene_root:
		return
	checkpoint()
	var c := SceneCodec.build(SceneCodec.node_to_dict(selected), false)
	selected.get_parent().add_child(c, true)
	if c is Node2D:
		(c as Node2D).position += Vector2(16, 16)
	elif c is Control and not (c.get_parent() is Container):
		(c as Control).position += Vector2(16, 16)
	_rebuild_scene_tree()
	select(c)
	mark_dirty()


func _move_selected(delta: int) -> void:
	if selected == null or selected == scene_root:
		return
	checkpoint()
	var p := selected.get_parent()
	p.move_child(selected, clampi(selected.get_index() + delta, 0, p.get_child_count() - 1))
	_rebuild_scene_tree()
	mark_dirty()


# =========================================================================
# Scripts
# =========================================================================

func _class_for_script(f: String) -> String:
	if scene_root != null:
		var stack := [scene_root]
		while not stack.is_empty():
			var n: Node = stack.pop_back()
			if str(n.get_meta("studio_script", "")) == f:
				return n.get_class()
			for c in n.get_children():
				stack.append(c)
	var src: String = script_screen.texts.get(f, "")
	var m := RegEx.create_from_string("(?m)^\\s*extends\\s+(\\w+)").search(src)
	if m != null and ClassDB.class_exists(m.get_string(1)):
		return m.get_string(1)
	return "Node"


func _open_script(f: String) -> void:
	if f == "" or not ProjectStore.list_scripts(pid).has(f):
		return
	script_screen.open_file(f)
	_show_screen("script")


func _on_attach_pressed() -> void:
	if selected == null:
		return
	if selected.has_meta("studio_script"):
		_open_script(str(selected.get_meta("studio_script")))
	else:
		_new_script_dialog(true)


func _new_script_dialog(attach: bool) -> void:
	_script_attach = attach and selected != null
	var base := selected.get_class() if _script_attach else "Node"
	var dname := ProjectStore.slug(String(selected.name)) if _script_attach else "new_script"
	if script_dialog.has_method("open"):
		script_dialog.open(base, dname, ProjectStore.list_scripts(pid), _script_attach)
	else:
		_log("The script dialog failed to load, so a script with default settings is created.", "warn")
		_quick_script(base, dname)


func _quick_script(base: String, dname: String) -> void:
	var existing := ProjectStore.list_scripts(pid)
	var file := dname + ".gd"
	var n := 2
	while existing.has(file):
		file = "%s_%d.gd" % [dname, n]
		n += 1
	_on_script_created(file, "gdscript", base, "default")


func _on_script_created(file: String, _language: String, base: String, kind: String) -> void:
	ProjectStore.write_script(pid, file, ScriptTools.template(file.get_extension(), base, kind))
	_rebuild_files()
	if _script_attach and selected != null:
		attach_script(selected, file)
	if script_screen.has_method("open_file"):
		script_screen.open_file(file)
		_show_screen("script")
	_log("Created script %s" % file, "editor")


func _on_script_chosen(file: String) -> void:
	if selected != null:
		attach_script(selected, file)


func attach_script(n: Node, file: String) -> void:
	checkpoint()
	if file == "":
		n.remove_meta("studio_script")
	else:
		n.set_meta("studio_script", file)
	_rebuild_scene_tree()
	select(n)
	mark_dirty()


func _retarget(n: Node, old: String, new_name: String) -> void:
	if str(n.get_meta("studio_script", "")) == old:
		if new_name == "":
			n.remove_meta("studio_script")
		else:
			n.set_meta("studio_script", new_name)
	for c in n.get_children():
		_retarget(c, old, new_name)


func _rename_script(old: String) -> void:
	_rename_target = old
	prompt.ask("Rename Script", old.get_basename(), _do_rename_script)


func _do_rename_script(text: String) -> void:
	var old := _rename_target
	var base := text.get_basename() if text.get_extension() in ["gd", "sts"] else text
	var new_name := base + "." + old.get_extension()
	if base == "" or new_name == old:
		return
	if ProjectStore.list_scripts(pid).has(new_name):
		_log("A script named %s already exists." % new_name, "error")
		return
	script_screen.save_all()
	if ProjectStore.rename_script(pid, old, new_name) != OK:
		_log("Could not rename %s." % old, "error")
		return
	if scene_root != null:
		_retarget(scene_root, old, new_name)
	script_screen.on_renamed(old, new_name)
	_rebuild_files()
	_rebuild_scene_tree()
	select(selected)
	mark_dirty()
	_log("Renamed %s → %s" % [old, new_name], "editor")


func _delete_script(f: String) -> void:
	_delete_target = f
	_ask_confirm("Delete script '%s'?\nNodes using it will lose their script." % f, _do_delete_script)


func _do_delete_script() -> void:
	var f := _delete_target
	ProjectStore.delete_script(pid, f)
	if scene_root != null:
		_retarget(scene_root, f, "")
	script_screen.on_deleted(f)
	_rebuild_files()
	_rebuild_scene_tree()
	select(selected)
	mark_dirty()
	_log("Deleted %s" % f, "editor")


func _ask_confirm(text: String, cb: Callable) -> void:
	_confirm_cb = cb
	confirm.dialog_text = text
	confirm.popup_centered()


func _on_confirm() -> void:
	if _confirm_cb.is_valid():
		_confirm_cb.call()


# =========================================================================
# FileSystem dock, images, export, settings
# =========================================================================

func _on_file_filter(_t: String) -> void:
	_rebuild_files()


func _rebuild_files() -> void:
	file_tree.clear()
	file_tree.hide_root = false
	var q := file_filter.text.strip_edges().to_lower()
	var root := file_tree.create_item()
	root.set_text(0, "res://")
	var scene_item := file_tree.create_item(root)
	scene_item.set_text(0, "main.scene")
	scene_item.set_icon(0, Icons.dot(Color("#5aa0ff")))
	scene_item.set_metadata(0, {"kind": "scene"})
	var sf := file_tree.create_item(root)
	sf.set_text(0, "scripts")
	sf.set_metadata(0, {"kind": "folder"})
	for f in ProjectStore.list_scripts(pid):
		if q == "" or f.to_lower().contains(q):
			var it := file_tree.create_item(sf)
			it.set_text(0, f)
			it.set_icon(0, Icons.dot(Color("#ff8ccc") if f.get_extension() == "gd" else Color("#ffd166")))
			it.set_metadata(0, {"kind": "script", "name": f})
	var af := file_tree.create_item(root)
	af.set_text(0, "assets")
	af.set_metadata(0, {"kind": "folder"})
	for f in ProjectStore.list_assets(pid):
		if q == "" or f.to_lower().contains(q):
			var ai := file_tree.create_item(af)
			ai.set_text(0, f)
			ai.set_icon(0, Icons.dot(Color("#8be28b")))
			ai.set_metadata(0, {"kind": "asset", "name": f})
	inspector.scripts = ProjectStore.list_scripts(pid)


func _selected_file() -> Variant:
	var it := file_tree.get_selected()
	return it.get_metadata(0) if it != null else null


func _on_file_activated() -> void:
	var d = _selected_file()
	if d == null:
		return
	if d["kind"] == "script":
		_open_script(d["name"])
	elif d["kind"] == "scene":
		_show_screen("3d" if scene_root is Node3D else "2d")


func _on_file_mouse(_pos: Vector2, btn: int) -> void:
	if btn != MOUSE_BUTTON_RIGHT:
		return
	var d = _selected_file()
	file_menu.clear()
	if d != null and d["kind"] == "script":
		file_menu.add_item("Open", M.F_OPEN)
		file_menu.add_item("Rename…", M.F_RENAME)
		file_menu.add_item("Delete…", M.F_DELETE)
		file_menu.add_separator()
	file_menu.add_item("New Script…", M.F_NEW)
	file_menu.add_item("Import Image…", M.F_IMPORT)
	file_menu.popup(Rect2i(Vector2i(get_global_mouse_position()), Vector2i.ZERO))


func _import_image() -> void:
	_pending_image = {}
	image_dialog.popup_centered(Vector2i(900, 600))


func _on_image_requested(obj: Object, prop: String) -> void:
	_pending_image = {"obj": obj, "prop": prop}
	image_dialog.popup_centered(Vector2i(900, 600))


func _on_image_selected(path: String) -> void:
	var rel := ProjectStore.import_asset(pid, path)
	if rel == "":
		_log("Could not import %s" % path.get_file(), "error")
		return
	_log("Imported %s" % rel, "editor")
	var tex := SceneCodec.load_image_texture(rel)
	if tex != null and not _pending_image.is_empty():
		var o: Object = _pending_image["obj"]
		if is_instance_valid(o):
			checkpoint()
			o.set(_pending_image["prop"], tex)
			inspector.refresh_all()
			mark_dirty()
			scene_view.queue_redraw()
	_pending_image = {}
	_rebuild_files()


func _export_open() -> void:
	save_project()
	export_dialog.current_file = ProjectStore.slug(str(meta["name"])) + ".zip"
	export_dialog.popup_centered(Vector2i(900, 600))


func _on_export_path(path: String) -> void:
	if not path.ends_with(".zip"):
		path += ".zip"
	var err := ProjectStore.export_zip(pid, path)
	if err == OK:
		_log("Exported project to %s" % path, "editor")
	else:
		_log("Export failed (error %d)." % err, "error")


func _on_settings_applied(m: Dictionary) -> void:
	meta = m
	ProjectStore.save_meta(meta)
	_apply_settings()
	_fit_view()
	_log("Project settings saved.", "editor")
