extends VBoxContainer
## The console. Everything printed by running games (print, push_error, ...) shows up here.

var COLORS := {
	"info": Color("#d9dde3"), "editor": Color("#8a94a6"), "warn": Color("#ffdd65"),
	"error": Color("#ff7b72"), "rich": Color("#d9dde3"),
}

@onready var log_view: RichTextLabel = %OutputLog
@onready var filter: LineEdit = %OutputFilter
@onready var err_btn: Button = %ErrBtn
@onready var warn_btn: Button = %WarnBtn
@onready var info_btn: Button = %InfoBtn

var lines: Array = []
var counts := {"error": 0, "warn": 0, "info": 0}


func _ready() -> void:
	%ClearBtn.pressed.connect(clear_log)
	filter.text_changed.connect(_on_filter)
	for b in [err_btn, warn_btn, info_btn]:
		b.toggled.connect(_on_toggle)
	_update_counts()


func _on_filter(_t: String) -> void:
	_render()


func _on_toggle(_p: bool) -> void:
	_render()


func _bucket(kind: String) -> String:
	if kind == "error":
		return "error"
	if kind == "warn":
		return "warn"
	return "info"


func _shown(text: String, kind: String) -> bool:
	var btn: Button = {"error": err_btn, "warn": warn_btn, "info": info_btn}[_bucket(kind)]
	if not btn.button_pressed:
		return false
	var q := filter.text.strip_edges().to_lower()
	return q == "" or text.to_lower().contains(q)


func add(text: String, kind: String = "info") -> void:
	lines.append([text, kind])
	counts[_bucket(kind)] += 1
	if lines.size() > 3000:
		var old: Array = lines.pop_front()
		counts[_bucket(old[1])] -= 1
		_render()
	elif _shown(text, kind):
		_append(text, kind)
	_update_counts()


func _append(text: String, kind: String) -> void:
	if kind == "rich":
		log_view.append_text(text + "\n")
		return
	log_view.push_color(COLORS.get(kind, COLORS["info"]))
	log_view.add_text(text + "\n")
	log_view.pop()


func _render() -> void:
	log_view.clear()
	for l in lines:
		if _shown(l[0], l[1]):
			_append(l[0], l[1])


func clear_log() -> void:
	lines.clear()
	counts = {"error": 0, "warn": 0, "info": 0}
	log_view.clear()
	_update_counts()


func _update_counts() -> void:
	err_btn.text = "Errors %d" % counts["error"]
	warn_btn.text = "Warnings %d" % counts["warn"]
	info_btn.text = "Info %d" % counts["info"]
