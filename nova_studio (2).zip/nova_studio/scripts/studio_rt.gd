extends Node
## Autoload "StudioRT": console bus + script registry used by the editor, running games and exports.
## User scripts call it through rewritten print()/push_error()/... calls and `use "script"`.

const ScriptTools = preload("res://scripts/script_tools.gd")
const NA := "\u0001"   # "argument not given" marker

signal message(text: String, kind: String)   # kind: info | warn | error | rich | editor
signal quit_requested

var current_project := ""      # id of the project open in the editor
var sources: Dictionary = {}   # "player.gd" -> source text (current run)
var assets_root := ""          # folder that "@image" assets are relative to
var _cache: Dictionary = {}


func reset() -> void:
	sources.clear()
	_cache.clear()


func _say(text: String, kind: String) -> void:
	message.emit(text, kind)
	if kind == "error":
		printerr(text)
	elif kind != "editor":
		print(text)


func _join(sep: String, items: Array) -> String:
	var parts := PackedStringArray()
	for v in items:
		if typeof(v) == TYPE_STRING and v == NA:
			continue
		parts.append(str(v))
	return sep.join(parts)


func out(a = NA, b = NA, c = NA, d = NA, e = NA, f = NA, g = NA, h = NA) -> void:
	_say(_join("", [a, b, c, d, e, f, g, h]), "info")

func outs(a = NA, b = NA, c = NA, d = NA, e = NA, f = NA, g = NA, h = NA) -> void:
	_say(_join(" ", [a, b, c, d, e, f, g, h]), "info")

func outt(a = NA, b = NA, c = NA, d = NA, e = NA, f = NA, g = NA, h = NA) -> void:
	_say(_join("\t", [a, b, c, d, e, f, g, h]), "info")

func out_rich(a = NA, b = NA, c = NA, d = NA, e = NA, f = NA, g = NA, h = NA) -> void:
	_say(_join("", [a, b, c, d, e, f, g, h]), "rich")

func err(a = NA, b = NA, c = NA, d = NA, e = NA, f = NA, g = NA, h = NA) -> void:
	_say(_join("", [a, b, c, d, e, f, g, h]), "error")

func warn(a = NA, b = NA, c = NA, d = NA, e = NA, f = NA, g = NA, h = NA) -> void:
	_say(_join("", [a, b, c, d, e, f, g, h]), "warn")

func quit_game(_code = 0) -> void:
	quit_requested.emit()


## Compiles a project script (cached). `base` is used when the script has no `extends`.
func compile(file: String, base: String = "RefCounted") -> GDScript:
	var key := file + "|" + base
	if _cache.has(key):
		return _cache[key]
	if not sources.has(file):
		_say("Script '%s' not found." % file, "error")
		return null
	var gd := GDScript.new()
	gd.source_code = ScriptTools.to_gdscript(sources[file], file.get_extension(), base)
	if gd.reload() != OK:
		_say("Script '%s' has errors and could not be compiled (see Godot's own Output panel for the line)." % file, "error")
		_cache[key] = null
		return null
	_cache[key] = gd
	return gd


## Used by `use "name"`: returns the script as a class (call .new() or static functions).
func load_script(script_name: String):
	var file := ""
	if sources.has(script_name):
		file = script_name
	else:
		for f in sources:
			if str(f).get_basename() == script_name:
				file = f
				break
	if file == "":
		_say("use \"%s\": no such script in this project." % script_name, "error")
		return null
	return compile(file)
