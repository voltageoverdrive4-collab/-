extends Control
## Transparent overlay over the editor viewport: selecting, moving and resizing nodes (2D),
## orbit camera + picking + moving (3D), and the selection gizmo.

signal picked(node: Node)
signal about_to_edit
signal edited
signal live_changed
signal viewport_resized(new_size: Vector2i)

const FRAME_HANDLES := [3, 4, 5]   # right, bottom-right, bottom edge handles of the game viewport

var mode := "2d"
var vp: SubViewport
var grid: Control
var frame: Control
var scene_root: Node = null
var selected: Node = null
var snap := false
var show_gizmos := true   # false while the game runs: no outlines at all
var zoom := 1.0
var pan := Vector2(80, 60)

var rig: Node3D
var cam: Camera3D
var yaw := 0.7
var elev := 0.45
var dist := 9.0
var target := Vector3(0, 0.5, 0)

var _drag := ""
var _handle := -1
var _moved := false
var _last_world := Vector2.ZERO
var _press_world := Vector2.ZERO
var _start_bounds := Rect2()
var _start_scale := Vector2.ONE
var _plane_offset := Vector3.ZERO
var _frame_handle := -1
var _frame_start := Vector2.ZERO


func setup(viewport: SubViewport, grid_node: Control, frame_node: Control) -> void:
	vp = viewport
	grid = grid_node
	frame = frame_node
	focus_mode = Control.FOCUS_CLICK
	_build_rig()
	apply_view()


# ----------------------------------------------------------------- view state

func to_world(p: Vector2) -> Vector2:
	return (p - pan) / zoom


func to_screen(w: Vector2) -> Vector2:
	return w * zoom + pan


func view_center_world() -> Vector2:
	return to_world(size / 2.0)


func apply_view() -> void:
	if vp != null:
		vp.canvas_transform = Transform2D(Vector2(zoom, 0), Vector2(0, zoom), pan)
	if grid != null:
		grid.queue_redraw()
	queue_redraw()


func fit() -> void:
	if frame == null or size.x < 10.0:
		return
	zoom = clampf(minf(size.x / (frame.size.x + 140.0), size.y / (frame.size.y + 140.0)), 0.1, 2.0)
	pan = (size - frame.size * zoom) / 2.0
	apply_view()


func set_mode(m: String) -> void:
	mode = m
	vp.transparent_bg = (m == "2d")
	grid.visible = (m == "2d")
	if m == "3d":
		if rig.get_parent() == null:
			vp.add_child(rig)
		update_cam()
	elif rig.get_parent() != null:
		vp.remove_child(rig)
	apply_view()


func _zoom_at(p: Vector2, f: float) -> void:
	var w := to_world(p)
	zoom = clampf(zoom * f, 0.1, 8.0)
	pan = p - w * zoom
	apply_view()


# ----------------------------------------------------------------- 3D rig

func _build_rig() -> void:
	rig = Node3D.new()
	rig.name = "EditorRig"
	cam = Camera3D.new()
	cam.far = 800.0
	rig.add_child(cam)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50, -30, 0)
	light.light_energy = 0.8
	rig.add_child(light)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#3a3f47")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.74, 0.8)
	env.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = env
	rig.add_child(we)
	rig.add_child(_make_grid())


func _make_grid() -> MeshInstance3D:
	var im := ImmediateMesh.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	im.surface_begin(Mesh.PRIMITIVE_LINES, mat)
	for i in range(-20, 21):
		var cz := Color(0.4, 0.6, 1.0, 0.9) if i == 0 else Color(1, 1, 1, 0.12)
		var cx := Color(1.0, 0.4, 0.4, 0.9) if i == 0 else Color(1, 1, 1, 0.12)
		im.surface_set_color(cz)
		im.surface_add_vertex(Vector3(i, 0, -20))
		im.surface_set_color(cz)
		im.surface_add_vertex(Vector3(i, 0, 20))
		im.surface_set_color(cx)
		im.surface_add_vertex(Vector3(-20, 0, i))
		im.surface_set_color(cx)
		im.surface_add_vertex(Vector3(20, 0, i))
	im.surface_end()
	var mi := MeshInstance3D.new()
	mi.mesh = im
	return mi


func update_cam() -> void:
	if cam == null or not cam.is_inside_tree():
		return
	var offset := Vector3(sin(yaw) * cos(elev), sin(elev), cos(yaw) * cos(elev)) * dist
	cam.look_at_from_position(target + offset, target, Vector3.UP)
	queue_redraw()


# ----------------------------------------------------------------- helpers

func _collect(n: Node, arr: Array) -> void:
	arr.append(n)
	for c in n.get_children():
		_collect(c, arr)


func _has_rect(n: Node) -> bool:
	if n is Control:
		return true
	if n is Node2D and n.has_method("get_rect"):
		var r: Rect2 = n.call("get_rect")
		return r.size.x > 0.0 and r.size.y > 0.0
	return false


func bounds_of(n: Node) -> Rect2:
	if n is Control:
		return (n as Control).get_global_rect()
	if n is Node2D:
		var n2 := n as Node2D
		if _has_rect(n2):
			var r: Rect2 = n2.call("get_rect")
			return n2.get_global_transform() * r
		return Rect2(n2.global_position - Vector2(16, 16), Vector2(32, 32))
	return Rect2()


func _can_move(n: Node) -> bool:
	if n is Control:
		return not (n.get_parent() is Container)
	return n is Node2D


func _can_resize(n: Node) -> bool:
	if n is Control:
		return n != scene_root and not (n.get_parent() is Container)
	return n is Node2D and _has_rect(n)


func _pick_2d(w: Vector2) -> Node:
	if scene_root == null:
		return null
	var all := []
	_collect(scene_root, all)
	for i in range(all.size() - 1, -1, -1):
		var n = all[i]
		if n is CanvasItem and (n as CanvasItem).visible and bounds_of(n).grow(2.0).has_point(w):
			return n
	return null


func _handles(sr: Rect2) -> Array:
	var p := sr.position
	var e := sr.end
	var c := sr.get_center()
	return [p, Vector2(c.x, p.y), Vector2(e.x, p.y), Vector2(e.x, c.y), e, Vector2(c.x, e.y), Vector2(p.x, e.y), Vector2(p.x, c.y)]


func _screen_rect(r: Rect2) -> Rect2:
	return Rect2(r.position * zoom + pan, r.size * zoom)


func _handle_at(p: Vector2) -> int:
	if selected == null or not is_instance_valid(selected) or not _can_resize(selected):
		return -1
	var hs := _handles(_screen_rect(bounds_of(selected)))
	for i in hs.size():
		if p.distance_to(hs[i]) <= 8.0:
			return i
	return -1


func _frame_rect_screen() -> Rect2:
	return Rect2(pan, frame.size * zoom)


func _frame_handles_visible() -> bool:
	if mode != "2d" or not show_gizmos or frame == null:
		return false
	return selected == null or not is_instance_valid(selected) or selected == scene_root


func _frame_handle_at(p: Vector2) -> int:
	if not _frame_handles_visible():
		return -1
	var hs := _handles(_frame_rect_screen())
	for i in FRAME_HANDLES:
		if p.distance_to(hs[i]) <= 10.0:
			return i
	return -1


func _do_frame_resize(p: Vector2) -> void:
	var w := to_world(p)
	var ns := _frame_start
	match _frame_handle:
		3: ns.x = w.x
		4: ns = w
		5: ns.y = w.y
	ns = ns.snapped(Vector2(8, 8)) if snap else ns.round()
	ns = ns.clamp(Vector2(64, 64), Vector2(8192, 8192))
	frame.size = ns
	_moved = true
	queue_redraw()
	live_changed.emit()


func _snapv(v: Vector2) -> Vector2:
	return v.snapped(Vector2(8, 8)) if snap else v


# ----------------------------------------------------------------- input

func _gui_input(event: InputEvent) -> void:
	if mode == "2d":
		_input_2d(event)
	else:
		_input_3d(event)


func _input_2d(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_zoom_at(mb.position, 1.15)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_zoom_at(mb.position, 1.0 / 1.15)
		elif mb.button_index == MOUSE_BUTTON_MIDDLE or mb.button_index == MOUSE_BUTTON_RIGHT:
			_drag = "pan" if mb.pressed else ""
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_left_down(mb.position)
			else:
				_left_up()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		match _drag:
			"pan":
				pan += mm.relative
				apply_view()
			"move":
				_do_move(mm.position)
			"resize":
				_do_resize(mm.position)
			"frame":
				_do_frame_resize(mm.position)
			_:
				_update_cursor(mm.position)
	elif event is InputEventKey and event.pressed:
		var step := 8.0 if event.shift_pressed else 1.0
		match event.keycode:
			KEY_LEFT: _nudge(Vector2(-step, 0))
			KEY_RIGHT: _nudge(Vector2(step, 0))
			KEY_UP: _nudge(Vector2(0, -step))
			KEY_DOWN: _nudge(Vector2(0, step))


func _nudge(d: Vector2) -> void:
	if selected == null or not is_instance_valid(selected) or not _can_move(selected):
		return
	about_to_edit.emit()
	if selected is Control:
		(selected as Control).position += d
	else:
		(selected as Node2D).global_position += d
	edited.emit()
	queue_redraw()


func _left_down(p: Vector2) -> void:
	grab_focus()
	var w := to_world(p)
	var fh := _frame_handle_at(p)
	if fh >= 0:
		_drag = "frame"
		_frame_handle = fh
		_moved = false
		_frame_start = frame.size
		return
	var h := _handle_at(p)
	if h >= 0:
		_drag = "resize"
		_handle = h
		_moved = false
		_start_bounds = bounds_of(selected)
		_start_scale = (selected as Node2D).scale if selected is Node2D else Vector2.ONE
		return
	var hit := _pick_2d(w)
	if hit != selected:
		picked.emit(hit)
	if hit != null and _can_move(hit):
		_drag = "move"
		_moved = false
		_last_world = w
		_press_world = w


func _left_up() -> void:
	if _drag == "move" or _drag == "resize":
		if _moved:
			edited.emit()
	elif _drag == "frame":
		if _moved:
			viewport_resized.emit(Vector2i(frame.size))
	_drag = ""
	_handle = -1
	_frame_handle = -1


func _do_move(p: Vector2) -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var w := to_world(p)
	if not _moved:
		if (w - _press_world).length() * zoom < 3.0:
			return
		about_to_edit.emit()
		_moved = true
	var d := w - _last_world
	_last_world = w
	if selected is Control:
		var c := selected as Control
		c.position = _snapv(c.position + d)
	elif selected is Node2D:
		var n2 := selected as Node2D
		n2.global_position = _snapv(n2.global_position + d)
	queue_redraw()
	live_changed.emit()


func _do_resize(p: Vector2) -> void:
	if selected == null or not is_instance_valid(selected):
		return
	if not _moved:
		about_to_edit.emit()
		_moved = true
	var w := _snapv(to_world(p))
	var l := _start_bounds.position.x
	var t := _start_bounds.position.y
	var r := _start_bounds.end.x
	var b := _start_bounds.end.y
	match _handle:
		0: l = w.x; t = w.y
		1: t = w.y
		2: r = w.x; t = w.y
		3: r = w.x
		4: r = w.x; b = w.y
		5: b = w.y
		6: l = w.x; b = w.y
		7: l = w.x
	var nr := Rect2(Vector2(minf(l, r), minf(t, b)), Vector2(absf(r - l), absf(b - t)))
	nr.size = nr.size.max(Vector2(4, 4))
	if selected is Control:
		var c := selected as Control
		c.global_position = nr.position
		c.size = nr.size
	elif selected is Node2D:
		var n2 := selected as Node2D
		var sx := nr.size.x / maxf(_start_bounds.size.x, 0.001)
		var sy := nr.size.y / maxf(_start_bounds.size.y, 0.001)
		n2.scale = _start_scale * Vector2(sx, sy)
		n2.global_position += nr.position - bounds_of(n2).position
	queue_redraw()
	live_changed.emit()


func _update_cursor(p: Vector2) -> void:
	var fh := _frame_handle_at(p)
	if fh >= 0:
		mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE if fh == 4 else (Control.CURSOR_HSIZE if fh == 3 else Control.CURSOR_VSIZE)
		return
	var h := _handle_at(p)
	match h:
		0, 4: mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE
		2, 6: mouse_default_cursor_shape = Control.CURSOR_BDIAGSIZE
		1, 5: mouse_default_cursor_shape = Control.CURSOR_VSIZE
		3, 7: mouse_default_cursor_shape = Control.CURSOR_HSIZE
		_: mouse_default_cursor_shape = Control.CURSOR_ARROW


# ----------------------------------------------------------------- 3D input

func _input_3d(event: InputEvent) -> void:
	if cam == null or not cam.is_inside_tree():
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			dist = clampf(dist * 0.9, 0.5, 200.0)
			update_cam()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			dist = clampf(dist * 1.1, 0.5, 200.0)
			update_cam()
		elif mb.button_index == MOUSE_BUTTON_RIGHT:
			_drag = "orbit" if mb.pressed else ""
		elif mb.button_index == MOUSE_BUTTON_MIDDLE:
			_drag = "pan3" if mb.pressed else ""
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				grab_focus()
				var hit = _pick_3d(mb.position)
				if hit != selected:
					picked.emit(hit)
				if hit != null:
					_drag = "move3"
					_moved = false
					var o := _plane_hit(mb.position, hit)
					_plane_offset = o - hit.global_position
			else:
				if _drag == "move3" and _moved:
					edited.emit()
				_drag = ""
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		match _drag:
			"orbit":
				yaw -= mm.relative.x * 0.01
				elev = clampf(elev + mm.relative.y * 0.01, -1.5, 1.5)
				update_cam()
			"pan3":
				var b := cam.global_transform.basis
				target += (-b.x * mm.relative.x + b.y * mm.relative.y) * dist * 0.0015
				update_cam()
			"move3":
				if selected != null and is_instance_valid(selected) and selected is Node3D:
					if not _moved:
						about_to_edit.emit()
						_moved = true
					var hitp := _plane_hit(mm.position, selected)
					(selected as Node3D).global_position = hitp - _plane_offset
					queue_redraw()
					live_changed.emit()


func _plane_hit(p: Vector2, n: Node) -> Vector3:
	var from := cam.project_ray_origin(p)
	var dir := cam.project_ray_normal(p)
	var origin: Vector3 = (n as Node3D).global_position
	var plane := Plane(-cam.global_transform.basis.z, origin)
	var hit = plane.intersects_ray(from, dir)
	return hit if hit != null else origin


func _pick_3d(p: Vector2) -> Node:
	if scene_root == null:
		return null
	var from := cam.project_ray_origin(p)
	var dir := cam.project_ray_normal(p)
	var best: Node = null
	var best_d := INF
	var all := []
	_collect(scene_root, all)
	for n in all:
		if not (n is Node3D):
			continue
		var d := INF
		if n is VisualInstance3D:
			var xf: Transform3D = (n as Node3D).global_transform
			var inv := xf.affine_inverse()
			var hit = (n as VisualInstance3D).get_aabb().intersects_ray(inv * from, inv.basis * dir)
			if hit != null:
				d = from.distance_to(xf * hit)
		var gp: Vector3 = (n as Node3D).global_position
		if not cam.is_position_behind(gp) and cam.unproject_position(gp).distance_to(p) < 14.0:
			d = minf(d, from.distance_to(gp))
		if d < best_d:
			best_d = d
			best = n
	return best


# ----------------------------------------------------------------- drawing

func _draw() -> void:
	if not show_gizmos:
		return
	if mode == "2d":
		_draw_2d()
	else:
		_draw_3d()


func _draw_2d() -> void:
	var font := ThemeDB.fallback_font
	if frame != null:
		var fr := _frame_rect_screen()
		var orange := Color("#ffb347")
		draw_rect(fr, orange, false, 2.0)
		draw_string(font, fr.position + Vector2(2, -7), "Game viewport  %d × %d  (root outline)" % [int(frame.size.x), int(frame.size.y)], HORIZONTAL_ALIGNMENT_LEFT, -1, 12, orange)
		if _frame_handles_visible():
			var fhs := _handles(fr)
			for i in FRAME_HANDLES:
				draw_rect(Rect2(fhs[i] - Vector2(5, 5), Vector2(10, 10)), orange)
				draw_rect(Rect2(fhs[i] - Vector2(5, 5), Vector2(10, 10)), Color.WHITE, false, 1.0)
	if scene_root != null:
		var all := []
		_collect(scene_root, all)
		for n in all:
			if n is Node2D and not _has_rect(n):
				var sp := to_screen((n as Node2D).global_position)
				var col := Color("#6aa9ff")
				draw_arc(sp, 7.0, 0.0, TAU, 20, col, 1.5)
				draw_line(sp + Vector2(-11, 0), sp + Vector2(11, 0), col, 1.0)
				draw_line(sp + Vector2(0, -11), sp + Vector2(0, 11), col, 1.0)
				draw_string(font, sp + Vector2(10, -8), String(n.name), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1, 1, 1, 0.6))
	if selected != null and is_instance_valid(selected) and selected is CanvasItem:
		var sr := _screen_rect(bounds_of(selected))
		draw_rect(sr, Color("#4aa3ff"), false, 1.5)
		if _can_resize(selected):
			for h in _handles(sr):
				draw_rect(Rect2(h - Vector2(4, 4), Vector2(8, 8)), Color.WHITE)
				draw_rect(Rect2(h - Vector2(4, 4), Vector2(8, 8)), Color("#4aa3ff"), false, 1.0)


func _draw_3d() -> void:
	if cam == null or not cam.is_inside_tree() or scene_root == null:
		return
	var font := ThemeDB.fallback_font
	var all := []
	_collect(scene_root, all)
	for n in all:
		if not (n is Node3D):
			continue
		var p: Vector3 = (n as Node3D).global_position
		if cam.is_position_behind(p):
			continue
		var sp := cam.unproject_position(p)
		var sel: bool = n == selected
		var col := Color("#4aa3ff") if sel else Color(1, 1, 1, 0.5)
		draw_arc(sp, 9.0 if sel else 6.0, 0.0, TAU, 20, col, 1.5)
		draw_string(font, sp + Vector2(10, -8), String(n.name), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, col)
		if sel:
			var bs: Basis = (n as Node3D).global_transform.basis
			var axes := [[bs.x, Color("#ff5a6a")], [bs.y, Color("#6aff7a")], [bs.z, Color("#5a8aff")]]
			for a in axes:
				var tip: Vector3 = p + (a[0] as Vector3).normalized() * 1.2
				if not cam.is_position_behind(tip):
					draw_line(sp, cam.unproject_position(tip), a[1], 2.0)
