extends Control
## Home screen: create, open, rename, delete, download (zip) and import projects.

const ProjectStore = preload("res://scripts/project_store.gd")
const CardScene = preload("res://scenes/project_card.tscn")
const SelfCheck = preload("res://scripts/self_check.gd")

@onready var list: VBoxContainer = %ProjectList
@onready var search: LineEdit = %Search
@onready var empty_label: Label = %EmptyLabel
@onready var open_btn: Button = %OpenButton
@onready var rename_btn: Button = %RenameButton
@onready var download_btn: Button = %DownloadButton
@onready var delete_btn: Button = %DeleteButton
@onready var prompt = %PromptDialog
@onready var confirm: ConfirmationDialog = %ConfirmDialog
@onready var export_dialog: FileDialog = %ExportDialog
@onready var import_dialog: FileDialog = %ImportDialog
@onready var info: AcceptDialog = %InfoDialog
@onready var problem_label: Label = %ProblemLabel

var selected_id := ""
var _cards := {}


func _ready() -> void:
	%NewButton.pressed.connect(_new_project)
	%ImportButton.pressed.connect(func(): import_dialog.popup_centered(Vector2i(900, 600)))
	open_btn.pressed.connect(func(): _open(selected_id))
	rename_btn.pressed.connect(_rename)
	download_btn.pressed.connect(_download)
	delete_btn.pressed.connect(_delete)
	search.text_changed.connect(func(_t): _refresh())
	confirm.confirmed.connect(_do_delete)
	export_dialog.file_selected.connect(_do_export)
	import_dialog.file_selected.connect(_do_import)
	var bad := SelfCheck.broken_scripts()
	if not bad.is_empty():
		problem_label.text = "⚠ These scripts have errors and won't work: %s\nOpen Godot's Debugger → Errors (or the Output panel) to read the red message." % ", ".join(bad)
		problem_label.visible = true
	_refresh()


func _refresh() -> void:
	for c in list.get_children():
		list.remove_child(c)
		c.queue_free()
	_cards.clear()
	var q := search.text.strip_edges().to_lower()
	var projects := ProjectStore.list_projects()
	var shown := 0
	for meta in projects:
		if q != "" and not str(meta["name"]).to_lower().contains(q):
			continue
		var card = CardScene.instantiate()
		list.add_child(card)
		card.setup(meta)
		card.selected.connect(_select)
		card.activated.connect(_open)
		_cards[meta["id"]] = card
		shown += 1
	empty_label.visible = shown == 0
	empty_label.text = "No projects yet.\nClick  New Project  to create your first game!" if projects.is_empty() else "No project matches your search."
	if not _cards.has(selected_id):
		selected_id = ""
	_select(selected_id)


func _select(id: String) -> void:
	selected_id = id
	for k in _cards:
		_cards[k].set_selected(k == id)
	for b in [open_btn, rename_btn, download_btn, delete_btn]:
		b.disabled = id == ""


func _open(id: String) -> void:
	if id == "":
		return
	StudioRT.current_project = id
	get_tree().change_scene_to_file("res://editor.tscn")


func _new_project() -> void:
	prompt.ask("New Project", "My Game", _create_named, "Give your project a name.")


func _create_named(text: String) -> void:
	if text == "":
		return
	var meta := ProjectStore.create(text)
	_open(meta["id"])


func _rename() -> void:
	if selected_id == "":
		return
	var meta := ProjectStore.load_meta(selected_id)
	prompt.ask("Rename Project", str(meta["name"]), _rename_to)


func _rename_to(text: String) -> void:
	if text == "" or selected_id == "":
		return
	var meta := ProjectStore.load_meta(selected_id)
	meta["name"] = text
	ProjectStore.save_meta(meta)
	_refresh()


func _delete() -> void:
	if selected_id == "":
		return
	var meta := ProjectStore.load_meta(selected_id)
	confirm.dialog_text = "Delete project '%s'?\nThis permanently removes its scene, scripts and assets." % meta["name"]
	confirm.popup_centered()


func _do_delete() -> void:
	ProjectStore.delete_project(selected_id)
	selected_id = ""
	_refresh()


func _download() -> void:
	if selected_id == "":
		return
	var meta := ProjectStore.load_meta(selected_id)
	export_dialog.current_file = ProjectStore.slug(str(meta["name"])) + ".zip"
	export_dialog.popup_centered(Vector2i(900, 600))


func _do_export(path: String) -> void:
	if not path.ends_with(".zip"):
		path += ".zip"
	var err := ProjectStore.export_zip(selected_id, path)
	info.title = "Download"
	info.dialog_text = ("Saved to:\n%s\n\nThe zip opens directly in Godot 4.3+ and can be imported back here." % path) if err == OK else "Could not write the zip (error %d)." % err
	info.popup_centered()


func _do_import(path: String) -> void:
	var meta := ProjectStore.import_zip(path)
	if meta.is_empty():
		info.title = "Import"
		info.dialog_text = "That zip is not a Nova Studio project export."
		info.popup_centered()
		return
	selected_id = meta["id"]
	_refresh()
