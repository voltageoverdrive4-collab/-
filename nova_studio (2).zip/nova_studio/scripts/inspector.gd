extends VBoxContainer
## Godot-style inspector built from ClassDB reflection: shows every editable property of the
## selected node (and of its sub-resources) with the right editor widget.

signal about_to_change
signal changed(prop: String)
signal script_chosen(file: String)       # "" = detach
signal open_script_requested(file: String)
signal rename_requested(new_name: String)
signal image_requested(obj: Object, prop: String)

const Icons = preload("res://scripts/icons.gd")
const HIDE := ["script", "owner", "scene_file_path", "multiplayer", "name", "unique_name_in_owner"]

@onready var header: Label = %InspectorHeader
@onready var filter: LineEdit = %InspectorFilter
@onready var box: VBoxContainer = %InspectorBox

var target: Object = null
var scripts: PackedStringArray = PackedStringArray()
var current_script := ""
var _refreshers: Array = []
var _collapsed := {}


func _ready() -> void:
	filter.text_changed.connect(_on_filter)


func _on_filter(_t: String) -> void:
	_rebuild()


func inspect(obj: Object) -> void:
	target = obj
	_rebuild()


func refresh_all() -> void:
	_rebuild()


## Re-reads values without rebuilding (used after drags / dependent properties).
func refresh_values() -> void:
	for r in _refreshers:
		if r.is_valid():
			r.call()


func _clear() -> void:
	_refreshers.clear()
	for c in box.get_children():
		box.remove_child(c)
		c.queue_free()


func _rebuild() -> void:
	_clear()
	if target == null or not is_instance_valid(target):
		header.text = "Inspector"
		var l := Label.new()
		l.text = "Select a node to edit its properties."
		l.modulate = Color(1, 1, 1, 0.5)
		box.add_child(l)
		return
	header.text = "%s   (%s)" % [str((target as Node).name) if target is Node else target.get_class(), target.get_class()]

	if target is Node:
		var row := HBoxContainer.new()
		var nl := Label.new()
		nl.text = "Name"
		nl.custom_minimum_size.x = 110
		var le := LineEdit.new()
		le.text = String((target as Node).name)
		le.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		le.text_submitted.connect(_on_rename)
		row.add_child(nl)
		row.add_child(le)
		box.add_child(row)

	var q := filter.text.strip_edges().to_lower()
	var sections := _sections(target)
	sections.reverse()   # most-derived class first, like Godot
	for s in sections:
		var rows: Array = s["props"].filter(func(p): return q == "" or String(p["name"]).to_lower().contains(q))
		if rows.is_empty():
			continue
		var body := VBoxContainer.new()
		var key: String = String(s["name"])
		var head := Button.new()
		head.flat = false
		head.alignment = HORIZONTAL_ALIGNMENT_CENTER
		head.focus_mode = Control.FOCUS_NONE
		var closed: bool = _collapsed.get(key, false) and q == ""
		head.text = ("▸  " if closed else "▾  ") + key
		head.pressed.connect(_toggle_section.bind(key))
		box.add_child(head)
		body.visible = not closed
		box.add_child(body)
		var last_group := ""
		for p in rows:
			var g: String = p.get("group", "")
			if g != last_group and g != "":
				var gl := Label.new()
				gl.text = g
				gl.modulate = Color(0.55, 0.75, 1.0)
				body.add_child(gl)
			last_group = g
			body.add_child(_row(target, p, 0))

	if target is Node:
		_script_row()


func _toggle_section(key: String) -> void:
	_collapsed[key] = not _collapsed.get(key, false)
	_rebuild()


func _on_rename(t: String) -> void:
	if t.strip_edges() != "":
		rename_requested.emit(t.strip_edges())


# --------------------------------------------------------------- property list

func _sections(obj: Object) -> Array:
	var sections := []
	var cur := {"name": obj.get_class(), "props": []}
	var group := ""
	var prefix := ""
	for p in obj.get_property_list():
		var usage: int = p["usage"]
		if usage & PROPERTY_USAGE_CATEGORY:
			if not cur["props"].is_empty():
				sections.append(cur)
			cur = {"name": p["name"], "props": []}
			group = ""
			prefix = ""
			continue
		if usage & PROPERTY_USAGE_GROUP:
			group = p["name"]
			prefix = p["hint_string"]
			continue
		if usage & PROPERTY_USAGE_SUBGROUP:
			continue
		if (usage & PROPERTY_USAGE_EDITOR) == 0 or p["name"] in HIDE:
			continue
		var d: Dictionary = p.duplicate()
		d["group"] = group
		d["prefix"] = prefix
		cur["props"].append(d)
	if not cur["props"].is_empty():
		sections.append(cur)
	return sections.filter(func(s): return s["name"] != "Object" and s["name"] != "RefCounted" and s["name"] != "Resource")


func _label_for(p: Dictionary) -> String:
	var n: String = p["name"]
	var pre: String = p.get("prefix", "")
	if pre != "" and n.begins_with(pre):
		n = n.substr(pre.length())
	return n.get_slice("/", n.get_slice_count("/") - 1).capitalize()


func _row(obj: Object, p: Dictionary, depth: int) -> Control:
	var row := HBoxContainer.new()
	var l := Label.new()
	l.text = _label_for(p)
	l.custom_minimum_size.x = 110
	l.size_flags_horizontal = Control.SIZE_FILL
	l.clip_text = true
	l.tooltip_text = String(p["name"])
	var ed := _make_editor(obj, p, depth)
	ed.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	row.add_child(ed)
	return row


func _apply(obj: Object, pname: String, v: Variant) -> void:
	about_to_change.emit()
	obj.set(pname, v)
	changed.emit(pname)
	call_deferred("refresh_values")


# --------------------------------------------------------------- editors

func _spin(v: float, lo: float, hi: float, step: float, is_int: bool) -> SpinBox:
	var sb := SpinBox.new()
	sb.min_value = lo
	sb.max_value = hi
	sb.step = 1.0 if is_int else step
	sb.allow_greater = true
	sb.allow_lesser = true
	sb.value = v
	sb.custom_minimum_size.x = 60
	sb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return sb


func _range_of(hint: int, hs: String, is_int: bool) -> Array:
	var lo := -1000000.0
	var hi := 1000000.0
	var step := 1.0 if is_int else 0.001
	if hint == PROPERTY_HINT_RANGE:
		var parts := hs.split(",")
		if parts.size() >= 2 and parts[0].is_valid_float() and parts[1].is_valid_float():
			lo = parts[0].to_float()
			hi = parts[1].to_float()
		if parts.size() >= 3 and parts[2].is_valid_float() and parts[2].to_float() > 0.0:
			step = parts[2].to_float()
	return [lo, hi, step]


func _to_arr(v: Variant) -> Array:
	match typeof(v):
		TYPE_VECTOR2, TYPE_VECTOR2I: return [v.x, v.y]
		TYPE_VECTOR3, TYPE_VECTOR3I: return [v.x, v.y, v.z]
		TYPE_VECTOR4, TYPE_VECTOR4I, TYPE_QUATERNION: return [v.x, v.y, v.z, v.w]
		TYPE_RECT2, TYPE_RECT2I: return [v.position.x, v.position.y, v.size.x, v.size.y]
	return []


func _from_arr(t: int, a: Array) -> Variant:
	match t:
		TYPE_VECTOR2: return Vector2(a[0], a[1])
		TYPE_VECTOR2I: return Vector2i(int(a[0]), int(a[1]))
		TYPE_VECTOR3: return Vector3(a[0], a[1], a[2])
		TYPE_VECTOR3I: return Vector3i(int(a[0]), int(a[1]), int(a[2]))
		TYPE_VECTOR4: return Vector4(a[0], a[1], a[2], a[3])
		TYPE_VECTOR4I: return Vector4i(int(a[0]), int(a[1]), int(a[2]), int(a[3]))
		TYPE_QUATERNION: return Quaternion(a[0], a[1], a[2], a[3])
		TYPE_RECT2: return Rect2(a[0], a[1], a[2], a[3])
		TYPE_RECT2I: return Rect2i(int(a[0]), int(a[1]), int(a[2]), int(a[3]))
	return null


func _make_editor(obj: Object, p: Dictionary, depth: int) -> Control:
	var pname: String = p["name"]
	var t: int = p["type"]
	var hint: int = p["hint"]
	var hs: String = p["hint_string"]
	var val: Variant = obj.get(pname)
	var deg := hs.contains("radians_as_degrees")
	match t:
		TYPE_BOOL:
			var cb := CheckBox.new()
			cb.button_pressed = val
			cb.toggled.connect(func(on: bool): _apply(obj, pname, on))
			_refreshers.append(func(): cb.set_pressed_no_signal(obj.get(pname)))
			return cb
		TYPE_INT, TYPE_FLOAT:
			var is_int := t == TYPE_INT
			if hint == PROPERTY_HINT_ENUM:
				return _enum_editor(obj, pname, hs, val, is_int)
			var r := _range_of(hint, hs, is_int)
			var sb := _spin(rad_to_deg(float(val)) if deg else float(val), r[0], r[1], r[2], is_int)
			sb.value_changed.connect(_on_spin.bind(obj, pname, is_int, deg))
			_refreshers.append(_refresh_spin.bind(sb, obj, pname, deg))
			return sb
		TYPE_STRING, TYPE_STRING_NAME, TYPE_NODE_PATH:
			if hint == PROPERTY_HINT_ENUM and t == TYPE_STRING:
				return _enum_editor(obj, pname, hs, val, false)
			if hint == PROPERTY_HINT_MULTILINE_TEXT:
				var te := TextEdit.new()
				te.custom_minimum_size.y = 70
				te.text = str(val)
				te.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
				te.text_changed.connect(_on_text_edit.bind(te, obj, pname))
				return te
			var le := LineEdit.new()
			le.text = str(val)
			le.text_submitted.connect(_on_line.bind(obj, pname, t))
			le.focus_exited.connect(_on_line_exit.bind(le, obj, pname, t))
			_refreshers.append(_refresh_line.bind(le, obj, pname))
			return le
		TYPE_COLOR:
			var cp := ColorPickerButton.new()
			cp.color = val
			cp.edit_alpha = hint != PROPERTY_HINT_COLOR_NO_ALPHA
			cp.custom_minimum_size.y = 26
			cp.color_changed.connect(func(c: Color): _apply(obj, pname, c))
			_refreshers.append(func(): cp.color = obj.get(pname))
			return cp
		TYPE_VECTOR2, TYPE_VECTOR2I, TYPE_VECTOR3, TYPE_VECTOR3I, TYPE_VECTOR4, TYPE_VECTOR4I, TYPE_QUATERNION, TYPE_RECT2, TYPE_RECT2I:
			return _vec_editor(obj, pname, t, val, deg)
		TYPE_OBJECT:
			return _resource_editor(obj, pname, hs, val, depth)
	var lab := Label.new()
	lab.text = "(%s)" % type_string(t)
	lab.modulate = Color(1, 1, 1, 0.4)
	return lab


func _on_spin(v: float, obj: Object, pname: String, is_int: bool, deg: bool) -> void:
	var out: Variant = deg_to_rad(v) if deg else v
	_apply(obj, pname, int(out) if is_int else out)


func _refresh_spin(sb: SpinBox, obj: Object, pname: String, deg: bool) -> void:
	var v := float(obj.get(pname))
	sb.set_value_no_signal(rad_to_deg(v) if deg else v)


func _on_text_edit(te: TextEdit, obj: Object, pname: String) -> void:
	_apply(obj, pname, te.text)


func _convert_str(text: String, t: int) -> Variant:
	if t == TYPE_STRING_NAME:
		return StringName(text)
	if t == TYPE_NODE_PATH:
		return NodePath(text)
	return text


func _on_line(text: String, obj: Object, pname: String, t: int) -> void:
	_apply(obj, pname, _convert_str(text, t))


func _on_line_exit(le: LineEdit, obj: Object, pname: String, t: int) -> void:
	if str(obj.get(pname)) != le.text:
		_apply(obj, pname, _convert_str(le.text, t))


func _refresh_line(le: LineEdit, obj: Object, pname: String) -> void:
	if not le.has_focus():
		le.text = str(obj.get(pname))


func _enum_editor(obj: Object, pname: String, hs: String, val: Variant, is_int: bool) -> Control:
	var ob := OptionButton.new()
	var values := []
	var idx := 0
	for part in hs.split(","):
		var label := part
		var value: Variant = idx
		if is_int and part.contains(":"):
			label = part.get_slice(":", 0)
			value = part.get_slice(":", 1).to_int()
		elif not is_int:
			value = part
		ob.add_item(label)
		values.append(value)
		idx += 1
	for i in values.size():
		if values[i] == val:
			ob.select(i)
	ob.item_selected.connect(_on_enum.bind(values, obj, pname))
	return ob


func _on_enum(i: int, values: Array, obj: Object, pname: String) -> void:
	_apply(obj, pname, values[i])


func _vec_editor(obj: Object, pname: String, t: int, val: Variant, deg: bool) -> Control:
	var h := HBoxContainer.new()
	var arr := _to_arr(val)
	var is_int := t in [TYPE_VECTOR2I, TYPE_VECTOR3I, TYPE_VECTOR4I, TYPE_RECT2I]
	var boxes: Array = []
	for i in arr.size():
		var sb := _spin(rad_to_deg(float(arr[i])) if deg else float(arr[i]), -1000000.0, 1000000.0, 0.01, is_int)
		boxes.append(sb)
		h.add_child(sb)
	for sb in boxes:
		sb.value_changed.connect(_on_vec.bind(boxes, obj, pname, t, deg))
	_refreshers.append(_refresh_vec.bind(boxes, obj, pname, deg))
	return h


func _on_vec(_v: float, boxes: Array, obj: Object, pname: String, t: int, deg: bool) -> void:
	var a := []
	for sb in boxes:
		a.append(deg_to_rad(sb.value) if deg else sb.value)
	_apply(obj, pname, _from_arr(t, a))


func _refresh_vec(boxes: Array, obj: Object, pname: String, deg: bool) -> void:
	var arr := _to_arr(obj.get(pname))
	for i in mini(arr.size(), boxes.size()):
		boxes[i].set_value_no_signal(rad_to_deg(float(arr[i])) if deg else float(arr[i]))


# --------------------------------------------------------------- resources

func _resource_classes(hs: String) -> Array:
	var out := []
	for base in hs.split(","):
		base = base.strip_edges()
		if base == "" or not ClassDB.class_exists(base):
			continue
		var cands := [base]
		for sub in ClassDB.get_inheriting_classes_from_class(base):
			cands.append(sub)
		for c in cands:
			if ClassDB.can_instantiate(c) and not str(c).begins_with("Editor") and not out.has(c):
				out.append(c)
	out.sort()
	return out


func _resource_editor(obj: Object, pname: String, hs: String, val: Variant, depth: int) -> Control:
	var v := VBoxContainer.new()
	var classes := _resource_classes(hs)
	if classes.is_empty():
		var lab := Label.new()
		lab.text = "(%s)" % (val.get_class() if val != null else "empty")
		lab.modulate = Color(1, 1, 1, 0.4)
		v.add_child(lab)
		return v
	var row := HBoxContainer.new()
	var ob := OptionButton.new()
	ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ob.add_item("<empty>")
	for c in classes:
		ob.add_item(c)
	if val != null:
		for i in classes.size():
			if classes[i] == val.get_class():
				ob.select(i + 1)
	ob.item_selected.connect(_on_resource_class.bind(classes, obj, pname))
	row.add_child(ob)
	if hs.contains("Texture"):
		var lb := Button.new()
		lb.text = "Load Image…"
		lb.pressed.connect(func(): image_requested.emit(obj, pname))
		row.add_child(lb)
	v.add_child(row)
	if val != null and val is Resource and depth < 1:
		var nested := VBoxContainer.new()
		var m := MarginContainer.new()
		m.add_theme_constant_override("margin_left", 12)
		for sec in _sections(val):
			for p in sec["props"]:
				nested.add_child(_row(val, p, depth + 1))
		m.add_child(nested)
		v.add_child(m)
	return v


func _on_resource_class(i: int, classes: Array, obj: Object, pname: String) -> void:
	_apply(obj, pname, null if i == 0 else ClassDB.instantiate(classes[i - 1]))
	_rebuild()


# --------------------------------------------------------------- script row

func _script_row() -> void:
	var head := Label.new()
	head.text = "Script"
	head.modulate = Color(0.55, 0.75, 1.0)
	box.add_child(head)
	var row := HBoxContainer.new()
	var ob := OptionButton.new()
	ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ob.add_item("<none>")
	var sel := 0
	for i in scripts.size():
		ob.add_item(scripts[i])
		if scripts[i] == current_script:
			sel = i + 1
	ob.select(sel)
	ob.item_selected.connect(_on_script_pick)
	row.add_child(ob)
	var open := Button.new()
	open.text = "Open"
	open.disabled = current_script == ""
	open.pressed.connect(func(): open_script_requested.emit(current_script))
	row.add_child(open)
	box.add_child(row)


func _on_script_pick(i: int) -> void:
	script_chosen.emit("" if i == 0 else scripts[i - 1])
