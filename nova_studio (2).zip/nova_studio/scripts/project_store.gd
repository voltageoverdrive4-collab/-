extends RefCounted
## Everything about projects on disk: user://studio_projects/<id>/{project.json, scene.json, scripts/, assets/}

const ROOT := "user://studio_projects"
const RUNTIME_FILES := ["scripts/studio_rt.gd", "scripts/scene_codec.gd", "scripts/script_tools.gd", "scripts/runner.gd"]
const RUNNER_TSCN := "[gd_scene load_steps=2 format=3]\n\n[ext_resource type=\"Script\" path=\"res://scripts/runner.gd\" id=\"1\"]\n\n[node name=\"Runner\" type=\"Node\"]\nscript = ExtResource(\"1\")\n"


static func dir_of(id: String) -> String:
	return ROOT.path_join(id)


static func read_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	return JSON.parse_string(FileAccess.get_file_as_string(path))


static func write_json(path: String, data: Variant) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data, "\t"))


static func slug(s: String) -> String:
	var out := ""
	for ch in s.to_lower():
		if (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9"):
			out += ch
		elif ch == " " or ch == "_" or ch == "-":
			out += "_"
	return out if out != "" else "project"


static func default_settings() -> Dictionary:
	return {"window_width": 1152, "window_height": 648, "bg_color": "#2b2b2b", "max_fps": 0, "physics_fps": 60, "export_name": ""}


# ------------------------------------------------------------------ projects

static func list_projects() -> Array:
	DirAccess.make_dir_recursive_absolute(ROOT)
	var res := []
	for d in DirAccess.get_directories_at(ROOT):
		var meta := load_meta(d)
		if not meta.is_empty():
			res.append(meta)
	res.sort_custom(func(a, b): return int(a.get("modified", 0)) > int(b.get("modified", 0)))
	return res


static func load_meta(id: String) -> Dictionary:
	var m = read_json(dir_of(id).path_join("project.json"))
	return m if m is Dictionary else {}


static func save_meta(meta: Dictionary) -> void:
	meta["modified"] = int(Time.get_unix_time_from_system())
	write_json(dir_of(meta["id"]).path_join("project.json"), meta)


static func create(project_name: String) -> Dictionary:
	var id := slug(project_name) + "_" + str(int(Time.get_unix_time_from_system() * 1000.0))
	var d := dir_of(id)
	DirAccess.make_dir_recursive_absolute(d.path_join("scripts"))
	DirAccess.make_dir_recursive_absolute(d.path_join("assets"))
	var now := int(Time.get_unix_time_from_system())
	var meta := {"id": id, "name": project_name, "description": "", "version": "1.0", "created": now, "modified": now, "settings": default_settings()}
	save_meta(meta)
	write_scene(id, {})
	return meta


static func remove_tree(path: String) -> void:
	for f in DirAccess.get_files_at(path):
		DirAccess.remove_absolute(path.path_join(f))
	for d in DirAccess.get_directories_at(path):
		remove_tree(path.path_join(d))
	DirAccess.remove_absolute(path)


static func delete_project(id: String) -> void:
	remove_tree(dir_of(id))


static func load_scene(id: String) -> Dictionary:
	var s = read_json(dir_of(id).path_join("scene.json"))
	return s if s is Dictionary else {}


static func write_scene(id: String, data: Dictionary) -> void:
	write_json(dir_of(id).path_join("scene.json"), data)


# ------------------------------------------------------------------ scripts & assets

static func list_scripts(id: String) -> PackedStringArray:
	var out := PackedStringArray()
	for f in DirAccess.get_files_at(dir_of(id).path_join("scripts")):
		if f.get_extension() in ["gd", "sts"]:
			out.append(f)
	out.sort()
	return out


static func script_path(id: String, file: String) -> String:
	return dir_of(id).path_join("scripts").path_join(file)


static func read_script(id: String, file: String) -> String:
	return FileAccess.get_file_as_string(script_path(id, file))


static func write_script(id: String, file: String, text: String) -> void:
	DirAccess.make_dir_recursive_absolute(dir_of(id).path_join("scripts"))
	var f := FileAccess.open(script_path(id, file), FileAccess.WRITE)
	if f != null:
		f.store_string(text)


static func delete_script(id: String, file: String) -> void:
	DirAccess.remove_absolute(script_path(id, file))


static func rename_script(id: String, old: String, new_name: String) -> Error:
	return DirAccess.rename_absolute(script_path(id, old), script_path(id, new_name))


static func list_assets(id: String) -> PackedStringArray:
	return DirAccess.get_files_at(dir_of(id).path_join("assets"))


## Copies an image into the project; returns the relative path ("assets/x.png") or "".
static func import_asset(id: String, src: String) -> String:
	var dst_dir := dir_of(id).path_join("assets")
	DirAccess.make_dir_recursive_absolute(dst_dir)
	var fname := src.get_file()
	var n := 1
	while FileAccess.file_exists(dst_dir.path_join(fname)):
		fname = "%s_%d.%s" % [src.get_file().get_basename(), n, src.get_extension()]
		n += 1
	if DirAccess.copy_absolute(src, dst_dir.path_join(fname)) != OK:
		return ""
	return "assets/" + fname


# ------------------------------------------------------------------ export / import

static func _project_godot(meta: Dictionary) -> String:
	var s: Dictionary = meta.get("settings", default_settings())
	var bg := Color.from_string(str(s.get("bg_color", "#2b2b2b")), Color(0.17, 0.17, 0.17))
	var t := "; Generated by Nova Studio\nconfig_version=5\n\n[application]\n\n"
	t += "config/name=\"%s\"\n" % str(meta["name"]).replace("\"", "'")
	t += "run/main_scene=\"res://runner.tscn\"\nrun/max_fps=%d\nconfig/features=PackedStringArray(\"4.3\")\n\n" % int(s.get("max_fps", 0))
	t += "[autoload]\n\nStudioRT=\"*res://scripts/studio_rt.gd\"\n\n"
	t += "[display]\n\nwindow/size/viewport_width=%d\nwindow/size/viewport_height=%d\nwindow/stretch/mode=\"canvas_items\"\n\n" % [int(s.get("window_width", 1152)), int(s.get("window_height", 648))]
	t += "[physics]\n\ncommon/physics_ticks_per_second=%d\n\n" % int(s.get("physics_fps", 60))
	t += "[rendering]\n\nrenderer/rendering_method=\"gl_compatibility\"\nenvironment/defaults/default_clear_color=Color(%f, %f, %f, 1)\n" % [bg.r, bg.g, bg.b]
	return t


static func _zip_bytes(z: ZIPPacker, path: String, data: PackedByteArray) -> void:
	z.start_file(path)
	z.write_file(data)
	z.close_file()


static func _zip_text(z: ZIPPacker, path: String, text: String) -> void:
	_zip_bytes(z, path, text.to_utf8_buffer())


## Writes a zip that is BOTH a ready-to-open Godot project and a Nova Studio backup.
static func export_zip(id: String, path: String) -> Error:
	var z := ZIPPacker.new()
	var err := z.open(path)
	if err != OK:
		return err
	var meta := load_meta(id)
	var d := dir_of(id)
	_zip_text(z, "project.godot", _project_godot(meta))
	_zip_text(z, "runner.tscn", RUNNER_TSCN)
	_zip_text(z, "README.md", "# %s\n\nExported from Nova Studio.\n\nOpen this folder with Godot 4.3+ and press F5.\nThe game lives in `studio_project/` (scene.json + scripts/ + assets/).\nImport the zip back into Nova Studio's home screen to keep editing it.\n" % meta["name"])
	for f in RUNTIME_FILES:
		_zip_text(z, f, FileAccess.get_file_as_string("res://" + f))
	_zip_text(z, "studio_project/project.json", JSON.stringify(meta, "\t"))
	_zip_text(z, "studio_project/scene.json", FileAccess.get_file_as_string(d.path_join("scene.json")))
	for f in list_scripts(id):
		_zip_text(z, "studio_project/scripts/" + f, read_script(id, f))
	for f in list_assets(id):
		_zip_bytes(z, "studio_project/assets/" + f, FileAccess.get_file_as_bytes(d.path_join("assets").path_join(f)))
	z.close()
	return OK


## Creates a new project from a zip made by export_zip(). Returns its meta, or {} on failure.
static func import_zip(path: String) -> Dictionary:
	var r := ZIPReader.new()
	if r.open(path) != OK:
		return {}
	var files := r.get_files()
	if not files.has("studio_project/project.json"):
		r.close()
		return {}
	var meta = JSON.parse_string(r.read_file("studio_project/project.json").get_string_from_utf8())
	if not (meta is Dictionary):
		r.close()
		return {}
	var created := create(str(meta.get("name", "Imported")))
	meta["id"] = created["id"]
	meta["created"] = created["created"]
	var d := dir_of(created["id"])
	for f in files:
		if not f.begins_with("studio_project/") or f.ends_with("/"):
			continue
		var rel: String = f.trim_prefix("studio_project/")
		if rel == "project.json":
			continue
		DirAccess.make_dir_recursive_absolute(d.path_join(rel).get_base_dir())
		var fa := FileAccess.open(d.path_join(rel), FileAccess.WRITE)
		if fa != null:
			fa.store_buffer(r.read_file(f))
	r.close()
	save_meta(meta)
	return meta
