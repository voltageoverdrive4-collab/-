extends Window
## In-editor documentation (docs/studio_script.md).

const Md = preload("res://scripts/md.gd")

@onready var text: RichTextLabel = %DocsText


func _ready() -> void:
	close_requested.connect(hide)
	text.meta_clicked.connect(_on_meta)
	text.text = Md.to_bbcode(FileAccess.get_file_as_string("res://docs/studio_script.md"))


func _on_meta(meta: Variant) -> void:
	OS.shell_open(str(meta))


func open() -> void:
	popup_centered(Vector2i(980, 760))
