extends RefCounted
## Finds project scripts that fail to compile, so problems are reported instead of buttons silently doing nothing.


static func broken_scripts() -> PackedStringArray:
	var bad := PackedStringArray()
	for f in DirAccess.get_files_at("res://scripts"):
		if f.get_extension() != "gd":
			continue
		var s = ResourceLoader.load("res://scripts/" + f)
		if s == null or (s is GDScript and not s.can_instantiate()):
			bad.append(f)
	return bad
