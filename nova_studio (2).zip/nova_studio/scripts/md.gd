extends RefCounted
## Tiny Markdown -> BBCode converter (used by the docs window).

static var _re_code := RegEx.create_from_string("`([^`]+)`")
static var _re_bold := RegEx.create_from_string("\\*\\*(.+?)\\*\\*")


static func escape(s: String) -> String:
	return s.replace("[", "[lb]")


static func to_bbcode(src: String) -> String:
	var out := PackedStringArray()
	var code_lines := PackedStringArray()
	var in_code := false
	for raw_line in src.split("\n"):
		var line: String = raw_line.trim_suffix("\r")
		if line.strip_edges().begins_with("```"):
			if in_code:
				out.append("[bgcolor=#101010][color=#d6e4ff][code]" + escape("\n".join(code_lines)) + "[/code][/color][/bgcolor]")
				code_lines.clear()
			in_code = not in_code
			continue
		if in_code:
			code_lines.append(line)
		else:
			out.append(_line(line))
	return "\n".join(out)


static func _line(line: String) -> String:
	var s := escape(line)
	var h := 0
	while h < s.length() and h < 6 and s[h] == "#":
		h += 1
	if h > 0 and s.length() > h and s[h] == " ":
		var sizes := [28, 22, 18, 16, 16, 16]
		return "\n[font_size=%d][b][color=#8ec5ff]%s[/color][/b][/font_size]" % [sizes[h - 1], _inline(s.substr(h + 1))]
	var t := s.strip_edges(true, false)
	if t.begins_with("- ") or t.begins_with("* "):
		return "  •  " + _inline(t.substr(2))
	return _inline(s)


static func _inline(s: String) -> String:
	s = _re_code.sub(s, "[bgcolor=#2c2c2c][color=#ffeda1][code]$1[/code][/color][/bgcolor]", true)
	s = _re_bold.sub(s, "[b]$1[/b]", true)
	return s
