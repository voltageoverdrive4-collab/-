extends RefCounted
## Saves / rebuilds scene trees as JSON, using Godot's own reflection (ClassDB), so every node
## type and property works. Also creates new nodes with sensible defaults.

const SKIP := ["name", "owner", "scene_file_path", "multiplayer", "script", "unique_name_in_owner",
	"resource_path", "resource_local_to_scene", "resource_scene_unique_id",
	"global_position", "global_rotation", "global_scale", "global_transform", "global_rotation_degrees"]


static func node_to_dict(n: Node) -> Dictionary:
	var d := {
		"type": n.get_class(),
		"name": String(n.name),
		"script": str(n.get_meta("studio_script", "")),
		"props": props_of(n),
		"children": [],
	}
	if n is Control:
		var ctl := n as Control
		d["layout"] = {
			"anchors": [ctl.anchor_left, ctl.anchor_top, ctl.anchor_right, ctl.anchor_bottom],
			"offsets": [ctl.offset_left, ctl.offset_top, ctl.offset_right, ctl.offset_bottom],
			"grow": [int(ctl.grow_horizontal), int(ctl.grow_vertical)],
		}
	for c in n.get_children():
		d["children"].append(node_to_dict(c))
	return d


static func props_of(obj: Object) -> Dictionary:
	var out := {}
	var fresh = ClassDB.instantiate(obj.get_class()) if ClassDB.can_instantiate(obj.get_class()) else null
	var is_control := obj is Control
	for p in obj.get_property_list():
		var usage: int = p["usage"]
		if (usage & PROPERTY_USAGE_STORAGE) == 0 or (usage & (PROPERTY_USAGE_CATEGORY | PROPERTY_USAGE_GROUP)) != 0:
			continue
		var pname: String = p["name"]
		if pname in SKIP or pname.begins_with("metadata/"):
			continue
		if is_control and (pname == "position" or pname == "size" or pname.begins_with("anchor_") or pname.begins_with("offset_") or pname.begins_with("grow_")):
			continue   # controls are stored through the explicit "layout" entry (exact placement)
		var t: int = p["type"]
		var v = obj.get(pname)
		if t == TYPE_OBJECT:
			var enc = encode_resource(v)
			if enc != null:
				out[pname] = enc
			continue
		if t in [TYPE_NIL, TYPE_ARRAY, TYPE_DICTIONARY, TYPE_CALLABLE, TYPE_SIGNAL, TYPE_RID]:
			continue
		if fresh != null and fresh.get(pname) == v:
			continue
		out[pname] = var_to_str(v)
	if fresh != null and not (fresh is RefCounted):
		fresh.free()
	return out


static func encode_resource(r: Variant) -> Variant:
	if r == null or not (r is Resource):
		return null
	if r.has_meta("studio_asset"):
		return {"@image": r.get_meta("studio_asset")}
	if r.resource_path != "":
		return null
	return {"@res": r.get_class(), "props": props_of(r)}


static func load_image_texture(rel: String) -> Texture2D:
	var img := Image.load_from_file(StudioRT.assets_root.path_join(rel))
	if img == null or img.is_empty():
		return null
	var tex := ImageTexture.create_from_image(img)
	tex.set_meta("studio_asset", rel)
	return tex


static func decode_resource(d: Dictionary) -> Resource:
	if d.has("@image"):
		return load_image_texture(d["@image"])
	var cls: String = d.get("@res", "")
	if cls == "" or not ClassDB.can_instantiate(cls):
		return null
	var r = ClassDB.instantiate(cls)
	apply_props(r, d.get("props", {}))
	return r


static func _rank(k: String) -> int:
	if k.begins_with("anchor"):
		return 0
	if k.begins_with("offset"):
		return 1
	return 2


static func apply_props(obj: Object, props: Dictionary) -> void:
	var keys := props.keys()
	keys.sort_custom(func(a, b): return _rank(a) < _rank(b))
	for k in keys:
		var v = props[k]
		if v is Dictionary:
			obj.set(k, decode_resource(v))
		else:
			obj.set(k, str_to_var(v))


static func build(d: Dictionary, with_scripts: bool) -> Node:
	var type: String = d.get("type", "Node")
	if not ClassDB.can_instantiate(type):
		type = "Node"
	var n: Node = ClassDB.instantiate(type)
	n.name = d.get("name", type)
	apply_props(n, d.get("props", {}))
	if n is Control and d.has("layout"):
		_apply_layout(n as Control, d["layout"])
	var sname: String = d.get("script", "")
	if sname != "":
		n.set_meta("studio_script", sname)
		if with_scripts:
			attach(n, sname)
	for cd in d.get("children", []):
		n.add_child(build(cd, with_scripts), true)
	return n


## Restores exactly where a Control was placed (anchors, grow direction, offsets).
static func _apply_layout(c: Control, l: Dictionary) -> void:
	var a: Array = l.get("anchors", [0, 0, 0, 0])
	for i in 4:
		c.set_anchor(i, float(a[i]), false, false)
	var g: Array = l.get("grow", [1, 1])
	c.grow_horizontal = int(g[0])
	c.grow_vertical = int(g[1])
	var o: Array = l.get("offsets", [0, 0, 0, 0])
	for i in 4:
		c.set_offset(i, float(o[i]))


static func attach(n: Node, file: String) -> void:
	var gd: GDScript = StudioRT.compile(file, n.get_class())
	if gd == null:
		return
	var base := String(gd.get_instance_base_type())
	if base != "" and not ClassDB.is_parent_class(n.get_class(), base):
		StudioRT.err("Script '%s' extends %s but node '%s' is a %s." % [file, base, n.name, n.get_class()])
		return
	n.set_script(gd)


# --------------------------------------------------------------- creating nodes

static func _placeholder(px: float) -> PlaceholderTexture2D:
	var t := PlaceholderTexture2D.new()
	t.size = Vector2(px, px)
	return t


static func create(type: String) -> Node:
	var n: Node = ClassDB.instantiate(type)
	n.name = type
	match type:
		"Sprite2D", "Sprite3D":
			n.set("texture", _placeholder(64))
		"TextureRect":
			n.set("texture", _placeholder(128))
		"MeshInstance3D":
			n.set("mesh", BoxMesh.new())
		"CollisionShape2D":
			var rs := RectangleShape2D.new()
			rs.size = Vector2(64, 64)
			n.set("shape", rs)
		"CollisionShape3D":
			n.set("shape", BoxShape3D.new())
		"Polygon2D":
			n.set("polygon", PackedVector2Array([Vector2(-32, -32), Vector2(32, -32), Vector2(32, 32), Vector2(-32, 32)]))
		"Line2D":
			n.set("points", PackedVector2Array([Vector2(-50, 0), Vector2(50, 0)]))
	if n is Control:
		var c := n as Control
		if type in ["Button", "CheckBox", "CheckButton", "LinkButton", "MenuButton", "OptionButton", "Label", "RichTextLabel", "ColorPickerButton"]:
			c.set("text", type)
		var m := c.get_combined_minimum_size()
		c.size = Vector2(m.x if m.x > 0.0 else 100.0, m.y if m.y > 0.0 else 100.0)
	return n


## Adds a camera + light to 3D games that don't have their own.
static func ensure_defaults(root: Node, host: Node) -> void:
	var has3d := root is Node3D or not root.find_children("*", "Node3D", true, false).is_empty()
	if not has3d:
		return
	if not (root is Camera3D) and root.find_children("*", "Camera3D", true, false).is_empty():
		var cam := Camera3D.new()
		cam.position = Vector3(0, 2.5, 7)
		cam.rotation_degrees = Vector3(-18, 0, 0)
		host.add_child(cam)
		cam.current = true
	if not (root is Light3D) and root.find_children("*", "Light3D", true, false).is_empty():
		var l := DirectionalLight3D.new()
		l.rotation_degrees = Vector3(-50, -30, 0)
		host.add_child(l)
