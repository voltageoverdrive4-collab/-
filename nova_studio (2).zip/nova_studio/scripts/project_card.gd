extends PanelContainer
## One project row on the Home screen.

signal selected(id: String)
signal activated(id: String)

@export var normal_style: StyleBox
@export var selected_style: StyleBox

@onready var name_label: Label = %NameLabel
@onready var info_label: Label = %InfoLabel
@onready var badge: Label = %Badge

var project_id := ""


func setup(meta: Dictionary) -> void:
	project_id = meta["id"]
	name_label.text = str(meta["name"])
	var t := Time.get_datetime_string_from_unix_time(int(meta.get("modified", 0)), true)
	info_label.text = "Last edited  %s      ·      user://studio_projects/%s" % [t, project_id]
	badge.text = str(meta["name"]).substr(0, 1).to_upper()
	set_selected(false)


func set_selected(v: bool) -> void:
	add_theme_stylebox_override("panel", selected_style if v else normal_style)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if event.double_click:
			activated.emit(project_id)
		else:
			selected.emit(project_id)
