extends ConfirmationDialog
## Project Settings: general, display, runtime, export.

signal applied(meta: Dictionary)
signal export_requested

@onready var proj_name: LineEdit = %ProjName
@onready var proj_desc: TextEdit = %ProjDesc
@onready var proj_version: LineEdit = %ProjVersion
@onready var win_w: SpinBox = %WinW
@onready var win_h: SpinBox = %WinH
@onready var bg_color: ColorPickerButton = %BgColor
@onready var max_fps: SpinBox = %MaxFps
@onready var phys_fps: SpinBox = %PhysFps
@onready var export_name: LineEdit = %ExportName

var _meta := {}


func _ready() -> void:
	confirmed.connect(_on_confirmed)
	%ExportBtn.pressed.connect(export_requested.emit)


func open(meta: Dictionary) -> void:
	_meta = meta
	var s: Dictionary = meta.get("settings", {})
	proj_name.text = str(meta.get("name", ""))
	proj_desc.text = str(meta.get("description", ""))
	proj_version.text = str(meta.get("version", "1.0"))
	win_w.value = float(s.get("window_width", 1152))
	win_h.value = float(s.get("window_height", 648))
	bg_color.color = Color.from_string(str(s.get("bg_color", "#2b2b2b")), Color("#2b2b2b"))
	max_fps.value = float(s.get("max_fps", 0))
	phys_fps.value = float(s.get("physics_fps", 60))
	export_name.text = str(s.get("export_name", ""))
	popup_centered(Vector2i(620, 460))


func _on_confirmed() -> void:
	var m := _meta.duplicate(true)
	m["name"] = proj_name.text.strip_edges() if proj_name.text.strip_edges() != "" else m.get("name", "Project")
	m["description"] = proj_desc.text
	m["version"] = proj_version.text
	m["settings"] = {
		"window_width": int(win_w.value), "window_height": int(win_h.value),
		"bg_color": "#" + bg_color.color.to_html(false), "max_fps": int(max_fps.value),
		"physics_fps": int(phys_fps.value), "export_name": export_name.text,
	}
	applied.emit(m)
