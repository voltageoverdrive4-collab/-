extends ConfirmationDialog
## "Attach Node Script" / "Create Script" dialog.

signal created(file: String, language: String, base: String, template: String)

@onready var lang: OptionButton = %Language
@onready var inherits_field: LineEdit = %Inherits
@onready var template_check: CheckBox = %TemplateCheck
@onready var template_opt: OptionButton = %TemplateOption
@onready var name_field: LineEdit = %ScriptName
@onready var status: RichTextLabel = %Status

var existing := PackedStringArray()


func _ready() -> void:
	lang.add_item("GDScript")
	lang.add_item("Studio Script")
	template_opt.add_item("Default")
	template_opt.add_item("Empty")
	confirmed.connect(_on_confirmed)
	lang.item_selected.connect(_on_changed_i)
	inherits_field.text_changed.connect(_on_changed_s)
	name_field.text_changed.connect(_on_changed_s)
	template_check.toggled.connect(_on_toggled)


func open(base: String, default_name: String, existing_files: PackedStringArray, attach: bool) -> void:
	title = "Attach Node Script" if attach else "Create Script"
	existing = existing_files
	inherits_field.text = base
	name_field.text = default_name
	_validate()
	popup_centered(Vector2i(560, 0))
	name_field.grab_focus()
	name_field.select_all()


func _file() -> String:
	var n := name_field.text.strip_edges()
	if n.get_extension() in ["gd", "sts"]:
		n = n.get_basename()
	return n + (".gd" if lang.selected == 0 else ".sts")


func _on_changed_i(_i: int) -> void:
	_validate()


func _on_changed_s(_t: String) -> void:
	_validate()


func _on_toggled(on: bool) -> void:
	template_opt.disabled = not on


func _validate() -> bool:
	var f := _file()
	var base := f.get_basename()
	var msgs := PackedStringArray()
	var ok := true
	var re := RegEx.create_from_string("^[A-Za-z0-9_\\-]+$")
	if base == "" or re.search(base) == null:
		msgs.append("[color=#ff8a80]• Invalid script name (use letters, numbers, _ and -).[/color]")
		ok = false
	elif existing.has(f):
		msgs.append("[color=#ff8a80]• A script called %s already exists.[/color]" % f)
		ok = false
	else:
		msgs.append("[color=#8be28b]• Script name is valid.[/color]")
		msgs.append("[color=#8be28b]• Will create %s in the project's scripts folder.[/color]" % f)
	if not ClassDB.class_exists(inherits_field.text.strip_edges()):
		msgs.append("[color=#ff8a80]• Unknown base class '%s'.[/color]" % inherits_field.text.strip_edges())
		ok = false
	status.text = "\n".join(msgs)
	get_ok_button().disabled = not ok
	return ok


func _on_confirmed() -> void:
	if not _validate():
		return
	var kind := "default" if (template_check.button_pressed and template_opt.selected == 0) else "empty"
	created.emit(_file(), "gdscript" if lang.selected == 0 else "studio", inherits_field.text.strip_edges(), kind)
