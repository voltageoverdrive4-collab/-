# Nova Studio

A mini game engine / editor built with Godot 4. Make projects on the Home screen; every project opens in its own editor
(Scene dock, FileSystem dock, 2D/3D viewport, Inspector, Script editor, Game view and Output console), uses real
GDScript (and a custom beginner format, Studio Script) and can be exported as a normal Godot project.

## Run it
1. Open `project.godot` in Godot 4.3 or newer (tested design target: 4.3 to 4.7).
2. Press F5. Home screen -> New Project.

## Scenes
- `home.tscn` : project manager (create, open, rename, delete, download .zip, import .zip)
- `editor.tscn` : the editor; a fresh instance is loaded every time a project is opened/created
- `scenes/` : project card, add-node dialog, script dialog, project settings, prompt, docs window
All UI nodes are real nodes in these scenes, so you can see and edit them in the Godot editor.

## Code map
- `scripts/studio_rt.gd` autoload: console bus + script compiler/registry
- `scripts/script_tools.gd` Studio Script -> GDScript, print() redirect, `use` keyword
- `scripts/scene_codec.gd` scene <-> JSON using ClassDB (every node type & property)
- `scripts/project_store.gd` projects on disk, zip export / import
- `scripts/editor.gd`, `scene_view.gd`, `inspector.gd`, `script_screen.gd`, `code_editor.gd`, `output_panel.gd`

Docs for users live in `docs/studio_script.md` (also shown in-app under Help).
