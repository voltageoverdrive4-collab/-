# Nova Studio Documentation

Everything about writing scripts in Nova Studio. Press F1 or use Help → Script Docs at any time.

## 1. Two script formats

Every project script is a plain text file in your project's scripts folder. Nova Studio supports two formats:

- **GDScript (.gd)**: the real Godot 4 language. Because scripts are compiled by Godot itself, every function, class, signal and node type that Godot has works here.
- **Studio Script (.sts)**: a friendly beginner format that is converted to GDScript when you press Run. Anything it doesn't recognise is passed through as normal GDScript, so you can mix both styles freely.

Create either one with File → New Script, with the **Script** button in the Scene dock (attaches it to the selected node), or the **+ Script** button in the FileSystem dock.

## 2. Attaching scripts to nodes

- Select a node, then click **Script** in the Scene dock (or right-click → Attach Script…) to create and attach a new script.
- Or pick an existing script from the **Script** dropdown at the bottom of the Inspector.
- The script's name appears next to the node in the Scene dock. Click it to open the script.
- A script must extend the node's type, for example `extends Sprite2D` on a Sprite2D. If the script has no `extends` line, Nova Studio uses the node's type automatically.
- Rename or delete scripts from the FileSystem dock (right-click) or the File menu in the Script screen. Nodes using a renamed script follow the rename. Deleting a script detaches it from every node.

## 3. The console (Output panel)

Everything your game prints shows up in the Output panel at the bottom of the editor when the game runs. For example:

```
func _ready() -> void:
	print("hi")
```

prints `hi` in the console as soon as the game starts. These functions are redirected to the console:

- `print()`, `prints()`, `printt()`, `print_debug()`: normal messages
- `print_rich()`: supports BBCode such as `[color=red]text[/color]`
- `push_warning()`: yellow warnings
- `push_error()` and `printerr()`: red errors

Use the Errors / Warnings / Info buttons and the filter box to find messages. The Clear button empties the console.

## 4. Studio Script reference

Studio Script lines are converted one by one. Indentation (tabs) works exactly like GDScript.

**Events**

```
on ready:
	say "The game started"

on process(delta):
	pass
```

| Studio Script | GDScript |
| --- | --- |
| `on ready:` | `func _ready():` |
| `on process(delta):` | `func _process(delta):` |
| `on physics(delta):` | `func _physics_process(delta):` |
| `on input(event):` | `func _input(event):` |
| `on key(event):` | `func _unhandled_key_input(event):` |
| `on draw:` | `func _draw():` |
| `on enter:` | `func _enter_tree():` |
| `on exit:` | `func _exit_tree():` |

**Functions and statements**

| Studio Script | GDScript |
| --- | --- |
| `to jump(power):` | `func jump(power):` |
| `say "hello"` | `print("hello")` |
| `set speed to 200` | `speed = 200` |
| `change score by 1` | `score += 1` |
| `repeat 5 times:` | `for _i in range(5):` |
| `wait 2 seconds` | `await get_tree().create_timer(2).timeout` |

**Full example (attach to a Sprite2D)**

```
extends Sprite2D

var speed = 150

on ready:
	say "Sprite ready!"

on process(delta):
	position.x += speed * delta
	if position.x > 1000:
		set position.x to 0

to bounce():
	say "bounce"
	repeat 3 times:
		rotation += 0.5
```

## 5. Using other scripts

Any script can use any other script in the same project with the `use` keyword (works in both formats):

```
use "helpers"
use "enemy_ai.gd" as ai
```

`use "helpers"` gives you a variable called `helpers` that holds the other script as a class:

```
# helpers.gd
static func double(x):
	return x * 2

func greet():
	print("hi from helpers")
```

```
# player.gd
extends Node2D
use "helpers"

func _ready():
	print(helpers.double(21))      # static functions: 42
	var h = helpers.new()          # or make an instance
	h.greet()
```

Notes: `use` goes at the top level of a script. You can also call `StudioRT.load_script("helpers")` from code. A script that doesn't `extends` anything is treated as a plain object (RefCounted).

## 6. Writing full GDScript

You have everything Godot has: signals, `@export`, `await`, `match`, inner classes, typed variables, lambdas, `get_node()` / `$Node`, the `Input` singleton, `randf()`, physics, tweens, timers and so on.

```
extends Button

func _ready() -> void:
	pressed.connect(_on_pressed)

func _on_pressed() -> void:
	print("Button clicked!")
	text = "Clicked!"
```

The script editor gives you Godot-style colours, line numbers, code folding, a minimap, auto-indent, bracket completion, code completion (Ctrl+Space, or after typing a dot), Find (Ctrl+F), Go to Line (Ctrl+L), Toggle Comment (Ctrl+K), a methods list and an open-scripts list.

Things that behave differently inside Nova Studio:

- `class_name` lines are ignored (they would clash when a game is run twice).
- `get_tree().quit()` stops your game instead of closing Nova Studio.
- `extends` must match the node type the script is attached to.
- If a script has a syntax error the console tells you which script failed; Godot's own Output panel shows the exact line.

## 7. Working in the editor

**Creating a scene.** A new project is empty. Everything is saved exactly where you placed it, and the game shows nodes at those same positions. In the Scene dock choose **2D Scene**, **3D Scene**, **User Interface**, or **Other Node…** (any Godot node type) as the root. Use **+** (or Ctrl+A) to add child nodes. The Create New Node window opens with the **Node Library**: about 65 common nodes grouped by category (2D, 2D physics, 3D, 3D physics, UI, containers, animation and audio, utility, particles, networking) with a description and example code for each (use **Copy example**). Below it is the full list of every Godot node. Nodes that can't be created directly are marked **(disabled)** with the reason. **Scene → Quick Add Node** is a faster menu version of the library.

**The game viewport outline.** The orange rectangle in the 2D view is the root outline: it shows exactly what the game window will see. Select the root (or click empty space) and drag the square handles on its right and bottom edges to resize the game viewport; the size is saved in Project Settings. Drag a node or the root itself to move it. The outline and all handles disappear while the game runs.

**Moving and resizing (2D / UI).** Click a node to select it. Drag to move it. Drag the white handles to resize it (Controls change size, sprites change scale). Arrow keys nudge by 1 pixel (Shift = 8). Turn on **Snap** for an 8 pixel grid. Mouse wheel zooms, right or middle drag pans, **Fit** frames the game window.

**3D.** Right-drag orbits, middle-drag pans, wheel zooms. Click a node (or its marker) to select it, drag to move it across the screen plane. Use the Inspector for exact position / rotation / scale.

**Scene dock.** Drag nodes to reorder or re-parent. Double-click or F2 renames. Right-click for more (Duplicate, Move Up/Down, Delete, scripts). Ctrl+Z / Ctrl+Y undo and redo.

**Inspector.** Shows every property of the selected node, grouped by class, with the right editor for each type. Resource properties (shapes, meshes, textures, materials) have a type dropdown; textures also have **Load Image…** to import your own pictures.

**Buttons and UI.** Button, Label, LineEdit, CheckBox and every other Control node work when you run the game. Connect them from a script, for example `$Button.pressed.connect(...)` or attach a script to the Button itself.

**Saving.** Your project saves automatically a moment after every change, and whenever you press Run or close the project.

## 8. Running

Press **▶** (F5) to run. The Game tab shows your game; the console shows everything it prints. **⏸** pauses and **■** (F8) stops. 3D games without a camera or light get a default camera and light so you can see something.

## 9. Project settings

Project → Project Settings: name, description, version, game window size, background colour, max FPS and physics ticks per second.

## 10. Exporting and downloading

- Project → **Export Project (.zip)** or **Download** on the Home screen saves a zip.
- The zip is a complete Godot 4.3+ project: open the folder in Godot and press F5 to run your game.
- The same zip can be imported back into Nova Studio from the Home screen (Import Project).
- Your game's source lives in `studio_project/` inside the zip (scene.json, scripts/, assets/).

## 11. Where are my projects?

Each project is a folder under `user://studio_projects/` (File → Project → Open Project Folder shows it). Every project has its own scene, scripts and assets.
