const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

// Free AI fallback: uses Pollinations.ai open models — no API key, no integration credits.
// Shared by aiChat, voltBotReply, generateHolidayQuest and getAccountWorth.

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function freeAI(prompt) {
  const statuses = [];
  const models = ['openai', 'mistral', 'openai-fast'];

  for (const model of models) {
    try {
      const res = await fetch('https://text.pollinations.ai/openai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Referer: 'https://voltage-clan-hubs.db.app' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }] }),
        signal: AbortSignal.timeout(90000)
      });
      if (res.ok) {
        const json = await res.json().catch(() => null);
        const text = json?.choices?.[0]?.message?.content;
        if (typeof text === 'string' && text.trim()) return text.trim();
        statuses.push(`${model}:empty`);
      } else {
        statuses.push(`${model}:${res.status}`);
      }
    } catch (e) {
      statuses.push(`${model}:err`);
    }
    await sleep(1500);
  }

  // last resort: simple GET completion endpoint
  try {
    const res2 = await fetch(
      `https://text.pollinations.ai/${encodeURIComponent(prompt).slice(0, 7000)}?model=openai&referrer=voltage-clan-hubs.db.app`,
      { signal: AbortSignal.timeout(90000) }
    );
    if (res2.ok) {
      const text2 = await res2.text();
      if (text2 && text2.trim()) return text2.trim();
    }
    statuses.push(`GET:${res2.status}`);
  } catch (e) {
    statuses.push('GET:err');
  }

  throw new Error(`Free AI service unavailable (${statuses.join(', ')})`);
}

function extractJSON(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try { return JSON.parse(text.slice(start, end + 1)); } catch { return null; }
}

export async function freeAIJSON(prompt) {
  const text = await freeAI(
    prompt + '\nRespond with ONLY a valid JSON object — no markdown, no code fences, no explanation.'
  );
  const parsed = extractJSON(text) || extractJSON(text.replace(/```json/g, '').replace(/```/g, ''));
  if (!parsed) throw new Error('AI did not return valid JSON');
  return parsed;
}

// Free image generation: a stable URL that renders the prompt on demand.
export function freeImageURL(prompt, width = 1024, height = 1024) {
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&nologo=true`;
}