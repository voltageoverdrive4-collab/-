const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { freeImageURL } from '../../shared/freeAI.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { prompt } = await req.json();
    if (!prompt || typeof prompt !== 'string' || prompt.length > 2000) {
      return Response.json({ error: 'Invalid prompt' }, { status: 400 });
    }

    return Response.json({ url: freeImageURL(prompt.slice(0, 2000)) });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}