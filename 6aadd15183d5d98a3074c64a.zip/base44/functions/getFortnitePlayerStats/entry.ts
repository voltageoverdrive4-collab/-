const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    if (!name || name.length > 40 || /[<>"'`\\]/.test(name)) {
      return Response.json({ error: 'Please provide a valid Fortnite gamertag' }, { status: 400 });
    }

    const apiKey = secrets.get('FORTNITE_API_KEY');
    if (!apiKey) return Response.json({ error: 'Fortnite API key not configured' }, { status: 500 });

    const apiRes = await fetch(
      `https://fortnite-api.com/v2/stats/br/v2?name=${encodeURIComponent(name)}&image=all`,
      { headers: { Authorization: apiKey } }
    );

    if (apiRes.status === 404) {
      return Response.json({ error: `No Fortnite stats found for "${name}". Check the spelling and try again.` }, { status: 404 });
    }
    if (apiRes.status === 403) {
      return Response.json({ error: 'Fortnite API key was rejected — it may be missing the required "stats" scope.' }, { status: 502 });
    }
    if (!apiRes.ok) {
      return Response.json({ error: 'Fortnite stats API unavailable right now' }, { status: 502 });
    }

    const json = await apiRes.json();
    const data = json?.data || {};
    const overall = data?.stats?.all?.overall || null;

    if (!overall) {
      return Response.json({ error: `No Battle Royale stats found for "${name}".` }, { status: 404 });
    }

    const round = (v, d = 1) =>
      typeof v === 'number' && Number.isFinite(v) ? Number(v.toFixed(d)) : null;

    return Response.json({
      account: {
        name: data.account?.name || name,
        id: data.account?.id || null
      },
      overall: {
        wins: overall.wins ?? null,
        winRate: round(overall.winRate),
        matches: overall.matches ?? null,
        kills: overall.kills ?? null,
        deaths: overall.deaths ?? null,
        kd: round(overall.kd, 2),
        killsPerMatch: round(overall.killsPerMatch, 2),
        top3: overall.top3 ?? null,
        top5: overall.top5 ?? null,
        top10: overall.top10 ?? null,
        top25: overall.top25 ?? null,
        playersOutLived: overall.playersOutLived ?? null,
        minutesPlayed: overall.minutesPlayed ?? null
      },
      image: json?.data?.image || null
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}