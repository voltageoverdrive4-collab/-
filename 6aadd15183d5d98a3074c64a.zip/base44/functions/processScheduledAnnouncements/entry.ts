const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getClanUsers, pushToClan } from '../../shared/clanUsers.ts';

// Runs every few minutes from a scheduled workflow: delivers announcements
// whose scheduled time has arrived (bell notification + mobile ping).
// No user session needed (workflow context).
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);

    // if a human calls it, they must be an admin; workflow calls have no user
    try {
      const user = await db.auth.me();
      if (user && user.role !== 'admin') {
        return Response.json({ error: 'Admins only' }, { status: 403 });
      }
    } catch (e) {
      // no session (scheduled workflow) — that's expected, carry on
    }

    const now = new Date().toISOString();
    const due = await db.asServiceRole.entities.Announcement.filter(
      { status: 'pending', send_at: { $lte: now } },
      { limit: 50 }
    );
    const items = due.items || [];
    if (items.length === 0) return Response.json({ ok: true, sent: 0 });

    const users = await getClanUsers(base44);

    let sent = 0;
    for (const a of items) {
      if (users.length > 0) {
        await db.asServiceRole.entities.Notification.bulkCreate(
          users.map((u) => ({ user_id: u.id, title: a.title, body: a.body || '' }))
        );
        await pushToClan(base44, users, {
          title: `⚡ ${a.title}`,
          content: a.body || a.title,
          actionUrl: '/',
        });
      }
      await db.asServiceRole.entities.Announcement.update(a.id, { status: 'sent' });
      sent += 1;
    }

    return Response.json({ ok: true, sent });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}