const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const pickImage = (images) => images?.featured || images?.icon || images?.small || images?.smallIcon || null;

const titleCase = (s) =>
  (s || '').toLowerCase().split(' ').map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

const cosmeticToItem = (cosmetic, price, fallbackType) => ({
  name: cosmetic?.name || 'Unknown item',
  description: cosmetic?.description || '',
  type: cosmetic?.type?.displayValue || fallbackType,
  rarity: titleCase(cosmetic?.rarity?.displayValue || cosmetic?.series?.name || 'Common'),
  price: typeof price === 'number' ? price : 0,
  image: pickImage(cosmetic?.images)
});

// one shop entry can hold several items (e.g. a bundle's cosmetics share one price)
const entryToItems = (e) => {
  const price = typeof e.regularPrice === 'number' ? e.regularPrice : 0;
  if (e.brItems?.length) {
    return e.brItems.map((c) => cosmeticToItem(c, price, 'Item'));
  }
  if (e.bundle) {
    return [{
      name: e.bundle.name || 'Bundle',
      description: e.bundle?.info?.['0'] || '',
      type: 'Bundle',
      rarity: 'Bundle',
      price,
      image: e.bundle?.image || null
    }];
  }
  if (e.instruments?.length) {
    return e.instruments.map((c) => cosmeticToItem(c, price, 'Instrument'));
  }
  if (e.cars?.length) {
    return e.cars.map((c) => cosmeticToItem(c, price, 'Car'));
  }
  if (e.tracks?.length) {
    return e.tracks.map((t) => ({
      name: t?.title || 'Jam Track',
      description: t?.artist ? `by ${t.artist}` : '',
      type: 'Jam Track',
      rarity: 'Common',
      price,
      image: t?.albumArt || null
    }));
  }
  return [];
};

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const apiRes = await fetch('https://fortnite-api.com/v2/shop');
    if (!apiRes.ok) {
      return Response.json({ error: 'Fortnite shop API unavailable' }, { status: 502 });
    }
    const shop = await apiRes.json();
    const entries = shop?.data?.entries || [];

    // group items into the same named sections the in-game shop uses,
    // keeping Fortnite's own section order from the API
    const sections = [];
    const bySectionId = {};
    for (const e of entries) {
      const sec = e.section || {};
      const id = sec.id || sec.name || 'More Items';
      if (!bySectionId[id]) {
        const s = { name: sec.name || 'More Items', items: [] };
        bySectionId[id] = s;
        sections.push(s);
      }
      bySectionId[id].items.push(...entryToItems(e).filter((i) => i.image));
    }

    return Response.json({
      date: shop?.data?.date || null,
      vbuckIcon: shop?.data?.vbuckIcon || null,
      sections
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}