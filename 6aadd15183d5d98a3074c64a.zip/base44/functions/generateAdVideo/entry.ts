const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Admin-only video generator: powers the Video Ads tab so admins can make
// promo clips for the app. Bounded input, fixed Core method, URL-only result.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // admins = platform admins or clan members flagged as admin
    let isAdmin = user.role === 'admin';
    if (!isAdmin) {
      const members = await db.entities.Member.filter({ email: user.email });
      isAdmin = !!(members[0] && members[0].is_admin);
    }
    if (!isAdmin) return Response.json({ error: 'Admins only' }, { status: 403 });

    const body = await req.json();
    const prompt = String(body.prompt || '').trim();
    const aspect_ratio = body.aspect_ratio === '9:16' ? '9:16' : '16:9';
    const duration = [4, 6, 8].includes(Number(body.duration)) ? Number(body.duration) : 6;
    if (prompt.length < 5) return Response.json({ error: 'Describe the video in at least 5 characters' }, { status: 400 });
    if (prompt.length > 1500) return Response.json({ error: 'Keep the description under 1500 characters' }, { status: 400 });

    const result = await db.asServiceRole.integrations.Core.GenerateVideo({
      prompt,
      aspect_ratio,
      duration,
      generate_audio: false,
    });
    const video_url = result?.url || result?.video_url;
    if (!video_url) return Response.json({ error: 'Video generation failed — try again' }, { status: 502 });

    return Response.json({ video_url, aspect_ratio, duration });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}