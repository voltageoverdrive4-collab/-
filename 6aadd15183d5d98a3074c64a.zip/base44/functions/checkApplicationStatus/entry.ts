const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Public status check for applicants — accounts are created only after
// an application is accepted, so callers are usually not logged in.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json({ error: 'Invalid email' }, { status: 400 });
    }

    const apps = await db.asServiceRole.entities.Application.filter({ email });
    if (!apps.length) return Response.json({ status: 'none' });

    // newest application wins
    const latest = apps.reduce((a, b) =>
      String(b.created_date || '') > String(a.created_date || '') ? b : a
    );
    return Response.json({ status: latest.status || 'pending' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}