const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // allow platform admins and clan-level admins (Member.is_admin)
    if (user.role !== 'admin') {
      const mine = await db.entities.Member.filter({ email: user.email });
      const isClanAdmin = Array.isArray(mine) && mine.some((m) => m && m.is_admin);
      if (!isClanAdmin) return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { to, subject, body } = await req.json();
    if (!to || !subject || typeof to !== 'string' || typeof subject !== 'string') {
      return Response.json({ error: 'Missing to/subject' }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) {
      return Response.json({ error: 'Invalid recipient' }, { status: 400 });
    }

    await db.asServiceRole.integrations.Core.SendEmail({
      to,
      subject: subject.slice(0, 200),
      body: (body || '').slice(0, 10000),
      from_name: 'Voltage Clan',
    });
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}