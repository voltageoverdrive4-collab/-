const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Admin-only: sets the clan-wide GUI theme. The value is written with the
// service role so clan-level admins (Member.is_admin) can use it too.
const VALID_THEMES = ['classic', 'ice', 'crimson', 'emerald', 'royal'];
const VALID_LAYOUTS = [
  'sidebar', 'rail', 'topbar', 'side-right', 'rail-right', 'side-compact', 'side-float',
  'rail-float', 'side-right-float', 'side-solid', 'side-clear', 'side-boxed', 'top-icons',
  'top-right', 'top-float', 'top-solid', 'top-boxed', 'top-center', 'dock-icons', 'dock-mini',
  'dock-labels', 'hub', 'hub-strip', 'side-solid-compact', 'side-clear-float', 'side-float-boxed',
  'side-clear-boxed', 'side-solid-boxed', 'rail-solid', 'rail-boxed', 'side-right-compact',
  'side-right-solid', 'side-right-clear', 'rail-right-float', 'side-right-boxed', 'top-clear',
  'top-icons-solid', 'top-float-boxed', 'top-center-float', 'top-right-float', 'dock-mini-labels',
  'hub-solid', 'hub-strip-clear',
];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let isAdmin = user.role === 'admin';
    if (!isAdmin) {
      const members = await db.entities.Member.filter({ email: user.email });
      isAdmin = !!(members[0] && members[0].is_admin);
    }
    if (!isAdmin) return Response.json({ error: 'Admins only' }, { status: 403 });

    const body = await req.json();
    const saveSetting = async (key, value) => {
      const rows = await db.asServiceRole.entities.AppSetting.filter({ key });
      if (rows[0]) await db.asServiceRole.entities.AppSetting.update(rows[0].id, { value });
      else await db.asServiceRole.entities.AppSetting.create({ key, value });
    };

    if (body.theme) {
      const theme = String(body.theme);
      if (!VALID_THEMES.includes(theme)) return Response.json({ error: 'Unknown theme' }, { status: 400 });
      await saveSetting('gui_theme', theme);
    }
    if (body.layout) {
      const layout = String(body.layout);
      if (!VALID_LAYOUTS.includes(layout)) return Response.json({ error: 'Unknown layout' }, { status: 400 });
      await saveSetting('gui_layout', layout);
    }
    if (!body.theme && !body.layout) return Response.json({ error: 'Nothing to set' }, { status: 400 });
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}