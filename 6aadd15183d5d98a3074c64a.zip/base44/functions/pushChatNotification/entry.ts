const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getClanUsers, pushToClan } from '../../shared/clanUsers.ts';

// Called after a clan chat message is posted: pushes a mobile ping to every
// member on the installed app (except the sender).
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const payload = await req.json().catch(() => ({}));
    const channel = (payload.channel || 'general').slice(0, 30);
    const username = (payload.username || user.full_name || 'A clanmate').slice(0, 30);
    const text = (payload.text || '').slice(0, 100);
    if (!text.trim()) return Response.json({ ok: true, pushed: 0 });

    const users = await getClanUsers(base44);
    const pushed = await pushToClan(base44, users, {
      title: `⚡ #${channel} — ${username}`,
      content: text,
      actionUrl: '/chat',
      skipUserId: user.id,
    });
    return Response.json({ ok: true, pushed });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}