const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { Trophy } from 'lucide-react';
import { withRetry } from '@/lib/apiRetry';

const RANK_STYLE = [
  'text-yellow-300 border-yellow-300/40 bg-yellow-300/10',
  'text-slate-200 border-slate-200/40 bg-slate-200/10',
  'text-amber-600 border-amber-600/40 bg-amber-600/10',
];

// Clan XP leaderboard — the top quest earners, ranked by total XP.
export default function QuestLeaderboard() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [members, setMembers] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const myName = user?.full_name || (user?.email || 'player').split('@')[0];

  useEffect(() => {
    (async () => {
      try {
        const [agg, memberList] = await Promise.all([
          withRetry(() => db.entities.QuestCompletion.aggregate({ query: { status: 'accepted' }, groupBy: 'username', sum: 'xp_earned', sort: '-sum_xp_earned', limit: 10 })),
          withRetry(() => db.entities.Member.list()),
        ]);
        setRows((agg.rows || []).filter((r) => r.username));
        const map = {};
        for (const m of memberList) if (m.username) map[m.username.toLowerCase()] = m;
        setMembers(map);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.id]);

  return (
    <div className="volt-panel rounded-3xl mt-6 p-4 sm:p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-[hsl(var(--voltage-yellow))]/25 to-[hsl(var(--voltage-blue))]/25 border border-white/10">
          <Trophy className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" />
        </div>
        <div>
          <div className="font-bold text-white/90">Clan XP Leaderboard</div>
          <p className="text-[11px] text-white/40">Top quest earners in the clan — every completion counts</p>
        </div>
      </div>

      {loading ? (
        <div className="space-y-2 animate-pulse">
          {[0, 1, 2].map((i) => <div key={i} className="h-12 bg-white/10 rounded-2xl" />)}
        </div>
      ) : error ? (
        <div className="text-center text-white/50 text-sm py-4">The leaderboard is busy — try again in a moment.</div>
      ) : rows.length === 0 ? (
        <div className="text-center text-white/50 text-sm py-4 border border-dashed border-white/15 rounded-2xl">
          No XP earned yet — complete a quest to claim the first spot.
        </div>
      ) : (
        <div className="space-y-2">
          {rows.map((r, i) => {
            const rec = members[(r.username || '').toLowerCase()];
            const me = (r.username || '').toLowerCase() === myName.toLowerCase();
            return (
              <div
                key={r.username}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-2.5 ${me
                  ? 'border-[hsl(var(--voltage-yellow))] bg-[hsl(var(--voltage-yellow))]/10'
                  : 'border-white/10 bg-white/[0.04]'}`}
              >
                <span className={`w-8 h-8 rounded-xl grid place-items-center text-sm font-black border shrink-0 ${i < 3 ? RANK_STYLE[i] : 'text-white/50 border-white/10 bg-white/5'}`}>
                  {i + 1}
                </span>
                {rec?.avatar_url ? (
                  <img src={rec.avatar_url} alt="" className="w-8 h-8 rounded-full object-cover border border-white/20 shrink-0" />
                ) : (
                  <span className="w-8 h-8 rounded-full grid place-items-center bg-gradient-to-br from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black font-bold text-sm shrink-0">
                    {(r.username || '?')[0]?.toUpperCase()}
                  </span>
                )}
                <span className="min-w-0 flex-1 truncate text-sm font-semibold text-white/90">
                  {r.username}
                  {me && <span className="ml-2 text-[10px] font-bold text-[hsl(var(--voltage-yellow))] uppercase tracking-wider">You</span>}
                </span>
                <span className="text-sm font-black text-[hsl(var(--voltage-yellow))] tabular-nums">{r.sum_xp_earned || 0} XP</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}