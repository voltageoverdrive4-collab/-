import React, { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { KeyRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { saveAppSetting } from '@/lib/appSettings';

// Shown when the Fortnite API key isn't connected yet: admins paste their
// free fortnite-api.com key right here, everyone else sees a heads-up.
export default function ApiKeySetup({ onSaved }) {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [key, setKey] = useState('');
  const [saving, setSaving] = useState(false);

  if (!isAdmin) {
    return (
      <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 p-4 text-sm text-amber-200">
        Fortnite stats need a free fortnite-api.com API key — ask an admin to connect it in this tab.
      </div>
    );
  }

  const save = async () => {
    if (!key.trim()) { toast.error('Paste the API key first'); return; }
    setSaving(true);
    try {
      await saveAppSetting('fortnite_api_key', key.trim());
      toast.success('Fortnite API key connected — searches work now');
      setKey('');
      onSaved?.();
    } catch {
      toast.error('Could not save the key — try again');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-xl border border-[hsl(var(--voltage-yellow))]/30 bg-[hsl(var(--voltage-yellow))]/5 p-4">
      <p className="text-sm text-white/70 mb-3 flex items-center gap-2">
        <KeyRound className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" />
        Connect a free fortnite-api.com API key (with the <span className="font-mono">stats</span> scope) to unlock player stats and account worth.
      </p>
      <div className="flex gap-2">
        <Input
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="Paste your fortnite-api.com API key"
          className="bg-black/40 border-white/20 text-white placeholder:text-white/40"
        />
        <Button onClick={save} disabled={saving || !key.trim()} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          {saving ? 'Saving…' : 'Connect'}
        </Button>
      </div>
    </div>
  );
}