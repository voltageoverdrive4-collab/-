import React from 'react';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { useMusicPlayer } from '@/lib/MusicPlayer';

// Floating mini player — play/pause, mute and volume for whatever song is
// playing, reachable from every tab.
export default function MiniPlayer() {
  const { current, playing, muted, volume, setVolume, toggleMute, playSong } = useMusicPlayer();
  if (!current) return null;
  return (
    <div className="fixed bottom-14 right-4 z-40 flex items-center gap-3 rounded-2xl border border-[hsl(var(--voltage-yellow))]/30 bg-black/75 backdrop-blur-xl px-3.5 py-2.5 shadow-[0_10px_40px_rgba(0,0,0,0.6)]">
      <button
        type="button"
        onClick={() => playSong(current)}
        className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black"
        title={playing ? 'Pause' : 'Play'}
      >
        {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
      </button>
      <div className="max-w-[150px] truncate text-xs font-semibold text-white/85">{current.title}</div>
      <button type="button" onClick={toggleMute} className="text-white/60 hover:text-white" title={muted ? 'Unmute' : 'Mute'}>
        {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
      </button>
      <input
        type="range"
        min="0"
        max="1"
        step="0.01"
        value={muted ? 0 : volume}
        onChange={(e) => setVolume(parseFloat(e.target.value))}
        className="w-20 accent-[hsl(var(--voltage-yellow))]"
        title="Volume"
      />
    </div>
  );
}