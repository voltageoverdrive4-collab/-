const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Zap, Send, CheckCircle2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function SignupForm() {
  const [form, setForm] = useState({ username: '', email: '', age: '', message: '' });
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await db.entities.Application.create({
        username: form.username.trim(),
        email: form.email.trim(),
        age: form.age ? parseInt(form.age, 10) : undefined,
        message: form.message.trim(),
        status: 'pending',
      });
      setDone(true);
      setForm({ username: '', email: '', age: '', message: '' });
    } catch (err) {
      setError(err.message || 'Something went wrong. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="text-center py-10 px-6 rounded-2xl bg-white/5 border border-white/10">
        <CheckCircle2 className="w-12 h-12 mx-auto text-[hsl(var(--voltage-yellow))] mb-4" />
        <h3 className="text-2xl font-bold mb-2">Application received.</h3>
        <p className="text-white/60 mb-6">The Voltage council will review your request. Stay charged.</p>
        <Button onClick={() => setDone(false)} variant="outline" className="border-white/20 text-white hover:bg-white/10">
          Submit another
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5 p-6 sm:p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl">
      <div className="grid sm:grid-cols-2 gap-5">
        <div className="space-y-2">
          <Label className="text-white/80">Username</Label>
          <Input required value={form.username} onChange={update('username')} placeholder="Your gamertag" className="bg-black/40 border-white/15 text-white placeholder:text-white/30" />
        </div>
        <div className="space-y-2">
          <Label className="text-white/80">Email</Label>
          <Input required type="email" value={form.email} onChange={update('email')} placeholder="you@email.com" className="bg-black/40 border-white/15 text-white placeholder:text-white/30" />
        </div>
      </div>
      <div className="space-y-2">
        <Label className="text-white/80">Age</Label>
        <Input type="number" min="1" max="120" value={form.age} onChange={update('age')} placeholder="Optional" className="bg-black/40 border-white/15 text-white placeholder:text-white/30" />
      </div>
      <div className="space-y-2">
        <Label className="text-white/80">Short message</Label>
        <Textarea value={form.message} onChange={update('message')} placeholder="Why do you want to join Voltage?" rows={4} className="bg-black/40 border-white/15 text-white placeholder:text-white/30" />
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <Button type="submit" disabled={submitting} className="w-full bg-[hsl(var(--voltage-yellow))] text-black font-bold hover:brightness-110">
        {submitting ? 'Transmitting…' : (<><Send className="w-4 h-4 mr-2" /> Join Voltage</>)}
      </Button>
    </form>
  );
}