import React from 'react';
import { Zap } from 'lucide-react';
import './intro.css';

// Phase 3 — a giant bolt slams down from the sky in a white flash and shakes
// the whole screen.
export default function StrikeFlash() {
  return (
    <div className="fixed inset-0 z-50 pointer-events-none grid place-items-center overflow-hidden">
      <div className="intro-strike-flash absolute inset-0 bg-white" />
      <div className="intro-strike-bolt">
        <Zap className="w-20 h-20 text-[hsl(var(--voltage-yellow))]" fill="currentColor" />
      </div>
    </div>
  );
}