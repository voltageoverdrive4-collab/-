import React, { useEffect, useState } from 'react';
import './intro.css';

// Typewriter line — the tagline types itself out with a blinking caret.
export function TypeLine({ text }) {
  return <span className="intro-typed">{text}</span>;
}

// Number that counts up from 0 — used for the live clan stat chips.
export function CountUp({ to, duration = 1100 }) {
  const [n, setN] = useState(0);

  useEffect(() => {
    let raf;
    const start = performance.now();
    const tick = (t) => {
      const p = Math.min(1, (t - start) / duration);
      setN(Math.round(to * p));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);

  return <>{n}</>;
}