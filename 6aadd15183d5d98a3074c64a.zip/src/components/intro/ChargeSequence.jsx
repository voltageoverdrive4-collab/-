import React, { useEffect, useState } from 'react';
import { Zap } from 'lucide-react';
import './intro.css';

// Phase 2 — the volt core charges up: spinning rings, a pulsing core and a
// live percentage climbing to 100%.
export default function ChargeSequence() {
  const [pct, setPct] = useState(0);

  useEffect(() => {
    let raf;
    const start = performance.now();
    const D = 2800;
    const tick = (t) => {
      const p = Math.min(1, (t - start) / D);
      setPct(Math.round(p * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/85 pointer-events-none">
      <div className="relative w-52 h-52 sm:w-64 sm:h-64">
        <div className="intro-ring absolute inset-0 rounded-full border-2 border-dashed border-[hsl(var(--voltage-yellow))]/40" />
        <div className="intro-ring-rev absolute inset-5 rounded-full border border-[hsl(var(--voltage-blue))]/50" />
        <div className="intro-core-pulse absolute inset-11 rounded-full bg-[hsl(var(--voltage-yellow))]/15 grid place-items-center">
          <Zap className="w-12 h-12 p-1 text-[hsl(var(--voltage-yellow))]" fill="currentColor" />
        </div>
      </div>
      <div className="mt-9 text-center">
        <p className="text-[hsl(var(--voltage-yellow))] font-black text-5xl tabular-nums volt-glow-pill rounded px-3 inline-block">{pct}%</p>
        <p className="text-[hsl(var(--voltage-blue))] tracking-[0.5em] text-[10px] uppercase mt-3 animate-pulse">Charging volt core</p>
      </div>
    </div>
  );
}