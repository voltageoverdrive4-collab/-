import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

const N = 6;
const DIRS = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];
const init = () => {
  const b = Array.from({ length: N }, () => Array(N).fill(null));
  b[2][2] = 'B'; b[2][3] = 'Y'; b[3][2] = 'Y'; b[3][3] = 'B';
  return b;
};

function flipsFor(b, r, c, p) {
  if (b[r][c]) return [];
  let all = [];
  for (const [dr, dc] of DIRS) {
    const line = [];
    let rr = r + dr, cc = c + dc;
    while (rr >= 0 && rr < N && cc >= 0 && cc < N && b[rr][cc] && b[rr][cc] !== p) { line.push([rr, cc]); rr += dr; cc += dc; }
    if (line.length && rr >= 0 && rr < N && cc >= 0 && cc < N && b[rr][cc] === p) all = all.concat(line);
  }
  return all;
}

const validMoves = (b, p) => {
  const moves = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (flipsFor(b, r, c, p).length) moves.push([r, c]);
  return moves;
};

function apply(b, r, c, p) {
  const next = b.map((row) => [...row]);
  next[r][c] = p;
  for (const [fr, fc] of flipsFor(b, r, c, p)) next[fr][fc] = p;
  return next;
}

// 6x6 Reversi vs VoltBot — flip the most discs, most discs at the end wins.
export default function VoltReversi() {
  const [board, setBoard] = useState(init);
  const [passMsg, setPassMsg] = useState('');
  const [over, setOver] = useState(false);

  const counts = board.flat().reduce((acc, v) => { acc[v] = (acc[v] || 0) + 1; return acc; }, {});

  const finishIfDone = (b) => {
    const yMoves = validMoves(b, 'Y');
    const bMoves = validMoves(b, 'B');
    if (yMoves.length === 0 && bMoves.length === 0) setOver(true);
  };

  const botTurn = (b) => {
    let best = null;
    let bestFlips = -1;
    for (const [r, c] of validMoves(b, 'B')) {
      const f = flipsFor(b, r, c, 'B').length;
      if (f > bestFlips) { bestFlips = f; best = [r, c]; }
    }
    let next = b;
    if (best) next = apply(b, best[0], best[1], 'B');
    else setPassMsg('VoltBot had to pass');
    setBoard(next);
    finishIfDone(next);
    if (validMoves(next, 'Y').length === 0 && !over) {
      setPassMsg('You had to pass — VoltBot goes again');
      setTimeout(() => botTurn(next), 600);
    }
  };

  const click = (r, c) => {
    if (over) return;
    if (flipsFor(board, r, c, 'Y').length === 0) return;
    setPassMsg('');
    const next = apply(board, r, c, 'Y');
    setBoard(next);
    if (validMoves(next, 'B').length > 0) {
      setTimeout(() => botTurn(next), 500);
    } else {
      setPassMsg('VoltBot had to pass — go again');
      finishIfDone(next);
    }
  };

  const restart = () => { setBoard(init()); setOver(false); setPassMsg(''); };
  const y = counts.Y || 0;
  const b = counts.B || 0;
  const result = over ? (y > b ? 'You win! 🏆' : y < b ? 'VoltBot wins 🤖' : 'A tie!') : null;

  useEffect(() => { finishIfDone(board); /* eslint-disable-next-line */ }, [board]);

  return (
    <div className="max-w-md mx-auto text-center space-y-4">
      <div className="grid grid-cols-6 gap-1.5 bg-black/40 p-3 rounded-xl border border-white/10">
        {board.map((row, r) => (
          row.map((cell, c) => {
            const valid = !over && !cell && flipsFor(board, r, c, 'Y').length > 0;
            return (
              <button
                key={`${r}-${c}`}
                onClick={() => click(r, c)}
                className={`aspect-square rounded-md flex items-center justify-center transition-colors ${valid ? 'bg-[hsl(var(--voltage-yellow))]/10 hover:bg-[hsl(var(--voltage-yellow))]/25' : 'bg-white/5'}`}
              >
                {cell && <span className={`w-4/5 h-4/5 rounded-full ${cell === 'Y' ? 'bg-[hsl(var(--voltage-yellow))]' : 'bg-slate-700 border border-white/20'}`} />}
              </button>
            );
          })
        ))}
      </div>
      <p className="text-sm text-white/70">
        <span className="font-bold text-[hsl(var(--voltage-yellow))]">You {y}</span>
        <span className="mx-2 text-white/30">vs</span>
        <span className="font-bold">VoltBot {b}</span>
      </p>
      <p className="text-xs text-white/50">{over ? result : passMsg || 'You are yellow — click a highlighted square'}</p>
      {over && <Button size="sm" variant="outline" className="border-white/20" onClick={restart}>Play Again</Button>}
    </div>
  );
}