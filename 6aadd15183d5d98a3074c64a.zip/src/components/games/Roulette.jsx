import React, { useState } from 'react';

const RED = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
const colorOf = (n) => (n === 0 ? 'green' : RED.has(n) ? 'red' : 'black');

// Pick your bet, spin the wheel — straight numbers pay 35:1.
export default function Roulette() {
  const [bank, setBank] = useState(100);
  const [betType, setBetType] = useState('red');
  const [number, setNumber] = useState(7);
  const [spin, setSpin] = useState(null);
  const [flash, setFlash] = useState('');

  const play = () => {
    if (bank < 10) return;
    setFlash('');
    setBank((v) => v - 10);
    const n = Math.floor(Math.random() * 37);
    setSpin(n);
    const c = colorOf(n);
    let won = 0;
    if (betType === 'number' && n === number) won = 360;
    else if (betType === 'red' && c === 'red') won = 20;
    else if (betType === 'black' && c === 'black') won = 20;
    else if (betType === 'odd' && n !== 0 && n % 2 === 1) won = 20;
    else if (betType === 'even' && n !== 0 && n % 2 === 0) won = 20;
    else if (betType === 'low' && n >= 1 && n <= 18) won = 20;
    else if (betType === 'high' && n >= 19) won = 20;
    if (won) {
      setBank((v) => v + won);
      setFlash(`It's ${n} ${c} — you win ${won - 10}!`);
    } else {
      setFlash(`It's ${n} ${c} — house keeps your 10`);
    }
  };

  const types = ['red', 'black', 'odd', 'even', 'low', 'high', 'number'];

  return (
    <div className="max-w-md mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">Bet 10 · even-money bets pay 1:1 · a straight number pays 35:1.</p>
      <p className="text-sm text-white/60">Bank: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{bank}</span></p>
      {spin !== null && (
        <div className={`mx-auto w-24 h-24 rounded-full flex items-center justify-center text-4xl font-black border-4 ${colorOf(spin) === 'red' ? 'border-red-500 text-red-400 bg-red-950' : colorOf(spin) === 'black' ? 'border-white/30 bg-black' : 'border-emerald-500 text-emerald-400 bg-emerald-950'}`}>
          {spin}
        </div>
      )}
      <div className="flex flex-wrap justify-center gap-2">
        {types.map((t) => (
          <button
            key={t}
            onClick={() => setBetType(t)}
            className={`px-4 py-1.5 rounded-full text-sm font-bold border capitalize transition-colors ${betType === t ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]' : 'border-white/15 text-white/50'}`}
          >
            {t}
          </button>
        ))}
      </div>
      {betType === 'number' && (
        <input
          type="number"
          min={0}
          max={36}
          value={number}
          onChange={(e) => setNumber(Math.max(0, Math.min(36, Number(e.target.value) || 0)))}
          className="w-24 mx-auto block rounded-xl border border-white/15 bg-black/40 text-center font-bold text-white"
        />
      )}
      <button onClick={play} disabled={bank < 10} className="px-8 py-2 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black disabled:opacity-40">
        Spin
      </button>
      <p className="text-xs text-white/40">{flash || `Betting on ${betType}`}</p>
    </div>
  );
}