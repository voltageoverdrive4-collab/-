import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const RIDDLES = [
  { e: '🧊👯', a: 'frozen' },
  { e: '🐢🍕', a: 'ninja turtles' },
  { e: '👑🦁', a: 'the lion king' },
  { e: '🕷️🧑', a: 'spider-man' },
  { e: '🔍🐟', a: 'finding nemo' },
  { e: '🎤🐍', a: 'taylor swift' },
  { e: '🎃👻', a: 'halloween' },
  { e: '🍔🍟', a: 'fast food' },
  { e: '🌙🐺', a: 'werewolf' },
  { e: '🚗💨', a: 'racing' },
];

export default function EmojiRiddle() {
  const [idx, setIdx] = useState(0);
  const [solved, setSolved] = useState(0);
  const [input, setInput] = useState('');
  const [msg, setMsg] = useState('');
  const [hint, setHint] = useState('');
  const done = idx >= RIDDLES.length;
  const r = RIDDLES[Math.min(idx, RIDDLES.length - 1)];

  const submit = (e) => {
    e.preventDefault();
    if (done || !input.trim()) return;
    if (input.trim().toLowerCase() === r.a) {
      setSolved((s) => s + 1);
      setMsg('');
      setHint('');
      setIdx(idx + 1);
    } else {
      setMsg('Not quite — try again!');
    }
    setInput('');
  };

  const restart = () => {
    setIdx(0);
    setSolved(0);
    setInput('');
    setMsg('');
    setHint('');
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto text-center">
      <p className="text-white/50 text-sm">Guess the phrase from the emojis. {Math.min(idx + 1, RIDDLES.length)}/{RIDDLES.length}</p>
      {done ? (
        <div className="space-y-3">
          <p className="text-5xl">🏆</p>
          <p className="font-bold text-[hsl(var(--voltage-yellow))]">You solved {solved}/{RIDDLES.length} riddles!</p>
          <Button onClick={restart} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Play again</Button>
        </div>
      ) : (
        <>
          <p className="text-6xl">{r.e}</p>
          <form onSubmit={submit} className="flex gap-2 justify-center">
            <Input autoFocus value={input} onChange={(e) => setInput(e.target.value)} className="w-56 bg-black/40 border-white/15 text-white text-center" />
            <Button type="submit" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Guess</Button>
          </form>
          {msg && <p className="text-red-400 font-semibold">{msg}</p>}
          {hint ? (
            <p className="text-white/60 text-sm">Hint: {hint}</p>
          ) : (
            <button onClick={() => setHint(`starts with "${r.a[0].toUpperCase()}"`)} className="text-xs underline text-[hsl(var(--voltage-blue))]">Need a hint?</button>
          )}
        </>
      )}
    </div>
  );
}