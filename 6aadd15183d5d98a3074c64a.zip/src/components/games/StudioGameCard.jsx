import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2 } from 'lucide-react';

// Hub card for a game a member published from Voltage Studio.
// Admins get Edit (opens the game in Studio) and Delete buttons.
export default function StudioGameCard({ game, isAdmin, onPlay, onEdit, onDelete }) {
  const [confirming, setConfirming] = useState(false);

  return (
    <div className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[hsl(var(--voltage-yellow))]/50 hover:-translate-y-0.5 transition-all flex flex-col">
      <button onClick={onPlay} className="w-full text-left flex-1">
        <div className="flex items-start justify-between mb-2">
          <span className="font-bold text-sm">{game.name}</span>
        </div>
        <Badge variant="outline" className="text-[10px] border-white/20 text-white/50">{game.category}</Badge>
        {game.by && <p className="text-[10px] text-white/30 mt-1.5">by {game.by}</p>}
      </button>

      {isAdmin && (
        confirming ? (
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 text-xs">
            <span className="text-white/60 flex-1">Delete this game?</span>
            <Button size="sm" variant="destructive" className="h-7 px-2 text-xs" onClick={onDelete}>Yes</Button>
            <Button size="sm" variant="outline" className="h-7 px-2 text-xs border-white/20 bg-transparent text-white" onClick={() => setConfirming(false)}>No</Button>
          </div>
        ) : (
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2">
            <button onClick={onEdit} className="flex items-center gap-1 text-xs text-white/60 hover:text-white transition-colors">
              <Pencil className="w-3 h-3" /> Edit
            </button>
            <button onClick={() => setConfirming(true)} className="flex items-center gap-1 text-xs text-white/60 hover:text-red-400 transition-colors">
              <Trash2 className="w-3 h-3" /> Delete
            </button>
          </div>
        )
      )}
    </div>
  );
}