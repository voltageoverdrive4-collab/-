import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

export default function ReactionGrid() {
  const [lit, setLit] = useState(null);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(30);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setTime((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [running]);

  useEffect(() => {
    if (running && time === 0) { setRunning(false); setLit(null); }
  }, [time, running]);

  const start = () => {
    setScore(0);
    setTime(30);
    setRunning(true);
    setLit(Math.floor(Math.random() * 9));
  };

  const hit = (i) => {
    if (!running) return;
    if (i === lit) {
      setScore((s) => s + 1);
      setLit(Math.floor(Math.random() * 9));
    } else {
      setScore((s) => Math.max(0, s - 1));
    }
  };

  return (
    <div className="space-y-4 max-w-md mx-auto text-center">
      <p className="text-white/50 text-sm">Smash the glowing cell — +1 per hit, -1 for a miss. 30 seconds on the clock.</p>
      <div className="grid grid-cols-3 gap-2">
        {Array.from({ length: 9 }, (_, i) => (
          <button
            key={i}
            onClick={() => hit(i)}
            className={`aspect-square rounded-xl border transition-all ${
              i === lit
                ? 'bg-[hsl(var(--voltage-yellow))] border-[hsl(var(--voltage-yellow))] shadow-[0_0_24px_hsl(var(--voltage-yellow)))/0.6]'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          />
        ))}
      </div>
      {running ? (
        <p className="font-semibold">Score: <span className="text-[hsl(var(--voltage-yellow))]">{score}</span> · {time}s</p>
      ) : (
        <div className="space-y-2">
          {time === 0 && <p className="font-bold text-[hsl(var(--voltage-yellow))]">Final score: {score}</p>}
          <Button onClick={start} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
            {time === 0 ? 'Play again' : 'Start'}
          </Button>
        </div>
      )}
    </div>
  );
}