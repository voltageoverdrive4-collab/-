import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

const N = 8, MINES = 10;

const makeBoard = () => {
  const cells = Array.from({ length: N * N }, () => ({ mine: false, revealed: false, flag: false, count: 0 }));
  let placed = 0;
  while (placed < MINES) {
    const i = Math.floor(Math.random() * N * N);
    if (!cells[i].mine) { cells[i].mine = true; placed++; }
  }
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    let n = 0;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      const rr = r + dr, cc = c + dc;
      if (rr >= 0 && rr < N && cc >= 0 && cc < N && cells[rr * N + cc].mine) n++;
    }
    cells[r * N + c].count = n;
  }
  return cells;
};

const NUM_COLOR = ['', 'text-blue-400', 'text-green-400', 'text-red-400', 'text-purple-400', 'text-orange-400', 'text-cyan-400', 'text-pink-400', 'text-white'];

export default function Minesweeper() {
  const [cells, setCells] = useState(makeBoard);
  const [state, setState] = useState('playing');

  const click = (i) => {
    if (state !== 'playing' || cells[i].revealed || cells[i].flag) return;
    const arr = cells.map((c) => ({ ...c }));
    if (arr[i].mine) {
      arr.forEach((c) => { if (c.mine) c.revealed = true; });
      setCells(arr);
      setState('lost');
      return;
    }
    const stack = [i];
    while (stack.length) {
      const j = stack.pop();
      const c = arr[j];
      if (c.revealed || c.flag) continue;
      c.revealed = true;
      if (c.count === 0) {
        const r = Math.floor(j / N), col = j % N;
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          const rr = r + dr, cc = col + dc;
          if (rr >= 0 && rr < N && cc >= 0 && cc < N) {
            const k = rr * N + cc;
            if (!arr[k].revealed && !arr[k].mine) stack.push(k);
          }
        }
      }
    }
    if (arr.every((c) => c.mine || c.revealed)) setState('won');
    setCells(arr);
  };

  const flag = (i, e) => {
    e.preventDefault();
    if (state !== 'playing' || cells[i].revealed) return;
    const arr = cells.map((c) => ({ ...c }));
    arr[i].flag = !arr[i].flag;
    setCells(arr);
  };

  const reset = () => { setCells(makeBoard()); setState('playing'); };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-4 flex-wrap justify-center">
        <span className="font-bold">🚩 {cells.filter((c) => c.flag).length}/{MINES}</span>
        {state !== 'playing' && (
          <span className={`font-bold ${state === 'won' ? 'text-[hsl(var(--voltage-yellow))]' : 'text-red-400'}`}>
            {state === 'won' ? 'Field cleared! ⚡' : 'Boom! You hit a mine.'}
          </span>
        )}
        <Button size="sm" variant="outline" onClick={reset} className="border-white/20 text-white">Reset</Button>
      </div>
      <div className="grid grid-cols-8 gap-1" onContextMenu={(e) => e.preventDefault()}>
        {cells.map((c, i) => (
          <button
            key={i}
            onClick={() => click(i)}
            onContextMenu={(e) => flag(i, e)}
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded text-sm font-bold ${c.revealed ? (c.mine ? 'bg-red-500/30' : 'bg-white/10') : 'bg-white/5 border border-white/15 hover:bg-white/10'} ${c.revealed && !c.mine ? NUM_COLOR[c.count] : ''}`}
          >
            {c.revealed ? (c.mine ? '💥' : (c.count || '')) : (c.flag ? '🚩' : '')}
          </button>
        ))}
      </div>
      <p className="text-white/40 text-xs">Click to reveal • right-click to flag • clear every safe cell to win</p>
    </div>
  );
}