import React, { useState } from 'react';

const SUITS = ['♠', '♥', '♦', '♣'];
const freshDeck = () => SUITS.flatMap((s) => ['A', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'J', 'Q', 'K'].map((r) => ({ r, s }))).sort(() => Math.random() - 0.5);
const cardValue = (r) => (r === 'A' ? 1 : ['J', 'Q', 'K', '0'].includes(r) ? 0 : Number(r));
const total = (cards) => cards.reduce((sum, c) => sum + cardValue(c.r), 0) % 10;

// Player vs Banker — closest hand to nine wins.
export default function Baccarat() {
  const [bank, setBank] = useState(100);
  const [side, setSide] = useState('Player');
  const [hands, setHands] = useState(null);
  const [flash, setFlash] = useState('');

  const deal = () => {
    if (bank < 10) return;
    setFlash('');
    setBank((v) => v - 10);
    const deck = freshDeck();
    const player = [deck.pop(), deck.pop()];
    const banker = [deck.pop(), deck.pop()];
    if (total(player) < 8 && total(banker) < 8) {
      if (total(player) < 6) player.push(deck.pop());
      if (total(banker) < 6) banker.push(deck.pop());
    }
    setHands({ player, banker });
    const p = total(player);
    const b = total(banker);
    const winner = p > b ? 'Player' : b > p ? 'Banker' : 'Tie';
    if (winner === side) {
      const win = side === 'Tie' ? 80 : side === 'Banker' ? 19 : 20;
      setBank((v) => v + 10 + win);
      setFlash(`${winner} wins ${p}–${b} — you win ${win}!`);
    } else {
      setFlash(`${winner} wins ${p}–${b} — house keeps your 10`);
    }
  };

  const Hand = ({ label, cards, t }) => (
    <div className="flex-1 rounded-xl border border-white/10 bg-black/50 p-3">
      <p className="text-xs uppercase tracking-widest text-white/40">{label}</p>
      <div className="flex justify-center gap-1 my-2 min-h-16">
        {cards.map((c, i) => (
          <div key={i} className={`w-10 h-16 rounded-lg bg-white text-black flex flex-col items-center justify-center font-black ${['♥', '♦'].includes(c.s) ? 'text-red-600' : ''}`}>
            <span>{c.r === '0' ? '10' : c.r}</span>
            <span>{c.s}</span>
          </div>
        ))}
      </div>
      <p className="font-bold text-[hsl(var(--voltage-yellow))]">Total: {t}</p>
    </div>
  );

  return (
    <div className="max-w-lg mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">Bet 10 · Player pays 1:1, Banker pays 0.95:1, Tie pays 8:1.</p>
      <p className="text-sm text-white/60">Bank: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{bank}</span></p>
      <div className="flex justify-center gap-2">
        {['Player', 'Banker', 'Tie'].map((s) => (
          <button
            key={s}
            onClick={() => setSide(s)}
            className={`px-5 py-2 rounded-xl text-sm font-bold border transition-colors ${side === s ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]' : 'border-white/15 text-white/50'}`}
          >
            {s}
          </button>
        ))}
        <button onClick={deal} disabled={bank < 10} className="px-6 py-2 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black disabled:opacity-40">
          Deal
        </button>
      </div>
      {hands ? (
        <div className="flex gap-3">
          <Hand label="Player" cards={hands.player} t={total(hands.player)} />
          <Hand label="Banker" cards={hands.banker} t={total(hands.banker)} />
        </div>
      ) : (
        <p className="text-white/30 text-sm">Place your bet on {side} and deal.</p>
      )}
      {flash && <p className="font-bold text-white/80">{flash}</p>}
    </div>
  );
}