import React, { useEffect, useRef, useState } from 'react';

const W = 320, H = 420, PR = 12;

export default function BombDodger() {
  const canvasRef = useRef(null);
  const [best, setBest] = useState(0);
  const [over, setOver] = useState(false);
  const [running, setRunning] = useState(false);
  const g = useRef({ px: W / 2, bombs: [], t: 0, spawn: 0, dead: false });

  const start = () => {
    g.current = { px: W / 2, bombs: [], t: 0, spawn: 0, dead: false };
    setOver(false);
    setRunning(true);
  };

  useEffect(() => {
    if (!running) return undefined;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let raf;
    const onMove = (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      g.current.px = Math.max(PR, Math.min(W - PR, x));
    };
    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('touchmove', onMove);
    const loop = () => {
      const s = g.current;
      s.t += 1 / 60;
      s.spawn -= 1 / 60;
      if (s.spawn <= 0) {
        s.bombs.push({ x: 20 + Math.random() * (W - 40), y: -20, v: 120 + Math.random() * 80 + s.t * 6 });
        s.spawn = Math.max(0.25, 0.8 - s.t * 0.02);
      }
      for (const b of s.bombs) b.y += b.v / 60;
      s.bombs = s.bombs.filter((b) => b.y < H + 20);
      for (const b of s.bombs) {
        if (Math.hypot(b.x - s.px, b.y - (H - 30)) < 10 + PR) s.dead = true;
      }
      if (s.dead) {
        setRunning(false);
        setOver(true);
        setBest((prev) => Math.max(prev, Math.floor(s.t)));
        return;
      }
      ctx.fillStyle = '#05070f';
      ctx.fillRect(0, 0, W, H);
      ctx.font = '16px serif';
      s.bombs.forEach((b) => ctx.fillText('💣', b.x - 8, b.y));
      ctx.fillText('⚡', s.px - 8, H - 24);
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px monospace';
      ctx.fillText(`${s.t.toFixed(1)}s`, 8, 16);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener('mousemove', onMove);
      canvas.removeEventListener('touchmove', onMove);
    };
  }, [running]);

  return (
    <div className="flex flex-col items-center gap-3">
      <p className="text-sm text-white/60 text-center">Move with your mouse or finger — dodge the bombs! Best: {best}s</p>
      <canvas ref={canvasRef} width={W} height={H} className="rounded-xl border border-white/10 touch-none" />
      {!running && (
        <button onClick={start} className="px-5 py-2 rounded-lg bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          {over ? `You survived ${Math.floor(g.current.t)}s — retry` : 'Start'}
        </button>
      )}
    </div>
  );
}