import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowUp, ArrowDown } from 'lucide-react';

const rand = () => 1 + Math.floor(Math.random() * 100);

export default function HigherLower() {
  const [current, setCurrent] = useState(rand);
  const [next, setNext] = useState(null);
  const [streak, setStreak] = useState(0);
  const [best, setBest] = useState(0);
  const [result, setResult] = useState('');

  const guess = (higher) => {
    const n = rand();
    const correct = higher ? n > current : n < current;
    setNext(n);
    if (correct) {
      const s = streak + 1;
      setStreak(s);
      setBest((b) => Math.max(b, s));
      setResult('Called it! ⚡');
    } else {
      setStreak(0);
      setResult(n === current ? 'Same number — no luck!' : 'Wrong call!');
    }
    setTimeout(() => { setCurrent(n); setNext(null); setResult(''); }, 1200);
  };

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-6 font-bold">
        <span>Streak: {streak}</span>
        <span className="text-white/50">Best: {best}</span>
      </div>
      <div className="flex items-center gap-6">
        <div className="w-24 h-24 rounded-xl bg-white/5 border border-white/15 flex items-center justify-center text-4xl font-black">{current}</div>
        <span className="text-white/40 font-bold">vs</span>
        <div className="w-24 h-24 rounded-xl bg-[hsl(var(--voltage-yellow))]/10 border border-[hsl(var(--voltage-yellow))]/30 flex items-center justify-center text-4xl font-black">
          {next !== null ? next : '?'}
        </div>
      </div>
      {result && <p className={`font-bold ${result.startsWith('Called') ? 'text-[hsl(var(--voltage-yellow))]' : 'text-red-400'}`}>{result}</p>}
      <div className="flex gap-4">
        <Button size="lg" disabled={next !== null} onClick={() => guess(true)} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold px-8"><ArrowUp className="w-5 h-5 mr-2" /> Higher</Button>
        <Button size="lg" variant="outline" disabled={next !== null} onClick={() => guess(false)} className="border-white/20 text-white hover:bg-white/10 px-8"><ArrowDown className="w-5 h-5 mr-2" /> Lower</Button>
      </div>
      <p className="text-white/40 text-xs">Will the next number (1–100) be higher or lower?</p>
    </div>
  );
}