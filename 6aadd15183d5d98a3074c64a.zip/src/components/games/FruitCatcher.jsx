import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';

const FRUITS = ['🍎', '🍌', '🍇', '🍉', '🍓'];

// Catch the falling fruit with the basket — three bombs and you're done.
export default function FruitCatcher() {
  const canvasRef = useRef(null);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [over, setOver] = useState(false);
  const [running, setRunning] = useState(false);
  const st = useRef({ items: [], basket: 200, score: 0, lives: 3, over: false, spawn: 0.5, keys: {} });

  useEffect(() => {
    if (!running) return undefined;
    let raf;
    let last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = st.current;
      const canvas = canvasRef.current;
      if (canvas && !s.over) {
        if (s.keys.ArrowLeft) s.basket -= 320 * dt;
        if (s.keys.ArrowRight) s.basket += 320 * dt;
        s.basket = Math.max(30, Math.min(370, s.basket));
        s.spawn -= dt;
        if (s.spawn <= 0) {
          const bomb = Math.random() < 0.22;
          s.items.push({ x: 20 + Math.random() * 360, y: -20, vy: 120 + Math.random() * 90, emoji: bomb ? '💣' : FRUITS[Math.floor(Math.random() * FRUITS.length)], bomb });
          s.spawn = 0.45 + Math.random() * 0.5;
        }
        s.items.forEach((it) => { it.y += it.vy * dt; });
        s.items = s.items.filter((it) => {
          if (it.y >= 440 && Math.abs(it.x - s.basket) < 42) {
            if (it.bomb) { s.lives -= 1; } else { s.score += 1; }
            return false;
          }
          return it.y < 500;
        });
        if (s.lives <= 0) { s.over = true; setOver(true); setRunning(false); }
        setScore(s.score);
        setLives(s.lives);

        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, 400, 480);
        ctx.fillStyle = '#0a0e14';
        ctx.fillRect(0, 0, 400, 480);
        ctx.font = '30px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        for (const it of s.items) ctx.fillText(it.emoji, it.x, it.y);
        ctx.fillStyle = '#ffe00f';
        ctx.beginPath();
        ctx.moveTo(s.basket - 42, 450);
        ctx.lineTo(s.basket + 42, 450);
        ctx.lineTo(s.basket + 30, 478);
        ctx.lineTo(s.basket - 30, 478);
        ctx.closePath();
        ctx.fill();
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  useEffect(() => {
    const down = (e) => { st.current.keys[e.code] = true; };
    const up = (e) => { st.current.keys[e.code] = false; };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  const start = () => {
    st.current = { items: [], basket: 200, score: 0, lives: 3, over: false, spawn: 0.5, keys: {} };
    setScore(0); setLives(3); setOver(false); setRunning(true);
  };

  const moveMouse = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    st.current.basket = Math.max(30, Math.min(370, ((e.clientX - rect.left) / rect.width) * 400));
  };

  return (
    <div className="max-w-md mx-auto text-center space-y-3">
      <div className="flex justify-center gap-6 text-sm">
        <span className="text-[hsl(var(--voltage-yellow))] font-bold">Fruit {score}</span>
        <span className="text-white/50">Lives {'❤️'.repeat(Math.max(0, lives))}</span>
      </div>
      <div className="relative inline-block">
        <canvas ref={canvasRef} width={400} height={480} onMouseMove={moveMouse} className="max-w-full rounded-xl border border-white/10" style={{ aspectRatio: '400/480' }} />
        {!running && (
          <div className="absolute inset-0 bg-black/70 rounded-xl flex flex-col items-center justify-center gap-3">
            <p className="text-white/80 font-bold">{over ? `Game over — ${score} fruit caught!` : 'Catch fruit, dodge bombs'}</p>
            <Button size="sm" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold" onClick={start}>{over ? 'Play Again' : 'Start'}</Button>
            <p className="text-[10px] text-white/40">Move with the mouse or ← →</p>
          </div>
        )}
      </div>
    </div>
  );
}