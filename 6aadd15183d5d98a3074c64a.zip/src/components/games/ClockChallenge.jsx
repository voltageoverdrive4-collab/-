import React, { useState } from 'react';

const genTime = () => {
  const h = 1 + Math.floor(Math.random() * 12);
  const m = Math.floor(Math.random() * 12) * 5;
  return { h, m };
};
const fmt = (h, m) => {
  const ampm = h < 12 ? 'AM' : 'PM';
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${String(m).padStart(2, '0')} ${ampm}`;
};

// Read the analog clock — four answers, one correct time.
export default function ClockChallenge() {
  const [time, setTime] = useState(genTime);
  const [options, setOptions] = useState(() => {
    const t = genTime();
    const o = [t];
    while (o.length < 4) {
      const hh = 1 + Math.floor(Math.random() * 12);
      const mm = Math.floor(Math.random() * 12) * 5;
      if (!o.some((x) => x.h === hh && x.m === mm)) o.push({ h: hh, m: mm });
    }
    return o.sort(() => Math.random() - 0.5);
  });
  const [picked, setPicked] = useState(null);
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(1);

  const correct = options.find((o) => o.h === time.h && o.m === time.m);

  const pick = (o) => {
    if (picked) return;
    setPicked(o);
    if (o.h === time.h && o.m === time.m) setScore((s) => s + 1);
  };

  const next = () => {
    const t = genTime();
    const o = [t];
    while (o.length < 4) {
      const hh = 1 + Math.floor(Math.random() * 12);
      const mm = Math.floor(Math.random() * 12) * 5;
      if (!o.some((x) => x.h === hh && x.m === mm)) o.push({ h: hh, m: mm });
    }
    setTime(t);
    setOptions(o.sort(() => Math.random() - 0.5));
    setPicked(null);
    setRound((r) => r + 1);
  };

  const hourAngle = (time.h % 12) * 30 + time.m * 0.5;
  const minAngle = time.m * 6;

  return (
    <div className="max-w-md mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">What time does the clock say? 10 rounds, no mercy for slip-ups.</p>
      <div className="flex justify-between text-xs text-white/40">
        <span>Round {round}/10</span>
        <span>Score: {score}</span>
      </div>
      <svg viewBox="0 0 100 100" className="w-44 h-44 mx-auto">
        <circle cx="50" cy="50" r="48" fill="rgba(0,0,0,0.5)" stroke="hsl(var(--voltage-yellow))" strokeWidth="2" />
        {Array.from({ length: 12 }, (_, i) => (
          <line key={i} x1="50" y1="6" x2="50" y2="12" stroke="rgba(255,255,255,0.5)" strokeWidth="2" transform={`rotate(${i * 30} 50 50)`} />
        ))}
        <line x1="50" y1="50" x2="50" y2="28" stroke="white" strokeWidth="4" strokeLinecap="round" transform={`rotate(${hourAngle} 50 50)`} />
        <line x1="50" y1="50" x2="50" y2="16" stroke="hsl(var(--voltage-yellow))" strokeWidth="2.5" strokeLinecap="round" transform={`rotate(${minAngle} 50 50)`} />
        <circle cx="50" cy="50" r="3" fill="hsl(var(--voltage-yellow))" />
      </svg>
      <div className="grid grid-cols-2 gap-2">
        {options.map((o, i) => (
          <button
            key={i}
            onClick={() => pick(o)}
            disabled={!!picked}
            className={`py-3 rounded-xl border font-bold transition-colors ${
              picked
                ? o === correct
                  ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]'
                  : 'border-white/10 text-white/40'
                : 'border-white/10 bg-white/5 hover:border-[hsl(var(--voltage-blue))]/60 hover:bg-white/10'
            }`}
          >
            {fmt(o.h, o.m)}
          </button>
        ))}
      </div>
      {picked && (
        <div className="space-y-1">
          <p className={`text-sm font-bold ${picked === correct ? 'text-[hsl(var(--voltage-yellow))]' : 'text-red-400'}`}>
            {picked === correct ? 'Correct!' : `It was ${fmt(time.h, time.m)}`}
          </p>
          {round < 10
            ? <button onClick={next} className="underline text-[hsl(var(--voltage-blue))]">Next clock</button>
            : <p className="text-white/40 text-xs">Done — final score {score}/10</p>}
        </div>
      )}
    </div>
  );
}