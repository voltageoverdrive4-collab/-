import React, { useState } from 'react';

const DENOMS = [
  { label: '1¢', value: 1 },
  { label: '5¢', value: 5 },
  { label: '10¢', value: 10 },
  { label: '25¢', value: 25 },
  { label: '$1', value: 100 },
  { label: '$5', value: 500 },
];
const money = (c) => `$${(c / 100).toFixed(2)}`;

const genRound = () => {
  const price = 15 + Math.floor(Math.random() * 950);
  const paid = Math.ceil(price / 100) * 100;
  return { price, paid };
};

// Count back the exact change — coin by coin.
export default function ChangeMaker() {
  const [round, setRound] = useState(genRound);
  const [tray, setTray] = useState(() => new Set());
  const [served, setServed] = useState(0);
  const [flash, setFlash] = useState('');

  const change = round.paid - round.price;
  const traySum = [...tray].reduce((s, i) => s + DENOMS[i].value, 0);

  const add = (i) => {
    if (traySum + DENOMS[i].value > change) return;
    setTray((prev) => new Set([...prev, i]));
    setFlash('');
  };

  const give = () => {
    if (traySum === change) {
      setServed((s) => s + 1);
      setRound(genRound());
      setTray(new Set());
      setFlash('Exact change — nice!');
    } else {
      setFlash(`That's ${money(traySum)} — the change is ${money(change)}`);
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">The register is broken — hand back the exact change yourself.</p>
      <div className="rounded-2xl border border-white/10 bg-black/50 p-5 space-y-1">
        <p className="text-sm text-white/60">Item price: <span className="font-bold text-white">{money(round.price)}</span></p>
        <p className="text-sm text-white/60">Customer paid: <span className="font-bold text-white">{money(round.paid)}</span></p>
        <p className="text-lg font-black text-[hsl(var(--voltage-yellow))]">Change due: {money(change)}</p>
        <p className="text-xs text-white/40">In your tray: {money(traySum)}</p>
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {DENOMS.map((d, i) => (
          <button
            key={d.label}
            onClick={() => add(i)}
            className="px-5 py-3 rounded-full border border-white/15 bg-white/5 font-bold hover:border-[hsl(var(--voltage-yellow))]/60 hover:bg-white/10 transition-colors"
          >
            {d.label}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-center gap-4">
        <button onClick={give} className="px-6 py-2 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black">Give change</button>
        <button onClick={() => setTray(new Set())} className="text-xs underline text-white/40">Empty tray</button>
      </div>
      <p className="text-xs text-white/40">{flash || `Customers served: ${served}`}</p>
    </div>
  );
}