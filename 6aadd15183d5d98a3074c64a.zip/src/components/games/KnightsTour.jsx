import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

const MOVES = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
const SIZE = 5;

export default function KnightsTour() {
  const [trail, setTrail] = useState(() => [[Math.floor(Math.random() * SIZE), Math.floor(Math.random() * SIZE)]]);
  const [msg, setMsg] = useState('');

  const pos = trail[trail.length - 1];
  const legal = new Set(
    MOVES.map(([dr, dc]) => [pos[0] + dr, pos[1] + dc])
      .filter(([r, c]) => r >= 0 && r < SIZE && c >= 0 && c < SIZE)
      .map(([r, c]) => r * SIZE + c)
  );
  const won = trail.length === SIZE * SIZE;
  const stuck = !won && legal.size === 0;

  const click = (r, c) => {
    if (won) return;
    const idx = r * SIZE + c;
    if (!legal.has(idx)) return;
    setTrail([...trail, [r, c]]);
    setMsg('');
  };

  const restart = () => {
    setTrail([[Math.floor(Math.random() * SIZE), Math.floor(Math.random() * SIZE)]]);
    setMsg('');
  };

  return (
    <div className="space-y-4 max-w-md mx-auto text-center">
      <p className="text-white/50 text-sm">Move the knight like in chess — visit all 25 squares to win.</p>
      <div className="grid grid-cols-5 gap-1">
        {Array.from({ length: SIZE * SIZE }, (_, idx) => {
          const r = Math.floor(idx / SIZE);
          const c = idx % SIZE;
          const trailIdx = trail.findIndex(([tr, tc]) => tr === r && tc === c);
          const isPos = trailIdx === trail.length - 1;
          const dark = (r + c) % 2 === 1;
          return (
            <button
              key={idx}
              onClick={() => click(r, c)}
              className={`aspect-square rounded-md text-sm font-bold border transition-all ${
                isPos
                  ? 'bg-[hsl(var(--voltage-yellow))] text-black border-[hsl(var(--voltage-yellow))]'
                  : trailIdx >= 0
                    ? 'bg-[hsl(var(--voltage-yellow))]/20 text-[hsl(var(--voltage-yellow))] border-[hsl(var(--voltage-yellow))]/30'
                    : legal.has(idx)
                      ? `${dark ? 'bg-white/10' : 'bg-white/5'} border-[hsl(var(--voltage-blue))]/60 hover:bg-[hsl(var(--voltage-blue))]/20`
                      : `${dark ? 'bg-black/40' : 'bg-black/25'} border-white/5`
              }`}
            >
              {isPos ? '♞' : trailIdx >= 0 ? trailIdx + 1 : ''}
            </button>
          );
        })}
      </div>
      {won && <p className="font-bold text-green-400">You completed the whole tour! 🏆</p>}
      {stuck && <p className="font-bold text-red-400">No moves left — you visited {trail.length} squares.</p>}
      <div className="flex items-center justify-center gap-4">
        <p className="text-white/60 text-sm">Visited: {trail.length}/25</p>
        {(won || stuck) && <Button onClick={restart} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">New tour</Button>}
      </div>
    </div>
  );
}