import React, { useState } from 'react';

const genTarget = () => 20 + Math.floor(Math.random() * 980);

// Hit the target number with a calculator keypad — the math runs left to right.
export default function Calculator() {
  const [target, setTarget] = useState(genTarget);
  const [tokens, setTokens] = useState([]);
  const [flash, setFlash] = useState('');
  const [solved, setSolved] = useState(0);

  const evaluate = (t) => {
    if (!t.length || typeof t[t.length - 1] === 'string') return null;
    let total = t[0];
    for (let i = 1; i < t.length; i += 2) {
      const op = t[i];
      const num = t[i + 1];
      if (op === '+') total += num;
      else if (op === '-') total -= num;
      else if (op === '×') total *= num;
      else if (num === 0) return null;
      else total /= num;
    }
    return Math.round(total * 100) / 100;
  };

  const current = evaluate(tokens);

  const press = (key) => {
    setFlash('');
    if (key === 'C') { setTokens([]); return; }
    if (key === '⌫') {
      setTokens((t) => {
        const n = t.slice();
        if (n.length && typeof n[n.length - 1] === 'number' && n[n.length - 1] >= 10) {
          n[n.length - 1] = Math.floor(n[n.length - 1] / 10);
        } else n.pop();
        return n;
      });
      return;
    }
    if (key === '=') {
      const v = evaluate(tokens);
      if (v === null) { setFlash('Finish the sum first'); return; }
      if (v === target) {
        setSolved((s) => s + 1);
        setTarget(genTarget());
        setTokens([]);
        setFlash('Bullseye! New target locked in');
      } else {
        setFlash(`${v} — not quite the target`);
      }
      return;
    }
    if (key === '+' || key === '-' || key === '×' || key === '÷') {
      if (!tokens.length || typeof tokens[tokens.length - 1] === 'string') return;
      setTokens((t) => [...t, key]);
      return;
    }
    setTokens((t) => {
      const n = t.slice();
      if (!n.length || typeof n[n.length - 1] === 'string') n.push(Number(key));
      else n[n.length - 1] = n[n.length - 1] * 10 + Number(key);
      return n;
    });
  };

  const keys = ['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '-', 'C', '0', '⌫', '+'];

  return (
    <div className="max-w-xs mx-auto space-y-4 text-center">
      <p className="text-white/50 text-sm">Build a sum that lands exactly on the target.</p>
      <div className="rounded-2xl border border-white/10 bg-black/50 p-4 space-y-3">
        <div>
          <p className="text-[10px] uppercase tracking-widest text-white/40">Target</p>
          <p className="font-heading text-4xl font-black text-[hsl(var(--voltage-yellow))]">{target}</p>
        </div>
        <div className="min-h-8 font-mono text-xl text-white">
          {tokens.length ? tokens.join(' ') : <span className="text-white/30">0</span>}
          {current !== null && <span className="text-white/40"> = {current}</span>}
        </div>
        <div className="grid grid-cols-4 gap-2">
          {keys.map((k) => (
            <button
              key={k}
              onClick={() => press(k)}
              className="h-12 rounded-xl border border-white/10 bg-white/5 font-bold text-lg hover:bg-white/10 hover:border-[hsl(var(--voltage-yellow))]/50 transition-colors"
            >
              {k}
            </button>
          ))}
          <button
            onClick={() => press('=')}
            className="col-span-4 h-12 rounded-xl font-black text-lg bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black hover:brightness-110 transition-all"
          >
            =
          </button>
        </div>
      </div>
      <p className="text-xs text-white/40">{flash || `Targets hit: ${solved}`}</p>
    </div>
  );
}