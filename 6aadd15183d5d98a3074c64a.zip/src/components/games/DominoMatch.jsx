import React, { useEffect, useState } from 'react';

const genDomino = () => {
  const a = Math.floor(Math.random() * 7);
  const b = Math.floor(Math.random() * 7);
  return { a, b };
};
const matches = (d, end) => d.a === end || d.b === end;

// Build the chain — every tile must match an open end before the timer dies.
export default function DominoMatch() {
  const [chain, setChain] = useState(() => [{ d: genDomino(), flipped: false }]);
  const [hand, setHand] = useState(() => [genDomino(), genDomino(), genDomino(), genDomino()]);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [time, setTime] = useState(8);
  const [flash, setFlash] = useState('');

  const ends = () => {
    const first = chain[0];
    const last = chain[chain.length - 1];
    return { left: first.flipped ? first.d.a : first.d.b, right: last.flipped ? last.d.b : last.d.a };
  };

  const over = lives <= 0;

  useEffect(() => {
    if (over) return;
    const t = setInterval(() => {
      setTime((v) => {
        if (v <= 1) {
          setLives((l) => l - 1);
          setFlash('Too slow — life lost');
          return 8;
        }
        return v - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [over]);

  const place = (i) => {
    if (over) return;
    const d = hand[i];
    const { left, right } = ends();
    if (!matches(d, left) && !matches(d, right)) {
      setLives((l) => l - 1);
      setFlash('No match — life lost');
      return;
    }
    setChain((prev) => {
      const next = prev.map((c) => ({ ...c }));
      if (matches(d, left)) {
        next.unshift({ d, flipped: d.b !== left });
      } else {
        next.push({ d, flipped: d.a !== right });
      }
      return next;
    });
    setScore((s) => s + 10 + time * 2);
    setFlash('');
    setTime(8);
    setHand((prev) => prev.map((h, j) => (j === i ? genDomino() : h)));
  };

  const Domino = ({ d }) => (
    <div className="flex flex-col rounded-xl border border-white/15 bg-white/90 text-black overflow-hidden font-black">
      <div className="h-9 flex items-center justify-center text-lg border-b border-black/20">{d.a}</div>
      <div className="h-9 flex items-center justify-center text-lg">{d.b}</div>
    </div>
  );

  return (
    <div className="max-w-lg mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">Match a tile to either open end of the chain — faster matches score more.</p>
      <div className="flex justify-between text-sm text-white/60">
        <span>Score: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{score}</span></span>
        <span>{'❤️'.repeat(Math.max(0, lives))}</span>
        <span className={time <= 3 ? 'text-red-400 font-bold' : ''}>⏱ {time}s</span>
      </div>
      <div className="flex flex-wrap justify-center gap-1.5 rounded-xl border border-white/10 bg-black/50 p-3 min-h-24">
        {chain.map((c, i) => <Domino key={i} d={{ a: c.flipped ? c.d.b : c.d.a, b: c.flipped ? c.d.a : c.d.b }} />)}
      </div>
      <div className="flex justify-center gap-2">
        {hand.map((d, i) => (
          <button key={i} onClick={() => place(i)} disabled={over} className="rounded-xl transition-transform hover:-translate-y-1 disabled:opacity-40">
            <Domino d={d} />
          </button>
        ))}
      </div>
      {flash && <p className="text-xs text-red-400">{flash}</p>}
      {over && (
        <div className="space-y-2">
          <p className="font-bold text-[hsl(var(--voltage-yellow))]">Chain broken — final score {score}!</p>
          <button
            onClick={() => { setChain([{ d: genDomino(), flipped: false }]); setHand([genDomino(), genDomino(), genDomino(), genDomino()]); setScore(0); setLives(3); setTime(8); setFlash(''); }}
            className="underline text-[hsl(var(--voltage-blue))]"
          >Play again</button>
        </div>
      )}
    </div>
  );
}