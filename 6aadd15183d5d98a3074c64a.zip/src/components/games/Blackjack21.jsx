import React, { useState } from 'react';

const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const newDeck = () => SUITS.flatMap((s) => RANKS.map((r) => ({ r, s })));
const shuffle = (d) => {
  const n = [...d];
  for (let i = n.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [n[i], n[j]] = [n[j], n[i]];
  }
  return n;
};
const value = (hand) => {
  let total = 0, aces = 0;
  for (const c of hand) {
    if (c.r === 'A') { total += 11; aces++; }
    else if (['J', 'Q', 'K'].includes(c.r)) total += 10;
    else total += parseInt(c.r, 10);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
};

function Card({ c, hidden }) {
  return (
    <div className={`w-12 h-16 rounded-lg border flex items-center justify-center text-xl font-bold shrink-0 ${
      hidden ? 'bg-slate-800 border-white/20 text-white/40'
      : c.s === '♥' || c.s === '♦' ? 'bg-white text-red-600 border-white'
      : 'bg-white text-black border-white'}`}
    >
      {hidden ? '?' : <>{c.r}<span className="text-sm">{c.s}</span></>}
    </div>
  );
}

export default function Blackjack21() {
  const [deck, setDeck] = useState(shuffle(newDeck()));
  const [player, setPlayer] = useState([]);
  const [dealer, setDealer] = useState([]);
  const [phase, setPhase] = useState('bet');
  const [result, setResult] = useState('');

  const deal = () => {
    const d = deck.length < 15 ? shuffle(newDeck()) : [...deck];
    const p = [d.pop(), d.pop()];
    const h = [d.pop(), d.pop()];
    setDeck(d); setPlayer(p); setDealer(h); setPhase('play'); setResult('');
  };

  const hit = () => {
    const d = [...deck];
    const p = [...player, d.pop()];
    setDeck(d); setPlayer(p);
    if (value(p) > 21) { setPhase('done'); setResult('Bust — dealer wins! 💀'); }
  };

  const stand = () => {
    const d = [...deck];
    const h = [...dealer];
    while (value(h) < 17) h.push(d.pop());
    setDeck(d); setDealer(h);
    const pv = value(player), hv = value(h);
    let msg;
    if (hv > 21) msg = 'Dealer busts — you win! 🎉';
    else if (pv > hv) msg = 'You win! 🎉';
    else if (pv < hv) msg = 'Dealer wins. 🤖';
    else msg = "Push — it's a tie.";
    setResult(msg);
    setPhase('done');
  };

  return (
    <div className="flex flex-col items-center gap-5">
      <div className="w-full max-w-sm p-4 rounded-xl bg-emerald-950/60 border border-emerald-800/50">
        <p className="text-xs text-white/50 mb-2">DEALER {phase === 'done' ? `— ${value(dealer)}` : ''}</p>
        <div className="flex gap-2 min-h-16">
          {dealer.map((c, i) => <Card key={i} c={c} hidden={phase === 'play' && i === 1} />)}
        </div>
        <p className="text-xs text-white/50 mt-5 mb-2">YOU — {value(player)}</p>
        <div className="flex gap-2 min-h-16">
          {player.map((c, i) => <Card key={i} c={c} hidden={false} />)}
        </div>
      </div>
      {result && <p className="font-bold text-[hsl(var(--voltage-yellow))]">{result}</p>}
      <div className="flex gap-2">
        {phase === 'bet' || phase === 'done' ? (
          <button onClick={deal} className="px-5 py-2 rounded-lg bg-[hsl(var(--voltage-yellow))] text-black font-bold">Deal</button>
        ) : (
          <>
            <button onClick={hit} className="px-5 py-2 rounded-lg bg-[hsl(var(--voltage-yellow))] text-black font-bold">Hit</button>
            <button onClick={stand} className="px-5 py-2 rounded-lg bg-[hsl(var(--voltage-blue))] text-black font-bold">Stand</button>
          </>
        )}
      </div>
      <p className="text-xs text-white/40 text-center">Get closer to 21 than the dealer without going over. Dealer stands on 17.</p>
    </div>
  );
}