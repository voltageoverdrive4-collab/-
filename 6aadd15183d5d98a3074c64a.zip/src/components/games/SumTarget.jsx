import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

const genRound = () => {
  const tiles = Array.from({ length: 9 }, () => 1 + Math.floor(Math.random() * 25));
  const picks = new Set();
  while (picks.size < 3) picks.add(Math.floor(Math.random() * 9));
  const target = [...picks].reduce((sum, i) => sum + tiles[i], 0);
  return { tiles, target };
};

// Tap numbers that add up to the target — the clock never stops ticking up.
export default function SumTarget() {
  const [round, setRound] = useState(genRound);
  const [picked, setPicked] = useState(() => new Set());
  const [solved, setSolved] = useState(0);
  const [shake, setShake] = useState(false);

  const pickedSum = [...picked].reduce((s, i) => s + round.tiles[i], 0);

  const click = (i) => {
    if (picked.has(i)) {
      const next = new Set(picked);
      next.delete(i);
      setPicked(next);
      return;
    }
    const nextSum = pickedSum + round.tiles[i];
    if (nextSum > round.target) {
      setShake(true);
      setTimeout(() => setShake(false), 400);
      setPicked(new Set());
      return;
    }
    const next = new Set(picked);
    next.add(i);
    if (nextSum === round.target) {
      setSolved((s) => s + 1);
      setRound(genRound());
      setPicked(new Set());
    } else {
      setPicked(next);
    }
  };

  return (
    <div className="max-w-md mx-auto text-center space-y-5">
      <div>
        <p className="text-white/50 text-xs uppercase tracking-widest">Target</p>
        <p className="font-heading text-4xl font-black text-[hsl(var(--voltage-yellow))]">{round.target}</p>
      </div>
      <p className="text-sm text-white/50">Picked so far: <span className="text-white font-bold">{pickedSum}</span></p>
      <div className={`grid grid-cols-3 gap-2.5 ${shake ? 'animate-pulse border-red-500/60 rounded-xl' : ''}`}>
        {round.tiles.map((v, i) => (
          <button
            key={i}
            onClick={() => click(i)}
            className={`h-16 rounded-lg border font-bold text-xl transition-colors ${picked.has(i) ? 'bg-[hsl(var(--voltage-yellow))] text-black border-[hsl(var(--voltage-yellow))]' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
          >
            {v}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-center gap-3">
        <p className="text-xs text-white/40">Solved {solved}</p>
        <Button size="sm" variant="outline" className="border-white/20" onClick={() => { setRound(genRound()); setPicked(new Set()); }}>Skip</Button>
      </div>
      {shake && <p className="text-xs text-red-400">Over the target — picks cleared!</p>}
    </div>
  );
}