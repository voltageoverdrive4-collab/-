import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';

// Pop the rising balloons before five of them float away.
export default function BalloonPop() {
  const [balloons, setBalloons] = useState([]);
  const [score, setScore] = useState(0);
  const [escaped, setEscaped] = useState(0);
  const [over, setOver] = useState(false);
  const st = useRef({ balloons: [], nextId: 1, escaped: 0, over: false });

  useEffect(() => {
    let raf;
    let last = performance.now();
    let spawn = 0.4;
    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = st.current;
      if (!s.over) {
        spawn -= dt;
        if (spawn <= 0) {
          s.balloons.push({ id: s.nextId++, x: 4 + Math.random() * 88, y: -10, speed: 20 + Math.random() * 28, hue: Math.floor(Math.random() * 360) });
          spawn = Math.max(0.35, 0.8 - Math.random() * 0.3);
        }
        for (const b of s.balloons) b.y += b.speed * dt;
        s.balloons = s.balloons.filter((b) => {
          if (b.y >= 106) { s.escaped += 1; return false; }
          return true;
        });
        if (s.escaped >= 5) { s.over = true; setOver(true); }
        setEscaped(s.escaped);
        setBalloons([...s.balloons]);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const pop = (id) => {
    const s = st.current;
    s.balloons = s.balloons.filter((b) => b.id !== id);
    setBalloons([...s.balloons]);
    setScore((v) => v + 1);
  };

  const restart = () => {
    st.current = { balloons: [], nextId: 1, escaped: 0, over: false };
    setBalloons([]); setScore(0); setEscaped(0); setOver(false);
  };

  return (
    <div className="max-w-md mx-auto text-center space-y-3">
      <div className="flex justify-center gap-6 text-sm">
        <span className="text-[hsl(var(--voltage-yellow))] font-bold">Popped {score}</span>
        <span className="text-white/50">Escaped {escaped}/5</span>
      </div>
      <div className="relative h-72 rounded-xl bg-gradient-to-b from-sky-900/30 to-black/50 border border-white/10 overflow-hidden">
        {balloons.map((b) => (
          <button
            key={b.id}
            onClick={() => pop(b.id)}
            className="absolute text-3xl transition-none hover:scale-110"
            style={{ left: `${b.x}%`, top: `${b.y}%` }}
          >
            <span style={{ filter: `hue-rotate(${b.hue}deg)` }}>🎈</span>
          </button>
        ))}
        {over && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-3">
            <p className="text-white/80 font-bold">Game over — {score} popped!</p>
            <Button size="sm" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold" onClick={restart}>Play Again</Button>
          </div>
        )}
      </div>
    </div>
  );
}