import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

const COLORS = [
  { name: 'Yellow', hex: '#ffe00f' },
  { name: 'Blue', hex: '#00c8ff' },
  { name: 'Red', hex: '#ff4d4d' },
  { name: 'Green', hex: '#4ade80' },
  { name: 'Purple', hex: '#c084fc' },
  { name: 'Orange', hex: '#fb923c' },
];

const pickRound = () => ({
  word: COLORS[Math.floor(Math.random() * COLORS.length)].name,
  ink: COLORS[Math.floor(Math.random() * COLORS.length)],
});

export default function ColorMatch() {
  const [round, setRound] = useState(pickRound);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const running = timeLeft > 0;

  useEffect(() => {
    if (!running) return;
    const clock = setInterval(() => setTimeLeft((t) => Math.max(0, t - 1)), 1000);
    return () => clearInterval(clock);
  }, [running]);

  const answer = (name) => {
    if (!running) return;
    if (name === round.ink.name) setScore((s) => s + 1);
    setRound(pickRound());
  };

  const start = () => { setScore(0); setTimeLeft(30); setRound(pickRound()); };

  // four options: the ink color plus three random other names
  const options = [round.ink.name];
  while (options.length < 4) {
    const n = COLORS[Math.floor(Math.random() * COLORS.length)].name;
    if (!options.includes(n)) options.push(n);
  }
  const shuffled = [...options].sort(() => Math.random() - 0.5);

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-6 font-bold">
        <span>Score: {score}</span>
        <span className="text-[hsl(var(--voltage-yellow))]">⏱ {timeLeft}s</span>
      </div>
      <p className="text-white/50 text-sm">What color is the WORD written in?</p>
      <div className="text-6xl font-black tracking-wide" style={{ color: round.ink.hex }}>{round.word}</div>
      {running ? (
        <div className="flex flex-wrap gap-3 justify-center">
          {shuffled.map((name) => (
            <Button key={name} size="lg" variant="outline" onClick={() => answer(name)} className="border-white/20 text-white hover:bg-white/10 px-6">{name}</Button>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2">
          {timeLeft === 0 && score > 0 && <p className="text-white/60 text-sm">Time! Final score: {score}</p>}
          <Button onClick={start} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Start</Button>
        </div>
      )}
      <p className="text-white/40 text-xs">Ignore what the word says — answer the ink color • 30 seconds</p>
    </div>
  );
}