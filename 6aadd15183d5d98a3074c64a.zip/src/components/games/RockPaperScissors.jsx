import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

const MOVES = ['rock', 'paper', 'scissors'];
const EMOJI = { rock: '🪨', paper: '📄', scissors: '✂️' };

export default function RockPaperScissors() {
  const [score, setScore] = useState({ you: 0, cpu: 0 });
  const [last, setLast] = useState(null);

  const play = (you) => {
    const cpu = MOVES[Math.floor(Math.random() * MOVES.length)];
    const win = (you === 'rock' && cpu === 'scissors') || (you === 'paper' && cpu === 'rock') || (you === 'scissors' && cpu === 'paper');
    const draw = you === cpu;
    setScore((s) => ({ you: s.you + (win ? 1 : 0), cpu: s.cpu + (!win && !draw ? 1 : 0) }));
    setLast({ you, cpu, result: draw ? 'draw' : win ? 'win' : 'lose' });
  };

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-8 font-bold text-lg">
        <span>You: {score.you}</span>
        <span className="text-white/30">—</span>
        <span>CPU: {score.cpu}</span>
      </div>

      {last ? (
        <div className="flex items-center gap-6 text-5xl">
          <span>{EMOJI[last.you]}</span>
          <span className={`font-bold text-sm px-3 py-1 rounded-full ${
            last.result === 'win' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]' :
            last.result === 'lose' ? 'bg-red-500/15 text-red-400' : 'bg-white/10 text-white/60'}`}>
            {last.result === 'win' ? 'YOU WIN ⚡' : last.result === 'lose' ? 'CPU WINS' : 'DRAW'}
          </span>
          <span>{EMOJI[last.cpu]}</span>
        </div>
      ) : (
        <p className="text-white/50">Choose your weapon</p>
      )}

      <div className="flex gap-3">
        {MOVES.map((m) => (
          <Button key={m} size="lg" variant="outline" onClick={() => play(m)} className="border-white/20 text-white hover:bg-white/10 text-2xl px-6">
            {EMOJI[m]}
          </Button>
        ))}
      </div>
    </div>
  );
}