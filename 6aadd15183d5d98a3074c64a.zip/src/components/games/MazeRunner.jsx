import React, { useEffect, useRef, useState } from 'react';

const COLS = 11, ROWS = 11, CELL = 22;

function genMaze() {
  const walls = Array.from({ length: ROWS }, () =>
    Array.from({ length: COLS }, () => ({ N: true, S: true, E: true, W: true })));
  const seen = Array.from({ length: ROWS }, () => new Array(COLS).fill(false));
  const stack = [[0, 0]];
  seen[0][0] = true;
  while (stack.length) {
    const [r, c] = stack[stack.length - 1];
    const dirs = [['N', -1, 0], ['S', 1, 0], ['E', 0, 1], ['W', 0, -1]]
      .filter(([, nr, nc]) => nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && !seen[nr][nc]);
    if (!dirs.length) { stack.pop(); continue; }
    const [d, nr, nc] = dirs[Math.floor(Math.random() * dirs.length)];
    walls[r][c][d] = false;
    walls[nr][nc][d === 'N' ? 'S' : d === 'S' ? 'N' : d === 'E' ? 'W' : 'E'] = false;
    seen[nr][nc] = true;
    stack.push([nr, nc]);
  }
  return walls;
}

export default function MazeRunner() {
  const canvasRef = useRef(null);
  const [walls, setWalls] = useState(genMaze);
  const [pos, setPos] = useState([0, 0]);
  const [won, setWon] = useState(false);
  const wallsRef = useRef(walls);
  wallsRef.current = walls;

  const move = (dir) => {
    setPos((p) => {
      const [r, c] = p;
      if (wallsRef.current[r][c][dir]) return p;
      const np = dir === 'N' ? [r - 1, c] : dir === 'S' ? [r + 1, c] : dir === 'E' ? [r, c + 1] : [r, c - 1];
      if (np[0] === ROWS - 1 && np[1] === COLS - 1) setWon(true);
      return np;
    });
  };

  useEffect(() => {
    const onKey = (e) => {
      const dir = { ArrowUp: 'N', ArrowDown: 'S', ArrowLeft: 'W', ArrowRight: 'E', w: 'N', s: 'S', a: 'W', d: 'E' }[e.key];
      if (!dir) return;
      e.preventDefault();
      move(dir);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    const ctx = canvasRef.current.getContext('2d');
    const [pr, pc] = pos;
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, COLS * CELL, ROWS * CELL);
    ctx.fillStyle = 'rgba(245,197,24,0.25)';
    ctx.fillRect((COLS - 1) * CELL + 2, (ROWS - 1) * CELL + 2, CELL - 4, CELL - 4);
    ctx.strokeStyle = '#f5c518';
    ctx.lineWidth = 2;
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const x = c * CELL, y = r * CELL, w = walls[r][c];
        ctx.beginPath();
        if (w.N) { ctx.moveTo(x, y); ctx.lineTo(x + CELL, y); }
        if (w.W) { ctx.moveTo(x, y); ctx.lineTo(x, y + CELL); }
        if (r === ROWS - 1 && w.S) { ctx.moveTo(x, y + CELL); ctx.lineTo(x + CELL, y + CELL); }
        if (c === COLS - 1 && w.E) { ctx.moveTo(x + CELL, y); ctx.lineTo(x + CELL, y + CELL); }
        ctx.stroke();
      }
    }
    ctx.beginPath();
    ctx.fillStyle = won ? '#4ade80' : '#38bdf8';
    ctx.arc(pc * CELL + CELL / 2, pr * CELL + CELL / 2, 6, 0, Math.PI * 2);
    ctx.fill();
  }, [pos, walls, won]);

  const restart = () => { setWalls(genMaze()); setPos([0, 0]); setWon(false); };

  return (
    <div className="flex flex-col items-center gap-4">
      <p className="text-sm text-white/60 text-center">
        {won ? 'You reached the glowing exit! 🎉' : 'Reach the glowing exit — arrows or WASD, or use the pad below.'}
      </p>
      <canvas ref={canvasRef} width={COLS * CELL} height={ROWS * CELL} className="rounded-xl border border-white/10" />
      <div className="grid grid-cols-3 gap-1 w-36">
        <div />
        <button onClick={() => move('N')} className="py-2 rounded-lg bg-white/10 hover:bg-white/20">↑</button>
        <div />
        <button onClick={() => move('W')} className="py-2 rounded-lg bg-white/10 hover:bg-white/20">←</button>
        <button onClick={() => move('S')} className="py-2 rounded-lg bg-white/10 hover:bg-white/20">↓</button>
        <button onClick={() => move('E')} className="py-2 rounded-lg bg-white/10 hover:bg-white/20">→</button>
      </div>
      <button onClick={restart} className="px-4 py-2 rounded-lg bg-[hsl(var(--voltage-yellow))] text-black text-sm font-bold">
        New maze
      </button>
    </div>
  );
}