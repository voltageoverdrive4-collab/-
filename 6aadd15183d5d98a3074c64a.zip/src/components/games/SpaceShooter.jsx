import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';

const W = 440, H = 460;

export default function SpaceShooter() {
  const canvasRef = useRef(null);
  const g = useRef({ ship: W / 2, bullets: [], rocks: [], keys: {}, frame: 0, score: 0, lives: 3, playing: false, spawnIn: 60 });
  const [hud, setHud] = useState({ score: 0, lives: 3 });
  const [over, setOver] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const s = g.current;
    let raf;

    const onKey = (e, down) => {
      if (['ArrowLeft', 'ArrowRight', ' '].includes(e.key)) e.preventDefault();
      s.keys[e.key] = down;
    };
    const kd = (e) => onKey(e, true);
    const ku = (e) => onKey(e, false);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);

    const onMouse = (e) => {
      const r = canvas.getBoundingClientRect();
      s.ship = Math.max(20, Math.min(W - 20, ((e.clientX - r.left) / r.width) * W));
    };
    const onShoot = () => { if (s.playing) s.bullets.push({ x: s.ship, y: H - 52 }); };
    canvas.addEventListener('mousemove', onMouse);
    canvas.addEventListener('click', onShoot);

    const loop = () => {
      if (s.playing) {
        s.frame++;
        if (s.keys.ArrowLeft) s.ship -= 5;
        if (s.keys.ArrowRight) s.ship += 5;
        s.ship = Math.max(20, Math.min(W - 20, s.ship));
        if (s.keys[' '] && s.frame % 8 === 0) onShoot();
        s.bullets.forEach((b) => { b.y -= 7; });
        s.bullets = s.bullets.filter((b) => b.y > -10);

        s.spawnIn--;
        if (s.spawnIn <= 0) {
          s.rocks.push({
            x: 30 + Math.random() * (W - 60),
            y: -20,
            r: 12 + Math.random() * 14,
            vx: (Math.random() - 0.5) * 2,
            vy: 1.6 + Math.random() * 1.6 + Math.min(1.6, s.score / 400),
          });
          s.spawnIn = Math.max(24, 70 - s.score / 30);
        }
        s.rocks.forEach((rock) => {
          rock.x += rock.vx;
          rock.y += rock.vy;
          if (rock.x < rock.r || rock.x > W - rock.r) rock.vx = -rock.vx;
        });
        s.rocks = s.rocks.filter((rock) => {
          for (let i = 0; i < s.bullets.length; i++) {
            const b = s.bullets[i];
            if (Math.hypot(rock.x - b.x, rock.y - b.y) < rock.r + 4) {
              s.bullets.splice(i, 1);
              s.score += Math.round(rock.r);
              setHud({ score: s.score, lives: s.lives });
              return false;
            }
          }
          if (Math.hypot(rock.x - s.ship, rock.y - (H - 42)) < rock.r + 15) {
            s.lives -= 1;
            setHud({ score: s.score, lives: s.lives });
            if (s.lives <= 0) { s.playing = false; setOver(true); }
            return false;
          }
          return rock.y < H + 30;
        });
      }

      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      for (let i = 0; i < 30; i++) {
        ctx.fillRect((i * 97 + s.frame * 0.3) % W, (i * 53 + s.frame * 1.2) % H, 1.5, 1.5);
      }
      ctx.fillStyle = '#ffe00f';
      ctx.beginPath();
      ctx.moveTo(s.ship, H - 58);
      ctx.lineTo(s.ship - 16, H - 26);
      ctx.lineTo(s.ship + 16, H - 26);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#00c8ff';
      s.bullets.forEach((b) => ctx.fillRect(b.x - 2, b.y - 8, 4, 10));
      ctx.strokeStyle = '#a855f7';
      s.rocks.forEach((rock) => {
        ctx.beginPath();
        for (let a = 0; a < 7; a++) {
          const ang = (a / 7) * Math.PI * 2;
          const rr = rock.r * (0.8 + 0.3 * Math.sin(a * 2 + rock.x));
          const px = rock.x + Math.cos(ang) * rr;
          const py = rock.y + Math.sin(ang) * rr;
          if (a === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      canvas.removeEventListener('mousemove', onMouse);
      canvas.removeEventListener('click', onShoot);
    };
  }, []);

  const start = () => {
    const s = g.current;
    s.ship = W / 2; s.bullets = []; s.rocks = []; s.score = 0; s.lives = 3; s.playing = true; s.spawnIn = 60;
    setHud({ score: 0, lives: 3 });
    setOver(false);
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-center gap-6 font-bold text-sm">
        <span>Score: {hud.score}</span><span className="text-white/40">|</span><span>Lives: {'⚡'.repeat(Math.max(0, hud.lives)) || '—'}</span>
      </div>
      <canvas ref={canvasRef} width={W} height={H} className="rounded-lg border border-white/10 max-w-full" />
      {over && <p className="font-bold text-red-400">Ship down! Final score: {hud.score}</p>}
      <Button onClick={start} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">{over ? 'Play again' : 'Launch'}</Button>
      <p className="text-white/40 text-xs">Move with mouse or ← → • click or space to shoot</p>
    </div>
  );
}