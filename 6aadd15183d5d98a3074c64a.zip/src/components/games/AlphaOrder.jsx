import React, { useEffect, useRef, useState } from 'react';

const LETTERS = 'ABCDEFGHIJ'.split('');
const shuffle = (arr) => arr.slice().sort(() => Math.random() - 0.5);

export default function AlphaOrder() {
  const [cells, setCells] = useState(() => shuffle(LETTERS));
  const [next, setNext] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [started, setStarted] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const startRef = useRef(null);

  const done = next >= LETTERS.length;

  useEffect(() => {
    if (!started || done) return;
    const t = setInterval(() => setElapsed((Date.now() - startRef.current) / 1000), 100);
    return () => clearInterval(t);
  }, [started, done]);

  const click = (letter) => {
    if (done) return;
    if (!started) {
      setStarted(true);
      startRef.current = Date.now();
    }
    if (letter === LETTERS[next]) {
      const n = next + 1;
      setNext(n);
      if (n === LETTERS.length) setElapsed((Date.now() - startRef.current) / 1000);
    } else {
      setMistakes((m) => m + 1);
    }
  };

  const restart = () => {
    setCells(shuffle(LETTERS));
    setNext(0);
    setMistakes(0);
    setStarted(false);
    setElapsed(0);
    startRef.current = null;
  };

  return (
    <div className="space-y-4 max-w-md mx-auto text-center">
      <p className="text-white/50 text-sm">Click the letters A→J in order as fast as you can.</p>
      <div className="grid grid-cols-5 gap-2">
        {cells.map((l) => {
          const used = LETTERS.indexOf(l) < next;
          return (
            <button
              key={l}
              onClick={() => click(l)}
              disabled={done}
              className={`aspect-square rounded-xl text-xl font-black border transition-all ${
                used
                  ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))]/50 text-[hsl(var(--voltage-yellow))] opacity-50'
                  : 'bg-white/5 border-white/10 hover:border-[hsl(var(--voltage-yellow))]/60'
              }`}
            >
              {l}
            </button>
          );
        })}
      </div>
      {done ? (
        <div className="space-y-2">
          <p className="font-bold text-[hsl(var(--voltage-yellow))]">Done in {elapsed.toFixed(1)}s with {mistakes} mistakes!</p>
          <button onClick={restart} className="underline text-[hsl(var(--voltage-blue))]">Play again</button>
        </div>
      ) : (
        <p className="text-white/60">Next: <span className="font-bold">{LETTERS[next]}</span> · Mistakes: {mistakes} · {elapsed.toFixed(0)}s</p>
      )}
    </div>
  );
}