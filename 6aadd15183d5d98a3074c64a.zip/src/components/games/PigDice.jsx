import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dices } from 'lucide-react';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rollDie = () => 1 + Math.floor(Math.random() * 6);

// Pig Dice vs VoltBot — first to 50 points wins; rolling a 1 loses the turn.
export default function PigDice() {
  const [you, setYou] = useState(0);
  const [bot, setBot] = useState(0);
  const [turnTotal, setTurnTotal] = useState(0);
  const [roll, setRoll] = useState(null);
  const [turn, setTurn] = useState('you');
  const [msg, setMsg] = useState('Your turn — roll to start');
  const [busy, setBusy] = useState(false);
  const [over, setOver] = useState(false);

  const botTurn = async () => {
    setTurn('bot');
    setBusy(true);
    setMsg('VoltBot is rolling…');
    await sleep(700);
    let total = 0;
    for (;;) {
      const r = rollDie();
      setRoll(r);
      setMsg(`VoltBot rolled a ${r}`);
      await sleep(900);
      if (r === 1) { total = 0; setMsg('VoltBot rolled a 1 — turn lost!'); break; }
      total += r;
      setTurnTotal(total);
      if (total >= 20 || bot + total >= 50) break;
      await sleep(600);
    }
    await sleep(400);
    const next = bot + total;
    setBot(next);
    setTurnTotal(0);
    setRoll(null);
    if (next >= 50) { setOver(true); setMsg('VoltBot wins this one.'); }
    else { setMsg('Your turn'); setTurn('you'); }
    setBusy(false);
  };

  const doRoll = async () => {
    if (busy || over || turn === 'bot') return;
    setBusy(true);
    const r = rollDie();
    setRoll(r);
    if (r === 1) {
      setTurnTotal(0);
      setMsg('You rolled a 1 — turn lost!');
      await sleep(900);
      setRoll(null);
      setBusy(false);
      botTurn();
    } else {
      setTurnTotal((t) => t + r);
      setMsg(`You rolled a ${r}`);
      setBusy(false);
    }
  };

  const hold = () => {
    if (busy || over || turnTotal === 0) return;
    const next = you + turnTotal;
    setYou(next);
    setTurnTotal(0);
    setRoll(null);
    if (next >= 50) { setOver(true); setMsg('You win! 🏆'); return; }
    botTurn();
  };

  const restart = () => {
    setYou(0); setBot(0); setTurnTotal(0); setRoll(null);
    setTurn('you'); setMsg('Your turn — roll to start'); setOver(false);
  };

  return (
    <div className="max-w-md mx-auto space-y-6 text-center">
      <div className="grid grid-cols-2 gap-4">
        <div className={`p-4 rounded-xl border ${turn === 'you' && !over ? 'border-[hsl(var(--voltage-yellow))]/60 bg-[hsl(var(--voltage-yellow))]/10' : 'border-white/10 bg-white/5'}`}>
          <p className="text-xs text-white/50 uppercase tracking-widest">You</p>
          <p className="text-3xl font-black">{you}</p>
        </div>
        <div className={`p-4 rounded-xl border ${turn === 'bot' && !over ? 'border-[hsl(var(--voltage-blue))]/60 bg-[hsl(var(--voltage-blue))]/10' : 'border-white/10 bg-white/5'}`}>
          <p className="text-xs text-white/50 uppercase tracking-widest">VoltBot</p>
          <p className="text-3xl font-black">{bot}</p>
        </div>
      </div>
      <div className="p-6 rounded-xl bg-white/5 border border-white/10">
        <div className="w-20 h-20 mx-auto rounded-xl bg-white text-black flex items-center justify-center text-4xl font-black">
          {roll || '?'}
        </div>
        <p className="text-white/70 mt-3">Turn total: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{turnTotal}</span></p>
        <p className="text-sm text-white/50 mt-1">{msg}</p>
      </div>
      <div className="flex flex-wrap justify-center gap-3">
        <Button onClick={doRoll} disabled={busy || turn === 'bot' || over} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <Dices className="w-4 h-4 mr-2" /> Roll
        </Button>
        <Button onClick={hold} disabled={busy || turn === 'bot' || over || turnTotal === 0} variant="outline" className="border-white/20 text-white hover:bg-white/10">
          Hold
        </Button>
        {over && <Button onClick={restart} variant="outline" className="border-white/20 text-white hover:bg-white/10">Play again</Button>}
      </div>
    </div>
  );
}