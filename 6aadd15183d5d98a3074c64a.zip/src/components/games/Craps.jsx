import React, { useState } from 'react';

const roll2 = () => [1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)];
const DICE = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

// Pass-line craps — 7 or 11 on the come-out wins, the point pays after.
export default function Craps() {
  const [bank, setBank] = useState(100);
  const [bet, setBet] = useState(10);
  const [phase, setPhase] = useState('comeout');
  const [point, setPoint] = useState(null);
  const [dice, setDice] = useState(null);
  const [log, setLog] = useState([]);

  const say = (line) => setLog((prev) => [line, ...prev].slice(0, 4));

  const roll = () => {
    if (bank < bet) return;
    const [a, b] = roll2();
    const total = a + b;
    setDice([a, b]);
    if (phase === 'comeout') {
      setBank((v) => v - bet);
      if (total === 7 || total === 11) {
        setBank((v) => v + bet * 2);
        say(`Come-out ${total} — winner! +${bet}`);
      } else if (total === 2 || total === 3 || total === 12) {
        say(`Come-out ${total} — craps, lost ${bet}`);
      } else {
        setPhase('point');
        setPoint(total);
        say(`Point set at ${total} — roll it again before a 7`);
        setBank((v) => v + bet);
        return;
      }
    } else {
      if (total === point) {
        setBank((v) => v + bet * 2);
        say(`Hit the ${point}! +${bet}`);
        setPhase('comeout');
        setPoint(null);
      } else if (total === 7) {
        say(`Seven out — lost ${bet}`);
        setPhase('comeout');
        setPoint(null);
      } else {
        say(`Rolled ${total} — still chasing the ${point}`);
      }
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">Pass line · 7 or 11 wins the come-out, then roll the point before a 7.</p>
      <div className="flex justify-between text-sm text-white/60">
        <span>Bank: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{bank}</span></span>
        <span>{phase === 'point' ? <span className="text-[hsl(var(--voltage-blue))] font-bold">Point: {point}</span> : 'Come-out roll'}</span>
      </div>
      <div className="text-7xl flex justify-center gap-4">
        {dice ? dice.map((d, i) => <span key={i} className="text-[hsl(var(--voltage-yellow))] drop-shadow">{DICE[d - 1]}</span>) : <span className="text-white/20 text-5xl self-center">🎲</span>}
      </div>
      <div className="flex items-center justify-center gap-2">
        {[5, 10, 25].map((b) => (
          <button
            key={b}
            onClick={() => setBet(b)}
            className={`px-4 py-1.5 rounded-full text-sm font-bold border transition-colors ${bet === b ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]' : 'border-white/15 text-white/50'}`}
          >
            {b}
          </button>
        ))}
        <button onClick={roll} disabled={bank < bet} className="ml-2 px-6 py-1.5 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black disabled:opacity-40">
          Roll
        </button>
      </div>
      <div className="space-y-1 text-xs text-white/50">
        {log.map((line, i) => <p key={i} className={i === 0 ? 'text-white/80' : ''}>{line}</p>)}
      </div>
    </div>
  );
}