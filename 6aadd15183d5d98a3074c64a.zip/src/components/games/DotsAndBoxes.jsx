import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

const N = 4; // 4x4 dots → 3x3 boxes
const COLORS = ['#ffe00f', '#00c8ff'];
const dot = (i) => 20 + i * 66;

const emptyGame = () => ({
  h: Array.from({ length: N }, () => Array(N - 1).fill(null)),
  v: Array.from({ length: N - 1 }, () => Array(N).fill(null)),
  boxes: Array.from({ length: N - 1 }, () => Array(N - 1).fill(null)),
  scores: [0, 0],
  turn: 0,
});

const boxSides = (h, v, r, c) => (h[r][c] != null) + (h[r + 1][c] != null) + (v[r][c] != null) + (v[r][c + 1] != null);

const withEdge = (g, edge, player) => {
  const h = g.h.map((row) => [...row]);
  const v = g.v.map((row) => [...row]);
  if (edge.type === 'h') h[edge.r][edge.c] = player; else v[edge.r][edge.c] = player;
  return { h, v };
};

const edgesOf = (g) => {
  const edges = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N - 1; c++) if (g.h[r][c] == null) edges.push({ type: 'h', r, c });
  for (let r = 0; r < N - 1; r++) for (let c = 0; c < N; c++) if (g.v[r][c] == null) edges.push({ type: 'v', r, c });
  return edges;
};

const completesBoxes = (g, edge) => {
  const { h, v } = withEdge(g, edge, 0);
  let n = 0;
  for (let r = 0; r < N - 1; r++) for (let c = 0; c < N - 1; c++)
    if (boxSides(h, v, r, c) === 4 && boxSides(g.h, g.v, r, c) < 4) n++;
  return n;
};

const createsDanger = (g, edge) => {
  const { h, v } = withEdge(g, edge, 0);
  let n = 0;
  for (let r = 0; r < N - 1; r++) for (let c = 0; c < N - 1; c++)
    if (boxSides(h, v, r, c) === 3 && boxSides(g.h, g.v, r, c) < 3) n++;
  return n;
};

const commit = (g, edge, player) => {
  const { h, v } = withEdge(g, edge, player);
  const boxes = g.boxes.map((row) => [...row]);
  let completed = 0;
  for (let r = 0; r < N - 1; r++) for (let c = 0; c < N - 1; c++) {
    if (boxes[r][c] == null && boxSides(h, v, r, c) === 4) { boxes[r][c] = player; completed++; }
  }
  const scores = [...g.scores];
  scores[player] += completed;
  return { h, v, boxes, scores, turn: completed > 0 ? player : 1 - player };
};

export default function DotsAndBoxes() {
  const [game, setGame] = useState(emptyGame);
  const totalBoxes = (N - 1) * (N - 1);
  const done = game.scores[0] + game.scores[1] === totalBoxes;
  const winner = done ? (game.scores[0] === game.scores[1] ? null : (game.scores[0] > game.scores[1] ? 0 : 1)) : null;

  const move = (edge) => setGame((g) => {
    if (g.turn !== 0 || done) return g;
    if (edge.type === 'h' ? g.h[edge.r][edge.c] != null : g.v[edge.r][edge.c] != null) return g;
    return commit(g, edge, 0);
  });

  // CPU: always finish a box if it can, otherwise avoid setting up free boxes.
  useEffect(() => {
    if (game.turn !== 1 || done) return undefined;
    const timer = setTimeout(() => {
      setGame((g) => {
        const edges = edgesOf(g);
        if (edges.length === 0) return g;
        const completing = edges.filter((e) => completesBoxes(g, e) > 0);
        let pick;
        if (completing.length) {
          pick = completing[Math.floor(Math.random() * completing.length)];
        } else {
          const safe = edges.filter((e) => createsDanger(g, e) === 0);
          const pool = safe.length ? safe : edges;
          pick = pool.reduce((best, e) => (createsDanger(g, e) < createsDanger(g, best) ? e : best));
        }
        return commit(g, pick, 1);
      });
    }, 650);
    return () => clearTimeout(timer);
  }, [game, done]);

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-center gap-6 font-bold text-sm">
        <span style={{ color: COLORS[0] }}>You: {game.scores[0]}</span>
        <span className="text-white/40">|</span>
        <span style={{ color: COLORS[1] }}>CPU: {game.scores[1]}</span>
      </div>
      <svg viewBox="0 0 240 240" className="w-[300px] max-w-full rounded-lg border border-white/10 bg-black/40">
        {game.boxes.map((row, r) => row.map((owner, c) => (owner != null ? (
          <rect key={`b${r}-${c}`} x={dot(c) + 4} y={dot(r) + 4} width={52} height={52} rx={4} fill={COLORS[owner]} opacity={0.25} />
        ) : null)))}
        {game.h.map((row, r) => row.map((owner, c) => (
          <g key={`h${r}-${c}`}>
            <line x1={dot(c)} y1={dot(r)} x2={dot(c + 1)} y2={dot(r)}
              stroke={owner != null ? COLORS[owner] : 'rgba(255,255,255,0.12)'} strokeWidth={owner != null ? 6 : 3} strokeLinecap="round" />
            {owner == null && game.turn === 0 && !done && (
              <line x1={dot(c)} y1={dot(r)} x2={dot(c + 1)} y2={dot(r)} stroke="transparent" strokeWidth={16} strokeLinecap="round"
                className="cursor-pointer hover:stroke-white/30" onClick={() => move({ type: 'h', r, c })} />
            )}
          </g>
        )))}
        {game.v.map((row, r) => row.map((owner, c) => (
          <g key={`v${r}-${c}`}>
            <line x1={dot(c)} y1={dot(r)} x2={dot(c)} y2={dot(r + 1)}
              stroke={owner != null ? COLORS[owner] : 'rgba(255,255,255,0.12)'} strokeWidth={owner != null ? 6 : 3} strokeLinecap="round" />
            {owner == null && game.turn === 0 && !done && (
              <line x1={dot(c)} y1={dot(r)} x2={dot(c)} y2={dot(r + 1)} stroke="transparent" strokeWidth={16} strokeLinecap="round"
                className="cursor-pointer hover:stroke-white/30" onClick={() => move({ type: 'v', r, c })} />
            )}
          </g>
        )))}
        {Array.from({ length: N }, (_, r) => Array.from({ length: N }, (_, c) => (
          <circle key={`d${r}-${c}`} cx={dot(c)} cy={dot(r)} r={4} fill="#ffe00f" opacity={0.7} />
        )))}
      </svg>
      {done && (
        <p className={`font-bold ${winner === 0 ? 'text-[hsl(var(--voltage-yellow))]' : winner === 1 ? 'text-[hsl(var(--voltage-blue))]' : 'text-white/60'}`}>
          {winner === 0 ? 'You win! ⚡' : winner === 1 ? 'CPU wins!' : "It's a tie!"}
        </p>
      )}
      <Button onClick={() => setGame(emptyGame())} variant="outline" className="border-white/20 text-white">New match</Button>
      <p className="text-white/40 text-xs">Click between the dots to draw a line • complete a box to score and go again</p>
    </div>
  );
}