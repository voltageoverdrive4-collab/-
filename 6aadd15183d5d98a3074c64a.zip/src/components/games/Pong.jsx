import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';

const W = 400, H = 260, PW = 10, PH = 60;

export default function Pong() {
  const canvasRef = useRef(null);
  const g = useRef({ py: H / 2 - PH / 2, ay: H / 2 - PH / 2, bx: W / 2, by: H / 2, vx: 3.4, vy: 1.5, ps: 0, as: 0, playing: false });
  const [score, setScore] = useState({ p: 0, a: 0 });
  const [over, setOver] = useState(false);

  const serve = () => {
    const s = g.current;
    s.bx = W / 2;
    s.by = H / 2;
    s.vx = 3.4 * (Math.random() < 0.5 ? 1 : -1);
    s.vy = (Math.random() * 4 - 2) || 1.5;
    s.playing = true;
    setOver(false);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const s = g.current;
    let raf;

    const movePaddle = (clientY) => {
      const r = canvas.getBoundingClientRect();
      const y = ((clientY - r.top) / r.height) * H;
      s.py = Math.max(0, Math.min(H - PH, y - PH / 2));
    };
    const onMouse = (e) => movePaddle(e.clientY);
    const onTouch = (e) => { e.preventDefault(); movePaddle(e.touches[0].clientY); };
    canvas.addEventListener('mousemove', onMouse);
    canvas.addEventListener('touchmove', onTouch, { passive: false });

    const loop = () => {
      if (s.playing) {
        s.bx += s.vx;
        s.by += s.vy;
        if (s.by < 5 || s.by > H - 5) s.vy = -s.vy;
        if (s.vx < 0 && s.bx < 24 && s.bx > 10 && s.by > s.py - 5 && s.by < s.py + PH + 5) {
          s.vx = -s.vx;
          s.vy += ((s.by - (s.py + PH / 2)) / (PH / 2)) * 2;
        }
        if (s.vx > 0 && s.bx > W - 24 && s.bx < W - 10 && s.by > s.ay - 5 && s.by < s.ay + PH + 5) {
          s.vx = -s.vx;
        }
        if (s.bx < -8) {
          s.as += 1;
          setScore({ p: s.ps, a: s.as });
          s.playing = false;
          if (s.as >= 5) setOver(true);
        }
        if (s.bx > W + 8) {
          s.ps += 1;
          setScore({ p: s.ps, a: s.as });
          s.playing = false;
          if (s.ps >= 5) setOver(true);
        }
      }
      const target = s.playing ? s.by - PH / 2 : H / 2 - PH / 2;
      s.ay += Math.max(-2.6, Math.min(2.6, (target - s.ay) * 0.12));

      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.setLineDash([6, 8]);
      ctx.beginPath();
      ctx.moveTo(W / 2, 0);
      ctx.lineTo(W / 2, H);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#ffe00f';
      ctx.fillRect(10, s.py, PW, PH);
      ctx.fillStyle = '#00c8ff';
      ctx.fillRect(W - 10 - PW, s.ay, PW, PH);
      ctx.beginPath();
      ctx.arc(s.bx, s.by, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener('mousemove', onMouse);
      canvas.removeEventListener('touchmove', onTouch);
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-6 font-bold">
        <span>You: {score.p}</span>
        <span className="text-white/40">—</span>
        <span>CPU: {score.a}</span>
      </div>
      <canvas ref={canvasRef} width={W} height={H} className="rounded-lg border border-white/10 max-w-full cursor-none" />
      {over && <p className={`font-bold ${score.p > score.a ? 'text-[hsl(var(--voltage-yellow))]' : 'text-red-400'}`}>{score.p > score.a ? 'Match won! ⚡' : 'CPU takes the match!'}</p>}
      {!over && <Button onClick={serve} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">{g.current.playing ? 'Restart Match' : 'Serve'}</Button>}
      <p className="text-white/40 text-xs">Move your mouse (or drag) over the table • first to 5 wins</p>
    </div>
  );
}