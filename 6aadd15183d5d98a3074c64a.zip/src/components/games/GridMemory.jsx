import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

const SIZE = 16;
const pickPattern = (n) => {
  const set = new Set();
  while (set.size < n) set.add(Math.floor(Math.random() * SIZE));
  return set;
};

// Remember the flashing cells and tap them back — one more every level.
export default function GridMemory() {
  const [level, setLevel] = useState(1);
  const [phase, setPhase] = useState('show'); // show | input | done | over
  const [pattern, setPattern] = useState(() => pickPattern(1));
  const [found, setFound] = useState(() => new Set());
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (phase !== 'show') return undefined;
    const t = setTimeout(() => setPhase('input'), 900 + level * 150);
    return () => clearTimeout(t);
  }, [phase, level]);

  const click = (i) => {
    if (phase !== 'input') return;
    if (pattern.has(i)) {
      const next = new Set(found);
      next.add(i);
      setFound(next);
      if (next.size === pattern.size) {
        setScore((s) => s + level * 10);
        setLevel((l) => l + 1);
        setPattern(pickPattern(Math.min(level + 1, 10)));
        setFound(new Set());
        setPhase('show');
      }
    } else {
      setPhase('over');
    }
  };

  const restart = () => { setLevel(1); setPattern(pickPattern(1)); setFound(new Set()); setScore(0); setPhase('show'); };

  return (
    <div className="max-w-sm mx-auto text-center space-y-4">
      <p className="text-white/60 text-sm">
        {phase === 'show' ? 'Memorize…' : phase === 'input' ? 'Now tap them back!' : phase === 'over' ? `Wrong cell — game over. Score ${score}` : `Level ${level} cleared!`}
      </p>
      <div className="grid grid-cols-4 gap-2">
        {Array.from({ length: SIZE }, (_, i) => {
          const lit = phase === 'show' && pattern.has(i);
          const hit = found.has(i);
          return (
            <button
              key={i}
              onClick={() => click(i)}
              className={`aspect-square rounded-lg border transition-colors ${lit ? 'bg-[hsl(var(--voltage-yellow))] border-[hsl(var(--voltage-yellow))]' : hit ? 'bg-[hsl(var(--voltage-blue))]/40 border-[hsl(var(--voltage-blue))]/60' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
            />
          );
        })}
      </div>
      <p className="text-xs text-white/40">Score {score} · Level {level}</p>
      {phase === 'over' && <Button size="sm" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold" onClick={restart}>Play Again</Button>}
    </div>
  );
}