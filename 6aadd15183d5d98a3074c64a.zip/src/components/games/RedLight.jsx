import React, { useEffect, useRef, useState } from 'react';

// Wait for green, smash the click — jump early and the round burns.
export default function RedLight() {
  const [phase, setPhase] = useState('wait'); // wait | green | done
  const [round, setRound] = useState(1);
  const [times, setTimes] = useState([]);
  const startedAt = useRef(null);
  const greenTimer = useRef(null);

  const ROUNDS = 5;

  useEffect(() => {
    if (phase !== 'wait') return;
    startedAt.current = null;
    const t = setTimeout(() => {
      setPhase('green');
      startedAt.current = performance.now();
    }, 1200 + Math.random() * 2300);
    return () => clearTimeout(t);
  }, [phase, round]);

  const click = () => {
    if (phase === 'green') {
      const ms = Math.round(performance.now() - startedAt.current);
      setTimes((prev) => [...prev, ms]);
      if (round >= ROUNDS) setPhase('done');
      else {
        setRound((r) => r + 1);
        setPhase('wait');
      }
    } else if (phase === 'wait') {
      // jumped early — round lost
      setTimes((prev) => [...prev, null]);
      if (round >= ROUNDS) setPhase('done');
      else {
        setRound((r) => r + 1);
        setPhase('wait');
      }
    }
  };

  const good = times.filter((t) => t !== null);
  const avg = good.length ? Math.round(good.reduce((s, t) => s + t, 0) / good.length) : null;

  return (
    <div className="max-w-md mx-auto space-y-6 text-center">
      <p className="text-white/50 text-sm">Five rounds — wait for the panel to flip green, then click instantly. Early clicks don&apos;t count.</p>
      <div className="text-xs text-white/40">Round {Math.min(round, ROUNDS)}/{ROUNDS} · Valid clicks: {good.length}</div>
      <button
        onClick={click}
        disabled={phase === 'done'}
        className={`w-56 h-56 rounded-full border-4 font-black text-2xl transition-all ${
          phase === 'green'
            ? 'bg-emerald-500/30 border-emerald-400 text-emerald-300 shadow-[0_0_50px_rgba(16,185,129,0.5)] scale-105'
            : phase === 'wait'
              ? 'bg-red-500/15 border-red-500/70 text-red-300'
              : 'bg-white/5 border-white/10 text-white/50'
        }`}
      >
        {phase === 'green' ? 'CLICK!' : phase === 'wait' ? 'WAIT…' : 'DONE'}
      </button>
      {phase === 'done' && (
        <div className="space-y-2">
          <p className="font-bold text-[hsl(var(--voltage-yellow))]">
            {avg ? `Average reaction: ${avg}ms across ${good.length} rounds` : 'Every round was a jump — no valid clicks!'}
          </p>
          <button onClick={() => { setPhase('wait'); setRound(1); setTimes([]); }} className="underline text-[hsl(var(--voltage-blue))]">Play again</button>
        </div>
      )}
      <div className="flex justify-center gap-2 flex-wrap text-xs text-white/50">
        {times.map((t, i) => (
          <span key={i} className={`px-2 py-0.5 rounded-full border ${t === null ? 'border-red-500/40 text-red-400' : 'border-white/15'}`}>
            {t === null ? 'early' : `${t}ms`}
          </span>
        ))}
      </div>
    </div>
  );
}