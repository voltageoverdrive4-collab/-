import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';

export default function BrickBreaker() {
  const canvasRef = useRef(null);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const stateRef = useRef({});

  const reset = () => {
    const c = canvasRef.current;
    const ctx = c.getContext('2d');
    const s = {
      x: 150, y: 280, dx: 3, dy: -3, px: 120, right: false, left: false,
      bricks: Array.from({ length: 4 }, (_, r) => Array.from({ length: 8 }, () => true)),
      score: 0, over: false,
    };
    stateRef.current = { ctx, s, c };
    setOver(false); setScore(0);

    const onKey = (e, down) => {
      if (e.key === 'ArrowRight') s.right = down;
      if (e.key === 'ArrowLeft') s.left = down;
    };
    const kd = (e) => onKey(e, true);
    const ku = (e) => onKey(e, false);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);

    const mouse = (e) => {
      const rect = c.getBoundingClientRect();
      s.px = Math.max(0, Math.min(220, e.clientX - rect.left - 40));
    };
    c.addEventListener('mousemove', mouse);

    let raf;
    const loop = () => {
      if (s.over) return;
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.fillRect(0, 0, 300, 320);
      // ball
      ctx.beginPath(); ctx.arc(s.x, s.y, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#D4FF00'; ctx.fill();
      // paddle
      ctx.fillStyle = '#00C2FF'; ctx.fillRect(s.px, 300, 80, 8);
      // bricks
      for (let r = 0; r < 4; r++) {
        for (let b = 0; b < 8; b++) {
          if (s.bricks[r][b]) {
            ctx.fillStyle = r % 2 ? '#00C2FF' : '#D4FF00';
            ctx.fillRect(b * 36 + 6, r * 18 + 10, 32, 14);
          }
        }
      }
      s.x += s.dx; s.y += s.dy;
      if (s.x < 6 || s.x > 294) s.dx = -s.dx;
      if (s.y < 6) s.dy = -s.dy;
      if (s.y > 294 && s.x > s.px && s.x < s.px + 80) s.dy = -s.dy;
      if (s.y > 320) { s.over = true; setOver(true); }
      for (let r = 0; r < 4; r++) {
        for (let b = 0; b < 8; b++) {
          if (s.bricks[r][b]) {
            const bx = b * 36 + 6, by = r * 18 + 10;
            if (s.x > bx && s.x < bx + 32 && s.y > by && s.y < by + 14) {
              s.bricks[r][b] = false; s.dy = -s.dy; s.score++; setScore(s.score);
            }
          }
        }
      }
      if (s.right) s.px = Math.min(220, s.px + 6);
      if (s.left) s.px = Math.max(0, s.px - 6);
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
    };
  };

  useEffect(() => { const cleanup = reset(); return cleanup; }, []);

  return (
    <div>
      <p className="text-white/60 mb-4 text-sm">Score: {score} {over && '• Game over'} • Use mouse or ←/→</p>
      <canvas ref={canvasRef} width={300} height={320} className="rounded-xl border border-white/15 bg-black/40" />
      <Button onClick={reset} variant="outline" className="mt-4 border-white/20 text-white hover:bg-white/10">Restart</Button>
    </div>
  );
}