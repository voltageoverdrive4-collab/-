import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'react-hot-toast';

const face = (v) => ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'][v - 1];
const fresh = () => [1, 2, 3, 4, 5].map(() => 1 + Math.floor(Math.random() * 6));

function scoreHand(dice) {
  const counts = {};
  dice.forEach((d) => { counts[d] = (counts[d] || 0) + 1; });
  const values = Object.values(counts).sort((a, b) => b - a);
  const uniq = [...new Set(dice)].sort((a, b) => a - b);
  const straight = uniq.length === 5 && uniq[4] - uniq[0] === 4;
  if (values[0] === 5) return { pts: 50, name: 'VOLTZEE — five of a kind!' };
  if (values[0] === 4) return { pts: 25, name: 'Four of a kind' };
  if (values[0] === 3 && values[1] === 2) return { pts: 20, name: 'Full house' };
  if (straight) return { pts: 15, name: 'Straight' };
  if (values[0] === 3) return { pts: 10, name: 'Three of a kind' };
  if (values[0] === 2 && values[1] === 2) return { pts: 5, name: 'Two pair' };
  if (values[0] === 2) return { pts: 2, name: 'One pair' };
  return { pts: 0, name: 'Nothing — bummer' };
}

// Roll, hold, reroll — build the best poker hand out of five dice.
export default function DicePoker() {
  const [dice, setDice] = useState(fresh);
  const [held, setHeld] = useState(() => new Set());
  const [rolls, setRolls] = useState(3);
  const [result, setResult] = useState(null);
  const [best, setBest] = useState(0);

  const toggleHold = (i) => {
    if (result || rolls === 3) return;
    const next = new Set(held);
    if (next.has(i)) next.delete(i); else next.add(i);
    setHeld(next);
  };

  const roll = () => {
    if (result || rolls === 0) return;
    const next = dice.map((d, i) => (held.has(i) ? d : 1 + Math.floor(Math.random() * 6)));
    setDice(next);
    const left = rolls - 1;
    setRolls(left);
    if (left === 0) {
      const r = scoreHand(next);
      setResult(r);
      if (r.pts > best) setBest(r.pts);
      if (r.pts > 0) toast.success(`${r.name} — +${r.pts} pts`);
      else toast.error('Nothing this hand');
    }
  };

  const newHand = () => { setDice(fresh()); setHeld(new Set()); setRolls(3); setResult(null); };

  return (
    <div className="max-w-md mx-auto text-center space-y-5">
      <div className="flex justify-center gap-3">
        {dice.map((d, i) => (
          <button
            key={i}
            onClick={() => toggleHold(i)}
            className={`text-6xl leading-none rounded-xl px-2 py-1 transition-colors ${held.has(i) ? 'bg-[hsl(var(--voltage-yellow))]/20 ring-2 ring-[hsl(var(--voltage-yellow))]' : 'hover:bg-white/5'}`}
          >
            {face(d)}
          </button>
        ))}
      </div>
      <p className="text-xs text-white/40">{result ? 'Hand over — start a new one' : rolls === 3 ? 'Roll to start, then tap dice to HOLD them' : `${rolls} roll${rolls === 1 ? '' : 's'} left — tap a die to hold it`}</p>
      <div className="flex justify-center gap-2">
        {result
          ? <Button className="bg-[hsl(var(--voltage-yellow))] text-black font-bold" onClick={newHand}>New Hand</Button>
          : <Button className="bg-[hsl(var(--voltage-yellow))] text-black font-bold px-8" onClick={roll} disabled={rolls === 0}>ROLL</Button>}
      </div>
      {result && (
        <div className="space-y-1">
          <p className={`font-bold ${result.pts > 0 ? 'text-[hsl(var(--voltage-yellow))]' : 'text-white/50'}`}>{result.name}</p>
          <p className="text-sm text-white/60">+{result.pts} points</p>
        </div>
      )}
      <p className="text-xs text-white/40">Best hand: {best} pts · VOLTZEE pays 50</p>
    </div>
  );
}