import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';

const COLORS = ['yellow', 'blue', 'red', 'green'];

export default function SimonSays() {
  const [seq, setSeq] = useState([]);
  const [playing, setPlaying] = useState(false);
  const [active, setActive] = useState(null);
  const [userIdx, setUserIdx] = useState(0);
  const [msg, setMsg] = useState('Press start');
  const timeouts = useRef([]);

  const clearAll = () => { timeouts.current.forEach(clearTimeout); timeouts.current = []; };

  const playSeq = (s) => {
    setPlaying(true);
    s.forEach((c, i) => {
      timeouts.current.push(setTimeout(() => setActive(c), 600 * i + 400));
      timeouts.current.push(setTimeout(() => setActive(null), 600 * i + 800));
    });
    timeouts.current.push(setTimeout(() => { setPlaying(false); setMsg('Your turn'); setUserIdx(0); }, 600 * s.length + 400));
  };

  const start = () => {
    clearAll();
    const s = [...seq, COLORS[Math.floor(Math.random() * 4)]];
    setSeq(s);
    setMsg('Watch…');
    setTimeout(() => playSeq(s), 300);
  };

  const tap = (c) => {
    if (playing) return;
    if (c === seq[userIdx]) {
      setActive(c); setTimeout(() => setActive(null), 200);
      if (userIdx + 1 === seq.length) {
        setMsg('Nice! Next round…');
        setTimeout(start, 700);
      } else {
        setUserIdx(userIdx + 1);
      }
    } else {
      setMsg(`Wrong! You reached ${seq.length - 1} rounds.`);
      setSeq([]); setPlaying(false);
    }
  };

  useEffect(() => () => clearAll(), []);

  const colorClass = (c) => {
    const map = { yellow: 'bg-[hsl(var(--voltage-yellow))]', blue: 'bg-[hsl(var(--voltage-blue))]', red: 'bg-red-500', green: 'bg-green-500' };
    return active === c ? map[c] + ' brightness-150' : map[c] + ' opacity-40';
  };

  return (
    <div>
      <p className="text-white/60 mb-4 text-sm">{msg}</p>
      <div className="grid grid-cols-2 gap-2 w-64">
        {COLORS.map((c) => (
          <button key={c} onClick={() => tap(c)} className={`aspect-square rounded-lg ${colorClass(c)} transition-all`} />
        ))}
      </div>
      <Button onClick={start} variant="outline" className="mt-4 border-white/20 text-white hover:bg-white/10">{seq.length ? 'Restart' : 'Start'}</Button>
    </div>
  );
}