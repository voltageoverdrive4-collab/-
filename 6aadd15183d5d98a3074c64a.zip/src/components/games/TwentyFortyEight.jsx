import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

const addTile = (b) => {
  const empty = [];
  b.forEach((row, r) => row.forEach((v, c) => { if (!v) empty.push([r, c]); }));
  if (!empty.length) return b;
  const [r, c] = empty[Math.floor(Math.random() * empty.length)];
  b[r][c] = Math.random() < 0.9 ? 2 : 4;
  return b;
};

const newBoard = () => addTile(addTile([[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]));

const slideLeft = (row) => {
  const nums = row.filter(Boolean);
  const out = [];
  let gained = 0;
  for (let i = 0; i < nums.length; i++) {
    if (nums[i] === nums[i + 1]) { out.push(nums[i] * 2); gained += nums[i] * 2; i++; }
    else out.push(nums[i]);
  }
  while (out.length < 4) out.push(0);
  return { row: out, gained };
};

const transpose = (b) => b[0].map((_, c) => b.map((row) => row[c]));
const reverseRows = (b) => b.map((row) => [...row].reverse());

const applyMove = (b, dir) => {
  let gained = 0;
  const slide = (row) => { const res = slideLeft(row); gained += res.gained; return res.row; };
  if (dir === 'left') return { board: b.map(slide), gained };
  if (dir === 'right') return { board: reverseRows(reverseRows(b).map(slide)), gained };
  if (dir === 'up') return { board: transpose(transpose(b).map(slide)), gained };
  const t = reverseRows(transpose(b));
  return { board: transpose(reverseRows(t.map(slide))), gained };
};

const canMove = (b) => {
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) {
    if (!b[r][c]) return true;
    if (c < 3 && b[r][c] === b[r][c + 1]) return true;
    if (r < 3 && b[r][c] === b[r + 1][c]) return true;
  }
  return false;
};

const TILE = {
  0: 'bg-white/5 text-transparent',
  2: 'bg-white/15 text-white',
  4: 'bg-white/25 text-white',
  8: 'bg-orange-400/80 text-black',
  16: 'bg-orange-500/80 text-black',
  32: 'bg-red-400/80 text-black',
  64: 'bg-red-500/80 text-black',
  128: 'bg-purple-400/80 text-black',
  256: 'bg-purple-500/80 text-black',
  512: 'bg-blue-400/80 text-black',
  1024: 'bg-blue-500/80 text-black',
  2048: 'bg-[hsl(var(--voltage-yellow))] text-black',
};

export default function TwentyFortyEight() {
  const [board, setBoard] = useState(newBoard);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);

  const move = (dir) => {
    if (over) return;
    const { board: nb, gained } = applyMove(board, dir);
    if (JSON.stringify(nb) === JSON.stringify(board)) return;
    addTile(nb);
    setBoard(nb);
    setScore((s) => s + gained);
    if (!canMove(nb)) setOver(true);
  };

  useEffect(() => {
    const map = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
    const onKey = (e) => {
      if (map[e.key]) { e.preventDefault(); move(map[e.key]); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [board, over]);

  const reset = () => { setBoard(newBoard()); setScore(0); setOver(false); };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-4 w-full justify-between">
        <span className="font-bold">Score: {score}</span>
        <Button size="sm" variant="outline" onClick={reset} className="border-white/20 text-white">New Game</Button>
      </div>
      <div className="grid grid-cols-4 gap-2 p-2 rounded-xl bg-black/40 border border-white/10">
        {board.map((row, r) => row.map((v, c) => (
          <div key={`${r}-${c}`} className={`w-16 h-16 sm:w-20 sm:h-20 rounded-lg flex items-center justify-center font-bold text-lg ${TILE[v] || 'bg-[hsl(var(--voltage-yellow))] text-black'}`}>{v || ''}</div>
        )))}
      </div>
      {over && <p className="font-bold text-red-400">No moves left — final score {score}!</p>}
      <div className="grid grid-cols-3 gap-1 w-36">
        <div />
        <Button variant="outline" onClick={() => move('up')}>↑</Button>
        <div />
        <Button variant="outline" onClick={() => move('left')}>←</Button>
        <Button variant="outline" onClick={() => move('down')}>↓</Button>
        <Button variant="outline" onClick={() => move('right')}>→</Button>
      </div>
      <p className="text-white/40 text-xs">Arrow keys to merge • reach the 2048 tile</p>
    </div>
  );
}