import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

const makeQuestion = () => {
  const ops = ['+', '−', '×'];
  const op = ops[Math.floor(Math.random() * ops.length)];
  let a, b, answer;
  if (op === '+') { a = 5 + Math.floor(Math.random() * 45); b = 5 + Math.floor(Math.random() * 45); answer = a + b; }
  else if (op === '−') { a = 20 + Math.floor(Math.random() * 60); b = 1 + Math.floor(Math.random() * 19); answer = a - b; }
  else { a = 2 + Math.floor(Math.random() * 11); b = 2 + Math.floor(Math.random() * 11); answer = a * b; }
  const options = new Set([answer]);
  while (options.size < 4) {
    const delta = Math.floor(Math.random() * 10) + 1;
    options.add(Math.random() < 0.5 ? answer - delta : answer + delta);
  }
  return { text: `${a} ${op} ${b}`, answer, options: [...options].sort(() => Math.random() - 0.5) };
};

export default function MathBlitz() {
  const [q, setQ] = useState(makeQuestion);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [timeLeft, setTimeLeft] = useState(0);
  const running = timeLeft > 0;

  useEffect(() => {
    if (!running) return;
    const clock = setInterval(() => setTimeLeft((t) => Math.max(0, t - 1)), 1000);
    return () => clearInterval(clock);
  }, [running]);

  const answer = (val) => {
    if (!running) return;
    if (val === q.answer) {
      setScore((s) => s + 1);
      setFeedback('✅');
    } else {
      setFeedback('❌');
    }
    setTimeout(() => setFeedback(''), 250);
    setQ(makeQuestion());
  };

  const start = () => { setScore(0); setQ(makeQuestion); setTimeLeft(30); };

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-6 font-bold">
        <span>Score: {score}</span>
        <span className="text-[hsl(var(--voltage-yellow))]">⏱ {timeLeft}s</span>
      </div>
      {running ? (
        <>
          <div className="text-5xl font-black">{q.text} {feedback}</div>
          <div className="grid grid-cols-2 gap-3">
            {q.options.map((o) => (
              <Button key={o} size="lg" variant="outline" onClick={() => answer(o)} className="border-white/20 text-white hover:bg-white/10 text-xl px-10">{o}</Button>
            ))}
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center gap-2">
          {timeLeft === 0 && score > 0 && <p className="text-white/60 text-sm">Time! You solved {score} problems.</p>}
          <Button onClick={start} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Start</Button>
        </div>
      )}
      <p className="text-white/40 text-xs">Pick the right answer as fast as you can • 30 seconds</p>
    </div>
  );
}