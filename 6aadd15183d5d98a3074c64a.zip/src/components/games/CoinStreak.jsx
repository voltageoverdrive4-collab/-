import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

// Call it in the air — every correct flip in a row grows your streak.
export default function CoinStreak() {
  const [side, setSide] = useState(null); // last flip
  const [pick, setPick] = useState(null);
  const [streak, setStreak] = useState(0);
  const [best, setBest] = useState(0);
  const [history, setHistory] = useState([]);

  const flip = (call) => {
    if (side && !pick) return;
    const result = Math.random() < 0.5 ? 'H' : 'T';
    setPick(call);
    setSide(result);
    setHistory((h) => [...h.slice(-9), result]);
    if (call === result) {
      setStreak((s) => { const n = s + 1; setBest((b) => Math.max(b, n)); return n; });
    } else {
      setStreak(0);
    }
    setTimeout(() => setPick(null), 900);
  };

  return (
    <div className="max-w-sm mx-auto text-center space-y-5">
      <div className={`mx-auto w-28 h-28 rounded-full flex items-center justify-center text-5xl font-black border-4 transition-all ${side ? 'border-[hsl(var(--voltage-yellow))] bg-[hsl(var(--voltage-yellow))]/10' : 'border-white/20 bg-white/5'}`}>
        {side ? (side === 'H' ? '⚡' : '★') : '🪙'}
      </div>
      {pick && (
        <p className={`text-sm font-bold ${pick === side ? 'text-green-400' : 'text-red-400'}`}>
          {pick === side ? 'Called it! +1 streak' : `Nope — it was ${side === 'H' ? 'HEADS' : 'TAILS'}`}
        </p>
      )}
      <div className="flex justify-center gap-3">
        <Button size="lg" onClick={() => flip('H')} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold px-8" disabled={!!pick}>HEADS</Button>
        <Button size="lg" variant="outline" onClick={() => flip('T')} className="border-white/25 font-bold px-8" disabled={!!pick}>TAILS</Button>
      </div>
      <div className="flex justify-center gap-1 text-lg min-h-6">
        {history.map((h, i) => <span key={i}>{h === 'H' ? '⚡' : '★'}</span>)}
      </div>
      <p className="text-xs text-white/40">Streak {streak} · Best {best}</p>
    </div>
  );
}