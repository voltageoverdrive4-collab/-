import React, { useState } from 'react';

const rollDie = () => 1 + Math.floor(Math.random() * 6);
const DICE = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

// Pick your number — every die that matches pays out.
export default function ChuckALuck() {
  const [pick, setPick] = useState(3);
  const [bet, setBet] = useState(10);
  const [bank, setBank] = useState(100);
  const [dice, setDice] = useState(null);
  const [flash, setFlash] = useState('');

  const play = () => {
    if (bank < bet) return;
    setFlash('');
    setBank((v) => v - bet);
    const rolled = [rollDie(), rollDie(), rollDie()];
    setDice(rolled);
    const hits = rolled.filter((d) => d === pick).length;
    if (hits > 0) {
      setBank((v) => v + bet + hits * bet);
      setFlash(`Hit ${hits} × your bet! +${hits * bet}`);
    } else {
      setFlash('No matches — the house keeps it');
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-5 text-center">
      <p className="text-white/50 text-sm">Bet on 1–6, three dice roll — one match pays 1:1, two pays 2:1, three pays 3:1.</p>
      <p className="text-sm text-white/60">Bank: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{bank}</span></p>
      <div className="flex justify-center gap-2">
        {[1, 2, 3, 4, 5, 6].map((n) => (
          <button
            key={n}
            onClick={() => setPick(n)}
            className={`w-12 h-12 rounded-xl border text-2xl font-black transition-colors ${pick === n ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]' : 'bg-white/5 border-white/10 text-white/60 hover:bg-white/10'}`}
          >
            {DICE[n - 1]}
          </button>
        ))}
      </div>
      <div className="text-6xl flex justify-center gap-3">
        {dice ? dice.map((d, i) => <span key={i} className="text-[hsl(var(--voltage-yellow))] drop-shadow">{DICE[d - 1]}</span>) : <span className="text-white/20 text-4xl self-center">🎲🎲🎲</span>}
      </div>
      <div className="flex items-center justify-center gap-2">
        {[5, 10, 25].map((b) => (
          <button
            key={b}
            onClick={() => setBet(b)}
            className={`px-4 py-1.5 rounded-full text-sm font-bold border transition-colors ${bet === b ? 'bg-[hsl(var(--voltage-blue))]/20 border-[hsl(var(--voltage-blue))] text-[hsl(var(--voltage-blue))]' : 'border-white/15 text-white/50'}`}
          >
            {b}
          </button>
        ))}
        <button onClick={play} disabled={bank < bet} className="ml-2 px-6 py-1.5 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black disabled:opacity-40">
          Roll
        </button>
      </div>
      <p className="text-xs text-white/40">{flash || `Your number: ${pick}`}</p>
    </div>
  );
}