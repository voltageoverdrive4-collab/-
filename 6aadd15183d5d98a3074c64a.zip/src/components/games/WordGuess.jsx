import React, { useEffect, useMemo, useState } from 'react';

const WORDS = [
  'apple', 'beach', 'brave', 'bread', 'brick', 'bring', 'broad', 'brown', 'brush', 'chair',
  'chase', 'chess', 'chill', 'claim', 'clean', 'clear', 'climb', 'clock', 'close', 'cloud',
  'coach', 'coast', 'count', 'court', 'cover', 'cream', 'crane', 'crash', 'dance', 'diary',
  'dizzy', 'doubt', 'draft', 'drain', 'drive', 'eagle', 'earth', 'feast', 'field', 'flame',
  'fleet', 'floor', 'focus', 'force', 'frame', 'fresh', 'front', 'fruit', 'ghost', 'giant',
  'glass', 'glory', 'grace', 'grade', 'grand', 'grant', 'grape', 'grass', 'green', 'grill',
  'guard', 'guide', 'happy', 'heart', 'honey', 'horse', 'house', 'human', 'juice', 'laser',
  'laugh', 'lemon', 'light', 'lucky', 'lunch', 'magic', 'mango', 'maple', 'march', 'match',
  'medal', 'mouse', 'music', 'night', 'ocean', 'olive', 'paint', 'party', 'peach', 'piano',
  'pilot', 'pixel', 'pizza', 'plant', 'point', 'power', 'pride', 'prime', 'prize', 'queen',
  'quick', 'quiet', 'radar', 'radio', 'rally', 'rapid', 'reach', 'ready', 'robot', 'ranch',
  'ridge', 'river', 'royal', 'rugby', 'salad', 'scale', 'scout', 'sense', 'shade', 'shake',
  'shape', 'share', 'sharp', 'sheep', 'shine', 'shirt', 'shock', 'short', 'skill', 'smile',
  'smoke', 'snake', 'solar', 'sound', 'space', 'spare', 'spark', 'speed', 'spine', 'sport',
  'squad', 'staff', 'stage', 'stand', 'steel', 'stone', 'storm', 'story', 'super', 'sweet',
  'sword', 'table', 'taste', 'tiger', 'title', 'toast', 'token', 'torch', 'track', 'trade',
  'trail', 'train', 'treat', 'truck', 'trust', 'truth', 'ultra', 'unity', 'vault', 'vital',
  'vivid', 'vocal', 'water', 'whale', 'wheel', 'world', 'worth', 'zebra',
];
const KEYS = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'];

const grade = (guess, target) => {
  const res = Array(5).fill('absent');
  const rest = {};
  for (let i = 0; i < 5; i++) {
    if (guess[i] === target[i]) res[i] = 'correct';
    else rest[target[i]] = (rest[target[i]] || 0) + 1;
  }
  for (let i = 0; i < 5; i++) {
    if (res[i] !== 'correct' && rest[guess[i]] > 0) { res[i] = 'present'; rest[guess[i]]--; }
  }
  return res;
};

const TILE_STYLES = {
  correct: 'bg-[hsl(var(--voltage-yellow))] text-black border-transparent',
  present: 'bg-[hsl(var(--voltage-blue))]/70 text-black border-transparent',
  absent: 'bg-white/10 text-white/40 border-white/10',
  empty: 'border-white/20',
};
const KEY_STYLES = {
  correct: 'bg-[hsl(var(--voltage-yellow))] text-black',
  present: 'bg-[hsl(var(--voltage-blue))]/70 text-black',
  absent: 'bg-white/10 text-white/30',
};

export default function WordGuess() {
  const target = useMemo(() => WORDS[Math.floor(Math.random() * WORDS.length)], []);
  const [guesses, setGuesses] = useState([]);
  const [current, setCurrent] = useState('');
  const won = guesses[guesses.length - 1] === target;
  const lost = !won && guesses.length >= 6;

  const type = (ch) => { if (!won && !lost && current.length < 5) setCurrent((c) => c + ch); };
  const submit = () => {
    if (current.length !== 5 || won || lost) return;
    setGuesses((gs) => [...gs, current]);
    setCurrent('');
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Enter') { e.preventDefault(); submit(); }
      else if (e.key === 'Backspace') setCurrent((c) => c.slice(0, -1));
      else if (/^[a-z]$/.test(e.key)) type(e.key);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const keyStates = {};
  guesses.forEach((g) => {
    grade(g, target).forEach((st, i) => {
      const ch = g[i];
      if (st === 'correct') keyStates[ch] = 'correct';
      else if (st === 'present' && keyStates[ch] !== 'correct') keyStates[ch] = 'present';
      else if (!keyStates[ch]) keyStates[ch] = 'absent';
    });
  });

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex flex-col gap-1.5">
        {[...Array(6)].map((_, r) => {
          const guess = guesses[r];
          const grades = guess ? grade(guess, target) : null;
          return (
            <div key={r} className="flex gap-1.5">
              {[...Array(5)].map((_, c) => {
                const ch = guess ? guess[c] : r === guesses.length ? current[c] : '';
                const st = grades ? grades[c] : 'empty';
                return (
                  <div key={c} className={`w-9 h-9 sm:w-11 sm:h-11 border-2 flex items-center justify-center font-bold uppercase ${TILE_STYLES[st]}`}>
                    {ch || ''}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
      {(won || lost) && (
        <p className={`font-bold ${won ? 'text-[hsl(var(--voltage-yellow))]' : 'text-red-400'}`}>
          {won ? 'Nailed it! ⚡' : `Out of guesses — the word was "${target.toUpperCase()}"`}
        </p>
      )}
      <div className="flex flex-col items-center gap-1.5">
        {KEYS.map((row) => (
          <div key={row} className="flex gap-1">
            {row.split('').map((ch) => (
              <button
                key={ch}
                onClick={() => type(ch)}
                disabled={won || lost}
                className={`w-7 h-9 sm:w-8 rounded-md text-xs font-bold uppercase transition-colors disabled:opacity-60 ${keyStates[ch] ? KEY_STYLES[keyStates[ch]] : 'bg-white/15 text-white hover:bg-white/25'}`}
              >
                {ch}
              </button>
            ))}
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={() => setCurrent((c) => c.slice(0, -1))} className="px-3 h-9 rounded-md bg-white/15 text-xs font-bold hover:bg-white/25">⌫</button>
        <button onClick={submit} disabled={won || lost} className="px-4 h-9 rounded-md bg-[hsl(var(--voltage-yellow))] text-black text-xs font-bold disabled:opacity-40">Enter</button>
      </div>
      <p className="text-white/40 text-xs">Guess the 5-letter word in 6 tries — type or tap</p>
    </div>
  );
}