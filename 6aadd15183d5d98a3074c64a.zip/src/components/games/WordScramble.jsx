import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'react-hot-toast';

const WORDS = ['voltage', 'fortnite', 'victory', 'battle', 'royale', 'lightning', 'controller', 'keyboard', 'sniper', 'building', 'tournament', 'teammate', 'creative', 'champion', 'headshot'];

const scramble = (word) => {
  let out = word;
  while (out === word) {
    out = [...word].sort(() => Math.random() - 0.5).join('');
  }
  return out;
};

export default function WordScramble() {
  const [round, setRound] = useState(0);
  const [word, setWord] = useState(() => WORDS[Math.floor(Math.random() * WORDS.length)]);
  const [guess, setGuess] = useState('');
  const [score, setScore] = useState(0);

  const nextWord = () => {
    setWord(WORDS[Math.floor(Math.random() * WORDS.length)]);
    setGuess('');
    setRound((r) => r + 1);
  };

  const check = () => {
    if (!guess.trim()) return;
    if (guess.trim().toLowerCase() === word) {
      setScore((s) => s + 1);
      toast.success('Unscrambled! ⚡');
      nextWord();
    } else {
      toast.error('Not quite — try again!');
    }
  };

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-6 font-bold">
        <span>Solved: {score}</span>
        <span className="text-white/50">Round: {round + 1}</span>
      </div>
      <div className="text-3xl sm:text-4xl font-black tracking-[0.2em] text-[hsl(var(--voltage-yellow))] uppercase">{scramble(word)}</div>
      <div className="flex gap-2 w-full max-w-xs">
        <Input
          value={guess}
          onChange={(e) => setGuess(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') check(); }}
          placeholder="Your guess…"
          className="bg-black/40 border-white/15 text-white"
        />
        <Button onClick={check} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Guess</Button>
      </div>
      <Button variant="outline" onClick={nextWord} className="border-white/20 text-white hover:bg-white/10">Skip Word</Button>
      <p className="text-white/40 text-xs">Unscramble the gaming word • Enter to submit</p>
    </div>
  );
}