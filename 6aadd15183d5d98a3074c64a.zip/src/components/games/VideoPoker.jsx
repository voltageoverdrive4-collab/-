import React, { useState } from 'react';

const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

const freshDeck = () => SUITS.flatMap((s) => RANKS.map((r) => ({ r, s }))).sort(() => Math.random() - 0.5);

const evaluate = (cards) => {
  const ranks = cards.map((c) => RANKS.indexOf(c.r)).sort((a, b) => a - b);
  const counts = {};
  ranks.forEach((r) => { counts[r] = (counts[r] || 0) + 1; });
  const groups = Object.values(counts).sort((a, b) => b - a);
  const flush = cards.every((c) => c.s === cards[0].s);
  const straight = ranks[4] - ranks[0] === 4 && new Set(ranks).size === 5;
  const royal = straight && ranks[0] === 8;
  if (flush && royal) return { name: 'Royal Flush', pay: 250 };
  if (flush && straight) return { name: 'Straight Flush', pay: 50 };
  if (groups[0] === 4) return { name: 'Four of a Kind', pay: 25 };
  if (groups[0] === 3 && groups[1] === 2) return { name: 'Full House', pay: 9 };
  if (flush) return { name: 'Flush', pay: 6 };
  if (straight) return { name: 'Straight', pay: 4 };
  if (groups[0] === 3) return { name: 'Three of a Kind', pay: 3 };
  if (groups[0] === 2 && groups[1] === 2) return { name: 'Two Pair', pay: 2 };
  if (groups[0] === 2 && ranks[3] >= 9) return { name: 'Jacks or Better', pay: 1 };
  return { name: 'No pay', pay: 0 };
};

// Five-card draw poker — hold what you want, redraw the rest.
export default function VideoPoker() {
  const [credits, setCredits] = useState(100);
  const [hand, setHand] = useState([]);
  const [deck, setDeck] = useState([]);
  const [held, setHeld] = useState(() => new Set());
  const [result, setResult] = useState(null);
  const phase = hand.length === 0 ? 'bet' : result ? 'done' : 'draw';

  const deal = () => {
    if (credits < 5) return;
    const d = freshDeck();
    setHand(d.slice(0, 5));
    setDeck(d.slice(5));
    setHeld(new Set());
    setResult(null);
    setCredits((c) => c - 5);
  };

  const draw = () => {
    const nextHand = hand.map((c, i) => (held.has(i) ? c : deck.shift() || c));
    setHand(nextHand);
    const ev = evaluate(nextHand);
    setResult(ev);
    setCredits((c) => c + ev.pay);
    setDeck([...deck]);
  };

  return (
    <div className="max-w-lg mx-auto space-y-4 text-center">
      <p className="text-white/50 text-sm">Bet 5 credits · hold the cards you keep, then draw.</p>
      <div className="flex justify-between text-sm text-white/60">
        <span>Credits: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{credits}</span></span>
        <span className="text-xs text-white/30">Royal flush pays 250</span>
      </div>
      <div className="flex justify-center gap-2">
        {hand.map((c, i) => (
          <button
            key={i}
            onClick={() => { if (phase !== 'draw') return; setHeld((prev) => { const n = new Set(prev); if (n.has(i)) n.delete(i); else n.add(i); return n; }); }}
            className={`w-[72px] h-24 rounded-xl border flex flex-col items-center justify-center text-3xl font-black transition-all ${
              held.has(i)
                ? 'bg-[hsl(var(--voltage-yellow))]/20 border-[hsl(var(--voltage-yellow))] -translate-y-2'
                : 'bg-white/95 border-white/20 text-black'
            } ${c && ['♥', '♦'].includes(c.s) ? 'text-red-600' : ''}`}
          >
            <span>{c?.r}</span>
            <span>{c?.s}</span>
            {held.has(i) && <span className="text-[9px] text-[hsl(var(--voltage-yellow))] mt-1">HELD</span>}
          </button>
        ))}
      </div>
      {result && <p className={`font-bold ${result.pay > 0 ? 'text-[hsl(var(--voltage-yellow))]' : 'text-white/50'}`}>{result.name} — pays {result.pay}</p>}
      <div>
        {phase === 'bet' && (
          <button onClick={deal} disabled={credits < 5} className="px-6 py-2 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black disabled:opacity-40">
            Deal — 5 credits
          </button>
        )}
        {phase === 'draw' && (
          <button onClick={draw} className="px-6 py-2 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black">
            Draw
          </button>
        )}
        {phase === 'done' && (
          <button onClick={deal} disabled={credits < 5} className="px-6 py-2 rounded-xl font-bold bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black disabled:opacity-40">
            Deal again
          </button>
        )}
      </div>
      {credits < 5 && <p className="text-xs text-red-400">Out of credits — refresh for a new stack</p>}
    </div>
  );
}