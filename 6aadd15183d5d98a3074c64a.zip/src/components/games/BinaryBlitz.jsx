import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const gen = () => {
  const n = 1 + Math.floor(Math.random() * 255);
  return { prompt: n.toString(2), answer: String(n) };
};

export default function BinaryBlitz() {
  const [puzzle, setPuzzle] = useState(gen);
  const [input, setInput] = useState('');
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(45);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (time === 0) return;
    const t = setTimeout(() => setTime((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [time]);

  const submit = (e) => {
    e.preventDefault();
    if (time === 0 || !input.trim()) return;
    if (input.trim() === puzzle.answer) {
      setScore((s) => s + 1);
      setMsg('Correct!');
    } else {
      setMsg(`It was ${puzzle.answer}`);
    }
    setInput('');
    setPuzzle(gen());
  };

  const restart = () => {
    setTime(45);
    setScore(0);
    setMsg('');
    setPuzzle(gen());
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto text-center">
      <p className="text-white/50 text-sm">Read binary like a computer — type the decimal number. 45 seconds.</p>
      <p className="text-4xl font-black font-mono text-[hsl(var(--voltage-yellow))]">{puzzle.prompt}</p>
      {time > 0 ? (
        <form onSubmit={submit} className="flex gap-2 justify-center">
          <Input autoFocus type="number" value={input} onChange={(e) => setInput(e.target.value)} className="w-40 bg-black/40 border-white/15 text-white text-center text-xl" />
          <Button type="submit" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Answer</Button>
        </form>
      ) : (
        <div className="space-y-2">
          <p className="font-bold text-[hsl(var(--voltage-yellow))]">Time! You solved {score}.</p>
          <Button onClick={restart} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Play again</Button>
        </div>
      )}
      {msg && time > 0 && <p className="font-semibold">{msg}</p>}
      {time > 0 && <p className="text-white/60 text-sm">Solved: {score} · {time}s left</p>}
    </div>
  );
}