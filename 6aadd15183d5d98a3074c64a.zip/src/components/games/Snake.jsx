import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';

const SIZE = 15, CELL = 20;

export default function Snake() {
  const canvasRef = useRef(null);
  const snakeRef = useRef([{ x: 7, y: 7 }]);
  const dirRef = useRef({ x: 1, y: 0 });
  const foodRef = useRef({ x: 3, y: 3 });
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const [running, setRunning] = useState(false);

  const setDir = (nd) => {
    const d = dirRef.current;
    if (nd.x === -d.x && nd.y === -d.y) return;
    dirRef.current = nd;
  };

  useEffect(() => {
    const map = { ArrowUp: { x: 0, y: -1 }, ArrowDown: { x: 0, y: 1 }, ArrowLeft: { x: -1, y: 0 }, ArrowRight: { x: 1, y: 0 } };
    const onKey = (e) => {
      const nd = map[e.key];
      if (nd) { e.preventDefault(); setDir(nd); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      const snake = snakeRef.current;
      const head = { x: snake[0].x + dirRef.current.x, y: snake[0].y + dirRef.current.y };
      const hitWall = head.x < 0 || head.y < 0 || head.x >= SIZE || head.y >= SIZE;
      const hitSelf = snake.some((s) => s.x === head.x && s.y === head.y);
      if (hitWall || hitSelf) { setRunning(false); setOver(true); return; }
      snake.unshift(head);
      const f = foodRef.current;
      if (head.x === f.x && head.y === f.y) {
        setScore((s) => s + 1);
        do {
          foodRef.current = { x: Math.floor(Math.random() * SIZE), y: Math.floor(Math.random() * SIZE) };
        } while (snake.some((s) => s.x === foodRef.current.x && s.y === foodRef.current.y));
      } else snake.pop();

      const ctx = canvasRef.current?.getContext('2d');
      if (!ctx) return;
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, SIZE * CELL, SIZE * CELL);
      ctx.fillStyle = '#ffe00f';
      snake.forEach((s) => ctx.fillRect(s.x * CELL + 1, s.y * CELL + 1, CELL - 2, CELL - 2));
      const nf = foodRef.current;
      ctx.fillStyle = '#00c8ff';
      ctx.fillRect(nf.x * CELL + 1, nf.y * CELL + 1, CELL - 2, CELL - 2);
    }, 130);
    return () => clearInterval(id);
  }, [running]);

  const start = () => {
    snakeRef.current = [{ x: 7, y: 7 }];
    dirRef.current = { x: 1, y: 0 };
    foodRef.current = { x: 3, y: 3 };
    setScore(0);
    setOver(false);
    setRunning(true);
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-4 w-full justify-between">
        <span className="font-bold">Score: {score}</span>
        <span className="text-white/60 text-sm">Length: {score + 3}</span>
        {!running && <Button onClick={start} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">{over ? 'Play Again' : 'Start'}</Button>}
      </div>
      <canvas ref={canvasRef} width={SIZE * CELL} height={SIZE * CELL} className="rounded-lg border border-white/10 max-w-full" />
      <div className="grid grid-cols-3 gap-1 w-36 sm:hidden">
        <div />
        <Button variant="outline" onClick={() => setDir({ x: 0, y: -1 })}>↑</Button>
        <div />
        <Button variant="outline" onClick={() => setDir({ x: -1, y: 0 })}>←</Button>
        <Button variant="outline" onClick={() => setDir({ x: 0, y: 1 })}>↓</Button>
        <Button variant="outline" onClick={() => setDir({ x: 1, y: 0 })}>→</Button>
      </div>
      <p className="text-white/40 text-xs">Arrow keys to steer • eat the blue cells</p>
    </div>
  );
}