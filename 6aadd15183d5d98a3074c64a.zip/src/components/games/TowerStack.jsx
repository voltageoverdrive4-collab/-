import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';

const W = 400;
const BLOCK_H = 22;
const START_W = 120;

// Stop the swinging block right on the tower — every perfect drop grows the stack.
export default function TowerStack() {
  const canvasRef = useRef(null);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const [running, setRunning] = useState(false);
  const st = useRef(null);

  const fresh = () => ({
    stack: [{ x: W / 2 - START_W / 2, w: START_W }],
    moving: { x: 0, dir: 1, speed: 160 },
    over: false,
  });

  useEffect(() => {
    if (!running) return undefined;
    let raf;
    let last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.04, (now - last) / 1000);
      last = now;
      const s = st.current;
      const canvas = canvasRef.current;
      if (canvas && s && !s.over) {
        s.moving.x += s.moving.dir * s.moving.speed * dt;
        if (s.moving.x < 0) { s.moving.x = 0; s.moving.dir = 1; }
        if (s.moving.x + s.stack.at(-1).w > W) { s.moving.x = W - s.stack.at(-1).w; s.moving.dir = -1; }

        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, W, 480);
        ctx.fillStyle = '#0a0e14';
        ctx.fillRect(0, 0, W, 480);
        // tower
        s.stack.forEach((b, i) => {
          const y = 460 - i * BLOCK_H;
          ctx.fillStyle = i === 0 ? '#3d4450' : `hsl(${45 + i * 6}, 90%, ${58 - Math.min(25, i * 2)}%)`;
          ctx.fillRect(b.x, y - BLOCK_H, b.w, BLOCK_H - 2);
        });
        // moving block
        const topY = 460 - s.stack.length * BLOCK_H;
        ctx.fillStyle = '#ffe00f';
        ctx.fillRect(s.moving.x, topY - BLOCK_H, s.stack.at(-1).w, BLOCK_H - 2);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  const drop = () => {
    if (!running || !st.current || st.current.over) return;
    const s = st.current;
    const prev = s.stack.at(-1);
    const w = prev.w;
    const x = s.moving.x;
    const overlap = Math.min(x + w, prev.x + prev.w) - Math.max(x, prev.x);
    if (overlap <= 0) {
      s.over = true;
      setOver(true);
      setRunning(false);
      return;
    }
    const perfect = Math.abs(x - prev.x) < 3;
    const newW = perfect ? w : overlap;
    const newX = perfect ? prev.x : Math.max(x, prev.x);
    s.stack.push({ x: newX, w: newW });
    setScore(s.stack.length - 1);
    s.moving = { x: Math.random() < 0.5 ? 0 : W - newW, dir: 1, speed: 160 + s.stack.length * 9 };
    s.moving.dir = s.moving.x === 0 ? 1 : -1;
  };

  useEffect(() => {
    const onKey = (e) => { if (e.code === 'Space' || e.code === 'ArrowDown') { e.preventDefault(); drop(); } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    /* eslint-disable-next-line */
  }, [running]);

  const start = () => {
    st.current = fresh();
    setScore(0); setOver(false); setRunning(true);
  };

  return (
    <div className="max-w-md mx-auto text-center space-y-3">
      <div className="flex justify-center gap-6 text-sm">
        <span className="text-[hsl(var(--voltage-yellow))] font-bold">Height {score}</span>
        <span className="text-white/40">click / space to drop</span>
      </div>
      <div className="relative inline-block">
        <canvas
          ref={canvasRef}
          width={W}
          height={480}
          onClick={drop}
          className="max-w-full rounded-xl border border-white/10 cursor-pointer"
          style={{ aspectRatio: '400/480' }}
        />
        {!running && (
          <div className="absolute inset-0 bg-black/70 rounded-xl flex flex-col items-center justify-center gap-3">
            <p className="text-white/80 font-bold">{over ? `Tower topped out at ${score}!` : 'Stack the tower as high as you can'}</p>
            <Button size="sm" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold" onClick={start}>{over ? 'Play Again' : 'Start'}</Button>
          </div>
        )}
      </div>
    </div>
  );
}