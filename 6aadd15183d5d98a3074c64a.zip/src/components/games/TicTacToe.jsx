import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

export default function TicTacToe() {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [x, setX] = useState(true);

  const winner = () => {
    for (const [a,b,c] of wins) if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
    return board.every(Boolean) ? 'Draw' : null;
  };
  const w = winner();
  const click = (i) => {
    if (board[i] || w) return;
    const b = [...board]; b[i] = x ? '⚡' : '🔵'; setBoard(b); setX(!x);
  };

  return (
    <div>
      <p className="text-white/60 mb-4 text-sm">{w ? (w === 'Draw' ? "It's a draw!" : `${w} wins!`) : `Turn: ${x ? '⚡' : '🔵'}`}</p>
      <div className="grid grid-cols-3 gap-2 w-64">
        {board.map((c, i) => (
          <button key={i} onClick={() => click(i)} className="aspect-square rounded-lg bg-black/40 border border-white/15 text-3xl hover:bg-white/10">{c}</button>
        ))}
      </div>
      <Button onClick={() => { setBoard(Array(9).fill(null)); setX(true); }} variant="outline" className="mt-4 border-white/20 text-white hover:bg-white/10">Reset</Button>
    </div>
  );
}