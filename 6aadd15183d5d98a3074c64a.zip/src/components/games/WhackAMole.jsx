import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

const HOLES = 9;

export default function WhackAMole() {
  const [active, setActive] = useState(-1);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const running = timeLeft > 0;

  useEffect(() => {
    if (!running) return;
    const mole = setInterval(() => setActive(Math.random() < 0.15 ? -1 : Math.floor(Math.random() * HOLES)), 650);
    const clock = setInterval(() => setTimeLeft((t) => Math.max(0, t - 1)), 1000);
    return () => { clearInterval(mole); clearInterval(clock); };
  }, [running]);

  useEffect(() => {
    if (timeLeft === 0 && score > 0) {
      setBest((b) => Math.max(b, score));
      setActive(-1);
    }
  }, [timeLeft]);

  const start = () => { setScore(0); setTimeLeft(30); };
  const whack = (i) => {
    if (running && i === active) { setScore((s) => s + 1); setActive(-1); }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex gap-6 font-bold">
        <span>Score: {score}</span>
        <span className="text-[hsl(var(--voltage-yellow))]">⏱ {timeLeft}s</span>
        <span className="text-white/50">Best: {best}</span>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {Array.from({ length: HOLES }, (_, i) => (
          <button
            key={i}
            onClick={() => whack(i)}
            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full text-2xl transition-all ${i === active ? 'bg-[hsl(var(--voltage-yellow))] scale-110' : 'bg-black/50 border border-white/10 hover:bg-white/10'}`}
          >
            {i === active ? '⚡' : ''}
          </button>
        ))}
      </div>
      {!running && (
        <div className="flex flex-col items-center gap-2">
          {best > 0 && <p className="text-white/60 text-sm">Time! You zapped {score} bolts.</p>}
          <Button onClick={start} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Start</Button>
        </div>
      )}
      <p className="text-white/40 text-xs">Tap the ⚡ as fast as you can • 30 seconds</p>
    </div>
  );
}