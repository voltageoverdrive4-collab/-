import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Brain } from 'lucide-react';

const QUESTIONS = [
  { q: 'Which company develops Fortnite?', o: ['Epic Games', 'Activision', 'Ubisoft', 'Valve'], a: 0 },
  { q: "What is Fortnite's in-game currency?", o: ['Robux', 'V-Bucks', 'Coins', 'Gems'], a: 1 },
  { q: 'What year did Fortnite Battle Royale launch?', o: ['2015', '2016', '2017', '2018'], a: 2 },
  { q: 'Which building material has the most HP?', o: ['Wood', 'Brick', 'Metal', 'Glass'], a: 2 },
  { q: 'What is the name of the bus that drops players on the island?', o: ['The Storm Bus', 'The Battle Bus', 'The Drop Bus', 'The Party Bus'], a: 1 },
  { q: 'What color is a Common rarity item?', o: ['Green', 'Blue', 'Gray', 'Purple'], a: 2 },
  { q: 'What shrinks the map and forces players together?', o: ['The Storm', 'The Flood', 'The Wall', 'The Fog'], a: 0 },
  { q: "Mario's brother is named…", o: ['Wario', 'Luigi', 'Toad', 'Yoshi'], a: 1 },
  { q: 'Which enemy explodes in Minecraft?', o: ['Zombie', 'Skeleton', 'Creeper', 'Enderman'], a: 2 },
  { q: 'Which company makes the Nintendo Switch?', o: ['Sony', 'Microsoft', 'Sega', 'Nintendo'], a: 3 },
  { q: 'What does "GG" stand for?', o: ['Go Go', 'Good Game', 'Great Goal', 'Get Good'], a: 1 },
  { q: 'In chess, which piece can only move diagonally?', o: ['Rook', 'Knight', 'Bishop', 'Queen'], a: 2 },
  { q: 'Pac-Man is chased by…', o: ['Ghosts', 'Robots', 'Aliens', 'Dragons'], a: 0 },
  { q: 'Master Chief is the hero of which series?', o: ['Destiny', 'Halo', 'Gears of War', 'Doom'], a: 1 },
  { q: 'Which company owns Xbox?', o: ['Microsoft', 'Sony', 'Apple', 'Google'], a: 0 },
  { q: 'What does RPG stand for?', o: ['Rapid Play Game', 'Role-Playing Game', 'Rank Point Game', 'Racing Power Game'], a: 1 },
  { q: 'What year did Among Us explode in popularity?', o: ['2018', '2019', '2020', '2021'], a: 2 },
  { q: 'How many squares are on a chess board?', o: ['36', '49', '64', '81'], a: 2 },
];

// Voltage Trivia — 18 gaming questions, multiple choice.
export default function TriviaVolt() {
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [picked, setPicked] = useState(null);
  const [done, setDone] = useState(false);

  const current = QUESTIONS[idx];

  const pick = (i) => {
    if (picked !== null) return;
    setPicked(i);
    if (i === current.a) setScore((s) => s + 1);
  };

  const next = () => {
    if (idx + 1 >= QUESTIONS.length) { setDone(true); return; }
    setIdx((i) => i + 1);
    setPicked(null);
  };

  const restart = () => { setIdx(0); setScore(0); setPicked(null); setDone(false); };

  if (done) {
    return (
      <div className="max-w-md mx-auto text-center space-y-4 p-8 rounded-xl bg-white/5 border border-white/10">
        <Brain className="w-10 h-10 mx-auto text-[hsl(var(--voltage-yellow))]" />
        <p className="text-3xl font-black">{score} / {QUESTIONS.length}</p>
        <p className="text-white/50">{score >= QUESTIONS.length - 3 ? 'Certified gaming legend 🏆' : score >= QUESTIONS.length / 2 ? 'Solid knowledge, keep grinding' : 'VoltBot is disappointed…'}</p>
        <Button onClick={restart} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Play again</Button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-5">
      <div className="flex items-center justify-between text-sm text-white/50">
        <span>Question {idx + 1} / {QUESTIONS.length}</span>
        <span>Score: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{score}</span></span>
      </div>
      <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
        <div className="h-full bg-[hsl(var(--voltage-yellow))] transition-all" style={{ width: `${((idx + (picked !== null ? 1 : 0)) / QUESTIONS.length) * 100}%` }} />
      </div>
      <p className="font-bold text-lg">{current.q}</p>
      <div className="grid gap-2">
        {current.o.map((opt, i) => {
          const isAnswer = i === current.a;
          const isPicked = i === picked;
          let cls = 'border-white/15 bg-white/5 hover:bg-white/10 text-white/80';
          if (picked !== null) {
            if (isAnswer) cls = 'border-emerald-400/60 bg-emerald-500/15 text-emerald-300';
            else if (isPicked) cls = 'border-red-400/60 bg-red-500/15 text-red-300';
            else cls = 'border-white/10 bg-white/[0.02] text-white/40';
          }
          return (
            <button key={opt} onClick={() => pick(i)} className={`text-left px-4 py-3 rounded-xl border transition-colors ${cls}`}>
              {opt}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <Button onClick={next} className="w-full bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          {idx + 1 >= QUESTIONS.length ? 'See results' : 'Next question'}
        </Button>
      )}
    </div>
  );
}