import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';

const SEGMENTS = [50, 10, 100, 5, 250, 10, 500, 25];

export default function LuckyWheel() {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [volts, setVolts] = useState(0);
  const [msg, setMsg] = useState('');
  const timerRef = useRef(null);

  useEffect(() => () => clearTimeout(timerRef.current), []);

  const spin = () => {
    if (spinning) return;
    setSpinning(true);
    setMsg('');
    const idx = Math.floor(Math.random() * SEGMENTS.length);
    const wanted = (360 - (idx * 45 + 22.5)) % 360;
    const current = ((rotation % 360) + 360) % 360;
    const delta = (wanted - current + 360) % 360;
    setRotation(rotation + 360 * 5 + delta);
    timerRef.current = setTimeout(() => {
      setSpinning(false);
      setVolts((v) => v + SEGMENTS[idx]);
      setMsg(`+${SEGMENTS[idx]} volts ⚡`);
    }, 2600);
  };

  return (
    <div className="space-y-5 max-w-md mx-auto text-center">
      <p className="text-white/50 text-sm">Spin the wheel and rack up volts.</p>
      <div className="text-2xl leading-none">🔻</div>
      <div className="relative w-56 h-56 mx-auto">
        <div
          className="w-full h-full rounded-full border-4 border-[hsl(var(--voltage-yellow))] transition-transform duration-[2500ms] ease-out"
          style={{
            background: 'conic-gradient(from -22.5deg, #facc15 0deg 45deg, #22d3ee 45deg 90deg, #f472b6 90deg 135deg, #4ade80 135deg 180deg, #facc15 180deg 225deg, #22d3ee 225deg 270deg, #f472b6 270deg 315deg, #4ade80 315deg 360deg)',
            transform: `rotate(${rotation}deg)`,
          }}
        >
          {SEGMENTS.map((v, i) => (
            <div key={i} className="absolute inset-0 flex justify-center pointer-events-none" style={{ transform: `rotate(${i * 45 + 22.5}deg)` }}>
              <span className="mt-2 text-sm font-black text-black/70">{v}</span>
            </div>
          ))}
        </div>
      </div>
      <Button onClick={spin} disabled={spinning} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
        {spinning ? 'Spinning…' : 'SPIN'}
      </Button>
      {msg && <p className="font-semibold text-[hsl(var(--voltage-yellow))]">{msg}</p>}
      <p className="text-white/60 text-sm">Total volts: <span className="font-bold">{volts}</span></p>
    </div>
  );
}