import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'react-hot-toast';

const ICONS = ['⚡', '🎮', '🏆', '💎', '🔔', '⭐'];
const rand = () => ICONS[Math.floor(Math.random() * ICONS.length)];

// Pull the lever — three matching bolts pay out big.
export default function VoltSlots() {
  const [reels, setReels] = useState(['⚡', '🎮', '🏆']);
  const [credits, setCredits] = useState(20);
  const [spinning, setSpinning] = useState(false);
  const [lastWin, setLastWin] = useState(0);
  const spinRef = useRef(0);

  useEffect(() => () => clearInterval(spinRef.current), []);

  const spin = () => {
    if (spinning || credits < 1) {
      if (credits < 1) toast.error('Out of credits — press Reset');
      return;
    }
    setCredits((c) => c - 1);
    setLastWin(0);
    setSpinning(true);
    let ticks = 0;
    spinRef.current = setInterval(() => {
      ticks++;
      setReels([rand(), rand(), rand()]);
      if (ticks > 18) {
        clearInterval(spinRef.current);
        const final = [rand(), rand(), rand()];
        setReels(final);
        setSpinning(false);
        let win = 0;
        if (final[0] === final[1] && final[1] === final[2]) win = final[0] === '⚡' ? 50 : 20;
        else if (final[0] === final[1] || final[1] === final[2] || final[0] === final[2]) win = 3;
        if (win > 0) {
          setCredits((c) => c + win);
          setLastWin(win);
          toast.success(`You won ${win} credits!`);
        }
      }
    }, 90);
  };

  return (
    <div className="max-w-md mx-auto text-center space-y-5">
      <div className="inline-flex gap-3 p-5 rounded-2xl bg-black/50 border border-white/10">
        {reels.map((r, i) => (
          <div key={i} className={`w-20 h-24 flex items-center justify-center text-5xl rounded-xl bg-white/5 border border-white/10 ${spinning ? 'animate-pulse' : ''}`}>{r}</div>
        ))}
      </div>
      <div className="flex justify-center items-center gap-4">
        <Button onClick={spin} disabled={spinning} className="bg-[hsl(var(--voltage-yellow))] text-black font-black px-8">
          {spinning ? 'Spinning…' : 'SPIN (1 credit)'}
        </Button>
        <Button size="sm" variant="outline" className="border-white/20" onClick={() => { setCredits(20); setLastWin(0); }}>Reset</Button>
      </div>
      <div className="text-sm text-white/70">
        Credits: <span className="font-bold text-[hsl(var(--voltage-yellow))]">{credits}</span>
        {lastWin > 0 && <span className="ml-2 text-green-400">+{lastWin} last win</span>}
      </div>
      <p className="text-[11px] text-white/40">3 ⚡ = 50 · 3 of a kind = 20 · any pair = 3</p>
    </div>
  );
}