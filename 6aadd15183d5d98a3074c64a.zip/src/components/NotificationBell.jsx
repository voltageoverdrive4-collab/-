const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import { Bell, BellRing, MessageSquare } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useAuth } from '@/lib/AuthContext';
import { fromDb } from '@/lib/time';

const LAST_SEEN_KEY = 'voltage_chat_last_seen';

// Floating notification bell: live-unread clan chat plus announcements
// broadcast from the Admin panel — with Discord-style pop-ups for
// everything that arrives while you're elsewhere in the app.
export default function NotificationBell() {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState([]);
  const [unreadNotes, setUnreadNotes] = useState(0);
  const [unreadChat, setUnreadChat] = useState(0);
  const onChatRef = useRef(false);
  onChatRef.current = location.pathname === '/chat';

  // browser system banners ("phone-style" alerts) for members using the website
  const [sysAlertsOn, setSysAlertsOn] = useState(
    typeof Notification !== 'undefined' && Notification.permission === 'granted'
  );
  const sysAlertsRef = useRef(sysAlertsOn);
  sysAlertsRef.current = sysAlertsOn;

  const enableSystemAlerts = async () => {
    try {
      const perm = await Notification.requestPermission();
      setSysAlertsOn(perm === 'granted');
      toast.success(perm === 'granted' ? 'Phone-style alerts on!' : 'Alerts are blocked in your browser settings');
    } catch (e) {
      toast.error("This browser can't show system alerts");
    }
  };

  // shows a banner at the top of the phone/desktop screen while the app runs in the background
  const systemAlert = (title, body, path) => {
    if (!sysAlertsRef.current || !document.hidden) return;
    try {
      const n = new Notification(title, { body, tag: path });
      n.onclick = () => { window.focus(); n.close(); navigate(path); };
    } catch (e) {
      /* this browser can't show system banners — the in-app pop-up already covered it */
    }
  };

  const markChatSeen = () => {
    localStorage.setItem(LAST_SEEN_KEY, new Date().toISOString());
    setUnreadChat(0);
  };

  // while on the chat page, incoming messages count as seen
  useEffect(() => { if (onChatRef.current) markChatSeen(); }, [location.pathname]);

  useEffect(() => {
    if (!user?.id) return;
    let alive = true;

    db.entities.Notification.filter({ user_id: user.id, read: false }, { sort: '-created_date', limit: 30 })
      .then((page) => {
        if (!alive) return;
        const items = page.items || [];
        setNotes(items);
        setUnreadNotes(items.length);
      })
      .catch(() => {});

    const seen = localStorage.getItem(LAST_SEEN_KEY);
    db.entities.ChatMessage.count(seen ? { created_date: { $gte: seen } } : {})
      .then((n) => { if (alive) setUnreadChat(n || 0); })
      .catch(() => {});

    const unsubNotes = db.entities.Notification.subscribe((e) => {
      if (e.type === 'create' && e.data?.user_id === user.id) {
        setNotes((prev) => [e.data, ...prev].slice(0, 30));
        setUnreadNotes((n) => n + 1);
        toast.custom((tid) => (
          <button
            onClick={() => { toast.dismiss(tid); setOpen(true); }}
            className="max-w-xs w-full text-left rounded-xl bg-[#0b0b0b]/95 border border-[hsl(var(--voltage-yellow))]/40 shadow-2xl px-4 py-3 backdrop-blur-xl"
          >
            <p className="text-sm font-bold text-[hsl(var(--voltage-yellow))]">⚡ {e.data.title}</p>
            {e.data.body && <p className="text-xs text-white/70 mt-1 line-clamp-2">{e.data.body}</p>}
          </button>
        ), { duration: 6000, position: 'top-right' });
        systemAlert(`⚡ ${e.data.title}`, e.data.body || '', '/');
      }
    });
    const unsubChat = db.entities.ChatMessage.subscribe((e) => {
      if (e.type !== 'create') return;
      if (e.data?.user_id && e.data.user_id === user.id) return; // no pop-up for your own message
      if (onChatRef.current) markChatSeen();
      else {
        setUnreadChat((n) => n + 1);
        toast.custom((tid) => (
          <button
            onClick={() => { toast.dismiss(tid); navigate('/chat'); }}
            className="max-w-xs w-full text-left rounded-xl bg-[#0b0b0b]/95 border border-[hsl(var(--voltage-blue))]/40 shadow-2xl px-4 py-3 backdrop-blur-xl"
          >
            <p className="text-sm font-bold text-[hsl(var(--voltage-blue))]">
              💬 New message in #{e.data.channel || 'general'}
            </p>
            {e.data.username && (
              <p className="text-xs text-white/70 mt-1 line-clamp-2">
                <span className="font-bold">{e.data.username}</span>: {e.data.text || ''}
              </p>
            )}
          </button>
        ), { duration: 6000, position: 'top-right' });
        systemAlert(`💬 #${e.data.channel || 'general'}`, `${e.data.username || ''}: ${e.data.text || ''}`, '/chat');
      }
    });

    return () => { alive = false; unsubNotes(); unsubChat(); };
  }, [user?.id]);

  const markAllRead = async () => {
    try {
      await db.entities.Notification.updateMany({ user_id: user?.id, read: false }, { $set: { read: true } });
    } catch (e) {
      /* marking read is best-effort */
    }
    setUnreadNotes(0);
    setNotes((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const total = unreadNotes + unreadChat;

  return (
    <div className="fixed bottom-3 right-3 z-50">
      {open && (
        <div className="absolute bottom-14 right-0 w-80 max-w-[calc(100vw-1.5rem)] rounded-2xl bg-[#0b0b0b]/95 backdrop-blur-xl border border-white/10 shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
            <p className="font-bold text-sm">Notifications</p>
            <button onClick={markAllRead} className="text-xs text-white/50 hover:text-white">Mark all read</button>
          </div>
          {typeof Notification !== 'undefined' && Notification.permission === 'default' && (
            <button
              onClick={enableSystemAlerts}
              className="w-full text-left px-4 py-2.5 border-b border-white/10 flex items-center gap-2 text-xs text-white/70 hover:bg-white/5"
            >
              <BellRing className="w-3.5 h-3.5 text-[hsl(var(--voltage-yellow))] shrink-0" />
              Turn on phone-style alerts
            </button>
          )}
          <div className="max-h-80 overflow-y-auto">
            {unreadChat > 0 && (
              <button
                onClick={() => { markChatSeen(); setOpen(false); navigate('/chat'); }}
                className="w-full text-left px-4 py-3 hover:bg-white/5 border-b border-white/5 flex items-center gap-3"
              >
                <MessageSquare className="w-4 h-4 text-[hsl(var(--voltage-blue))] shrink-0" />
                <span className="text-sm">
                  <span className="font-bold">{unreadChat > 99 ? '99+' : unreadChat}</span> new message{unreadChat === 1 ? '' : 's'} in clan chat
                </span>
              </button>
            )}
            {notes.map((n) => (
              <div key={n.id} className="px-4 py-3 border-b border-white/5">
                <p className="text-sm font-semibold flex items-start gap-2">
                  <BellRing className="w-3.5 h-3.5 text-[hsl(var(--voltage-yellow))] shrink-0 mt-0.5" />
                  {n.title}
                </p>
                {n.body && <p className="text-xs text-white/60 mt-1">{n.body}</p>}
                <p className="text-[10px] text-white/30 mt-1">{n.created_date ? fromDb(n.created_date).toLocaleString() : ''}</p>
              </div>
            ))}
            {unreadChat === 0 && notes.length === 0 && (
              <p className="text-white/40 text-sm text-center py-8">You're all caught up 🎉</p>
            )}
          </div>
        </div>
      )}
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative w-12 h-12 rounded-full bg-[hsl(var(--voltage-yellow))] text-black flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
        title="Notifications"
      >
        <Bell className="w-5 h-5" />
        {total > 0 && (
          <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
            {total > 99 ? '99+' : total}
          </span>
        )}
      </button>
    </div>
  );
}