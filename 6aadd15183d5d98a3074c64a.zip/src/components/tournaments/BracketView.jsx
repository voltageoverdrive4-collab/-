import React from 'react';

export default function BracketView({ tournament, isAdmin, onSetWinner }) {
  const matches = tournament.matches || [];
  if (!matches.length) return <p className="text-white/40 text-sm">Bracket coming soon.</p>;

  const rounds = Math.max(...matches.map((m) => m.round));
  const cols = [];
  for (let r = 1; r <= rounds; r++) {
    cols.push(matches.filter((m) => m.round === r).sort((a, b) => a.pos - b.pos));
  }

  const side = (m, team, isA) => {
    const isWinner = !!team && m.winner === team;
    const canPick = isAdmin && !!team && !m.winner;
    return (
      <button
        type="button"
        key={isA ? 'a' : 'b'}
        disabled={!canPick}
        onClick={() => canPick && onSetWinner(m.round, m.pos, team)}
        className={`w-full text-left px-3 py-1.5 text-sm rounded transition-colors ${
          !team ? 'text-white/25 cursor-default'
          : isWinner ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] font-bold'
          : canPick ? 'text-white/80 hover:bg-white/10 cursor-pointer'
          : 'text-white/80 cursor-default'}`}
      >
        {team || '—'}
      </button>
    );
  };

  return (
    <div className="flex gap-4 overflow-x-auto pb-2">
      {cols.map((col, i) => (
        <div key={i} className="flex flex-col gap-4 min-w-[180px]">
          <p className="text-[10px] uppercase tracking-widest text-white/30 text-center">
            {i === cols.length - 1 ? 'Final' : i === cols.length - 2 ? 'Semifinals' : `Round ${i + 1}`}
          </p>
          {col.map((m) => (
            <div key={`${m.round}-${m.pos}`} className="rounded-lg border border-white/10 bg-white/5 divide-y divide-white/10">
              {side(m, m.a, true)}
              {side(m, m.b, false)}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}