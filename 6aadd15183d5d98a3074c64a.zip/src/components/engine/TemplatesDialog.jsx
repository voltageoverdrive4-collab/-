import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Zap } from 'lucide-react';
import { SCRIPT_TEMPLATES } from '@/lib/voltscript/templates';

const FORMAT_LABELS = { voltscript: 'VoltScript', gdscript: 'GDScript', csharp: 'C#-style', visual: 'Visual Blocks' };
const FORMAT_FILTERS = ['all', 'voltscript', 'gdscript', 'csharp', 'visual'];

export default function TemplatesDialog({ open, onClose, onPick, currentFormat }) {
  const [filter, setFilter] = useState(currentFormat || 'all');
  const list = SCRIPT_TEMPLATES.filter((t) => filter === 'all' || t.format === filter);

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto bg-[hsl(var(--voltage-black))] border-white/15 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-black">
            <Zap className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" fill="currentColor" /> Script Templates
          </DialogTitle>
          <DialogDescription className="text-white/50">
            Pick a starter project, then modify the code however you like.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-wrap gap-1.5 mb-4">
          {FORMAT_FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-full text-xs font-bold border transition ${
                filter === f
                  ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] border-[hsl(var(--voltage-yellow))]/50'
                  : 'text-white/50 border-white/15 hover:text-white hover:border-white/30'
              }`}
            >
              {f === 'all' ? 'All formats' : FORMAT_LABELS[f]}
            </button>
          ))}
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {list.map((t) => (
            <div key={t.id} className="rounded-xl border border-white/10 bg-black/40 p-3 flex flex-col hover:border-[hsl(var(--voltage-yellow))]/40 transition">
              <div className="flex items-center justify-between gap-2 mb-1">
                <h3 className="font-bold">{t.name}</h3>
                <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-[hsl(var(--voltage-blue))]/15 text-[hsl(var(--voltage-blue))] font-bold whitespace-nowrap">
                  {FORMAT_LABELS[t.format]}
                </span>
              </div>
              <p className="text-xs text-white/50 mb-2">{t.description}</p>
              <pre className="flex-1 text-[10px] leading-relaxed text-white/60 bg-black/50 rounded-lg p-2 mb-2 whitespace-pre overflow-hidden max-h-28">
                {t.format === 'visual' ? 'Visual blocks — opens in the block editor.' : t.code.split('\n').slice(0, 8).join('\n')}
              </pre>
              <Button size="sm" onClick={() => onPick(t)} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
                Use template
              </Button>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}