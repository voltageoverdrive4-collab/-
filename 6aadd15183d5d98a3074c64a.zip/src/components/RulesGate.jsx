const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { ScrollText, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getAppSettings } from '@/lib/appSettings';
import { DEFAULT_RULES } from '@/lib/clanRules';

// The clan rules gate — shows once when a member joins (or the first time
// they open the hub after this feature ships). Accepting stores it forever;
// the hub stays locked behind the rules until they do.
export default function RulesGate() {
  const { user } = useAuth();
  const [needed, setNeeded] = useState(false);
  const [rules, setRules] = useState(DEFAULT_RULES);
  const [accepting, setAccepting] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    let alive = true;
    (async () => {
      try {
        const acc = await db.entities.RulesAcceptance.filter({ user_id: user.id }, { limit: 1 });
        if (!alive) return;
        if (!acc.length) {
          setNeeded(true);
          getAppSettings(['clan_rules'])
            .then((s) => { if (alive && s.clan_rules) setRules(s.clan_rules); })
            .catch(() => {});
        }
      } catch {
        // server hiccup — don't lock members out of the hub
      }
    })();
    return () => { alive = false; };
  }, [user?.id]);

  if (!needed) return null;

  const accept = async () => {
    setAccepting(true);
    try {
      await db.entities.RulesAcceptance.create({ user_id: user.id });
      setNeeded(false);
      toast.success('Welcome to Voltage — the hub is yours');
    } catch {
      toast.error('Could not save — try again');
    } finally {
      setAccepting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl overflow-y-auto p-6 sm:p-10">
      <div className="max-w-2xl mx-auto volt-panel rounded-3xl p-6 sm:p-10 mt-6">
        <div className="flex items-center gap-3">
          <ScrollText className="w-8 h-8 text-[hsl(var(--voltage-yellow))]" />
          <div>
            <h2 className="font-heading text-2xl font-black text-white">Clan Rules</h2>
            <p className="text-xs text-white/50">Read and accept the rules to enter the hub</p>
          </div>
        </div>
        <div className="volt-scrollbar mt-5 whitespace-pre-line text-sm leading-relaxed text-white/80 overflow-y-auto max-h-[50vh] pr-3 border border-white/10 rounded-2xl p-4 bg-black/30">
          {rules}
        </div>
        <Button
          onClick={accept}
          disabled={accepting}
          className="mt-6 w-full h-12 bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black font-black rounded-2xl"
        >
          <ShieldCheck className="w-5 h-5 mr-2" /> {accepting ? 'Saving…' : 'I accept the rules'}
        </Button>
        <p className="mt-3 text-center text-[11px] text-white/40">You only have to do this once</p>
      </div>
    </div>
  );
}