const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'react-hot-toast';
import { Globe, Trash2, ExternalLink } from 'lucide-react';
import SiteFavicon from '@/components/SiteFavicon';

export default function WebsitesTab() {
  const [sites, setSites] = useState([]);
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);

  const load = () => {
    db.entities.EmbeddedSite.list('created_date', 100)
      .then(setSites)
      .catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const add = async () => {
    const cleanName = name.trim();
    let cleanUrl = url.trim();
    if (!cleanName || !cleanUrl) { toast.error('Give the tab a name and a URL'); return; }
    if (!/^https?:\/\//i.test(cleanUrl)) cleanUrl = `https://${cleanUrl}`;
    setBusy(true);
    try {
      await db.entities.EmbeddedSite.create({ name: cleanName, url: cleanUrl });
      setName('');
      setUrl('');
      toast.success(`"${cleanName}" tab added — everyone sees it now`);
      load();
    } catch (e) {
      toast.error('Could not save — try again in a moment');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (site) => {
    try {
      await db.entities.EmbeddedSite.delete(site.id);
      toast.success(`"${site.name}" tab removed`);
      load();
    } catch (e) {
      toast.error('Could not delete — try again in a moment');
    }
  };

  return (
    <div className="space-y-4">
      <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
        <p className="text-white/50 text-sm">
          Embed any website as its own tab — pick a name, paste the URL, and the tab shows up in every member's menu.
          Some big sites (like Google or Instagram) block embedding; members can still use the "open in new tab" button on those.
        </p>
        <div className="flex flex-wrap gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tab name (e.g. Fortnite Tracker)" className="flex-1 min-w-[180px] bg-black/40 border-white/15 text-white" />
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com" className="flex-1 min-w-[220px] bg-black/40 border-white/15 text-white" onKeyDown={(e) => { if (e.key === 'Enter') add(); }} />
          <Button onClick={add} disabled={busy} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Globe className="w-4 h-4 mr-1" /> Add tab</Button>
        </div>
      </div>
      {sites.map((s) => (
        <div key={s.id} className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <SiteFavicon url={s.url} className="w-4 h-4 shrink-0" />
            <span className="font-bold truncate">{s.name}</span>
            <span className="text-white/40 text-sm truncate">{s.url}</span>
          </div>
          <div className="flex gap-2">
            <a href={s.url} target="_blank" rel="noreferrer">
              <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10"><ExternalLink className="w-4 h-4 mr-1" /> Visit</Button>
            </a>
            <Button size="sm" variant="destructive" onClick={() => remove(s)}><Trash2 className="w-4 h-4" /></Button>
          </div>
        </div>
      ))}
      {sites.length === 0 && <p className="text-white/40 text-center py-8">No website tabs yet — add one above.</p>}
    </div>
  );
}