import React, { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { withRetry } from '@/lib/apiRetry';
import { getAppSettings, saveAppSettings } from '@/lib/appSettings';
import { THEMES, HOLIDAY_THEMES, applyTheme, skinForVersion, LAYOUTS, GUI_VERSIONS, ALL_THEMES } from '@/lib/guiThemes';

// mini wireframe of a layout preset, drawn from its config
const LayoutPreview = ({ cfg }) => {
  if (cfg.shell === 'top' || cfg.shell === 'deck')
    return (
      <div className="h-16 rounded-md border border-white/15 overflow-hidden flex flex-col">
        <div className="h-4 bg-[hsl(var(--voltage-yellow))]/40 border-b border-white/15" />
        <div className="flex-1 bg-white/10" />
      </div>
    );
  if (cfg.shell === 'dock')
    return (
      <div className="h-16 rounded-md border border-white/15 overflow-hidden flex flex-col">
        <div className="flex-1 bg-white/10" />
        <div className="h-4 bg-[hsl(var(--voltage-yellow))]/40 border-t border-white/15" />
      </div>
    );
  if (cfg.shell === 'hub')
    return (
      <div className="h-16 rounded-md border border-white/15 overflow-hidden flex flex-col">
        <div className="h-3 bg-[hsl(var(--voltage-yellow))]/40 border-b border-white/15" />
        <div className="flex-1 bg-white/10 grid grid-cols-4 gap-1 p-1">
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <div key={i} className="rounded-sm bg-[hsl(var(--voltage-blue))]/40" />)}
        </div>
      </div>
    );
  return (
    <div className={`h-16 rounded-md border border-white/15 overflow-hidden flex ${cfg.side === 'right' ? 'flex-row-reverse' : ''}`}>
      <div className={`${cfg.iconsOnly ? 'w-2' : 'w-6'} h-full bg-[hsl(var(--voltage-yellow))]/40 shrink-0`} />
      <div className="flex-1 bg-white/10" />
    </div>
  );
};

// Admin panel: pick the clan-wide GUI look — the layout (where everything
// is placed) and the colors. Both apply to every member instantly.
export default function GuiThemeTab() {
  const [current, setCurrent] = useState('classic');
  const [layout, setLayout] = useState('sidebar');
  const [version, setVersion] = useState('classic-v1');
  const [holidayPick, setHolidayPick] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    withRetry(() => getAppSettings(['gui_theme', 'gui_layout', 'gui_version']))
      .then((map) => {
        setCurrent(map.gui_theme || 'classic');
        setLayout(map.gui_layout || 'sidebar');
        setVersion(map.gui_version || 'classic-v1');
      })
      .catch(() => {});
  }, []);

  // saved straight to the clan's settings — no server call needed, so layouts
  // and themes keep saving even while workspace credits are being renewed.
  // Single-record saves (not bulk upserts) so every member's app picks the
  // change up live instead of after a refresh.
  const saveSetting = (key, value) => withRetry(() => saveAppSettings({ [key]: value }));

  const pick = async (id) => {
    setSaving(true);
    try {
      await saveSetting('gui_theme', id);
      applyTheme(id, skinForVersion(version));
      setHolidayPick('');
      setCurrent(id);
      toast.success('Colors set for everyone ⚡');
    } catch (e) {
      toast.error('Could not save the theme — try again in a moment');
    } finally {
      setSaving(false);
    }
  };

  const pickLayout = async (id) => {
    setSaving(true);
    try {
      await saveSetting('gui_layout', id);
      setLayout(id);
      toast.success('Layout set for everyone ⚡');
    } catch (e) {
      toast.error('Could not save the layout — try again in a moment');
    } finally {
      setSaving(false);
    }
  };

  // any design in any holiday's colors
  const pickHolidayVersion = async (v, h) => {
    setSaving(true);
    try {
      await withRetry(() => saveAppSettings({ gui_version: v.id, gui_theme: h.id, gui_layout: v.layout }));
      applyTheme(h.id, skinForVersion(v.id));
      setCurrent(h.id);
      setLayout(v.layout);
      setVersion(v.id);
      setHolidayPick(`${v.id}:${h.id}`);
      toast.success(`${v.name} in ${h.name} colors set for everyone ⚡`);
    } catch (e) {
      toast.error('Could not save — try again in a moment');
    } finally {
      setSaving(false);
    }
  };

  // a whole design package at once — colors and where everything sits
  const pickVersion = async (v) => {
    setSaving(true);
    try {
      await withRetry(() => saveAppSettings({ gui_version: v.id, gui_theme: v.theme, gui_layout: v.layout }));
      applyTheme(v.theme, skinForVersion(v.id));
      setCurrent(v.theme);
      setLayout(v.layout);
      setVersion(v.id);
      setHolidayPick('');
      toast.success(`${v.name} set for everyone ⚡`);
    } catch (e) {
      toast.error('Could not save — try again in a moment');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-5xl space-y-8">
      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">GUI Versions</h3>
          <p className="text-white/50 text-sm">Complete design packages — colors and layout together, applied clan-wide instantly. Includes every past look plus the new makeover designs.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {GUI_VERSIONS.map((v) => {
            const selected = version === v.id;
            const t = ALL_THEMES.find((x) => x.id === v.theme) || {};
            return (
              <button
                key={v.id}
                onClick={() => pickVersion(v)}
                disabled={saving}
                className={`p-4 rounded-xl border text-left transition-all ${
                  selected ? 'border-[hsl(var(--voltage-yellow))] bg-white/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex gap-1.5">
                    <span className="w-6 h-6 rounded-full" style={{ background: `hsl(${t.yellow || '0 0% 60%'})` }} />
                    <span className="w-6 h-6 rounded-full" style={{ background: `hsl(${t.blue || '0 0% 60%'})` }} />
                    <span className="w-6 h-6 rounded-full border border-white/20" style={{ background: `hsl(${t.bg || '0 0% 5%'})` }} />
                  </div>
                  {selected && <Check className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" />}
                </div>
                <p className="font-bold">{v.name}</p>
                <p className="text-xs text-white/50 mt-0.5">{v.tagline}</p>
                <p className="text-[10px] uppercase tracking-widest text-white/30 mt-2">Colors: {t.name || v.theme} • Layout: {(LAYOUTS.find((l) => l.id === v.layout) || {}).name || v.layout}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">Holiday Versions</h3>
          <p className="text-white/50 text-sm">Any design wearing any holiday palette — the layout of the version you pick with the seasonal colors, applied clan-wide instantly.</p>
        </div>
        <div className="space-y-3">
          {GUI_VERSIONS.map((v) => (
            <div key={v.id} className="rounded-xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <p className="font-bold text-sm">{v.name}</p>
                <span className="text-[10px] uppercase tracking-widest text-white/30">{(LAYOUTS.find((l) => l.id === v.layout) || {}).name || v.layout}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {HOLIDAY_THEMES.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => pickHolidayVersion(v, h)}
                    disabled={saving}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                      holidayPick === `${v.id}:${h.id}`
                        ? 'border-[hsl(var(--voltage-yellow))] bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]'
                        : 'border-white/15 text-white/60 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span className="mr-1">{h.icon}</span>{h.name}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">Layout</h3>
          <p className="text-white/50 text-sm">Where everything is placed — {LAYOUTS.length} arrangements to choose from, applied clan-wide instantly.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {LAYOUTS.map((l) => {
            const selected = layout === l.id;
            return (
              <button
                key={l.id}
                onClick={() => pickLayout(l.id)}
                disabled={saving}
                className={`p-4 rounded-xl border text-left transition-all ${
                  selected ? 'border-[hsl(var(--voltage-yellow))] bg-white/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-3">
                  <LayoutPreview cfg={l} />
                  {selected && <Check className="w-4 h-4 text-[hsl(var(--voltage-yellow))] shrink-0" />}
                </div>
                <p className="font-bold text-sm">{l.name}</p>
                <p className="text-xs text-white/50 mt-0.5">{l.tagline}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">Colors</h3>
          <p className="text-white/50 text-sm">The clan's accent colors and background tint — applies to every member instantly.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {THEMES.map((t) => {
            const selected = current === t.id;
            return (
              <button
                key={t.id}
                onClick={() => pick(t.id)}
                disabled={saving}
                className={`p-4 rounded-xl border text-left transition-all ${
                  selected ? 'border-[hsl(var(--voltage-yellow))] bg-white/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex gap-1.5">
                    <span className="w-6 h-6 rounded-full" style={{ background: `hsl(${t.yellow})` }} />
                    <span className="w-6 h-6 rounded-full" style={{ background: `hsl(${t.blue})` }} />
                    <span className="w-6 h-6 rounded-full border border-white/20" style={{ background: `hsl(${t.bg})` }} />
                  </div>
                  {selected && <Check className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" />}
                </div>
                <p className="font-bold">{t.name}</p>
                <p className="text-xs text-white/50 mt-0.5">{t.tagline}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">Holiday Colors</h3>
          <p className="text-white/50 text-sm">The seasonal palettes from each holiday zone — wear them any time of year.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {HOLIDAY_THEMES.map((t) => {
            const selected = current === t.id;
            return (
              <button
                key={t.id}
                onClick={() => pick(t.id)}
                disabled={saving}
                className={`p-4 rounded-xl border text-left transition-all ${
                  selected ? 'border-[hsl(var(--voltage-yellow))] bg-white/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex gap-1.5 items-center">
                    <span className="text-xl leading-none">{t.icon}</span>
                    <span className="w-6 h-6 rounded-full" style={{ background: `hsl(${t.yellow})` }} />
                    <span className="w-6 h-6 rounded-full" style={{ background: `hsl(${t.blue})` }} />
                    <span className="w-6 h-6 rounded-full border border-white/20" style={{ background: `hsl(${t.bg})` }} />
                  </div>
                  {selected && <Check className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" />}
                </div>
                <p className="font-bold">{t.name}</p>
                <p className="text-xs text-white/50 mt-0.5">{t.tagline}</p>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}