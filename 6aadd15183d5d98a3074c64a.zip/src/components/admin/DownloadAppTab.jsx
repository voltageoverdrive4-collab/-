import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Download, Smartphone, QrCode, Copy, Check, MonitorDown } from 'lucide-react';
import { toast } from 'react-hot-toast';

// Admin → Download App: get the hub onto any device. The hub installs straight
// from whatever browser a device allows — no Chrome and no app store needed:
// a one-tap install when the browser offers it, a launcher file that opens
// the hub in the device's default browser, a QR code for phones, and the
// add-to-home-screen steps for every device.
export default function DownloadAppTab() {
  const [installEvent, setInstallEvent] = useState(null);
  const [copied, setCopied] = useState(false);
  const appUrl = window.location.origin;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(appUrl)}`;

  useEffect(() => {
    const handler = (e) => { e.preventDefault(); window.__voltInstallPrompt = e; setInstallEvent(e); };
    window.addEventListener('beforeinstallprompt', handler);
    // the browser may have offered the install while the hub was still loading
    if (window.__voltInstallPrompt) setInstallEvent(window.__voltInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const installNow = async () => {
    if (!installEvent) return;
    try {
      installEvent.prompt();
      const { outcome } = await installEvent.userChoice;
      toast.success(outcome === 'accepted' ? 'Voltage Hub installed!' : 'No problem — the steps below work too');
    } catch { toast.error('The browser refused the install — use the steps below'); }
    setInstallEvent(null);
  };

  // A tiny launcher file: download it once, open it any time and it jumps
  // straight into the hub in the device's default browser — works even on
  // devices where Chrome is blocked.
  const downloadLauncher = () => {
    const html = [
      '<!DOCTYPE html>',
      '<html><head><meta charset="utf-8"><title>Voltage Hub</title>',
      `<meta http-equiv="refresh" content="0;url=${appUrl}">`,
      `<script>window.location.replace(${JSON.stringify(appUrl)});<\/script>`,
      '</head>',
      '<body style="margin:0;background:#0d0312;color:#fff;font-family:system-ui;text-align:center;padding-top:40vh">',
      '<p style="font-size:20px">Opening the <b>Voltage Hub</b>…</p>',
      `<p><a href="${appUrl}" style="color:#ffd166">Tap here if nothing happens</a></p>`,
      '</body></html>',
    ].join('\n');
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Voltage Hub.html';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast.success('Launcher downloaded — open it to jump straight into the hub');
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopied(true);
      toast.success('Hub link copied');
      setTimeout(() => setCopied(false), 2000);
    } catch { toast.error('Could not copy — select the link and copy it manually'); }
  };

  const steps = [
    { title: 'Android phones & tablets', text: 'Open the hub link in any browser app — Samsung Internet, Firefox, Edge, anything. Tap the ⋮ menu and choose "Add to Home screen" or "Install app".' },
    { title: 'iPhone & iPad', text: 'Open the hub link in Safari, tap the Share button, then "Add to Home Screen".' },
    { title: 'Computers', text: 'Use the Install button above if this browser offers it, or download the launcher — it opens the hub in your default browser.' },
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-5 p-6 sm:p-8 rounded-3xl volt-panel">
        <div>
          <h3 className="font-bold text-lg flex items-center gap-2"><Smartphone className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" />Install the hub on this device</h3>
          <p className="text-white/50 text-sm mt-1">The hub installs straight from whatever browser you&apos;re using — no Chrome and no app store needed.</p>
        </div>
        {installEvent ? (
          <Button onClick={installNow} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
            <Download className="w-4 h-4 mr-2" />Install the Voltage Hub
          </Button>
        ) : (
          <p className="text-sm text-white/40 rounded-xl border border-dashed border-white/15 p-3">This browser didn&apos;t offer a one-tap install — the steps below work in every browser.</p>
        )}
        <Button onClick={downloadLauncher} variant="outline" className="border-white/20 text-white hover:bg-white/10">
          <MonitorDown className="w-4 h-4 mr-2" />Download launcher — opens the hub without Chrome
        </Button>
        <div className="space-y-3">
          {steps.map((s, i) => (
            <div key={s.title} className="p-4 rounded-xl bg-white/5 border border-white/10">
              <div className="font-bold text-sm mb-1"><span className="text-[hsl(var(--voltage-yellow))] mr-2">{i + 1}.</span>{s.title}</div>
              <p className="text-white/60 text-sm">{s.text}</p>
            </div>
          ))}
          <div className="p-4 rounded-xl bg-[hsl(var(--voltage-blue))]/10 border border-[hsl(var(--voltage-blue))]/40">
            <div className="font-bold text-sm mb-1">Phone blocks every website?</div>
            <p className="text-white/60 text-sm">
              The hub is a website app — if a phone refuses to open any website at all, no link, QR code or launcher can get through, and nothing inside the hub can change that device rule. The way onto those phones is the real app store version: the clan owner generates the Google Play / App Store files from the editor (Publish → Mobile app), and once the store listing is live, members install the hub straight from the app store — no browser needed.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-5 p-6 sm:p-8 rounded-3xl volt-panel h-fit">
        <div>
          <h3 className="font-bold text-lg flex items-center gap-2"><QrCode className="w-5 h-5 text-[hsl(var(--voltage-blue))]" />Get it on a phone</h3>
          <p className="text-white/50 text-sm mt-1">Scan with the phone&apos;s camera — the hub opens in whatever browser the phone has.</p>
        </div>
        <img src={qrUrl} alt="Scan to open the Voltage Hub" className="w-52 h-52 rounded-2xl bg-white p-2 mx-auto" />
        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <Label className="text-white/60 text-xs uppercase tracking-widest">Hub link</Label>
          <div className="flex items-center gap-2 mt-1">
            <code className="flex-1 min-w-0 truncate text-sm text-[hsl(var(--voltage-yellow))]">{appUrl}</code>
            <Button size="sm" variant="outline" onClick={copyLink} className="border-white/20 text-white hover:bg-white/10 shrink-0">
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </div>
        <p className="text-white/40 text-xs">After opening the link, follow the same add-to-home-screen steps and the hub sits on the home screen like a real app.</p>
      </div>
    </div>
  );
}