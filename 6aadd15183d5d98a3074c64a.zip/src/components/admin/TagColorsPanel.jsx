const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useMemo, useState } from 'react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { toast } from 'react-hot-toast';
import { Palette, Save } from 'lucide-react';
import { withRetry } from '@/lib/apiRetry';

// admin panel: set the color each member tag shows as in clan chat
export default function TagColorsPanel({ members }) {
  const [tags, setTags] = useState([]);
  const [drafts, setDrafts] = useState({});
  const [saving, setSaving] = useState(null);
  const [teamTags, setTeamTags] = useState([]);

  const load = async () => setTags(await withRetry(() => db.entities.ChatTag.list()));
  useEffect(() => {
    load().catch(() => toast.error('Could not load tag colors — try again shortly'));
    db.entities.Team.list().then((teams) => setTeamTags([...new Set(teams.flatMap((t) => t.tags || []))])).catch(() => {});
  }, []);

  const allTags = useMemo(() => {
    const set = new Set();
    members.forEach((m) => (m.tags || []).forEach((t) => set.add(t)));
    teamTags.forEach((t) => set.add(t));
    return [...set].sort();
  }, [members, teamTags]);

  const colorOf = (name) => drafts[name] ?? tags.find((t) => t.name === name)?.color ?? '#ffe00f';

  const save = async (name) => {
    setSaving(name);
    try {
      const color = colorOf(name);
      const existing = tags.find((t) => t.name === name);
      if (existing) await withRetry(() => db.entities.ChatTag.update(existing.id, { color }));
      else await withRetry(() => db.entities.ChatTag.create({ name, color }));
      await load();
      toast.success(`"${name}" tag color saved`);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(null);
    }
  };

  return (
    <div className="p-4 rounded-xl bg-white/5 border border-white/10">
      <h3 className="font-bold flex items-center gap-2 mb-3"><Palette className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" /> Chat Tag Colors</h3>
      {allTags.length === 0 ? (
        <p className="text-white/40 text-sm">No tags yet — add tags to members above, then set their chat colors here.</p>
      ) : (
        <div className="flex flex-wrap gap-3">
          {allTags.map((name) => (
            <div key={name} className="flex items-center gap-2 p-2 rounded-lg bg-black/40 border border-white/10">
              <Badge className="text-[10px] px-1.5" style={{ backgroundColor: `${colorOf(name)}26`, color: colorOf(name), borderColor: `${colorOf(name)}66` }}>{name}</Badge>
              <input
                type="color"
                value={colorOf(name)}
                onChange={(e) => setDrafts((d) => ({ ...d, [name]: e.target.value }))}
                className="w-8 h-8 rounded cursor-pointer bg-transparent border border-white/15"
                aria-label={`Color for ${name} tag`}
              />
              <Button size="sm" variant="outline" disabled={saving === name} onClick={() => save(name)} className="h-8 border-white/20 text-white hover:bg-white/10">
                <Save className="w-3.5 h-3.5 mr-1" /> Save
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}