const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useCallback, useEffect, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Check, X, Rocket, History } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { APP_VERSION, VERSION_LOG } from '@/lib/appVersion';

// Update requests: new releases wait here as pending — accept one and its
// version goes live: members see the What's New popup and the update ping.
export default function UpdatesTab() {
  const [reqs, setReqs] = useState(null);
  const [form, setForm] = useState({ title: '', version: '', body: '' });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const page = await db.entities.UpdateRequest.filter({}, { sort: '-created_date', limit: 50 });
      setReqs(page.items);
    } catch { setReqs([]); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const decide = async (r, status) => {
    try {
      await db.entities.UpdateRequest.update(r.id, { status });
      toast.success(status === 'live' ? `${r.version} is live — members will see What's New` : 'Update denied');
      load();
    } catch { toast.error('Could not save — try again'); }
  };

  const create = async () => {
    if (!form.title.trim() || !form.version.trim()) { toast.error('Title and version are required'); return; }
    setSaving(true);
    try {
      await db.entities.UpdateRequest.create({
        title: form.title.trim(),
        version: form.version.trim(),
        body: form.body,
        status: 'pending',
      });
      setForm({ title: '', version: '', body: '' });
      toast.success('Update request queued');
      load();
    } catch { toast.error('Could not queue the request'); }
    finally { setSaving(false); }
  };

  // A new version that shipped without a release request — one click sends
  // it here as a pending request for approval instead of going straight out.
  const queueCurrent = async () => {
    const notes = (VERSION_LOG.find((v) => v.version === APP_VERSION)?.notes || []).join('\n');
    setSaving(true);
    try {
      await db.entities.UpdateRequest.create({
        title: `${APP_VERSION} — clan update`,
        version: APP_VERSION,
        body: notes,
        status: 'pending',
      });
      toast.success(`Release request for ${APP_VERSION} sent — approve it below`);
      load();
    } catch { toast.error('Could not send the request'); }
    finally { setSaving(false); }
  };

  if (reqs === null) return <p className="text-white/40">Loading updates…</p>;
  const pending = reqs.filter((r) => r.status === 'pending');
  const decided = reqs.filter((r) => r.status !== 'pending');
  const unrequested = !reqs.some((r) => r.version === APP_VERSION);

  return (
    <div className="max-w-3xl space-y-8">
      <section>
        <h3 className="font-heading text-xl font-black mb-3 flex items-center gap-2">
          <Rocket className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" /> Waiting for release ({pending.length})
        </h3>
        {unrequested && (
          <div className="p-5 rounded-xl mb-4 bg-[hsl(var(--voltage-blue))]/10 border border-[hsl(var(--voltage-blue))]/40">
            <div className="font-bold">Version {APP_VERSION} shipped without a release request</div>
            <p className="text-white/60 text-sm mt-1 mb-3">Send it for approval — members only see What&apos;s New after you release it here.</p>
            <Button size="sm" disabled={saving} onClick={queueCurrent} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Send release request for {APP_VERSION}</Button>
          </div>
        )}
        {pending.length === 0 && <p className="text-white/40 text-sm">No updates waiting — new releases land here for your approval.</p>}
        {pending.map((r) => (
          <div key={r.id} className="p-5 rounded-xl bg-[hsl(var(--voltage-yellow))]/5 border border-[hsl(var(--voltage-yellow))]/25 mb-3">
            <div className="flex flex-wrap justify-between gap-3 items-start">
              <div className="min-w-0">
                <div className="font-bold">{r.title} <Badge className="ml-2 bg-[hsl(var(--voltage-blue))]/20 text-[hsl(var(--voltage-blue))]">{r.version}</Badge></div>
                {r.body && <p className="text-white/70 text-sm mt-2 max-w-xl whitespace-pre-line">{r.body}</p>}
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={() => decide(r, 'live')} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Check className="w-4 h-4 mr-1" /> Release</Button>
                <Button size="sm" variant="destructive" onClick={() => decide(r, 'denied')}><X className="w-4 h-4 mr-1" /> Deny</Button>
              </div>
            </div>
          </div>
        ))}
      </section>

      <section>
        <h3 className="font-heading text-xl font-black mb-3">Queue your own update</h3>
        <div className="p-5 rounded-xl bg-white/5 border border-white/10 space-y-3">
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1"><Label className="text-white/80">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-black/40 border-white/15 text-white" /></div>
            <div className="space-y-1"><Label className="text-white/80">Version</Label><Input value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} placeholder="v3.33" className="bg-black/40 border-white/15 text-white" /></div>
          </div>
          <div className="space-y-1"><Label className="text-white/80">What's in it</Label><Textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} rows={3} className="bg-black/40 border-white/15 text-white" /></div>
          <Button onClick={create} disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">Queue update</Button>
        </div>
      </section>

      <section>
        <h3 className="font-heading text-xl font-black mb-3 flex items-center gap-2"><History className="w-5 h-5 text-white/50" /> Release history</h3>
        {decided.length === 0 && <p className="text-white/40 text-sm">Nothing released yet.</p>}
        {decided.map((r) => (
          <div key={r.id} className="p-4 rounded-xl bg-white/5 border border-white/10 mb-2 flex items-center justify-between gap-3">
            <span className="font-bold truncate">{r.title} <span className="text-white/40 font-normal">· {r.version}</span></span>
            <Badge className={r.status === 'live' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>{r.status === 'live' ? 'LIVE' : 'DENIED'}</Badge>
          </div>
        ))}
      </section>
    </div>
  );
}