const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'react-hot-toast';
import { UserPlus } from 'lucide-react';

// Lets the admin create a real account for a member. The platform emails the
// member a link to set their own password — handled by the auth system, not
// integration credits.
export default function CreateAccountPanel() {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('user');
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await db.users.inviteUser(email.trim(), role);
      toast.success(`Account created — ${email.trim()} got an email to set their password`);
      setEmail('');
    } catch (err) {
      toast.error(err?.message || 'Could not create the account');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
      <div className="flex items-center gap-2 font-bold">
        <UserPlus className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" /> Create an account for a member
      </div>
      <p className="text-sm text-white/50">
        The member gets an email with a link to set their own password, then can log in right away.
      </p>
      <div className="flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-[220px] space-y-1">
          <Label className="text-white/80 text-xs">Their email</Label>
          <Input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="gamer@example.com"
            className="bg-black/40 border-white/15 text-white"
          />
        </div>
        <div className="space-y-1">
          <Label className="text-white/80 text-xs">Role</Label>
          <div className="flex rounded-lg border border-white/10 overflow-hidden text-sm">
            <button
              type="button"
              className={`px-3 py-1.5 ${role === 'user' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]' : 'text-white/50 hover:text-white/80'}`}
              onClick={() => setRole('user')}
            >Member</button>
            <button
              type="button"
              className={`px-3 py-1.5 ${role === 'admin' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]' : 'text-white/50 hover:text-white/80'}`}
              onClick={() => setRole('admin')}
            >Admin</button>
          </div>
        </div>
        <Button type="submit" disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <UserPlus className="w-4 h-4 mr-1" /> {saving ? 'Creating…' : 'Create account'}
        </Button>
      </div>
    </form>
  );
}