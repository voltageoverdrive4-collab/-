import React from 'react';
import { Download, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ROOMS } from '@/lib/holidayRooms';
import { BACKDROP } from '@/components/theme/HubSurface';

// Opens the picture in a new tab where the browser's Save handles the
// download — the files live on public CDN storage, so no server call is needed.
const saveAs = (url, name) => {
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.target = '_blank';
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
};

const fileName = (url) => url.split('/').pop();

const holidayRooms = Object.values(ROOMS).filter((r) => r.pictureUrl);

export default function AssetsTab() {
  return (
    <div className="space-y-8">
      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">Hub Backdrop</h3>
          <p className="text-white/50 text-sm">The space image behind every hub tab and Clan Chat.</p>
        </div>
        <div className="flex flex-wrap items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10">
          <img src={BACKDROP} alt="Hub backdrop" className="w-44 h-24 object-cover rounded-lg border border-white/10" />
          <div className="flex-1 min-w-[160px]">
            <div className="font-semibold text-sm">Deep Space Backdrop</div>
            <div className="text-white/40 text-xs mt-0.5 break-all">{fileName(BACKDROP)}</div>
          </div>
          <Button size="sm" onClick={() => saveAs(BACKDROP, fileName(BACKDROP))} className="bg-[hsl(var(--voltage-yellow))] text-black">
            <Download className="w-4 h-4 mr-1" /> Download
          </Button>
        </div>
        <p className="text-white/40 text-xs">The VOLTAGE logo is a live lightning icon + text mark, not a picture file — there's nothing to download for it.</p>
      </section>

      <section className="space-y-4">
        <div>
          <h3 className="font-bold text-lg">Holiday Pictures</h3>
          <p className="text-white/50 text-sm">The exclusive reward pictures members can win in each holiday room.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {holidayRooms.map((r) => (
            <div key={r.pictureUrl} className="p-4 rounded-xl bg-white/5 border border-white/10">
              <img src={r.pictureUrl} alt={r.name} className="w-full h-32 object-cover rounded-lg border border-white/10 mb-3" />
              <div className="font-semibold text-sm mb-2">{r.emoji} {r.name}</div>
              <Button size="sm" variant="outline" onClick={() => saveAs(r.pictureUrl, fileName(r.pictureUrl))} className="border-white/20 text-white hover:bg-white/10">
                <ImageIcon className="w-4 h-4 mr-1" /> Download
              </Button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}