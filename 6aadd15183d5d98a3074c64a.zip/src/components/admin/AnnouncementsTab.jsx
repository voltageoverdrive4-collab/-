const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CalendarClock, Clock, Megaphone, Trash2 } from 'lucide-react';
import { toast } from 'react-hot-toast';

// Admin panel: broadcast an announcement — every member gets an in-app
// notification. Send it now or schedule it for later.
export default function AnnouncementsTab() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [when, setWhen] = useState('');
  const [busy, setBusy] = useState(false);
  const [past, setPast] = useState([]);

  const load = async () => {
    try {
      const rows = await db.entities.Announcement.list('-created_date', 20);
      setPast(rows);
    } catch (e) {
      /* the history list is nice-to-have */
    }
  };
  useEffect(() => { load(); }, []);

  const sendNow = async () => {
    if (!title.trim()) { toast.error('Give the announcement a title'); return; }
    setBusy(true);
    try {
      const res = await db.functions.invoke('sendAnnouncement', { title: title.trim(), body: body.trim() });
      const d = res?.data ?? res;
      toast.success(`Notified ${d?.notified || 0} member${d?.notified === 1 ? '' : 's'}`);
      setTitle('');
      setBody('');
      load();
    } catch (e) {
      toast.error(e?.response?.data?.error || e?.message || 'Could not send the announcement');
    } finally {
      setBusy(false);
    }
  };

  const schedule = async () => {
    if (!title.trim() || !when) { toast.error('Pick a title and a time first'); return; }
    const iso = new Date(when).toISOString();
    if (new Date(iso) <= new Date()) { toast.error('Pick a time in the future'); return; }
    setBusy(true);
    try {
      await db.entities.Announcement.create({ title: title.trim(), body: body.trim(), status: 'pending', send_at: iso });
      toast.success('Scheduled — it goes out automatically at that time');
      setTitle('');
      setBody('');
      setWhen('');
      load();
    } catch (e) {
      toast.error(e?.response?.data?.error || e?.message || 'Could not schedule the announcement');
    } finally {
      setBusy(false);
    }
  };

  const cancel = async (id) => {
    try {
      await db.entities.Announcement.delete(id);
      toast.success('Scheduled announcement cancelled');
      load();
    } catch (e) {
      toast.error('Could not cancel it');
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-4 p-6 rounded-xl bg-white/5 border border-white/10 h-fit">
        <h3 className="font-bold flex items-center gap-2">
          <Megaphone className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" /> New Announcement
        </h3>
        <div className="space-y-2">
          <Label className="text-white/80">Title</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Tournament tonight at 8!" className="bg-black/40 border-white/15 text-white" />
        </div>
        <div className="space-y-2">
          <Label className="text-white/80">Message</Label>
          <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={4} placeholder="Tell the clan what's up…" className="bg-black/40 border-white/15 text-white" />
        </div>
        <div className="space-y-2">
          <Label className="text-white/80">Or schedule it for later</Label>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              type="datetime-local"
              value={when}
              onChange={(e) => setWhen(e.target.value)}
              className="bg-black/40 border-white/15 text-white flex-1"
            />
            <Button onClick={schedule} disabled={busy} variant="outline" className="border-white/20 text-white hover:bg-white/10 shrink-0">
              <CalendarClock className="w-4 h-4 mr-2" /> Schedule
            </Button>
          </div>
          <p className="text-xs text-white/40">Scheduled announcements send themselves automatically — no one has to be here.</p>
        </div>
        <Button onClick={sendNow} disabled={busy} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <Megaphone className="w-4 h-4 mr-2" /> {busy ? 'Working…' : 'Notify the clan now'}
        </Button>
      </div>

      <div className="space-y-3">
        <h3 className="font-bold">Recent announcements</h3>
        {past.map((a) => (
          <div key={a.id} className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex items-start justify-between gap-2">
              <div className="font-bold">
                {a.title}
                {a.status === 'pending' && (
                  <span className="ml-2 text-[10px] uppercase tracking-wide bg-[hsl(var(--voltage-blue))]/20 text-[hsl(var(--voltage-blue))] px-2 py-0.5 rounded-full align-middle">
                    scheduled
                  </span>
                )}
              </div>
              {a.status === 'pending' && (
                <button onClick={() => cancel(a.id)} className="text-white/40 hover:text-red-400 shrink-0" title="Cancel this scheduled announcement">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
            {a.body && <p className="text-white/60 text-sm mt-1">{a.body}</p>}
            <div className="text-white/40 text-xs mt-1 flex items-center gap-1">
              {a.status === 'pending'
                ? <><Clock className="w-3 h-3" /> Goes out {a.send_at ? new Date(a.send_at).toLocaleString() : ''}</>
                : <>{a.created_by_name} {a.created_date ? `• ${new Date(a.created_date).toLocaleString()}` : ''}</>}
            </div>
          </div>
        ))}
        {past.length === 0 && <p className="text-white/40">Nothing sent yet.</p>}
      </div>
    </div>
  );
}