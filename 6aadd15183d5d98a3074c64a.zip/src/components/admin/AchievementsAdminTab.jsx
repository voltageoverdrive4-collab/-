const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, Award } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { ACHIEVEMENTS } from '@/lib/achievements';
import { withRetry, delay } from '@/lib/apiRetry';

// Admin panel: create custom achievements and grant any achievement to members.
export default function AchievementsAdminTab({ members }) {
  const [custom, setCustom] = useState([]);
  const [grants, setGrants] = useState([]);
  const [form, setForm] = useState({ name: '', desc: '', emoji: '🏅' });
  const [memberId, setMemberId] = useState('');
  const [achKey, setAchKey] = useState('');
  const [grantingAll, setGrantingAll] = useState(false);

  const load = async () => {
    try {
      const c = await withRetry(() => db.entities.CustomAchievement.list('-created_date', 100));
      await delay(250);
      const g = await withRetry(() => db.entities.AchievementGrant.list('-created_date', 30));
      setCustom(c);
      setGrants(g);
    } catch (e) {
      // panel loads best-effort
    }
  };
  useEffect(() => { load(); }, []);

  const createCustom = async () => {
    if (!form.name.trim()) { toast.error('Give the achievement a name'); return; }
    try {
      await db.entities.CustomAchievement.create({ name: form.name.trim(), desc: form.desc.trim(), emoji: form.emoji || '🏅' });
      toast.success('Achievement created');
      setForm({ name: '', desc: '', emoji: '🏅' });
      load();
    } catch (e) {
      toast.error('Could not create the achievement');
    }
  };

  const delCustom = async (c) => {
    try { await db.entities.CustomAchievement.delete(c.id); load(); } catch (e) {
      toast.error('Could not delete');
    }
  };

  const grant = async () => {
    const m = members.find((x) => x.id === memberId);
    if (!m || !achKey) { toast.error('Pick a member and an achievement'); return; }
    try {
      await db.entities.AchievementGrant.create({ key: achKey, username: m.username, user_id: m.user_id || '' });
      toast.success(`Granted to ${m.username} 🏆`);
      load();
    } catch (e) {
      toast.error('Could not grant the achievement');
    }
  };

  // Gives the picked member every badge they don't have yet, in one go
  const grantAll = async () => {
    const m = members.find((x) => x.id === memberId);
    if (!m) { toast.error('Pick a member first'); return; }
    setGrantingAll(true);
    try {
      const mine = await withRetry(() => db.entities.AchievementGrant.filter({ user_id: m.user_id || '' }));
      const have = new Set(mine.map((g) => g.key));
      const missing = options.filter((o) => !have.has(o.key))
        .map((o) => ({ key: o.key, username: m.username, user_id: m.user_id || '' }));
      if (missing.length === 0) { toast.success(`${m.username} already has every badge`); return; }
      await db.entities.AchievementGrant.bulkCreate(missing);
      toast.success(`Granted ${missing.length} badges to ${m.username} 🏆`);
      load();
    } catch (e) {
      toast.error('Could not grant all badges — try again');
    } finally {
      setGrantingAll(false);
    }
  };

  const options = [
    ...Object.entries(ACHIEVEMENTS).map(([key, a]) => ({ key, label: `${a.name} (built-in)` })),
    ...custom.map((c) => ({ key: c.id, label: `${c.emoji} ${c.name} (custom)` }))
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-6">
        <div className="space-y-4 p-6 rounded-xl bg-white/5 border border-white/10">
          <h3 className="font-bold">Grant an Achievement</h3>
          <div className="space-y-2">
            <Label className="text-white/80">Member</Label>
            <select value={memberId} onChange={(e) => setMemberId(e.target.value)} className="w-full bg-black/40 border border-white/15 rounded-md px-3 py-2 text-white">
              <option value="">Select a member…</option>
              {members.map((m) => <option key={m.id} value={m.id}>{m.username}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <Label className="text-white/80">Achievement</Label>
            <select value={achKey} onChange={(e) => setAchKey(e.target.value)} className="w-full bg-black/40 border border-white/15 rounded-md px-3 py-2 text-white">
              <option value="">Select an achievement…</option>
              {options.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
            </select>
          </div>
          <div className="flex gap-3">
            <Button onClick={grant} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Award className="w-4 h-4 mr-2" /> Grant</Button>
            <Button variant="outline" disabled={grantingAll} onClick={grantAll} className="border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))] font-bold hover:bg-[hsl(var(--voltage-yellow))]/10">
              {grantingAll ? 'Granting…' : 'Grant ALL badges'}
            </Button>
          </div>
        </div>

        <div className="space-y-4 p-6 rounded-xl bg-white/5 border border-white/10">
          <h3 className="font-bold">New Custom Achievement</h3>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-2">
              <Label className="text-white/80">Emoji</Label>
              <Input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} maxLength={4} className="bg-black/40 border-white/15 text-white" />
            </div>
            <div className="col-span-2 space-y-2">
              <Label className="text-white/80">Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Clutch King" className="bg-black/40 border-white/15 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-white/80">Description</Label>
            <Input value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} placeholder="How it's earned" className="bg-black/40 border-white/15 text-white" />
          </div>
          <Button onClick={createCustom} className="bg-[hsl(var(--voltage-blue))] text-black font-bold">Create Achievement</Button>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="font-bold">Custom Achievements ({custom.length})</h3>
        {custom.map((c) => (
          <div key={c.id} className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{c.emoji}</span>
              <div>
                <p className="font-bold">{c.name}</p>
                <p className="text-white/50 text-sm">{c.desc}</p>
              </div>
            </div>
            <Button size="sm" variant="destructive" onClick={() => delCustom(c)}><Trash2 className="w-4 h-4" /></Button>
          </div>
        ))}
        {custom.length === 0 && <p className="text-white/40">No custom achievements yet.</p>}

        <h3 className="font-bold pt-4">Recent Grants</h3>
        {grants.map((g) => (
          <div key={g.id} className="p-3 rounded-xl bg-white/5 border border-white/10 text-sm">
            <span className="font-semibold">{g.username}</span>
            <span className="text-white/50"> — {g.key}</span>
          </div>
        ))}
        {grants.length === 0 && <p className="text-white/40">No grants yet.</p>}
      </div>
    </div>
  );
}