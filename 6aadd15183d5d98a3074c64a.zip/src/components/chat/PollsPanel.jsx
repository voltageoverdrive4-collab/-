const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { Plus, Trash2 } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { withRetry } from '@/lib/apiRetry';
import { grantAchievement } from '@/lib/achievements';

// Clan polls: any member can start one, everyone gets one vote, results
// update live as glowing progress meters in the right HUD.
export default function PollsPanel({ user, myName, isAdmin }) {
  const [polls, setPolls] = useState([]);
  const [votes, setVotes] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const [p, v] = await Promise.all([
        withRetry(() => db.entities.ChatPoll.list('-created_date', 50)),
        withRetry(() => db.entities.ChatPollVote.list()),
      ]);
      setPolls(p);
      setVotes(v);
    } catch (e) {
      /* polls are an extra — never break chat over them */
    }
  };

  useEffect(() => {
    load();
    const u1 = db.entities.ChatPoll.subscribe(() => load());
    const u2 = db.entities.ChatPollVote.subscribe(() => load());
    return () => { u1(); u2(); };
  }, []);

  const createPoll = async () => {
    const opts = options.map((o) => o.trim()).filter(Boolean);
    if (!question.trim() || opts.length < 2) {
      toast.error('Add a question and at least 2 options');
      return;
    }
    setCreating(true);
    try {
      await withRetry(() => db.entities.ChatPoll.create({
        question: question.trim(),
        options: opts,
        created_by_name: myName,
      }));
      grantAchievement(user, 'poll-starter');
      toast.success('Poll posted!');
      setQuestion('');
      setOptions(['', '']);
      setShowCreate(false);
      load();
    } catch (e) {
      toast.error(e.message || 'Could not create the poll');
    } finally {
      setCreating(false);
    }
  };

  const vote = async (poll, choice) => {
    if (votes.some((v) => v.poll_id === poll.id && v.user_id === user?.id)) return;
    setBusy(true);
    try {
      await withRetry(() => db.entities.ChatPollVote.create({
        poll_id: poll.id,
        choice,
        username: myName,
        user_id: user?.id,
      }));
      grantAchievement(user, 'poll-voter');
      load();
    } catch (e) {
      toast.error(e.message || 'Could not record your vote');
    } finally {
      setBusy(false);
    }
  };

  const removePoll = async (poll) => {
    if (!window.confirm('Delete this poll and its votes?')) return;
    try {
      for (const v of votes.filter((x) => x.poll_id === poll.id)) {
        await db.entities.ChatPollVote.delete(v.id);
      }
      await db.entities.ChatPoll.delete(poll.id);
      load();
    } catch (e) {
      toast.error(e.message || 'Could not delete the poll');
    }
  };

  const myVote = (pollId) => votes.find((v) => v.poll_id === pollId && v.user_id === user?.id)?.choice;

  return (
    <>
      <div className="ph">Clan Polls</div>
      <p className="pd">Vote on scrims, events, and more — one vote per member.</p>
      <button className="btn v" style={{ marginTop: 0 }} onClick={() => setShowCreate(!showCreate)}>
        <Plus />New poll
      </button>

      {showCreate && (
        <div className="pform" style={{ marginTop: 16 }}>
          <input className="inp" placeholder="Ask the clan something…" value={question} onChange={(e) => setQuestion(e.target.value)} />
          {options.map((o, i) => (
            <input
              key={i}
              className="inp"
              value={o}
              onChange={(e) => setOptions(options.map((x, j) => (j === i ? e.target.value : x)))}
              placeholder={`Option ${i + 1}`}
            />
          ))}
          {options.length < 4 && (
            <button className="pill-l" style={{ width: 'fit-content' }} onClick={() => setOptions([...options, ''])}>+ Add option</button>
          )}
          <button className="btn" style={{ marginTop: 2 }} onClick={createPoll} disabled={creating}>
            {creating ? 'Posting…' : 'Post Poll'}
          </button>
        </div>
      )}

      <div className="sep" />

      {polls.map((p) => {
        const mine = myVote(p.id);
        const total = votes.filter((v) => v.poll_id === p.id).length;
        return (
          <div key={p.id} style={{ marginTop: 6 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 9 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#dcdef7' }}>{p.question}</span>
              {isAdmin && (
                <button className="mini x" onClick={() => removePoll(p)} title="Delete poll"><Trash2 /></button>
              )}
            </div>
            <p className="pd" style={{ margin: '-6px 0 9px' }}>by {p.created_by_name} • {total} vote{total === 1 ? '' : 's'}</p>
            {(p.options || []).map((opt, i) => {
              const count = votes.filter((v) => v.poll_id === p.id && v.choice === i).length;
              const pct = total ? Math.round((count / total) * 100) : 0;
              const isMine = mine === i;
              return (
                <button
                  key={i}
                  type="button"
                  className="pbar"
                  disabled={mine !== undefined || busy}
                  onClick={() => vote(p, i)}
                >
                  <i style={{ width: `${mine !== undefined ? pct : 0}%` }} />
                  <span>{opt}{isMine ? ' ✓' : ''}{mine !== undefined ? ` — ${pct}%` : ''}</span>
                </button>
              );
            })}
          </div>
        );
      })}
      {polls.length === 0 && <div className="empty">No polls yet — start the first one!</div>}
    </>
  );
}