const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { SmilePlus } from 'lucide-react';
import { grantAchievement } from '@/lib/achievements';

const QUICK = ['👍', '🔥', '😂', '😮', '❤️', '⚡', '😢', '🎉'];
const MORE = ['😀', '😎', '🥳', '😱', '🤯', '🤔', '💯', '👑', '🎯', '💀', '🤖', '🐸', '💙', '😈', '🍕', '🎮', '🤩', '😍', '🥺', '😭', '🤣', '🤝', '🫡', '🙌', '🤙', '👊', '🥹', '😤', '🤠', '🦖', '🍀', '🫶', '🌈', '🍀'];
const ALL = [...QUICK, ...MORE];

// Emoji reactions for a single chat message — glowing chips with counts,
// and hovering a chip shows exactly who reacted.
export default function MessageReactions({ messageId, user, reactions, myName }) {
  const [open, setOpen] = useState(false);
  const forMsg = reactions.filter((r) => r.chat_message_id === messageId);
  const mine = new Set(forMsg.filter((r) => r.user_id === user?.id).map((r) => r.emoji));
  const counts = {};
  const names = {};
  for (const r of forMsg) {
    counts[r.emoji] = (counts[r.emoji] || 0) + 1;
    names[r.emoji] = [...(names[r.emoji] || []), r.username || 'member'];
  }

  const toggle = async (emoji, closeAfter = false) => {
    if (closeAfter) setOpen(false);
    const existing = forMsg.find((r) => r.user_id === user?.id && r.emoji === emoji);
    try {
      if (existing) await db.entities.ChatReaction.delete(existing.id);
      else {
        await db.entities.ChatReaction.create({ chat_message_id: messageId, user_id: user.id, username: myName, emoji });
        grantAchievement(user, 'hype-squad');
      }
    } catch (e) { /* realtime subscription resyncs the counts */ }
  };

  return (
    <>
      {Object.keys(counts).map((emoji) => (
        <div key={emoji} className="relative group/chip">
          <button
            type="button"
            onClick={() => toggle(emoji)}
            title={names[emoji].join(', ')}
            className={`chip ${mine.has(emoji) ? 'on' : ''}`}
          >
            <span>{emoji}</span> {counts[emoji]}
          </button>
          <span className="pointer-events-none absolute bottom-full left-0 mb-1 hidden group-hover/chip:block whitespace-nowrap rounded-lg px-2 py-1 text-[10px] text-white/80 z-10 bg-[rgba(17,17,43,.95)] border border-[rgba(13,245,227,.35)] shadow-lg">
            {names[emoji].join(', ')}
          </span>
        </div>
      ))}
      <button
        type="button"
        className={`chip ${open ? 'on' : ''}`}
        onClick={() => setOpen((v) => !v)}
      >
        <SmilePlus /> React
      </button>
      {open && (
        <div className="picker">
          <p>Pick a reaction</p>
          <div className="pg">
            {ALL.map((emoji) => (
              <button key={emoji} type="button" onClick={() => toggle(emoji, true)}>{emoji}</button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}