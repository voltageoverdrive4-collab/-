import React, { useState } from 'react';
import { Smile, ImagePlus, Send, X, Upload } from 'lucide-react';

const CHAT_EMOJIS = ['😀', '😂', '😎', '😱', '🥳', '😍', '🤔', '😭', '😤', '🤯', '😈', '💀', '👑', '🔥', '⚡', '💯', '🎉', '🎯', '❤️', '💙', '👍', '🙏', '🤖', '🐸', '🍕', '🎮', '🏆'];

// The message composer — reply banner, picture attachments (link or
// Cloudinary file upload), emoji picker and the glowing send button.
export default function ChatComposer({
  text, setText, onSend, sending, activeChannel,
  replyTo, clearReply, replyName,
  imageFile, setImageFile, imageLink, setImageLink, cloudConfigured,
}) {
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [picOpen, setPicOpen] = useState(false);

  return (
    <form className="cmp" onSubmit={onSend}>
      {replyTo && (
        <div className="rpl">
          <span>Replying to <b>{replyName}</b></span>
          <button type="button" className="mini x" onClick={clearReply} aria-label="clear reply"><X /></button>
        </div>
      )}
      {(imageFile || imageLink.trim()) && (
        <div className="row" style={{ marginBottom: 10 }}>
          <span className="chip on">
            <ImagePlus /> {imageFile ? imageFile.name : imageLink.trim()}
            <button
              type="button"
              className="mini"
              style={{ padding: 0 }}
              onClick={() => (imageFile ? setImageFile(null) : setImageLink(''))}
              aria-label="clear attachment"
            ><X /></button>
          </span>
        </div>
      )}
      {picOpen && (
        <div className="atts">
          <div className="row">
            <input
              className="inp"
              placeholder="Paste a picture link (https://…)"
              value={imageLink}
              onChange={(e) => setImageLink(e.target.value)}
            />
            <button type="button" className="btn" onClick={() => setPicOpen(false)}>Use link</button>
          </div>
          <div className="row" style={{ marginBottom: 0 }}>
            <label className="pill-l">
              <Upload />
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => { setImageFile(e.target.files?.[0] || null); setPicOpen(false); }}
              />
              Upload a file
            </label>
            <span className="note" style={{ margin: 0 }}>
              {cloudConfigured
                ? 'Files upload to ImgBB. Pictures are public — anyone with the link can open them.'
                : 'Not connected yet — paste a picture link, or an admin can connect ImgBB in Chat Admin Controls.'}
            </span>
          </div>
        </div>
      )}
      {emojiOpen && (
        <div className="picker">
          <p>Emoji</p>
          <div className="pg">
            {CHAT_EMOJIS.map((e) => (
              <button key={e} type="button" onClick={() => setText(text + e)}>{e}</button>
            ))}
          </div>
        </div>
      )}
      <div className="row">
        <input
          className="inp"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={`Message #${activeChannel}…`}
        />
        <button type="button" className="sq" onClick={() => setEmojiOpen((v) => !v)} title="Emoji"><Smile /></button>
        <button type="button" className="sq" onClick={() => setPicOpen((v) => !v)} title="Send a picture"><ImagePlus /></button>
        <button type="submit" className="send" disabled={sending} aria-label="send"><Send /></button>
      </div>
    </form>
  );
}