const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { Plus, Power, Trash2, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { withRetry } from '@/lib/apiRetry';

// Admin panel of the Forms tab — build forms, review submissions and
// accept or reject them. A form with a team name drops accepted members
// straight into that team (e.g. Shop Publisher enroll).
export default function FormsAdmin({ onReload }) {
  const { user } = useAuth();
  const [forms, setForms] = useState([]);
  const [responses, setResponses] = useState([]);
  const [members, setMembers] = useState({});
  const [teams, setTeams] = useState([]);
  const [acting, setActing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState('');
  const [grantsTeam, setGrantsTeam] = useState('');

  const loadAdmin = async () => {
    try {
      const [formPage, respPage] = await Promise.all([
        withRetry(() => db.entities.Form.filter({}, { sort: '-created_date', limit: 100 })),
        withRetry(() => db.entities.FormResponse.filter({ status: 'pending' }, { sort: '-created_date', limit: 100 })),
      ]);
      setForms(formPage.items);
      setResponses(respPage.items);
    } catch { /* retried on the next visit */ }
  };

  useEffect(() => {
    loadAdmin();
    db.entities.Member.list().then((list) => {
      const map = {};
      for (const m of list) {
        if (m.user_id) map[m.user_id] = m;
        if (m.username) map[m.username.toLowerCase()] = m;
      }
      setMembers(map);
    }).catch(() => {});
    withRetry(() => db.entities.Team.filter({}, { limit: 200 }))
      .then((p) => setTeams(p.items))
      .catch(() => {});
    const unsub = db.entities.FormResponse.subscribe(() => loadAdmin());
    return unsub;
  }, []);

  const create = async (e) => {
    e.preventDefault();
    if (!title.trim()) { toast.error('Give the form a name'); return; }
    setSaving(true);
    try {
      await withRetry(() => db.entities.Form.create({
        title: title.trim(),
        description: description.trim(),
        questions: questions.split('\n').map((q) => q.trim()).filter(Boolean),
        grants_team: grantsTeam.trim(),
        active: true,
      }));
      setTitle(''); setDescription(''); setQuestions(''); setGrantsTeam('');
      toast.success('Form is live for members');
      loadAdmin();
      onReload();
    } catch {
      toast.error('Could not save the form — try again in a moment');
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (f) => {
    try {
      await withRetry(() => db.entities.Form.update(f.id, { active: !f.active }));
      toast.success(f.active ? `"${f.title}" closed — members no longer see it` : `"${f.title}" is open again`);
      loadAdmin();
      onReload();
    } catch {
      toast.error('Could not update the form — try again');
    }
  };

  const del = async (f) => {
    try {
      await withRetry(() => db.entities.Form.delete(f.id));
      toast.success('Form deleted');
      loadAdmin();
      onReload();
    } catch {
      toast.error('Could not delete the form — try again');
    }
  };

  // accepting is where team enrollment happens
  const accept = async (r) => {
    setActing(r.id);
    try {
      await withRetry(() => db.entities.FormResponse.update(r.id, { status: 'accepted' }));
      const f = forms.find((x) => x.id === r.form_id);
      if (f?.grants_team) {
        const m = members[r.user_id] || members[(r.username || '').toLowerCase()];
        if (m) {
          let team = teams.find((t) => t.name.toLowerCase() === f.grants_team.trim().toLowerCase());
          if (!team) {
            team = await withRetry(() => db.entities.Team.create({
              name: f.grants_team.trim(),
              owner_user_id: user.id,
              owner_name: 'Admin',
              member_ids: [],
              admin_ids: [],
            }));
            setTeams((prev) => [...prev, team]);
          }
          if (!(team.member_ids || []).includes(m.id)) {
            await withRetry(() => db.entities.Team.update(team.id, {
              member_ids: [...(team.member_ids || []), m.id],
            }));
          }
          toast.success(`Accepted — ${r.username || 'member'} joined ${f.grants_team}`);
        } else {
          toast.success('Accepted');
        }
      } else {
        toast.success(`Accepted — ${r.username || 'member'} will see it`);
      }
      loadAdmin();
    } catch {
      toast.error('Could not accept — try again');
    } finally {
      setActing(null);
    }
  };

  const reject = async (r) => {
    setActing(r.id);
    try {
      await withRetry(() => db.entities.FormResponse.update(r.id, { status: 'rejected' }));
      toast.success('Rejected — they can resubmit the form');
      loadAdmin();
    } catch {
      toast.error('Could not reject — try again');
    } finally {
      setActing(null);
    }
  };

  return (
    <div className="volt-panel rounded-3xl mt-6 p-4 sm:p-6">
      <div className="text-xs font-bold tracking-[0.2em] uppercase text-[hsl(var(--voltage-yellow))] mb-4">Form builder — admins</div>

      {responses.length > 0 && (
        <div className="mb-6 rounded-2xl border border-[hsl(var(--voltage-blue))]/40 bg-[hsl(var(--voltage-blue))]/5 p-4">
          <div className="text-xs font-bold tracking-[0.2em] uppercase text-[hsl(var(--voltage-blue))] mb-3">
            Waiting for your review ({responses.length})
          </div>
          <div className="space-y-3">
            {responses.map((r) => {
              const f = forms.find((x) => x.id === r.form_id);
              return (
                <div key={r.id} className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="min-w-0 flex-1 basis-40">
                      <div className="truncate text-sm text-white/85">{r.username || 'member'} — {r.form_title || f?.title || 'form'}</div>
                      {f?.grants_team && <div className="text-[11px] text-[hsl(var(--voltage-blue))]">Accepting adds them to {f.grants_team}</div>}
                    </div>
                    <Button size="sm" onClick={() => accept(r)} disabled={acting === r.id} className="bg-emerald-400 text-black font-bold hover:bg-emerald-300">
                      <Check className="w-3.5 h-3.5 mr-1.5" /> Accept
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => reject(r)} disabled={acting === r.id} className="border-red-400/30 text-red-300 hover:bg-red-400/10">
                      <X className="w-3.5 h-3.5 mr-1.5" /> Reject
                    </Button>
                  </div>
                  <div className="mt-2 space-y-1">
                    {(f?.questions || []).map((q, qi) => (
                      <div key={qi} className="text-[11px] text-white/60">
                        <span className="text-white/40">{q}: </span>{(r.answers || [])[qi] || '—'}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <form onSubmit={create} className="grid gap-3">
        <input className="rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30" placeholder="Form name, e.g. Admin Enroll" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input className="rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30" placeholder="What it's for (optional)" value={description} onChange={(e) => setDescription(e.target.value)} />
        <textarea
          className="rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30 resize-y"
          rows={3}
          placeholder={'One question per line, e.g.\nWhy do you want to be admin?\nHow old are you?'}
          value={questions}
          onChange={(e) => setQuestions(e.target.value)}
        />
        <input className="rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30" placeholder="Team enrolled on accept (optional), e.g. Shop Publisher" value={grantsTeam} onChange={(e) => setGrantsTeam(e.target.value)} />
        <Button type="submit" disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <Plus className="w-4 h-4 mr-2" /> {saving ? 'Saving…' : 'Create form'}
        </Button>
      </form>

      {forms.length > 0 && (
        <div className="mt-5 space-y-2">
          {forms.map((f) => (
            <div key={f.id} className={`flex items-center gap-3 rounded-2xl border px-4 py-3 ${f.active ? 'border-[hsl(var(--voltage-yellow))]/30 bg-[hsl(var(--voltage-yellow))]/5' : 'border-white/10 bg-white/[0.04] opacity-60'}`}>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold text-white/90">{f.title}</div>
                <div className="text-[11px] text-white/40">
                  {(f.questions || []).length} question{(f.questions || []).length === 1 ? '' : 's'}{f.grants_team ? ` · enrolls into ${f.grants_team}` : ''}{!f.active && ' · closed'}
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => toggle(f)} className="border-white/20 text-white/80">
                <Power className="w-3.5 h-3.5 mr-1.5" /> {f.active ? 'Close' : 'Open'}
              </Button>
              <Button variant="outline" size="sm" onClick={() => del(f)} className="border-red-400/30 text-red-300 hover:bg-red-400/10">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}