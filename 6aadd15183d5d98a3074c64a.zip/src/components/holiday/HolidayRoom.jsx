const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/lib/AuthContext';

import { toast } from 'react-hot-toast';
import HolidayQuest from '@/components/holiday/HolidayQuest';
import { grantAchievement } from '@/lib/achievements';
import { ROOMS } from '@/lib/holidayRooms';

const todayStr = () => new Date().toISOString().slice(0, 10);

// Themed seasonal room: one present per day (tag / achievement / exclusive
// picture / message) until the holiday day, plus an optional yearly quest.
export default function HolidayRoom({ holidayKey }) {
  const room = ROOMS[holidayKey];
  const { user } = useAuth();
  const [mine, setMine] = useState(null);
  const [reveal, setReveal] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    if (!user?.id) return;
    db.entities.HolidayPresent.filter({ user_id: user.id, holiday_key: holidayKey })
      .then(setMine)
      .catch(() => setMine([]));
  };

  useEffect(() => {
    load();
    return db.entities.HolidayPresent.subscribe(() => load());
  }, [user?.id, holidayKey]);

  if (!room) return null;

  const now = new Date();
  const holidayDate = new Date(now.getFullYear(), room.holidayMonth, room.holidayDay);
  const daysLeft = Math.ceil((holidayDate - now) / 86400000);
  // one present per day by default — the birthday party hands out several
  const presentLimit = room.presentsPerDay || 1;
  const openedCount = (mine || []).filter((r) => r.opened_day === todayStr()).length;
  const presentsLeft = Math.max(0, presentLimit - openedCount);
  const openedToday = openedCount >= presentLimit;

  const openPresent = async () => {
    if (busy || openedToday) return;
    setBusy(true);
    const roll = Math.random();
    let reward;
    if (roll < 0.45) reward = { reward_type: 'tag', reward_value: room.tags[Math.floor(Math.random() * room.tags.length)] };
    else if (roll < 0.7) reward = { reward_type: 'achievement', reward_value: room.rewardAchievement };
    else if (roll < 0.9 && room.pictureUrl) reward = { reward_type: 'picture', reward_value: room.pictureUrl };
    else reward = { reward_type: 'message', reward_value: room.messages[Math.floor(Math.random() * room.messages.length)] };
    try {
      await db.entities.HolidayPresent.create({
        user_id: user.id,
        holiday_key: holidayKey,
        opened_day: todayStr(),
        reward_type: reward.reward_type,
        reward_value: reward.reward_value
      });
      if (reward.reward_type === 'tag') {
        const recs = await db.entities.Member.filter({ email: user.email });
        const m = recs[0];
        if (m && !(m.tags || []).includes(reward.reward_value)) {
          await db.entities.Member.update(m.id, { tags: [...(m.tags || []), reward.reward_value] });
        }
      }
      if (reward.reward_type === 'achievement') grantAchievement(user, reward.reward_value);
      setReveal(reward);
      load();
    } catch (e) {
      toast.error('Could not open the present — try again in a moment');
    } finally {
      setBusy(false);
    }
  };

  const rewardLabel = (r) =>
    r.reward_type === 'tag' ? `${r.reward_value} (new clan tag!)`
    : r.reward_type === 'achievement' ? 'an exclusive achievement! 🏆'
    : r.reward_type === 'picture' ? 'an exclusive holiday picture! 🖼️'
    : r.reward_value;

  return (
    <div className="hub-holiday-room min-h-screen p-4 sm:p-8" style={{ '--room-background': room.bg, '--room-accent': room.accent }}>
      <div className="max-w-3xl mx-auto">
        <h1 className="font-heading text-4xl font-black mb-2">
          {room.emoji} {room.name}
        </h1>
        <p className="text-white/60 text-sm mb-8">{room.subtitle}</p>

        {/* Cozy fireplace (Christmas only) */}
        {room.fireplace && (
          <div className="mx-auto mb-8 w-full max-w-sm">
            <div className="relative rounded-2xl border-4 border-[#3d2417] bg-[#23150d] p-4 pt-6 overflow-hidden">
              <div className="absolute top-0 inset-x-0 h-4 bg-[#4a2c1a] rounded-t-xl" />
              <div className="relative h-40 rounded-xl bg-black overflow-hidden flex items-end justify-center">
                <div className="absolute bottom-2 w-3/4 h-5 rounded-full bg-[#3a2313]" />
                <div className="absolute bottom-4 w-10 h-16 rounded-full flame" style={{ background: 'radial-gradient(ellipse at bottom, #ffd166 0%, #ff7b00 45%, rgba(255,60,0,0.15) 100%)', filter: 'blur(2px)' }} />
                <div className="absolute bottom-4 w-16 h-20 rounded-full flame" style={{ background: 'radial-gradient(ellipse at bottom, rgba(255,200,80,0.9) 0%, rgba(255,90,0,0.5) 60%, transparent 100%)', filter: 'blur(4px)', animationDelay: '0.3s' }} />
                <div className="absolute bottom-3 w-24 h-24 rounded-full flame" style={{ background: 'radial-gradient(circle at bottom, rgba(255,150,50,0.35), transparent 70%)', filter: 'blur(6px)', animationDelay: '0.6s' }} />
              </div>
              <div className="flex justify-center gap-6 mt-3 text-2xl">🧦🧦🧦</div>
            </div>
          </div>
        )}

        {/* Daily presents */}
        <div className="p-5 rounded-2xl bg-black/40 border border-white/10 mb-6">
          <h2 className="font-bold text-lg mb-1">Daily presents {room.presentEmoji}</h2>
          <p className="text-white/50 text-sm mb-4">
            {daysLeft > 0
              ? `${daysLeft} day${daysLeft === 1 ? '' : 's'} until ${room.holidayName} — open one present each day until then!`
              : `Happy ${room.holidayName}!`}
          </p>
          <button
            onClick={openPresent}
            disabled={busy || openedToday}
            className={`px-6 py-3 rounded-xl font-bold text-black transition ${openedToday ? 'bg-white/10 text-white/40' : 'hover:brightness-110'}`}
            style={openedToday ? {} : { backgroundColor: room.accent }}
          >
            {openedToday
              ? presentLimit > 1 ? `That's all ${presentLimit} presents for today ✅` : 'Come back tomorrow for another present ✅'
              : busy ? 'Unwrapping…' : presentLimit > 1 ? `Open a present — ${presentsLeft} left today ${room.presentEmoji}` : `Open today's present ${room.presentEmoji}`}
          </button>
          {reveal && reveal.reward_type === 'picture' && (
            <img src={reveal.reward_value} alt="holiday reward" className="mt-4 rounded-xl border border-white/10 w-full max-w-sm object-cover" />
          )}
          {reveal && <p className="mt-3 text-sm font-semibold" style={{ color: room.accent }}>You got: {rewardLabel(reveal)}</p>}
          {mine?.length > 0 && <p className="mt-2 text-xs text-white/40">Presents opened so far: {mine.length}</p>}
        </div>

        {/* Yearly quest (Halloween + Christmas) */}
        {room.quest && (
          <div className="p-5 rounded-2xl bg-black/40 border border-white/10">
            <HolidayQuest holidayKey={holidayKey} accent={room.accent} />
          </div>
        )}
      </div>
    </div>
  );
}