import React from 'react';
import { Zap } from 'lucide-react';

// The Voltage bolt in party mode — the logo mark shown on the clan birthday:
// the gold bolt wearing a party hat with confetti, drawn in code so it needs
// no image credits and keeps the GUI exactly as the clan picked it.
export default function BirthdayLogo() {
  return (
    <div className="relative w-10 h-10 shrink-0" title="Voltage Birthday">
      {/* confetti flecks */}
      <span className="absolute left-2 top-1 w-1.5 h-1.5 rounded-full bg-[hsl(var(--voltage-blue))] animate-pulse" />
      <span className="absolute right-1 top-4 w-1 h-1 rounded-full bg-[hsl(var(--voltage-yellow))] animate-pulse" style={{ animationDelay: '.6s' }} />
      <span className="absolute right-3 top-0 w-1 h-1 rotate-45 bg-white/80 animate-pulse" style={{ animationDelay: '1.2s' }} />
      {/* party hat */}
      <div className="absolute top-1 right-1.5 w-4 h-4" style={{ transform: 'rotate(12deg)' }}>
        <span className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[hsl(var(--voltage-yellow))]" />
        <span
          className="absolute top-0.5 left-0 w-0 h-0"
          style={{ borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderBottom: '15px solid hsl(var(--voltage-blue))' }}
        />
      </div>
      {/* bolt + glow */}
      <div className="absolute left-0 bottom-0">
        <div className="absolute inset-0 blur-md text-[hsl(var(--voltage-yellow))] opacity-60">
          <Zap className="w-8 h-8" fill="currentColor" />
        </div>
        <Zap className="relative w-8 h-8 text-[hsl(var(--voltage-yellow))]" fill="currentColor" />
      </div>
    </div>
  );
}