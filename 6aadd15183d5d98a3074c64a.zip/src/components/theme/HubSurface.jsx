const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';

export const BACKDROP = 'https://media.db.com/images/public/6aadd15183d5d98a3074c64a/efc6c8fd2_generated_771a3314.jpg';
export const RETRO_BACKDROP = 'https://media.db.com/images/public/6aadd15183d5d98a3074c64a/12c387d0a_generated_a80d3196.jpg';

export default function HubSurface({ children }) {
  return (
    <div className="hub-surface">
      <div className="hub-backdrop" aria-hidden="true">
        <img src={BACKDROP} alt="" className="hub-backdrop-img" />
        <img src={RETRO_BACKDROP} alt="" className="hub-backdrop-retro" />
        <div className="hub-scrim" />
      </div>
      <div className="hub-content">{children}</div>
    </div>
  );
}