import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { NODE_TYPES } from '@/lib/engine/registry';
import { NODE_DOCS } from '@/lib/engine/nodeDocs';

const KIND_LABEL = { num: 'number', str: 'string', bool: 'bool', vec2: 'Vector2', color: 'Color', array: 'array' };

function defaultText(def) {
  if (def && typeof def === 'object') {
    if (def.__vec2) return `(${def.x}, ${def.y})`;
    if (def.__color) return `(${def.r}, ${def.g}, ${def.b}, ${def.a})`;
    if (Array.isArray(def)) return `[${def.length} items]`;
  }
  return def === undefined ? '—' : String(def);
}

export default function NodeLibraryPanel() {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState('CharacterBody2D');

  const types = useMemo(() => {
    const q = query.toLowerCase();
    return Object.keys(NODE_TYPES).filter((t) => !q || t.toLowerCase().includes(q));
  }, [query]);

  const docs = NODE_DOCS[selected] || null;
  const Cls = NODE_TYPES[selected] || NODE_TYPES.Node;

  return (
    <div className="h-full flex gap-3 min-h-0">
      {/* node list */}
      <div className="w-48 shrink-0 flex flex-col gap-2 min-h-0">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/40" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search nodes…"
            className="h-8 pl-8 text-sm bg-black/40 border-white/15 text-white"
          />
        </div>
        <div className="flex-1 overflow-y-auto space-y-1 pr-1">
          {types.map((t) => (
            <button
              key={t}
              onClick={() => setSelected(t)}
              className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm text-left transition-colors ${
                t === selected
                  ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] font-semibold'
                  : 'text-white/60 hover:bg-white/5 hover:text-white'}`}
            >
              <span>{NODE_TYPES[t].icon}</span> {t}
            </button>
          ))}
          {types.length === 0 && <p className="text-white/30 text-xs p-2">No nodes match "{query}".</p>}
        </div>
      </div>

      {/* detail */}
      <div className="flex-1 min-w-0 overflow-y-auto pr-2 space-y-5">
        <div className="flex items-center gap-3">
          <span className="text-4xl">{Cls.icon}</span>
          <div>
            <h2 className="font-heading text-2xl font-black">{selected}</h2>
            <p className="text-xs text-white/40">
              {docs?.inherits ? `inherits ${docs.inherits}` : 'base class'}
            </p>
          </div>
        </div>

        {docs && <p className="text-white/70 text-sm leading-relaxed max-w-3xl">{docs.description}</p>}

        <section>
          <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2">Properties</h3>
          <div className="rounded-lg border border-white/10 overflow-hidden max-w-3xl">
            <table className="w-full text-sm">
              <tbody>
                {Cls.PROPS.map((p, i) => (
                  <tr key={p.name} className={i % 2 ? 'bg-white/[0.02]' : ''}>
                    <td className="px-3 py-1.5 font-mono text-[hsl(var(--voltage-blue))] whitespace-nowrap">{p.name}</td>
                    <td className="px-3 py-1.5 text-white/40 text-xs whitespace-nowrap">{KIND_LABEL[p.kind] || p.kind}</td>
                    <td className="px-3 py-1.5 text-white/60 font-mono text-xs">{defaultText(p.default)}</td>
                  </tr>
                ))}
                {Cls.PROPS.length === 0 && (
                  <tr><td className="px-3 py-2 text-white/30 text-xs">No properties — this node inherits everything.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {docs?.methods?.length > 0 && (
          <section>
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2">Methods</h3>
            <div className="space-y-1.5 max-w-3xl">
              {docs.methods.map((m) => (
                <div key={m.sig} className="px-3 py-2 rounded-lg bg-white/[0.03] border border-white/5">
                  <code className="text-sm text-[hsl(var(--voltage-blue))]">{m.sig}</code>
                  <p className="text-white/50 text-xs mt-0.5">{m.desc}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {(docs?.signals?.length || 0) > 0 && (
          <section>
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2">Signals</h3>
            <div className="flex flex-wrap gap-2">
              {docs.signals.map((s) => (
                <code key={s} className="text-xs px-2.5 py-1 rounded-full bg-[hsl(var(--voltage-yellow))]/10 border border-[hsl(var(--voltage-yellow))]/30 text-[hsl(var(--voltage-yellow))]">{s}</code>
              ))}
            </div>
          </section>
        )}

        {docs?.snippet && (
          <section>
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2">Example script</h3>
            <pre className="rounded-lg bg-black/60 border border-white/10 p-4 text-xs font-mono text-white/80 overflow-x-auto whitespace-pre leading-relaxed">
              {docs.snippet}
            </pre>
          </section>
        )}
      </div>
    </div>
  );
}