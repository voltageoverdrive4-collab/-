import React, { useEffect, useRef } from 'react';
import { Terminal, AlertTriangle } from 'lucide-react';

export default function ConsolePanel({ logs, errors, activeTab, onTabChange, onClear }) {
  const items = activeTab === 'errors' ? errors : logs;
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [items.length]);
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-4 px-3 py-1.5 border-b border-white/10 text-xs">
        <button
          className={`flex items-center gap-1.5 uppercase tracking-widest ${
            activeTab === 'console' ? 'text-[hsl(var(--voltage-yellow))]' : 'text-white/40 hover:text-white/70'
          }`}
          onClick={() => onTabChange('console')}
        >
          <Terminal className="w-3.5 h-3.5" /> Console
        </button>
        <button
          className={`flex items-center gap-1.5 uppercase tracking-widest ${
            activeTab === 'errors' ? 'text-red-400' : 'text-white/40 hover:text-white/70'
          }`}
          onClick={() => onTabChange('errors')}
        >
          <AlertTriangle className="w-3.5 h-3.5" /> Errors {errors.length > 0 && <span className="bg-red-500/80 text-white rounded-full px-1.5 text-[10px]">{errors.length}</span>}
        </button>
        <button className="ml-auto text-white/30 hover:text-white/60" onClick={onClear}>Clear</button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto font-mono text-xs px-3 py-2 space-y-0.5">
        {items.length === 0 && (
          <div className="text-white/25">$ {activeTab === 'errors' ? 'no errors — looking good' : 'console output appears here when the scene runs'}</div>
        )}
        {items.map((l, i) => (
          <div key={i} className={l.kind === 'error' ? 'text-red-400' : l.kind === 'system' ? 'text-white/35' : 'text-[hsl(var(--voltage-blue))]'}>
            {l.kind === 'error' && l.node ? `[${l.node}] ` : ''}
            {l.text}
          </div>
        ))}
      </div>
    </div>
  );
}