// Project persistence for Voltage Studio — each project owns its own scene + scripts, saved in localStorage.
import { makeNode } from '@/components/studio/sceneData';

const PROJECTS_KEY = 'voltage_studio_projects_v1';
const LAST_KEY = 'voltage_studio_last_project_v1';
const LEGACY_SCENE_KEY = 'voltage_studio_scene_v1';

export function listProjects() {
  try {
    const raw = JSON.parse(localStorage.getItem(PROJECTS_KEY) || '[]');
    if (Array.isArray(raw)) return raw;
  } catch (e) { /* corrupted */ }
  return [];
}

export function getProject(id) {
  return listProjects().find((p) => p.id === id) || null;
}

export function saveProject(project) {
  const all = listProjects();
  const i = all.findIndex((p) => p.id === project.id);
  if (i >= 0) all[i] = project;
  else all.push(project);
  try { localStorage.setItem(PROJECTS_KEY, JSON.stringify(all)); } catch (e) { /* storage full */ }
}

export function deleteProject(id) {
  try {
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(listProjects().filter((p) => p.id !== id)));
  } catch (e) { /* storage error */ }
  if (localStorage.getItem(LAST_KEY) === id) localStorage.removeItem(LAST_KEY);
}

export function createProject(name) {
  const project = {
    id: `p${Date.now().toString(36)}${Math.floor(Math.random() * 10000)}`,
    name: name || 'Untitled Project',
    created: new Date().toISOString(),
    updated: new Date().toISOString(),
    scene: null, // empty until first save
  };
  saveProject(project);
  return project;
}

export function getLastProjectId() {
  return localStorage.getItem(LAST_KEY) || null;
}

export function setLastProjectId(id) {
  if (id) localStorage.setItem(LAST_KEY, id);
  else localStorage.removeItem(LAST_KEY);
}

// A brand-new project starts completely empty: one root node, no children, no scripts.
export function emptyScene() {
  return { root: makeNode('Node2D', 'Main') };
}

// One-time migration of the old single-scene save into a project.
export function migrateLegacyScene() {
  try {
    const raw = localStorage.getItem(LEGACY_SCENE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.root) return null;
    const project = createProject('My Project');
    project.scene = parsed;
    saveProject(project);
    localStorage.removeItem(LEGACY_SCENE_KEY);
    return project;
  } catch (e) {
    return null;
  }
}