import React, { useEffect, useRef, useCallback } from 'react';
import { Runtime } from '@/lib/engine/Runtime';
import { NODE_TYPES } from '@/lib/engine/registry';
import { drawExtraNode, RECT_DEFAULTS, EXTRA_BOX_TYPES } from '@/lib/engine/extraDraw';

export const GAME_KEYS = new Set(['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'Enter']);

export function globalPos(node) {
  let x = node.props.position ? node.props.position.x : 0;
  let y = node.props.position ? node.props.position.y : 0;
  let p = node.parent;
  while (p && p.__isNode && p.props && p.props.position) {
    x += p.props.position.x;
    y += p.props.position.y;
    p = p.parent;
  }
  return { x, y };
}

function cssColor(c, fallback = '#ffffff') {
  if (!c) return fallback;
  if (typeof c === 'string') return c;
  const to = (v) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0');
  if ('r' in c) return `#${to(c.r)}${to(c.g)}${to(c.b)}${'a' in c ? to(c.a) : 'ff'}`;
  return fallback;
}

function roundRect(ctx, x, y, w, h, r = 6) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawNode(ctx, node) {
  if (!node.props || node.props.visible === false) return;
  const { x, y } = globalPos(node);
  const t = node.type;
  const P = node.props;

  if (t === 'Sprite2D' || t === 'CharacterBody2D' || t === 'RigidBody2D' || t === 'StaticBody2D') {
    const w = P.size ? P.size.x : 64;
    const h = P.size ? P.size.y : 64;
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    if (P.rotation_degrees) ctx.rotate((P.rotation_degrees * Math.PI) / 180);
    ctx.globalAlpha = P.modulate ? (P.modulate.a ?? 1) : 1;
    if (t === 'RigidBody2D') {
      ctx.fillStyle = cssColor(P.color, '#8ee98e');
      ctx.beginPath();
      ctx.arc(0, 0, Math.min(w, h) / 2, 0, Math.PI * 2);
      ctx.fill();
    } else if (t === 'StaticBody2D') {
      ctx.fillStyle = '#3d4450';
      roundRect(ctx, -w / 2, -h / 2, w, h, 3);
      ctx.fill();
      ctx.fillStyle = '#4c566a';
      for (let bx = -w / 2; bx < w / 2; bx += 26) {
        for (let by = -h / 2; by < h / 2; by += 13) {
          ctx.fillRect(bx + 1, by + 1, 24, 11);
        }
      }
    } else {
      ctx.fillStyle = cssColor(P.color, t === 'CharacterBody2D' ? '#0a78f2' : '#4a90d9');
      roundRect(ctx, -w / 2, -h / 2, w, h, 8);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.25)';
      ctx.lineWidth = 1;
      ctx.stroke();
      if (t === 'Sprite2D' && P.texture) {
        ctx.font = `${Math.min(w, h) * 0.7}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#fff';
        ctx.fillText(String(P.texture).slice(0, 2), 0, 1);
      }
      if (t === 'CharacterBody2D') {
        ctx.fillStyle = '#ffd60a';
        ctx.beginPath();
        ctx.arc(-w / 6, -h / 6, Math.max(3, w * 0.08), 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(w / 6, -h / 6, Math.max(3, w * 0.08), 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  } else if (t === 'Label') {
    ctx.save();
    ctx.font = `bold ${P.font_size || 20}px ui-sans-serif, system-ui`;
    ctx.fillStyle = cssColor(P.color, '#fff');
    ctx.textBaseline = 'top';
    ctx.fillText(String(P.text ?? ''), x, y);
    ctx.restore();
  } else if (t === 'Button') {
    const w = P.size ? P.size.x : 140;
    const h = P.size ? P.size.y : 44;
    ctx.fillStyle = cssColor(P.color, '#ffe00f');
    roundRect(ctx, x, y, w, h, 8);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.font = `bold 16px ui-sans-serif, system-ui`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(P.text ?? 'Button'), x + w / 2, y + h / 2 + 1);
  } else if (t === 'ColorRect') {
    ctx.fillStyle = cssColor(P.color, '#f00');
    ctx.fillRect(x, y, P.size ? P.size.x : 100, P.size ? P.size.y : 50);
  } else if (t === 'Line2D') {
    const pts = P.points || [];
    if (pts.length > 1) {
      ctx.strokeStyle = cssColor(P.color, '#00bfa0');
      ctx.lineWidth = P.width || 5;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      pts.forEach((p, i) => {
        if (i === 0) ctx.moveTo(x + p.x, y + p.y);
        else ctx.lineTo(x + p.x, y + p.y);
      });
      ctx.stroke();
    }
  } else if (t === 'Polygon2D') {
    const pts = P.polygon || [];
    if (pts.length > 2) {
      ctx.fillStyle = cssColor(P.color, '#8f6fff');
      ctx.beginPath();
      pts.forEach((p, i) => {
        if (i === 0) ctx.moveTo(x + p.x, y + p.y);
        else ctx.lineTo(x + p.x, y + p.y);
      });
      ctx.closePath();
      ctx.fill();
    }
  } else if (t === 'Area2D') {
    const w = P.size ? P.size.x : 60;
    const h = P.size ? P.size.y : 60;
    ctx.fillStyle = cssColor(P.color, 'rgba(255,224,15,0.35)');
    roundRect(ctx, x, y, w, h, 18);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,224,15,0.8)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.font = '16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('⚡', x + w / 2, y + h / 2);
  } else if (t === 'Camera2D') {
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x - 10, y - 10, 20, 20);
    ctx.beginPath();
    ctx.moveTo(x - 14, y);
    ctx.lineTo(x + 14, y);
    ctx.moveTo(x, y - 14);
    ctx.lineTo(x, y + 14);
    ctx.stroke();
  } else if (t === 'Timer' || t === 'Node') {
    // invisible logic nodes
  } else if (t === 'Node2D') {
    ctx.fillStyle = 'rgba(255,224,15,0.9)';
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, Math.PI * 2);
    ctx.fill();
  } else {
    drawExtraNode(ctx, node, { x, y });
  }

  for (const c of node.children) drawNode(ctx, c);
}

export function drawScene(ctx, canvas, runtime) {
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  // background
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#0a0e14');
  grad.addColorStop(1, '#0d1520');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
  // grid
  ctx.strokeStyle = 'rgba(255,224,15,0.05)';
  ctx.lineWidth = 1;
  for (let gx = 0; gx <= w; gx += 40) {
    ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, h); ctx.stroke();
  }
  for (let gy = 0; gy <= h; gy += 40) {
    ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(w, gy); ctx.stroke();
  }
  // axes
  ctx.strokeStyle = 'rgba(255,255,255,0.12)';
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(w, h);
  ctx.moveTo(w, 0); ctx.lineTo(0, h); ctx.stroke();
  ctx.strokeStyle = 'rgba(255,224,15,0.25)';
  ctx.beginPath(); ctx.moveTo(0, 0.5); ctx.lineTo(w, 0.5);
  ctx.moveTo(0.5, 0); ctx.lineTo(0.5, h); ctx.stroke();

  const cam = runtime.activeCamera;
  ctx.save();
  if (cam && cam.props && cam.props.position) {
    ctx.translate(w / 2 - cam.props.position.x, h / 2 - cam.props.position.y);
    const z = cam.props.zoom || 1;
    if (z !== 1) {
      ctx.translate(w / 2, h / 2);
      ctx.scale(z, z);
      ctx.translate(-w / 2, -h / 2);
    }
  }
  if (runtime.root) drawNode(ctx, runtime.root);
  ctx.restore();
}

// ---- editor hit-testing / selection helpers (walk the plain scene data tree) ----
function nodeBoundsAt(node, gx, gy) {
  const P = node.props || {};
  if (P.visible === false) return null;
  const t = node.type;
  if (t === 'Sprite2D' || t === 'CharacterBody2D' || t === 'RigidBody2D' || t === 'StaticBody2D' || t === 'Button' || t === 'ColorRect' || t === 'Area2D' || RECT_DEFAULTS[t]) {
    const defs = { Button: [140, 44], ColorRect: [100, 50], Area2D: [60, 60], ...RECT_DEFAULTS }[t] || [64, 64];
    const sx = P.size ? P.size.x : defs[0];
    const sy = P.size ? P.size.y : defs[1];
    return { x: gx, y: gy, w: sx, h: sy, resizable: true, sx, sy };
  }
  if (t === 'Label') {
    const fs = P.font_size || 20;
    const text = String(P.text ?? '');
    return { x: gx, y: gy, w: Math.max(24, text.length * fs * 0.6), h: fs * 1.3, resizable: false };
  }
  if (t === 'Line2D' || t === 'Polygon2D') {
    const pts = (t === 'Line2D' ? P.points : P.polygon) || [];
    if (pts.length < 2) return null;
    const xs = pts.map((p) => gx + p.x);
    const ys = pts.map((p) => gy + p.y);
    return {
      x: Math.min(...xs), y: Math.min(...ys),
      w: Math.max(8, Math.max(...xs) - Math.min(...xs)),
      h: Math.max(8, Math.max(...ys) - Math.min(...ys)),
      resizable: false,
    };
  }
  if (t === 'Camera2D' || t === 'Node2D' || EXTRA_BOX_TYPES.has(t)) return { x: gx - 14, y: gy - 14, w: 28, h: 28, resizable: false };
  if (t === 'Path2D' || t === 'CollisionPolygon2D') {
    const pts = (t === 'Path2D' ? P.curve_points : P.polygon) || [];
    if (pts.length < 2) return null;
    const xs = pts.map((p) => gx + p.x);
    const ys = pts.map((p) => gy + p.y);
    return {
      x: Math.min(...xs), y: Math.min(...ys),
      w: Math.max(8, Math.max(...xs) - Math.min(...xs)),
      h: Math.max(8, Math.max(...ys) - Math.min(...ys)),
      resizable: false,
    };
  }
  if (t === 'TileMap') {
    const cs = P.cell_size || 32;
    const cells = P.cells || [];
    if (cells.length === 0) return null;
    const xs = cells.map((c) => gx + c.x * cs);
    const ys = cells.map((c) => gy + c.y * cs);
    return {
      x: Math.min(...xs), y: Math.min(...ys),
      w: Math.max(cs, Math.max(...xs) - Math.min(...xs) + cs),
      h: Math.max(cs, Math.max(...ys) - Math.min(...ys) + cs),
      resizable: false,
    };
  }
  return null;
}

function collectBounds(root) {
  const out = [];
  const walk = (node, ox, oy) => {
    if (!node) return;
    const P = node.props || {};
    const px = P.position ? P.position.x : 0;
    const py = P.position ? P.position.y : 0;
    if (P.position) {
      const b = nodeBoundsAt(node, ox + px, oy + py);
      if (b) out.push({ uid: node.uid, lx: px, ly: py, ...b });
    }
    (node.children || []).forEach((c) => walk(c, ox + px, oy + py));
  };
  walk(root, 0, 0);
  return out;
}

function applyCam(ctx, canvas, cam) {
  if (cam && cam.props && cam.props.position) {
    ctx.translate(canvas.width / 2 - cam.props.position.x, canvas.height / 2 - cam.props.position.y);
    const z = cam.props.zoom || 1;
    if (z !== 1) {
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(z, z);
      ctx.translate(-canvas.width / 2, -canvas.height / 2);
    }
  }
}

function drawSelectionOverlay(ctx, canvas, cam, b) {
  ctx.save();
  applyCam(ctx, canvas, cam);
  ctx.strokeStyle = '#ffe00f';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([6, 4]);
  ctx.strokeRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4);
  ctx.setLineDash([]);
  if (b.resizable) {
    ctx.fillStyle = '#ffe00f';
    ctx.fillRect(b.x + b.w - 3, b.y + b.h - 3, 8, 8);
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 1;
    ctx.strokeRect(b.x + b.w - 3, b.y + b.h - 3, 8, 8);
  }
  ctx.restore();
}

function buildPreview(sceneData) {
  const rt = new Runtime({ onPrint: () => {}, onError: () => {} });
  const stripped = JSON.parse(JSON.stringify(sceneData));
  const strip = (n) => { n.scriptSource = null; n.children.forEach(strip); };
  strip(stripped.root);
  try {
    rt.loadScene(stripped);
  } catch (e) {
    // even the stripped scene failed — give up silently
    return null;
  }
  return rt;
}

export default function ViewportPanel({ playing, runtime, sceneData, frameCount, selectedUid, onSelect, onUpdateNode }) {
  const canvasRef = useRef(null);
  const rafRef = useRef(null);
  const previewRef = useRef(null);
  const dragRef = useRef(null);
  const liveRef = useRef({});

  // play-mode render loop
  useEffect(() => {
    if (!playing || !runtime) return undefined;
    const loop = () => {
      const canvas = canvasRef.current;
      if (canvas && runtime.root) {
        drawScene(canvas.getContext('2d'), canvas, runtime);
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [playing, runtime]);

  // edit-mode preview render
  useEffect(() => {
    if (playing || !sceneData) return undefined;
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    const preview = buildPreview(sceneData);
    previewRef.current = preview;
    const ctx = canvas.getContext('2d');
    if (preview) {
      drawScene(ctx, canvas, preview);
      if (selectedUid) {
        const b = collectBounds(sceneData.root).find((n) => n.uid === selectedUid);
        if (b) drawSelectionOverlay(ctx, canvas, preview.activeCamera, b);
      }
    } else {
      ctx.fillStyle = '#0a0e14';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    return undefined;
  }, [playing, sceneData, selectedUid]);

  // keyboard input while playing
  useEffect(() => {
    if (!playing || !runtime) return undefined;
    const down = (e) => {
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      runtime.handleKeyDown(e.code);
    };
    const up = (e) => runtime.handleKeyUp(e.code);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, [playing, runtime]);

  // keep the latest props available to the window-level drag listeners
  useEffect(() => {
    liveRef.current = { sceneData, selectedUid, onSelect, onUpdateNode };
  }, [sceneData, selectedUid, onSelect, onUpdateNode]);

  const toWorldMouse = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    let mx = (e.clientX - rect.left) * (canvas.width / rect.width);
    let my = (e.clientY - rect.top) * (canvas.height / rect.height);
    const cam = previewRef.current ? previewRef.current.activeCamera : null;
    if (cam && cam.props && cam.props.position) {
      mx += cam.props.position.x - canvas.width / 2;
      my += cam.props.position.y - canvas.height / 2;
    }
    return { mx, my };
  };

  const onDragMove = useCallback((e) => {
    const d = dragRef.current;
    const onUpdate = liveRef.current.onUpdateNode;
    if (!d || !onUpdate) return;
    const { mx, my } = toWorldMouse(e);
    const dx = mx - d.mx;
    const dy = my - d.my;
    if (d.mode === 'move') {
      onUpdate(d.uid, { position: { x: Math.round(d.ox + dx), y: Math.round(d.oy + dy) } });
    } else {
      onUpdate(d.uid, { size: { x: Math.max(8, Math.round(d.sx + dx)), y: Math.max(8, Math.round(d.sy + dy)) } });
    }
  }, []);

  const onDragEnd = useCallback(() => {
    dragRef.current = null;
    window.removeEventListener('mousemove', onDragMove);
    window.removeEventListener('mouseup', onDragEnd);
  }, [onDragMove]);

  // edit mode: click selects a node, dragging moves it, and the corner handle resizes it
  const handleEditMouseDown = (e) => {
    if (playing || !sceneData) return;
    const { mx, my } = toWorldMouse(e);
    const list = collectBounds(sceneData.root);
    if (selectedUid) {
      const sel = list.find((b) => b.uid === selectedUid);
      if (sel && sel.resizable && Math.abs(mx - (sel.x + sel.w)) <= 8 && Math.abs(my - (sel.y + sel.h)) <= 8) {
        e.preventDefault();
        dragRef.current = { mode: 'resize', uid: selectedUid, mx, my, sx: sel.sx, sy: sel.sy };
        window.addEventListener('mousemove', onDragMove);
        window.addEventListener('mouseup', onDragEnd);
        return;
      }
    }
    for (let i = list.length - 1; i >= 0; i--) {
      const b = list[i];
      if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) {
        e.preventDefault();
        onSelect?.(b.uid);
        dragRef.current = { mode: 'move', uid: b.uid, mx, my, ox: b.lx, oy: b.ly };
        window.addEventListener('mousemove', onDragMove);
        window.addEventListener('mouseup', onDragEnd);
        return;
      }
    }
  };

  const handleClick = useCallback((e) => {
    if (!playing || !runtime) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    // the canvas is CSS-scaled to fit the panel — map mouse coords into the 800x500 space
    let mx = (e.clientX - rect.left) * (canvas.width / rect.width);
    let my = (e.clientY - rect.top) * (canvas.height / rect.height);
    const cam = runtime.activeCamera;
    if (cam && cam.props && cam.props.position) {
      mx += cam.props.position.x - canvas.width / 2;
      my += cam.props.position.y - canvas.height / 2;
    }
    // topmost button under the cursor
    const buttons = runtime.allNodes.filter((n) => (n.type === 'Button' || n.type === 'TextureButton') && n.props.visible !== false);
    for (let i = buttons.length - 1; i >= 0; i--) {
      const b = buttons[i];
      const { x, y } = globalPos(b);
      const w = b.props.size ? b.props.size.x : 140;
      const h = b.props.size ? b.props.size.y : 44;
      if (mx >= x && mx <= x + w && my >= y && my <= y + h) {
        runtime.emitSignal(b, 'pressed', []);
        return;
      }
    }
  }, [playing, runtime]);

  return (
    <div className="relative h-full w-full flex items-center justify-center bg-black/30">
      <canvas
        ref={canvasRef}
        width={800}
        height={500}
        onClick={handleClick}
        onMouseDown={handleEditMouseDown}
        className={`max-w-full rounded-lg border ${playing ? 'border-[hsl(var(--voltage-yellow))]/60 neon-border' : 'border-white/10'} shadow-2xl`}
        style={{ aspectRatio: '8/5', cursor: playing ? 'pointer' : 'default' }}
      />
      {playing ? (
        <div className="absolute top-2 left-2 flex items-center gap-2 text-xs">
          <span className="bg-red-500/90 text-white px-2 py-0.5 rounded font-bold tracking-wider">▶ RUNNING</span>
          <span className="bg-black/60 text-white/70 px-2 py-0.5 rounded">frame {frameCount}</span>
        </div>
      ) : (
        <div className="absolute top-2 left-2 text-[10px] uppercase tracking-widest bg-black/60 text-white/50 px-2 py-0.5 rounded">
          Editor preview — press Play to run
        </div>
      )}
    </div>
  );
}