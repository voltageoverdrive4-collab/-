// Scene data helpers: plain-JSON scene model used by the editor + default demo scene.
import { NODE_TYPES as NODE_TYPE_META } from '@/lib/engine/registry';

let uidCounter = 0;
export function newUid() {
  uidCounter += 1;
  return `n${Date.now().toString(36)}${uidCounter}`;
}

export function makeNode(type, name, extra = {}) {
  return {
    uid: newUid(),
    type,
    name: name || type,
    uniqueName: false,
    groups: [],
    props: {},
    scriptSource: null,
    children: [],
    ...extra,
  };
}

export function findNode(node, uid) {
  if (node.uid === uid) return node;
  for (const c of node.children) {
    const r = findNode(c, uid);
    if (r) return r;
  }
  return null;
}

export function findParent(root, uid) {
  if (!root) return null;
  if (root.children.some((c) => c.uid === uid)) return root;
  for (const c of root.children) {
    const r = findParent(c, uid);
    if (r) return r;
  }
  return null;
}

export function removeNode(root, uid) {
  const parent = findParent(root, uid);
  if (!parent) return;
  parent.children = parent.children.filter((c) => c.uid !== uid);
}

export function addChild(root, parentUid, node) {
  const parent = findNode(root, parentUid);
  if (parent) parent.children.push(node);
}

export function walk(node, fn) {
  fn(node);
  node.children.forEach((c) => walk(c, fn));
}

export function cloneScene(scene) {
  return JSON.parse(JSON.stringify(scene));
}

export const NODE_CATALOG = [
  { type: 'Node', icon: '⚙️', desc: 'Base node — pure logic / organisation' },
  { type: 'Node2D', icon: '🧭', desc: '2D transform: position, rotation, scale' },
  { type: 'Sprite2D', icon: '🖼️', desc: '2D sprite / colored shape' },
  { type: 'Label', icon: '📝', desc: 'Text display' },
  { type: 'Button', icon: '🔘', desc: 'Clickable button (pressed signal)' },
  { type: 'ColorRect', icon: '🟥', desc: 'Solid color rectangle' },
  { type: 'Line2D', icon: '📏', desc: 'Polyline drawing' },
  { type: 'Polygon2D', icon: '🔺', desc: 'Polygon shape' },
  { type: 'CharacterBody2D', icon: '🏃', desc: 'Player/character physics body (move_and_slide)' },
  { type: 'RigidBody2D', icon: '🎱', desc: 'Dynamic physics body' },
  { type: 'StaticBody2D', icon: '🧱', desc: 'Solid wall / floor collider' },
  { type: 'Area2D', icon: '⚡', desc: 'Overlap detection (body_entered)' },
  { type: 'Timer', icon: '⏱️', desc: 'Countdown timer (timeout signal)' },
  { type: 'Camera2D', icon: '🎥', desc: '2D camera' },
  { type: 'AnimatedSprite2D', icon: '🎞️', desc: 'Frame-based animated sprite' },
  { type: 'TileMap', icon: '🗺️', desc: 'Grid-based tile system for levels' },
  { type: 'CollisionShape2D', icon: '🔷', desc: 'Collision shape for physics bodies' },
  { type: 'CollisionPolygon2D', icon: '🔻', desc: 'Polygon-based collision shape' },
  { type: 'Node3D', icon: '📦', desc: 'Base 3D node with transform' },
  { type: 'MeshInstance3D', icon: '🧊', desc: 'Display 3D mesh' },
  { type: 'Camera3D', icon: '📹', desc: '3D camera for rendering' },
  { type: 'DirectionalLight3D', icon: '☀️', desc: 'Directional light source (sun)' },
  { type: 'SpotLight3D', icon: '🔦', desc: 'Cone-shaped light' },
  { type: 'OmniLight3D', icon: '💡', desc: 'Point light radiating in all directions' },
  { type: 'CharacterBody3D', icon: '🚶', desc: 'Kinematic body for 3D character control' },
  { type: 'RigidBody3D', icon: '🎲', desc: 'Dynamic 3D physics body' },
  { type: 'StaticBody3D', icon: '🏢', desc: 'Non-moving 3D physics body (walls, floors)' },
  { type: 'Area3D', icon: '🌐', desc: '3D overlap detection area' },
  { type: 'CollisionShape3D', icon: '🔷', desc: '3D collision shape' },
  { type: 'TextureButton', icon: '🟦', desc: 'Button with textures' },
  { type: 'LineEdit', icon: '✏️', desc: 'Single-line text input' },
  { type: 'TextEdit', icon: '📄', desc: 'Multi-line text input' },
  { type: 'Panel', icon: '🔲', desc: 'Container with background' },
  { type: 'ProgressBar', icon: '📶', desc: 'Progress indicator' },
  { type: 'CheckBox', icon: '☑️', desc: 'Toggle checkbox' },
  { type: 'OptionButton', icon: '🔽', desc: 'Dropdown selection menu' },
  { type: 'Control', icon: '🎛️', desc: 'Base UI node with anchors and margins' },
  { type: 'Container', icon: '🧩', desc: 'Base container for automatic layout' },
  { type: 'VBoxContainer', icon: '📋', desc: 'Vertical box layout' },
  { type: 'HBoxContainer', icon: '↔️', desc: 'Horizontal box layout' },
  { type: 'GridContainer', icon: '▦', desc: 'Grid layout' },
  { type: 'MarginContainer', icon: '🟧', desc: 'Container with margins' },
  { type: 'ScrollContainer', icon: '📜', desc: 'Scrollable container' },
  { type: 'TabContainer', icon: '🗂️', desc: 'Tabbed interface' },
  { type: 'AnimationPlayer', icon: '🎬', desc: 'Play keyframe animations' },
  { type: 'AnimationTree', icon: '🌲', desc: 'Advanced animation blending' },
  { type: 'AudioStreamPlayer', icon: '🔊', desc: '2D audio playback (non-positional)' },
  { type: 'AudioStreamPlayer2D', icon: '🔉', desc: '2D positional audio' },
  { type: 'AudioStreamPlayer3D', icon: '📢', desc: '3D positional audio' },
  { type: 'Tween', icon: '〰️', desc: 'Animate property values smoothly' },
  { type: 'CanvasLayer', icon: '🪟', desc: 'Separate rendering layer (for UI)' },
  { type: 'ParallaxBackground', icon: '🌄', desc: 'Parallax scrolling background' },
  { type: 'ParallaxLayer', icon: '🌁', desc: 'One parallax layer with motion_scale' },
  { type: 'Path2D', icon: '➰', desc: 'Curved path for nodes to follow' },
  { type: 'PathFollow2D', icon: '🔁', desc: 'Move nodes along parent Path2D' },
  { type: 'RayCast2D', icon: '🎯', desc: '2D ray collision detection' },
  { type: 'VisibleOnScreenNotifier2D', icon: '👁️', desc: 'Detect when node enters/exits screen' },
  { type: 'GPUParticles2D', icon: '✨', desc: 'GPU-accelerated 2D particles' },
  { type: 'CPUParticles2D', icon: '🌟', desc: 'CPU-based 2D particles' },
  { type: 'GPUParticles3D', icon: '🌠', desc: 'GPU-accelerated 3D particles' },
  { type: 'CPUParticles3D', icon: '☄️', desc: 'CPU-based 3D particles' },
  { type: 'HTTPRequest', icon: '🌐', desc: 'HTTP request node (get/post with signals)' },
];

const PLAYER_SCRIPT = `extends CharacterBody2D

# Move with arrows / WASD, jump with Space.
@export var speed = 260
@export var jump_force = -420

func _ready():
	print("Player ready. Move with arrows, jump with Space!")

func _physics_process(delta):
	var dir = Input.get_axis("move_left", "move_right")
	velocity.x = dir * speed
	if is_on_floor() and Input.is_action_just_pressed("jump"):
		velocity.y = jump_force
	velocity.y += 900 * delta
	move_and_slide()
	if position.y > 480:
		position = Vector2(100, 150)
`;

const COIN_SCRIPT = `extends Area2D

signal collected(value)

@export var value = 10

func _ready():
	body_entered.connect(_on_body_entered)

func _on_body_entered(body):
	if body.is_in_group("player"):
		print("Coin collected! +" + str(value))
		emit_signal("collected", value)
		queue_free()
`;

const SCORE_SCRIPT = `extends Label

var score = 0

func _ready():
	_on_score_changed(0)

func _on_score_changed(amount):
	score += amount
	text = "Score: %d" % score
`;

const MAIN_SCRIPT = `extends Node2D

func _ready():
	print("=== Voltage scene loaded ===")
	%Coin.collected.connect(_on_coin_collected)
	var tween = create_tween()
	tween.tween_property(%Coin, "position:y", 330, 1.5)
	for child in get_children():
		print("- " + child.name + " <" + child.type + ">")
	print("Scene has %d nodes. Press Play, collect the coin!" % get_children().size())

func _on_coin_collected(value):
	%Score._on_score_changed(value)
`;

// hydration: fill every declared prop with its default so the inspector,
// viewport and runtime all see a complete node
export function plainDefault(def) {
  if (def && typeof def === 'object') {
    if (def.__vec2) return { x: def.x, y: def.y };
    if (def.__color) return { r: def.r, g: def.g, b: def.b, a: def.a };
    if (Array.isArray(def)) return def;
  }
  return def;
}

export function hydrateNode(node) {
  const meta = NODE_TYPE_META[node.type] || {};
  const props = meta.PROPS || [];
  if (!node.uid) node.uid = newUid();
  if (!node.groups) node.groups = [];
  if (!node.children) node.children = [];
  if (!node.uniqueName) node.uniqueName = false;
  if (node.props === undefined) node.props = {};
  for (const p of props) {
    if (node.props[p.name] === undefined) node.props[p.name] = plainDefault(p.default);
  }
  node.children.forEach(hydrateNode);
}

export function hydrateScene(scene) {
  walk(scene.root, hydrateNode);
  return scene;
}

export function defaultScene() {
  const main = makeNode('Node2D', 'Main', {
    scriptSource: MAIN_SCRIPT,
    props: {},
    children: [
      makeNode('StaticBody2D', 'Ground', {
        props: { position: { x: -50, y: 380 }, size: { x: 900, y: 40 } },
      }),
      makeNode('ColorRect', 'Platform', {
        props: { position: { x: 240, y: 290 }, size: { x: 140, y: 16 }, color: { r: 0.06, g: 0.47, b: 0.98, a: 1 } },
      }),
      makeNode('CharacterBody2D', 'Player', {
        groups: ['player'],
        scriptSource: PLAYER_SCRIPT,
        props: { position: { x: 100, y: 150 }, size: { x: 40, y: 56 } },
      }),
      makeNode('Area2D', 'Coin', {
        uniqueName: true,
        scriptSource: COIN_SCRIPT,
        props: { position: { x: 300, y: 250 }, size: { x: 36, y: 36 }, color: { r: 1, g: 0.88, b: 0.06, a: 0.4 } },
      }),
      makeNode('Label', 'Score', {
        uniqueName: true,
        scriptSource: SCORE_SCRIPT,
        props: { position: { x: 20, y: 20 }, text: 'Score: 0', font_size: 24 },
      }),
    ],
  });
  return { root: main };
}