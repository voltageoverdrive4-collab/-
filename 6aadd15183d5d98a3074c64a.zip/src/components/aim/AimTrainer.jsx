import React, { useEffect, useState } from 'react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Play, RotateCcw, Crosshair, Target, MousePointer2, Lightbulb, Trophy } from 'lucide-react';
import AimCanvas from './AimCanvas';
import AimSettings from './AimSettings';
import { loadSettings, saveSettings, loadBest, saveBest, roundTips, ROUND_SECONDS } from './aimMath';
import { useAuth } from '@/lib/AuthContext';
import { grantAchievement } from '@/lib/achievements';

const MODES = [
  { id: 'gridshot', label: 'Gridshot', desc: 'Pop 6 targets as fast as you can — builds speed and precision.' },
  { id: 'flick', label: 'Flick', desc: 'One target at a time — builds flick speed and reaction time.' },
  { id: 'tracking', label: 'Tracking', desc: 'Keep your crosshair glued to a moving target — builds tracking.' },
];

export default function AimTrainer() {
  const { user } = useAuth();
  const [settings, setSettings] = useState(loadSettings);
  const [mode, setMode] = useState('gridshot');
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);
  const [best, setBest] = useState(loadBest);

  useEffect(() => { saveSettings(settings); }, [settings]);

  const handleEnd = (r) => {
    setRunning(false);
    setResults(r);
    grantAchievement(user, 'sharpshooter');
    const prev = best[r.mode];
    if (!prev || r.score > prev.score) {
      const next = { ...best, [r.mode]: r };
      setBest(next);
      saveBest(next);
    }
  };

  const tips = results ? roundTips(results.mode, results) : [];
  const bestFor = best[mode];

  return (
    <div className="grid lg:grid-cols-[1fr_320px] gap-6">
      <div className="space-y-4">
        <Tabs value={mode} onValueChange={(v) => { if (!running) { setMode(v); setResults(null); } }}>
          <TabsList className="bg-black/40 border border-white/10">
            {MODES.map((m) => (
              <TabsTrigger
                key={m.id}
                value={m.id}
                disabled={running}
                className="data-[state=active]:bg-[hsl(var(--voltage-yellow))]/15 data-[state=active]:text-[hsl(var(--voltage-yellow))]"
              >
                {m.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="relative rounded-xl overflow-hidden border border-white/10">
          <AimCanvas settings={settings} mode={mode} running={running} onRoundEnd={handleEnd} />
          {!running && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 text-center px-6">
              <p className="text-white/60 text-sm max-w-md">
                {MODES.find((m) => m.id === mode).desc} Move the mouse to aim, click to shoot, hold right-click to ADS. {ROUND_SECONDS}s round.
              </p>
              <Button
                onClick={() => { setResults(null); setRunning(true); }}
                size="lg"
                className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"
              >
                <Play className="w-4 h-4 mr-2" /> Start Round
              </Button>
              {bestFor && (
                <p className="text-xs text-white/40 flex items-center gap-1">
                  <Trophy className="w-3.5 h-3.5 text-[hsl(var(--voltage-yellow))]" /> Best: {bestFor.score} pts
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      <aside className="space-y-4">
        <div className="p-4 rounded-xl bg-black/40 border border-white/10">
          <h3 className="font-bold mb-3 flex items-center gap-2"><Crosshair className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" /> Your Settings</h3>
          <AimSettings settings={settings} onChange={setSettings} />
        </div>

        {results && (
          <div className="p-4 rounded-xl bg-[hsl(var(--voltage-yellow))]/5 border border-[hsl(var(--voltage-yellow))]/30">
            <h3 className="font-bold mb-2 flex items-center gap-2"><RotateCcw className="w-4 h-4" /> Round Complete</h3>
            <ul className="text-sm space-y-1">
              <li>Score: <b>{results.score}</b></li>
              {results.mode !== 'tracking' && <li>Accuracy: <b>{results.accuracy}%</b> ({results.hits}/{results.shots} shots)</li>}
              {results.mode === 'flick' && results.avgReaction > 0 && <li>Avg reaction: <b>{results.avgReaction}ms</b></li>}
              {results.mode === 'tracking' && <li>Time on target: <b>{results.trackPct}%</b></li>}
            </ul>
            {tips.length > 0 && (
              <ul className="mt-3 space-y-1.5 text-xs text-white/70">
                {tips.map((t) => (
                  <li key={t} className="flex gap-1.5"><Lightbulb className="w-3.5 h-3.5 text-[hsl(var(--voltage-yellow))] shrink-0 mt-0.5" />{t}</li>
                ))}
              </ul>
            )}
          </div>
        )}

        <div className="p-4 rounded-xl bg-black/40 border border-white/10">
          <h3 className="font-bold mb-2 flex items-center gap-2"><Trophy className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" /> Bests</h3>
          <ul className="text-sm space-y-1">
            {MODES.map((m) => (
              <li key={m.id} className="flex justify-between">
                <span className="text-white/60">{m.label}</span>
                <b>{best[m.id]?.score ?? '—'}</b>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-4 rounded-xl bg-black/40 border border-white/10">
          <h3 className="font-bold mb-2 flex items-center gap-2"><Target className="w-4 h-4 text-[hsl(var(--voltage-blue))]" /> How it helps</h3>
          <p className="text-xs text-white/50">
            The camera rotates at the speed your real sensitivity produces, so the muscle memory you build here transfers to Fortnite.
            Do 2–3 rounds a day and track your accuracy and reaction trends.
          </p>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-white/40"><MousePointer2 className="w-3.5 h-3.5" /> Click the canvas once to lock your cursor for the round.</div>
        </div>
      </aside>
    </div>
  );
}