// Aim trainer math + persistence helpers
export const FOV_DEG = 103; // Fortnite-style horizontal FOV
export const ROUND_SECONDS = 30;

export const DEFAULT_SETTINGS = {
  device: 'keyboard',
  dpi: 800,
  xSens: 8,
  ySens: 8,
  adsSens: 45,
  deadzone: 8,
};

// degrees of camera rotation per pixel of mouse movement (hipfire)
export function degPerPixel(s) {
  if (s.device === 'controller') return Math.max(1, s.xSens) / 50 * 0.02;
  const dpi = Math.max(100, s.dpi || 800);
  const sens = Math.max(0.5, s.xSens || 8);
  const cm360 = 211200 / (dpi * sens); // approximate Fortnite cm/360
  return (360 * 2.54) / (cm360 * dpi);
}

export function cm360(s) {
  const dpi = Math.max(100, s.dpi || 800);
  return 211200 / (dpi * Math.max(0.5, s.xSens || 8));
}

const SETTINGS_KEY = 'voltage_aim_settings';
const BEST_KEY = 'voltage_aim_best';

export function loadSettings() {
  try {
    return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}
export function saveSettings(s) {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* ignore */ }
}
export function loadBest() {
  try { return JSON.parse(localStorage.getItem(BEST_KEY) || '{}'); } catch { return {}; }
}
export function saveBest(b) {
  try { localStorage.setItem(BEST_KEY, JSON.stringify(b)); } catch { /* ignore */ }
}

export function roundTips(mode, r) {
  const tips = [];
  if (mode === 'gridshot' || mode === 'flick') {
    if (r.accuracy < 55) tips.push('Accuracy under 55% — slow your flicks and confirm the crosshair before clicking.');
    else if (r.accuracy < 75) tips.push('Decent accuracy — work on "stopping" your mouse dead on the target before the shot.');
    else tips.push('Great accuracy! Push your speed up, but don\'t let accuracy drop below 70%.');
  }
  if (mode === 'flick' && r.avgReaction > 0) {
    if (r.avgReaction > 600) tips.push('Reactions over 600ms — keep your crosshair near the center so targets spawn closer to it.');
    else tips.push('Reaction time is solid — drill one clean motion: flick, stop, click.');
  }
  if (mode === 'tracking') {
    if (r.trackPct < 40) tips.push('Keep your arm loose and match the target\'s speed instead of chasing it.');
    else if (r.trackPct < 70) tips.push('Good tracking — micro-correct earlier when the target changes direction.');
    else tips.push('Excellent tracking! Try a faster sensitivity or smaller targets next.');
  }
  return tips;
}