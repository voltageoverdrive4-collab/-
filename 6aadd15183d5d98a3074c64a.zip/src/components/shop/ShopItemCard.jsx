import React from 'react';
import { Store, ShoppingBag, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

// One item card in the Clan Shop grid — counts down as it sells, shows
// Sold Out when the last one goes, and admins get a remove button.
export default function ShopItemCard({ item, canBuy, onBuy, onRemove }) {
  const qty = item.quantity || 1;
  const sold = item.sold || 0;
  const left = qty - sold;
  const soldOut = left <= 0;

  return (
    <div className={`volt-panel volt-card rounded-3xl overflow-hidden relative ${soldOut ? 'opacity-70' : ''}`}>
      {onRemove && (
        <button
          onClick={onRemove}
          title="Remove listing"
          className="absolute top-2 right-2 z-10 w-8 h-8 grid place-items-center rounded-xl bg-black/60 border border-red-400/40 text-red-300 hover:bg-red-400/20 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      )}
      {item.image_url ? (
        <img src={item.image_url} alt={item.title} className="w-full h-36 object-cover" />
      ) : (
        <div className="w-full h-36 bg-gradient-to-br from-[hsl(var(--voltage-yellow))]/20 to-[hsl(var(--voltage-blue))]/20 grid place-items-center">
          <Store className="w-10 h-10 text-white/30" />
        </div>
      )}
      <div className="p-4">
        <div className="text-sm font-bold text-white/90 truncate">{item.title}</div>
        <div className="text-[11px] text-white/40">{item.category} · {item.seller_name || 'seller'}</div>
        {item.description && <p className="text-xs text-white/50 mt-1 line-clamp-2">{item.description}</p>}
        <div className="text-[11px] mt-1.5">
          {soldOut ? (
            <span className="font-bold text-red-300 uppercase tracking-wider">Sold out</span>
          ) : qty > 1 ? (
            <span className="text-white/50">{sold > 0 ? `${sold} sold · ` : ''}{left} left</span>
          ) : sold > 0 ? (
            <span className="text-white/50">{sold} sold</span>
          ) : null}
        </div>
        <div className="flex items-center justify-between mt-3">
          <span className="text-lg font-black volt-gradient-text">${Number(item.price).toFixed(2)}</span>
          {canBuy ? (
            soldOut ? (
              <span className="text-[11px] font-bold text-white/40 italic">Sold out</span>
            ) : (
              <Button onClick={onBuy} size="sm" className="bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black font-bold rounded-xl">
                <ShoppingBag className="w-3.5 h-3.5 mr-1.5" /> Buy
              </Button>
            )
          ) : (
            <span className="text-[11px] text-white/40 italic">Your listing</span>
          )}
        </div>
      </div>
    </div>
  );
}