const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useCallback, useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { withRetry } from '@/lib/apiRetry';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Link } from 'react-router-dom';
import { Trash2, Users } from 'lucide-react';

export default function RoomsTab() {
  const { user } = useAuth();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [myMember, setMyMember] = useState(null);

  const loadRooms = useCallback(async () => {
    try {
      const list = await withRetry(() => db.entities.MeetRoom.list('-created_date', 50));
      setRooms(list);
      setError('');
    } catch {
      setError('Rooms are busy right now — please try again in a moment.');
    }
  }, []);

  useEffect(() => {
    (async () => {
      try { await loadRooms(); } finally { setLoading(false); }
    })();
    // live updates come straight from the event — no re-fetch per event, so a
    // burst of activity can't pile into a rate-limit storm
    const unsubscribe = db.entities.MeetRoom.subscribe((event) => {
      if (event.type === 'create') setRooms((prev) => [event.data, ...prev.filter((r) => r.id !== event.data.id)]);
      else if (event.type === 'update') setRooms((prev) => prev.map((r) => (r.id === event.data.id ? event.data : r)));
      else if (event.type === 'delete') setRooms((prev) => prev.filter((r) => r.id !== event.data.id));
    });
    return unsubscribe;
  }, [loadRooms]);

  useEffect(() => {
    if (!user?.email) return;
    withRetry(() => db.entities.Member.filter({ email: user.email }))
      .then((r) => setMyMember(r[0] || null))
      .catch(() => {});
  }, [user?.email]);

  const isAdmin = user?.role === 'admin' || !!myMember?.is_admin;

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');
    const link = url.trim();
    if (!name.trim()) { setError('Give the room a name.'); return; }
    if (!/^https?:\/\//i.test(link)) { setError('Paste a valid meeting link (starting with https://).'); return; }
    setSaving(true);
    try {
      await db.entities.MeetRoom.create({
        name: name.trim(),
        meeting_url: link,
        created_by_name: myMember?.username || user?.email || 'A clan member',
      });
      setName('');
      setUrl('');
    } catch {
      setError('Could not open the room. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    await db.entities.MeetRoom.delete(id);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleCreate} className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
        <p className="text-sm text-white/60 flex items-center gap-2">
          <Users className="w-4 h-4 text-[hsl(var(--voltage-blue))]" />
          Create a Meet room at meet.google.com, then share the link here so squadmates can jump in.
        </p>
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="room-name">Room name</Label>
            <Input id="room-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Squad A — ranked grind" className="bg-white/5 border-white/10" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="room-url">Meet link</Label>
            <Input id="room-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://meet.google.com/abc-defg-hij" className="bg-white/5 border-white/10" />
          </div>
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <Button type="submit" disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold hover:bg-[hsl(var(--voltage-yellow))]/90">
          {saving ? 'Opening...' : 'Open room'}
        </Button>
      </form>

      {!loading && error ? (
        <p className="text-white/50 text-center py-6">{error} <button type="button" onClick={loadRooms} className="underline text-[hsl(var(--voltage-yellow))]">Retry</button></p>
      ) : loading ? (
        <p className="text-white/40 text-center py-6">Loading rooms...</p>
      ) : rooms.length === 0 ? (
        <p className="text-white/40 text-center py-6">No rooms open right now. Start one above!</p>
      ) : (
        <div className="space-y-3">
          {rooms.map((room) => (
            <div key={room.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-4">
              <div className="min-w-0 flex-1">
                <h3 className="font-bold truncate">{room.name}</h3>
                <p className="text-white/40 text-xs truncate">Opened by {room.created_by_name || 'a clan member'}</p>
              </div>
              <Link to={`/meetings/room/${room.id}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] text-sm font-medium border border-[hsl(var(--voltage-yellow))]/40 hover:bg-[hsl(var(--voltage-yellow))]/25 transition-colors whitespace-nowrap">
                Open room
              </Link>
              {(isAdmin || room.created_by_id === user?.id) && (
                <Button variant="ghost" size="icon" onClick={() => handleDelete(room.id)} className="text-white/40 hover:text-red-400 hover:bg-white/5">
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}