const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { ExternalLink, Maximize2, Minimize2, Video } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HYPER_MEET_URL = 'https://hyper-meet.db.app/dashboard';

export default function HyperMeetTab() {
  const frameWrapRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const onChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, []);

  const toggleFullscreen = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else if (frameWrapRef.current) {
      frameWrapRef.current.requestFullscreen();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <p className="text-sm text-white/60 flex items-center gap-2">
          <Video className="w-4 h-4 text-[hsl(var(--voltage-blue))]" />
          Your Hyper Meet app, right inside the hub.
        </p>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="border-white/15 text-white/70 hover:bg-white/5"
            onClick={toggleFullscreen}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            {isFullscreen ? 'Exit full screen' : 'Full screen'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-white/15 text-white/70 hover:bg-white/5"
            onClick={() => window.open(HYPER_MEET_URL, '_blank', 'noopener')}
          >
            <ExternalLink className="w-4 h-4" /> Open in new tab
          </Button>
        </div>
      </div>
      <div
        ref={frameWrapRef}
        className="rounded-2xl overflow-hidden border border-white/10 bg-black/40"
      >
        <iframe
          src={HYPER_MEET_URL}
          title="Hyper Meet"
          className={
            isFullscreen
              ? 'w-full h-screen block'
              : 'w-full h-[calc(100vh-320px)] min-h-[500px] block'
          }
          allow="camera; microphone; fullscreen; display-capture"
        />
      </div>
    </div>
  );
}