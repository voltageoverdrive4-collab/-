const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useCallback, useEffect, useState } from 'react';

import { ExternalLink } from 'lucide-react';

export default function UpcomingCallsTab() {
  const [calls, setCalls] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadCalls = useCallback(async () => {
    const list = await db.entities.ScheduledEvent.list('date', 200);
    const today = new Date().toISOString().slice(0, 10);
    setCalls(list.filter((e) => e.meeting_url && e.date >= today));
  }, []);

  useEffect(() => {
    (async () => {
      try { await loadCalls(); } finally { setLoading(false); }
    })();
    const unsubscribe = db.entities.ScheduledEvent.subscribe(() => { loadCalls(); });
    return unsubscribe;
  }, [loadCalls]);

  return (
    <div className="space-y-3">
      {loading ? (
        <p className="text-white/40 text-center py-6">Loading calls...</p>
      ) : calls.length === 0 ? (
        <p className="text-white/40 text-center py-6">No upcoming calls with a Meet link yet.</p>
      ) : calls.map((e) => (
        <div key={e.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-4">
          <div className="w-14 text-center shrink-0">
            <div className="text-[hsl(var(--voltage-yellow))] text-xs uppercase tracking-widest">
              {new Date(e.date).toLocaleString('en', { month: 'short' })}
            </div>
            <div className="text-2xl font-black">{new Date(e.date).getDate()}</div>
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="font-bold truncate">{e.title}</h3>
            {e.time && <p className="text-[hsl(var(--voltage-blue))] text-sm">{e.time}</p>}
          </div>
          <a href={e.meeting_url} target="_blank" rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] text-sm font-medium border border-[hsl(var(--voltage-yellow))]/40 hover:bg-[hsl(var(--voltage-yellow))]/25 transition-colors whitespace-nowrap">
            <ExternalLink className="w-3.5 h-3.5" /> Join
          </a>
        </div>
      ))}
    </div>
  );
}