const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useCallback, useEffect, useRef, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send } from 'lucide-react';
import moment from 'moment';
import { useAuth } from '@/lib/AuthContext';
import { grantAchievement } from '@/lib/achievements';
import { fromDb } from '@/lib/time';

export default function PrivateMessenger({ myMember, contacts, fixedContactId = null, heightClass = 'h-[420px]' }) {
  const { user } = useAuth();
  const [activeId, setActiveId] = useState(fixedContactId || (contacts.length > 0 ? contacts[0].id : null));
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef(null);

  const active = contacts.find((c) => c.id === activeId) || null;

  const load = useCallback(async () => {
    if (!myMember) { setLoading(false); return; }
    try {
      const [sent, received] = await Promise.all([
        db.entities.DirectMessage.filter({ sender_id: myMember.id }),
        db.entities.DirectMessage.filter({ recipient_id: myMember.id }),
      ]);
      const all = [...sent, ...received].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
      setMessages(all);
    } catch (e) { /* transient */ } finally { setLoading(false); }
  }, [myMember]);

  useEffect(() => { load(); }, [load]);

  // live updates when new private messages arrive
  useEffect(() => {
    const unsub = db.entities.DirectMessage.subscribe(() => load());
    return unsub;
  }, [load]);

  const convo = activeId && myMember
    ? messages.filter(
        (m) => (m.sender_id === myMember.id && m.recipient_id === activeId)
          || (m.sender_id === activeId && m.recipient_id === myMember.id)
      )
    : [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'nearest' });
  }, [convo.length, activeId]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim() || !active || !myMember) return;
    setSending(true);
    try {
      await db.entities.DirectMessage.create({
        sender_id: myMember.id,
        sender_name: myMember.username,
        recipient_id: active.id,
        recipient_name: active.username,
        text: text.trim(),
      });
      grantAchievement(user, 'dm-starter');
      setText('');
      load();
    } finally { setSending(false); }
  };

  if (!myMember) {
    return (
      <div className={`flex items-center justify-center ${heightClass}`}>
        <p className="text-white/40 text-sm text-center px-6">
          You need a member profile before you can send private messages — create one on the Profile page.
        </p>
      </div>
    );
  }

  return (
    <div className={`flex ${heightClass} min-h-0`}>
      {!fixedContactId && (
        <aside className="w-40 shrink-0 border-r border-white/10 overflow-y-auto py-2">
          {contacts.length === 0 && <p className="text-white/30 text-xs px-3">No members yet.</p>}
          {contacts.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setActiveId(c.id)}
              className={`w-full text-left px-3 py-2 text-sm truncate transition-colors ${
                c.id === activeId
                  ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              {c.username}
            </button>
          ))}
        </aside>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <div className="px-4 py-2 border-b border-white/10 text-sm font-semibold truncate">
          {active ? active.username : 'No conversation selected'}
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {loading && <p className="text-white/30 text-xs">Loading messages…</p>}
          {!loading && convo.length === 0 && (
            <p className="text-white/30 text-xs">No messages yet — say hi!</p>
          )}
          {convo.map((m) => (
            <div key={m.id} className={`flex ${m.sender_id === myMember.id ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[75%] px-3 py-1.5 rounded-lg text-sm ${
                  m.sender_id === myMember.id
                    ? 'bg-[hsl(var(--voltage-yellow))]/20 text-white'
                    : 'bg-white/10 text-white/80'
                }`}
              >
                <div>{m.text}</div>
                <div className="text-[10px] text-white/40 mt-0.5">{moment(fromDb(m.created_date)).fromNow()}</div>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={send} className="flex gap-2 p-3 border-t border-white/10">
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={active ? `Message ${active.username}…` : 'Select a member…'}
            disabled={!active}
            className="bg-black/50 border-white/15 text-white"
          />
          <Button
            type="submit"
            size="sm"
            disabled={sending || !active || !text.trim()}
            className="bg-[hsl(var(--voltage-yellow))] text-black font-bold shrink-0"
          >
            <Send className="w-4 h-4" /> Send
          </Button>
        </form>
      </div>
    </div>
  );
}