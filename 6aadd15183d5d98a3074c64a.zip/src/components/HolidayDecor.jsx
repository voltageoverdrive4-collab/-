import React, { useEffect, useMemo } from 'react';
import { useActiveHoliday } from '@/lib/useHoliday';

const PARTICLE_COUNT = 16;

// Seasonal decorations shown across the app during holiday windows.
export default function HolidayDecor() {
  const holiday = useActiveHoliday();

  const particles = useMemo(() => {
    if (!holiday) return [];
    return Array.from({ length: PARTICLE_COUNT }, (_, i) => ({
      emoji: holiday.emojis[i % holiday.emojis.length],
      left: (i * 61) % 100,
      top: (i * 47) % 85,
      delay: ((i * 0.9) % 12).toFixed(1),
      duration: (9 + ((i * 1.7) % 9)).toFixed(1),
      size: 15 + ((i * 5) % 16),
    }));
  }, [holiday]);

  // Decorations and the seasonal icon do not overwrite the selected GUI.
  // The shared theme hook is the only owner of the color tokens.
  useEffect(() => {
    if (!holiday) return undefined;
    // Swap the browser-tab app icon for the holiday's emoji mark.
    let link = document.querySelector("link[rel~='icon']");
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    const prevHref = link.href;
    link.href = `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y="0.9em" font-size="90">${holiday.icon}</text></svg>`)}`;
    return () => { link.href = prevHref; };
  }, [holiday]);

  if (!holiday) return null;

  return (
    <div aria-hidden="true" className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {particles.map((p, i) => (
        <span
          key={i}
          className={holiday.motion === 'fall' ? 'holiday-fall' : 'holiday-float'}
          style={{
            position: 'absolute',
            left: `${p.left}%`,
            top: holiday.motion === 'fall' ? '-8vh' : `${p.top}%`,
            fontSize: `${p.size}px`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            opacity: 0.8,
          }}
        >
          {p.emoji}
        </span>
      ))}
    </div>
  );
}