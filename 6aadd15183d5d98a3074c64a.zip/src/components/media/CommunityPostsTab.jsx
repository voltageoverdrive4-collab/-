const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Trash2, Upload, Image as ImageIcon, Film } from 'lucide-react';

// Community wall: any member can publish their photos and Fortnite clips.
export default function CommunityPostsTab() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [posts, setPosts] = useState(null);
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);

  const load = () => {
    db.entities.MediaPost.list('-created_date', 100)
      .then(setPosts)
      .catch(() => setPosts([]));
  };

  useEffect(() => {
    load();
    return db.entities.MediaPost.subscribe(() => load());
  }, []);

  const upload = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
      toast({ title: 'File too large (max 50 MB)', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      await db.entities.MediaPost.create({
        user_id: user.id,
        username: user.full_name || user.email.split('@')[0],
        title: title.trim(),
        file_url,
        kind: file.type.startsWith('video') ? 'clip' : 'photo'
      });
      setTitle('');
      toast({ title: 'Published! 🎉' });
    } catch (err) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const del = async (p) => {
    try { await db.entities.MediaPost.delete(p.id); } catch (e) {
      toast({ title: 'Could not delete', variant: 'destructive' });
    }
  };

  const canDelete = (p) => user?.role === 'admin' || p.user_id === user?.id || p.created_by_id === user?.id;

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-2 mb-6">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Give your post a title (optional)"
          className="bg-black/40 border-white/15 text-white"
        />
        <label className={`inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-bold cursor-pointer whitespace-nowrap ${
          busy ? 'bg-white/10 text-white/40' : 'bg-[hsl(var(--voltage-yellow))] text-black hover:brightness-110'
        }`}>
          <Upload className="w-4 h-4" />
          {busy ? 'Uploading…' : 'Post a photo or clip'}
          <input type="file" accept="image/*,video/*" className="hidden" onChange={upload} disabled={busy} />
        </label>
      </div>

      {posts === null && <p className="text-white/40 text-sm">Loading posts…</p>}
      {posts !== null && posts.length === 0 && (
        <div className="text-center py-10 text-white/40">
          <ImageIcon className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No community posts yet — be the first to share!</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {(posts || []).map((p) => (
          <div key={p.id} className="group relative rounded-xl overflow-hidden bg-black/40 border border-white/10">
            {p.kind === 'clip' ? (
              <video src={p.file_url} controls className="w-full aspect-video object-cover bg-black" />
            ) : (
              <img src={p.file_url} alt={p.title || 'community post'} className="w-full aspect-video object-cover" />
            )}
            <div className="p-3 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">{p.title || (p.kind === 'clip' ? 'Fortnite clip' : 'Photo')}</p>
                <p className="text-xs text-white/40 flex items-center gap-1">
                  {p.kind === 'clip' ? <Film className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
                  {p.username}
                </p>
              </div>
              {canDelete(p) && (
                <button onClick={() => del(p)} className="opacity-0 group-hover:opacity-100 text-white/40 hover:text-red-400">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}