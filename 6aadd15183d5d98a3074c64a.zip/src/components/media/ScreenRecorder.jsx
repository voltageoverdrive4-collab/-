import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Circle, Square, Download, ScreenShare } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { grantAchievement } from '@/lib/achievements';

const formatTime = (totalSeconds) => {
  const m = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
  const s = String(totalSeconds % 60).padStart(2, '0');
  return `${m}:${s}`;
};

export default function ScreenRecorder({ user }) {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [recordings, setRecordings] = useState([]);
  const recorderRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);

  const supported = typeof navigator !== 'undefined' &&
    !!navigator.mediaDevices?.getDisplayMedia &&
    typeof window.MediaRecorder !== 'undefined';

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      if (recorderRef.current && recorderRef.current.state !== 'inactive') recorderRef.current.stop();
    };
  }, []);

  const start = async () => {
    if (!supported) {
      toast.error('Screen recording is not supported in this browser');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: true });
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
      const recorder = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        if (chunksRef.current.length === 0) return;
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const stamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
        setRecordings((prev) => [
          { id: `${stamp}-${prev.length}`, name: `voltage-recording-${stamp}.webm`, url: URL.createObjectURL(blob) },
          ...prev,
        ]);
        grantAchievement(user, 'director');
        toast.success('Recording saved below — download it to keep it');
      };
      stream.getVideoTracks()[0].addEventListener('ended', stop);
      streamRef.current = stream;
      recorderRef.current = recorder;
      recorder.start(1000);
      setSeconds(0);
      setRecording(true);
      timerRef.current = setInterval(() => setSeconds((s) => s + 1), 1000);
    } catch (e) {
      if (e?.name !== 'NotAllowedError') toast.error(e?.message || 'Could not start the screen recorder');
    }
  };

  const stop = () => {
    if (recorderRef.current && recorderRef.current.state !== 'inactive') recorderRef.current.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    if (timerRef.current) clearInterval(timerRef.current);
    setRecording(false);
  };

  return (
    <div className="mb-6 p-4 rounded-xl bg-white/5 border border-white/10 flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <ScreenShare className="w-5 h-5 text-[hsl(var(--voltage-blue))]" />
        <div>
          <div className="font-bold text-sm">Screen Recorder</div>
          <p className="text-white/50 text-xs">Record any tab — captures happen live, files save right here</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        {recording && (
          <span className="flex items-center gap-2 text-sm font-bold text-red-400">
            <Circle className="w-3 h-3 fill-red-400 animate-pulse" /> REC {formatTime(seconds)}
          </span>
        )}
        {recording ? (
          <Button size="sm" variant="destructive" onClick={stop}>
            <Square className="w-4 h-4 mr-1" /> Stop
          </Button>
        ) : (
          <Button size="sm" onClick={start} className="bg-[hsl(var(--voltage-blue))] text-black font-bold">
            <Circle className="w-4 h-4 mr-1 fill-current" /> Start Recording
          </Button>
        )}
      </div>
      {recordings.length > 0 && (
        <div className="w-full flex flex-col gap-2 border-t border-white/10 pt-3">
          {recordings.map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-3">
              <span className="text-sm text-white/70 truncate">{r.name}</span>
              <a href={r.url} download={r.name}>
                <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  <Download className="w-4 h-4 mr-1" /> Save File
                </Button>
              </a>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}