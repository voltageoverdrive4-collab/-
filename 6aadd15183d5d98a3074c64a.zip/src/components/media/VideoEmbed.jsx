import React from 'react';

export default function VideoEmbed({ url }) {
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{6,})/);
  if (yt) {
    return (
      <div className="aspect-video rounded-lg overflow-hidden bg-black/60 border border-white/10">
        <iframe
          src={`https://www.youtube.com/embed/${yt[1]}`}
          title="Video player"
          className="w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  }
  return (
    <video
      src={url}
      controls
      className="w-full aspect-video rounded-lg bg-black/60 border border-white/10"
    />
  );
}