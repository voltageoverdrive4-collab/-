const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { Trophy, Coins } from 'lucide-react';
import RetroLeaderboard from '@/components/dashboard/RetroLeaderboard';

const MEDALS = ['🥇', '🥈', '🥉'];

export default function ClanLeaderboard({ isAdmin, retro = false }) {
  const [achievers, setAchievers] = useState(null);
  const [donors, setDonors] = useState(null);

  useEffect(() => {
    (async () => {
      // grants and donations may store an account email instead of a gamertag —
      // resolve every name through the member directory so the board always shows gamertags
      let nameMap = {};
      try {
        const members = await db.entities.Member.list();
        for (const m of members) {
          if (m.email) nameMap[m.email.toLowerCase()] = m.username || '';
          if (m.username) nameMap[m.username.toLowerCase()] = m.username;
        }
      } catch { /* fall back to the stored name */ }
      const display = (raw) => {
        const v = (raw || '').trim();
        if (!v) return '';
        return nameMap[v.toLowerCase()] || (v.includes('@') ? v.split('@')[0] : v);
      };
      try {
        const res = await db.entities.AchievementGrant.aggregate({ groupBy: 'username', sort: '-count' });
        const rows = (res.rows || []).map((r) => ({ ...r, username: display(r.username) }));
        setAchievers(rows.filter((r) => r.username).slice(0, 10));
      } catch { setAchievers([]); }
      if (!isAdmin) return;
      try {
        const res = await db.entities.Donation.aggregate({
          query: { status: 'paid' },
          groupBy: 'username',
          sum: 'amount',
          sort: '-sum_amount',
        });
        const rows = (res.rows || []).map((r) => ({ ...r, username: display(r.username) }));
        setDonors(rows.filter((r) => r.username).slice(0, 5));
      } catch { setDonors([]); }
    })();
  }, [isAdmin]);

  if (retro) return <RetroLeaderboard achievers={achievers} donors={donors} isAdmin={isAdmin} />;

  return (
    <div className="mt-10 grid md:grid-cols-2 gap-5">
      <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
        <h3 className="font-heading font-bold text-lg mb-4 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" /> Achievement Leaders
        </h3>
        {achievers === null ? (
          <p className="text-white/40 text-sm">Loading…</p>
        ) : achievers.length === 0 ? (
          <p className="text-white/40 text-sm">No achievements earned yet — be the first!</p>
        ) : (
          <ol className="space-y-2">
            {achievers.map((r, i) => (
              <li key={r.username} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2">
                  <span className="w-6 text-center">{MEDALS[i] || i + 1}</span>
                  <span className="font-semibold">{r.username}</span>
                </span>
                <span className="text-[hsl(var(--voltage-yellow))] font-bold">
                  {r.count} {r.count === 1 ? 'badge' : 'badges'}
                </span>
              </li>
            ))}
          </ol>
        )}
      </div>

      {isAdmin && (
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
          <h3 className="font-heading font-bold text-lg mb-4 flex items-center gap-2">
            <Coins className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" /> Top Donors
          </h3>
          {donors === null ? (
            <p className="text-white/40 text-sm">Loading…</p>
          ) : donors.length === 0 ? (
            <p className="text-white/40 text-sm">No donations received yet.</p>
          ) : (
            <ol className="space-y-2">
              {donors.map((r, i) => (
                <li key={r.username} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <span className="w-6 text-center">{MEDALS[i] || i + 1}</span>
                    <span className="font-semibold">{r.username}</span>
                  </span>
                  <span className="text-[hsl(var(--voltage-blue))] font-bold">
                    ${(r.sum_amount || 0).toFixed(2)}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </div>
      )}
    </div>
  );
}