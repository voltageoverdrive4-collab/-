const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const FIELDS = [
  ['full_name', 'Full name'],
  ['email', 'Email'],
  ['address_line1', 'Street address'],
  ['address_line2', 'Apt / suite (optional)'],
  ['city', 'City'],
  ['state', 'State / province'],
  ['zip', 'ZIP / postal code'],
  ['country', 'Country'],
  ['phone', 'Phone (optional)']
];

export default function EntryForm({ giveaway, onDone, onCancel }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState({ email: user?.email || '', country: 'US' });
  const [busy, setBusy] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    if (!form.full_name || !form.email || !form.address_line1 || !form.city || !form.state || !form.zip || !form.country) {
      toast({ title: 'Please fill in your name and full shipping address', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      await db.entities.GiveawayEntry.create({
        giveaway_id: giveaway.id,
        user_id: user.id,
        username: user.full_name || user.email.split('@')[0],
        email: form.email,
        full_name: form.full_name,
        address_line1: form.address_line1,
        address_line2: form.address_line2 || '',
        city: form.city,
        state: form.state,
        zip: form.zip,
        country: form.country,
        phone: form.phone || ''
      });
      toast({ title: "You're in the giveaway! 🎉" });
      onDone();
    } catch (e) {
      toast({ title: 'Could not enter', description: e.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-3">
      <p className="text-xs text-white/40 mb-3">Your address is only used to ship your prize if you win.</p>
      <div className="grid sm:grid-cols-2 gap-3">
        {FIELDS.map(([key, placeholder]) => (
          <Input
            key={key}
            type={key === 'email' ? 'email' : 'text'}
            placeholder={placeholder}
            value={form[key] || ''}
            onChange={(e) => set(key, e.target.value)}
          />
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <Button onClick={submit} disabled={busy} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          {busy ? 'Entering…' : 'Enter giveaway'}
        </Button>
        <Button onClick={onCancel} variant="ghost" className="text-white/60">Cancel</Button>
      </div>
    </div>
  );
}