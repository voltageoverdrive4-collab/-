import React, { useState } from 'react';
import { Coins, CreditCard, CheckCircle2, Trophy } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import EntryForm from '@/components/giveaways/EntryForm';

export default function GiveawayCard({ giveaway, myEntry, onEntered }) {
  const [showForm, setShowForm] = useState(false);
  const { user } = useAuth();
  const isVbucks = giveaway.prize_type === 'vbucks';
  const prize = giveaway.prize_value || (isVbucks ? 'V-Bucks' : 'Fortnite Gift Card');
  const done = giveaway.status === 'completed';

  return (
    <div className="mb-4 p-5 rounded-2xl bg-white/5 border border-white/10">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h3 className="font-bold text-lg">{giveaway.title}</h3>
          {giveaway.description && <p className="text-white/50 text-sm">{giveaway.description}</p>}
        </div>
        <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] border border-[hsl(var(--voltage-yellow))]/40 whitespace-nowrap">
          {isVbucks ? <Coins className="w-3.5 h-3.5" /> : <CreditCard className="w-3.5 h-3.5" />}
          {prize}
        </span>
      </div>

      {done ? (
        <div className="mt-3 flex items-center gap-2 text-sm">
          <Trophy className="w-4 h-4 text-[hsl(var(--voltage-yellow))]" />
          <span>Winner: <b>{giveaway.winner_name}</b>{giveaway.sent ? ' — prize sent! 🎉' : ' — prize on the way'}</span>
        </div>
      ) : myEntry ? (
        <div className="mt-3 flex items-center gap-2 text-sm text-[hsl(var(--voltage-yellow))] font-semibold">
          <CheckCircle2 className="w-4 h-4" /> You're in — good luck!
        </div>
      ) : showForm ? (
        <EntryForm
          giveaway={giveaway}
          onDone={() => { setShowForm(false); onEntered(); }}
          onCancel={() => setShowForm(false)}
        />
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className="mt-3 px-4 py-2 rounded-lg bg-[hsl(var(--voltage-yellow))] text-black text-sm font-bold hover:brightness-110"
        >
          Enter giveaway
        </button>
      )}
    </div>
  );
}