const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useCallback, useEffect, useState } from 'react';

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { UserPlus, Check, Clock, Trophy } from 'lucide-react';
import { toast } from 'react-hot-toast';
import AchievementsPanel from '@/components/members/AchievementsPanel';

// the profile background the member set — worn by their popup in the directory
const frameStyle = (m) => (m?.profile_bg_image
  ? { backgroundImage: `linear-gradient(rgba(0,0,0,0.62), rgba(0,0,0,0.62)), url(${m.profile_bg_image})`, backgroundSize: 'cover', backgroundPosition: 'center' }
  : m?.profile_bg_color ? { background: m.profile_bg_color } : undefined);

const renderAvatar = (m, cls) => m.avatar_url
  ? <img src={m.avatar_url} alt={m.username} className={cls} />
  : (
    <div className={`${cls} bg-gradient-to-br from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] flex items-center justify-center text-black font-black`}>
      {(m.username || 'V')[0]?.toUpperCase()}
    </div>
  );

export default function MembersDirectory({ members, myMember, user, loadFailed }) {
  const [selected, setSelected] = useState(null);
  const [showAch, setShowAch] = useState({});
  const [requests, setRequests] = useState([]);

  const loadRequests = useCallback(async () => {
    if (!user?.id) return;
    try {
      const [outgoing, incoming] = await Promise.all([
        db.entities.FriendRequest.filter({ requester_id: user.id }),
        db.entities.FriendRequest.filter({ addressee_id: user.id }),
      ]);
      setRequests([...outgoing, ...incoming]);
    } catch { /* server busy — friend buttons recover once it calms down */ }
  }, [user?.id]);

  useEffect(() => {
    loadRequests();
    const unsubscribe = db.entities.FriendRequest.subscribe(() => { loadRequests(); });
    return unsubscribe;
  }, [loadRequests]);

  const statusFor = (member) => {
    const r = requests.find((req) =>
      (req.requester_id === user?.id && req.addressee_id === member.user_id) ||
      (req.requester_id === member.user_id && req.addressee_id === user?.id));
    if (!r) return 'none';
    if (r.status === 'accepted') return 'friends';
    return r.requester_id === user?.id ? 'outgoing' : 'incoming';
  };

  const requestFor = (member) => requests.find((req) =>
    (req.requester_id === user?.id && req.addressee_id === member.user_id) ||
    (req.requester_id === member.user_id && req.addressee_id === user?.id));

  const addFriend = async (member) => {
    try {
      await db.entities.FriendRequest.create({
        requester_id: user.id,
        requester_name: myMember?.username || '',
        addressee_id: member.user_id,
        addressee_name: member.username,
      });
      toast.success(`Friend request sent to ${member.username}`);
      loadRequests();
    } catch {
      toast.error('Could not send the request');
    }
  };

  const acceptFriend = async (member) => {
    const r = requestFor(member);
    if (!r) return;
    try {
      await db.entities.FriendRequest.update(r.id, { status: 'accepted' });
      toast.success(`You and ${member.username} are now friends!`);
      loadRequests();
    } catch {
      toast.error('Could not accept the request');
    }
  };

  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {members.map((m) => (
          <button
            key={m.id}
            onClick={() => setSelected(m)}
            className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-[hsl(var(--voltage-yellow))]/40 transition-colors text-left"
          >
            {renderAvatar(m, 'w-12 h-12 rounded-full object-cover')}
            <p className="font-bold mt-2 truncate">{m.username || 'Unnamed'}</p>
            <div className="flex flex-wrap gap-1 mt-1.5">
              {(m.tags || []).filter((t) => !(m.hidden_tags || []).includes(t)).slice(0, 2).map((t) => (
                <span key={t} className="px-1.5 py-0.5 rounded bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] text-[10px] font-semibold">{t}</span>
              ))}
            </div>
          </button>
        ))}
        {members.length === 0 && <p className="text-white/40 col-span-full text-center py-6">{loadFailed ? 'Members are still loading — one moment.' : 'No other members yet.'}</p>}
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent style={frameStyle(selected)} className="bg-[hsl(var(--voltage-black))] border-white/15 text-white max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  {renderAvatar(selected, 'w-14 h-14 rounded-full object-cover shrink-0')}
                  <span className="min-w-0">
                    <span className="block truncate">{selected.username || 'Unnamed'}</span>
                    <span className="block text-xs font-normal text-white/40">{(selected.tags || []).filter((t) => !(selected.hidden_tags || []).includes(t)).join(' · ') || 'Clan member'}</span>
                  </span>
                </DialogTitle>
              </DialogHeader>
              {selected.bio && <p className="text-white/70 text-sm">{selected.bio}</p>}
              {user?.id && selected.user_id && selected.user_id !== user.id && (
                <div>
                  {statusFor(selected) === 'none' && (
                    <Button onClick={() => addFriend(selected)} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
                      <UserPlus className="w-4 h-4 mr-2" /> Add Friend
                    </Button>
                  )}
                  {statusFor(selected) === 'outgoing' && (
                    <Button disabled variant="outline" className="border-white/15 text-white/50"><Clock className="w-4 h-4 mr-2" /> Request sent</Button>
                  )}
                  {statusFor(selected) === 'incoming' && (
                    <Button onClick={() => acceptFriend(selected)} className="bg-green-500 text-black font-bold hover:bg-green-400">
                      <Check className="w-4 h-4 mr-2" /> Accept friend request
                    </Button>
                  )}
                  {statusFor(selected) === 'friends' && (
                    <Button disabled variant="outline" className="border-green-500/40 text-green-400"><Check className="w-4 h-4 mr-2" /> Friends</Button>
                  )}
                </div>
              )}
              <div className="mt-2">
                <Button size="sm" variant="outline" onClick={() => setShowAch((s) => ({ ...s, [selected.id]: !s[selected.id] }))} className="border-white/20 text-white hover:bg-white/10">
                  <Trophy className="w-4 h-4 mr-1.5 text-[hsl(var(--voltage-yellow))]" />
                  {showAch[selected.id] ? 'Hide Achievements' : 'Show Achievements'}
                </Button>
              </div>
              {showAch[selected.id] && (
                <div className="max-h-64 overflow-y-auto pr-1">
                  <h3 className="font-heading font-black text-sm mb-2 text-white/80">Achievements</h3>
                  <AchievementsPanel user={{ id: selected.user_id }} />
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}