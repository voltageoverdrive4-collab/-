import React, { useState, useRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { freeChat, freeImageURL } from '@/lib/freeAIClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Image as ImageIcon, Send, Sparkles, Bot, User } from 'lucide-react';

export default function AITools() {
  return (
    <div className="p-6 sm:p-10 max-w-4xl mx-auto">
      <h1 className="font-heading text-3xl font-black mb-6 flex items-center gap-2"><Sparkles className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> AI Lab</h1>
      <Tabs defaultValue="image">
        <TabsList className="bg-white/5 border border-white/10">
          <TabsTrigger value="image"><ImageIcon className="w-4 h-4 mr-2" /> Image Generator</TabsTrigger>
          <TabsTrigger value="chat"><Bot className="w-4 h-4 mr-2" /> Chatbot</TabsTrigger>
        </TabsList>
        <TabsContent value="image" className="mt-6"><ImageGen /></TabsContent>
        <TabsContent value="chat" className="mt-6"><Chatbot /></TabsContent>
      </Tabs>
    </div>);

}

function ImageGen() {
  const [prompt, setPrompt] = useState('');
  const [img, setImg] = useState('');
  const [busy, setBusy] = useState(false);

  const gen = () => {
    if (!prompt.trim()) return;
    setBusy(true);
    setImg(freeImageURL(prompt.trim()));
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Describe an image… e.g. neon Fortnite llama in a storm" className="bg-black/40 border-white/15 text-white" onKeyDown={(e) => e.key === 'Enter' && gen()} />
        <Button onClick={gen} disabled={busy} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">{busy ? 'Generating…' : 'Generate'}</Button>
      </div>
      <div className="aspect-video rounded-2xl bg-black/40 border border-white/10 flex items-center justify-center overflow-hidden">
        {busy ?
        <div className="flex flex-col items-center text-white/50"><Sparkles className="w-8 h-8 animate-pulse mb-2" /> Conjuring pixels…</div> :
        img ?
        <img
          src={img}
          alt="Generated"
          className="w-full h-full object-contain"
          onLoad={() => setBusy(false)}
          onError={() => { setBusy(false); setImg(''); }}
        /> :

        <p className="text-white/30">Your generated image appears here.</p>
        }
      </div>
    </div>);

}

function Chatbot() {
  const [messages, setMessages] = useState([{ role: 'assistant', text: 'Hey! I\'m Volt, the Voltage clan AI. Ask me anything.' }]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);

  const send = async () => {
    if (!input.trim() || busy) return;
    const userMsg = input.trim();
    const next = [...messages, { role: 'user', text: userMsg }];
    setMessages(next);
    setInput('');
    setBusy(true);
    try {
      const reply = await freeChat([
        { role: 'system', content: 'You are Volt, the friendly AI assistant for the Voltage Fortnite clan. Be upbeat, brief, and gamer-friendly.' },
        ...next.map((m) => ({ role: m.role, content: m.text })),
      ]);
      setMessages((m) => [...m, { role: 'assistant', text: reply }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'assistant', text: 'Sorry, I glitched. Try again.' }]);
    } finally {setBusy(false);}
    setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
  };

  return (
    <div className="flex flex-col h-[60vh]">
      <div className="flex-1 overflow-y-auto space-y-3 p-4 rounded-2xl bg-black/40 border border-white/10">
        {messages.map((m, i) =>
        <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${m.role === 'user' ? 'bg-white/10' : 'bg-gradient-to-br from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black'}`}>
              {m.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            <div className={`max-w-[75%] px-4 py-2 rounded-2xl text-sm ${m.role === 'user' ? 'bg-white/10' : 'bg-[hsl(var(--voltage-blue))]/15 border border-[hsl(var(--voltage-blue))]/30'}`}>{m.text}</div>
          </div>
        )}
        {busy && <p className="text-white/40 text-sm px-4">Volt is typing…</p>}
        <div ref={endRef} />
      </div>
      <div className="mt-3 flex gap-2">
        <Input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Ask Volt…" className="bg-black/40 border-white/15 text-white" />
        <Button onClick={send} disabled={busy} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Send className="w-4 h-4" /></Button>
      </div>
    </div>);

}