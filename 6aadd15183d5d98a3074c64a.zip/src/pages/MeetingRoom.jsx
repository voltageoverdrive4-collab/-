const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ExternalLink, Video } from 'lucide-react';
import RoomChat from '@/components/meetings/RoomChat';
import { ensureMember } from '@/lib/members';

// In-app view of a Meet room: details, one-click join, and a live room chat.
export default function MeetingRoom() {
  const { id } = useParams();
  const { user } = useAuth();
  const [room, setRoom] = useState(null);
  const [myMember, setMyMember] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setRoom(await db.entities.MeetRoom.get(id));
        setMyMember(await ensureMember(user));
      } finally {
        setLoading(false);
      }
    })();
  }, [id, user?.email]);

  const joinMeet = () => {
    window.open(room.meeting_url, '_blank', 'noopener=yes,width=1100,height=750');
  };

  if (loading) return <div className="p-10 text-white/50">Loading room…</div>;

  if (!room) {
    return (
      <div className="p-10 text-white/50">
        This room is no longer open. <Link to="/meetings" className="underline">Back to Meetings</Link>
      </div>
    );
  }

  return (
    <div className="p-6 sm:p-10 max-w-3xl mx-auto">
      <Link to="/meetings" className="inline-flex items-center gap-1.5 text-white/50 hover:text-white text-sm mb-4">
        <ArrowLeft className="w-4 h-4" /> Back to Meetings
      </Link>

      <div className="flex flex-wrap items-center gap-4">
        <h1 className="font-heading text-3xl font-black">{room.name}</h1>
        <Button onClick={joinMeet} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <Video className="w-4 h-4 mr-2" /> Join Meet
        </Button>
      </div>
      <p className="text-white/50 text-sm mt-2">Opened by {room.created_by_name || 'a clan member'}</p>
      <p className="text-white/40 text-xs mt-3 flex items-start gap-1.5">
        <ExternalLink className="w-3.5 h-3.5 mt-0.5 shrink-0" />
        Google doesn't allow Meet to be shown inside the app frame, so the call opens in a pop-up window right beside this page — the app and room chat stay open here.
      </p>

      <h2 className="font-heading text-xl font-black mt-8 mb-4">Room chat</h2>
      <RoomChat roomId={id} senderName={myMember?.username || user?.email || 'Clan member'} />
    </div>
  );
}