const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { ClipboardList, Send, Check, Clock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { withRetry } from '@/lib/apiRetry';
import FormsAdmin from '@/components/forms/FormsAdmin';

// Forms tab — admins build forms (Admin Enroll, Shop Publisher, anything);
// members fill them out and an admin reviews each response.
export default function Forms() {
  const { user } = useAuth();
  const [forms, setForms] = useState([]);
  const [myResponses, setMyResponses] = useState([]);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [submitting, setSubmitting] = useState(null);
  const isAdmin = user?.role === 'admin';
  const myName = user?.full_name || (user?.email || 'player').split('@')[0];

  const load = async () => {
    setLoading(true);
    setError(false);
    try {
      const [formPage, respPage] = await Promise.all([
        withRetry(() => db.entities.Form.filter({ active: true }, { sort: '-created_date', limit: 100 })),
        withRetry(() => db.entities.FormResponse.filter({ user_id: user.id }, { sort: '-created_date', limit: 200 })),
      ]);
      setForms(formPage.items);
      setMyResponses(respPage.items);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    load();
    const unsub = db.entities.Form.subscribe(() => load());
    return unsub;
  }, [user?.id]);

  const setAns = (formId, qi, val) =>
    setAnswers((p) => ({ ...p, [formId]: { ...(p[formId] || {}), [qi]: val } }));

  const submit = async (f) => {
    const qs = f.questions || [];
    if (qs.some((_, i) => !String(answers[f.id]?.[i] || '').trim())) {
      toast.error('Answer every question first');
      return;
    }
    setSubmitting(f.id);
    try {
      await withRetry(() => db.entities.FormResponse.create({
        form_id: f.id,
        form_title: f.title,
        user_id: user.id,
        username: myName,
        answers: qs.map((_, i) => String(answers[f.id][i]).trim()),
        status: 'pending',
      }));
      setAnswers((p) => ({ ...p, [f.id]: {} }));
      toast.success('Sent — an admin will review it');
      load();
    } catch {
      toast.error('Could not send — try again in a moment');
    } finally {
      setSubmitting(null);
    }
  };

  const responseFor = (f) => myResponses.find((r) => r.form_id === f.id);

  return (
    <div className="min-h-screen px-4 sm:px-8 py-10 max-w-4xl mx-auto">
      <div className="volt-rise">
        <h1 className="font-heading text-4xl sm:text-5xl font-black volt-gradient-text leading-none flex items-center gap-3">
          <ClipboardList className="w-9 h-9 text-[hsl(var(--voltage-yellow))]" /> Forms
        </h1>
        <p className="text-white/50 text-sm mt-3 tracking-wide">Clan enrollments and applications — fill one out and an admin reviews it</p>
      </div>

      {loading ? (
        <div className="space-y-3 mt-6 animate-pulse">
          {[0, 1].map((i) => <div key={i} className="h-40 bg-white/10 rounded-3xl" />)}
        </div>
      ) : error ? (
        <div className="volt-panel rounded-3xl mt-6 p-8 text-center text-white/60 text-sm">
          Forms are busy right now — try again in a moment.
          <div className="mt-3"><Button variant="outline" onClick={load} className="border-white/20 text-white/80">Retry</Button></div>
        </div>
      ) : forms.length === 0 ? (
        <div className="volt-panel rounded-3xl mt-6 p-10 text-center text-white/60 text-sm border-dashed">
          No forms open right now — check back soon.
        </div>
      ) : (
        <div className="space-y-4 mt-6">
          {forms.map((f, i) => {
            const r = responseFor(f);
            const showForm = !r || r.status === 'rejected';
            return (
              <div key={f.id} className="volt-panel volt-rise rounded-3xl p-5 sm:p-6" style={{ animationDelay: `${i * 0.07}s` }}>
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <h3 className="font-bold text-white/90">{f.title}</h3>
                  {r?.status === 'accepted' && (
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-300 rounded-full border border-emerald-300/30 bg-emerald-300/10 px-3 py-1">
                      <Check className="w-3 h-3" /> Accepted
                    </span>
                  )}
                  {r?.status === 'pending' && (
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-300 rounded-full border border-amber-300/30 bg-amber-300/10 px-3 py-1">
                      <Clock className="w-3 h-3 animate-pulse" /> Waiting for review
                    </span>
                  )}
                  {r?.status === 'rejected' && (
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-red-300 rounded-full border border-red-300/30 bg-red-300/10 px-3 py-1">
                      <X className="w-3 h-3" /> Rejected — try again
                    </span>
                  )}
                </div>
                {f.description && <p className="text-xs text-white/50 mt-1">{f.description}</p>}
                {showForm ? (
                  <div className="mt-4 space-y-3">
                    {(f.questions || []).map((q, qi) => (
                      <label key={qi} className="block">
                        <span className="text-xs font-semibold text-white/70">{q}</span>
                        <input
                          className="mt-1 w-full rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30 focus:border-[hsl(var(--voltage-yellow))]/60 focus:outline-none"
                          value={answers[f.id]?.[qi] || ''}
                          onChange={(e) => setAns(f.id, qi, e.target.value)}
                          placeholder="Your answer"
                        />
                      </label>
                    ))}
                    <Button
                      onClick={() => submit(f)}
                      disabled={submitting === f.id}
                      className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"
                    >
                      <Send className="w-4 h-4 mr-2" /> {submitting === f.id ? 'Sending…' : 'Send'}
                    </Button>
                  </div>
                ) : (
                  <p className="text-[11px] text-white/40 mt-3">You can resubmit if it gets rejected</p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {isAdmin && <FormsAdmin onReload={load} />}
    </div>
  );
}