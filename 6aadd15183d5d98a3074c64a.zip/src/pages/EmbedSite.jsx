const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { Button } from '@/components/ui/button';
import { ExternalLink, Maximize, Minimize, ShieldAlert } from 'lucide-react';
import SiteFavicon from '@/components/SiteFavicon';
import { fetchPageViaPublicProxy, prepareHtml } from '@/lib/embedProxy';

// Opens an embedded website tab. It tries the server-side anti-block proxy
// first, then a credit-free public proxy, and only falls back to a direct
// embed (which strict sites can block) when neither works.
export default function EmbedSite() {
  const { id } = useParams();
  const [site, setSite] = useState(null);
  // mode: 'loading' | 'proxy' | 'public' | 'direct' | 'error'
  const [mode, setMode] = useState('loading');
  const [html, setHtml] = useState('');
  const frameWrap = useRef(null);
  const [isFull, setIsFull] = useState(false);

  useEffect(() => {
    const onFsChange = () => setIsFull(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else frameWrap.current?.requestFullscreen?.();
  };

  useEffect(() => {
    let cancelled = false;
    setSite(null);
    setHtml('');
    setMode('loading');
    db.entities.EmbeddedSite.get(id)
      .then(async (s) => {
        setSite(s);
        // 1. server-side anti-block proxy
        try {
          const res = await db.functions.invoke('proxySite', { site_id: id });
          if (res.data?.html) {
            if (!cancelled) { setHtml(res.data.html); setMode('proxy'); }
            return;
          }
        } catch (e) {
          // server proxy unavailable — keep going
        }
        // 2. credit-free public proxy, fetched right in the browser
        const raw = await fetchPageViaPublicProxy(s.url);
        if (cancelled) return;
        if (raw) {
          setHtml(prepareHtml(raw, s.url));
          setMode('public');
          return;
        }
        // 3. direct embed
        setMode('direct');
      })
      .catch(() => { if (!cancelled) setMode('error'); });
    return () => { cancelled = true; };
  }, [id]);

  if (mode === 'error') {
    return (
      <div className="p-10 text-center text-white/50">
        This tab is no longer available. <Link to="/dashboard" className="underline">Back to home</Link>
      </div>
    );
  }
  if (mode === 'loading' || !site) return <p className="p-10 text-center text-white/40">Loading…</p>;

  return (
    <div ref={frameWrap} className="hub-tool-surface h-screen flex flex-col p-4 bg-[var(--holiday-bg)]">
      <div className="hub-toolbar flex items-center justify-between gap-3 mb-3 shrink-0">
        <h1 className="font-heading text-xl font-black truncate flex items-center gap-2">
          <SiteFavicon url={site.url} className="w-5 h-5" /> {site.name}
        </h1>
        <div className="flex gap-2 shrink-0">
          <Button size="sm" variant="outline" onClick={toggleFullscreen} className="border-white/20 text-white hover:bg-white/10">
            {isFull ? <Minimize className="w-4 h-4 mr-1" /> : <Maximize className="w-4 h-4 mr-1" />}
            {isFull ? 'Exit full screen' : 'Full screen'}
          </Button>
          {mode === 'direct' && (
            <span className="hidden sm:flex items-center gap-1.5 text-xs text-white/40 border border-white/10 rounded-md px-2 py-1">
              <ShieldAlert className="w-3.5 h-3.5" /> Direct mode — this site may block embedding
            </span>
          )}
          <a href={site.url} target="_blank" rel="noreferrer">
            <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10">
              <ExternalLink className="w-4 h-4 mr-1" /> Open in new tab
            </Button>
          </a>
        </div>
      </div>
      {mode === 'direct' ? (
        <iframe src={site.url} title={site.name} className="flex-1 w-full min-h-0 rounded-2xl border border-white/10 bg-white" />
      ) : (
        <iframe
          srcDoc={html}
          title={site.name}
          sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
          className="flex-1 w-full min-h-0 rounded-2xl border border-white/10 bg-white"
        />
      )}
    </div>
  );
}