const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Bug, Lightbulb, Send, Loader2, MessageSquareWarning } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { grantAchievement } from '@/lib/achievements';
import { withRetry } from '@/lib/apiRetry';

const STATUS_STYLES = {
  open: 'bg-blue-500/20 border-blue-400/40 text-blue-300',
  in_review: 'bg-yellow-500/20 border-yellow-400/40 text-yellow-300',
  resolved: 'bg-green-500/20 border-green-400/40 text-green-300',
  declined: 'bg-red-500/20 border-red-400/40 text-red-300',
};

export default function Feedback() {
  const { user } = useAuth();
  const [type, setType] = useState('bug');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [mine, setMine] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadMine = async () => {
    setLoading(true);
    try {
      // withRetry waits out the server's busy periods with growing pauses,
      // so a rate-limited moment no longer breaks the page
      setMine(await withRetry(() => db.entities.Feedback.list('-created_date', 50)));
    } catch {
      toast.error('Could not load your feedback — try again in a moment');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadMine(); }, []);

  const submit = async () => {
    if (!title.trim() || !description.trim()) {
      toast.error('Title and description are required');
      return;
    }
    setSaving(true);
    try {
      await db.entities.Feedback.create({
        type,
        title: title.trim(),
        description: description.trim(),
        submitted_by: user?.full_name || user?.email || '',
        email: user?.email || '',
      });
      grantAchievement(user, 'voice');
      toast.success(type === 'bug' ? 'Bug reported — thanks!' : 'Feature request submitted!');
      setTitle('');
      setDescription('');
      loadMine();
    } catch (e) {
      toast.error(e.message || 'Could not submit feedback');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 sm:p-10 max-w-4xl mx-auto">
      <h1 className="font-heading text-3xl font-black mb-6 flex items-center gap-2">
        <MessageSquareWarning className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> Feedback
      </h1>

      <div className="space-y-4 p-6 rounded-xl bg-white/5 border border-white/10">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setType('bug')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold border transition-all ${
              type === 'bug'
                ? 'bg-red-500/20 border-red-400/50 text-red-300'
                : 'bg-black/30 border-white/10 text-white/50 hover:text-white'
            }`}
          >
            <Bug className="w-4 h-4" /> Report a Bug
          </button>
          <button
            type="button"
            onClick={() => setType('feature')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold border transition-all ${
              type === 'feature'
                ? 'bg-[hsl(var(--voltage-blue))]/20 border-[hsl(var(--voltage-blue))]/50 text-[hsl(var(--voltage-blue))]'
                : 'bg-black/30 border-white/10 text-white/50 hover:text-white'
            }`}
          >
            <Lightbulb className="w-4 h-4" /> Request a Feature
          </button>
        </div>

        <div className="space-y-2">
          <Label className="text-white/80">Title</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={type === 'bug' ? 'What went wrong?' : 'What would you like to see?'}
            className="bg-black/40 border-white/15 text-white"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-white/80">Details</Label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            placeholder={type === 'bug' ? 'Steps to reproduce the bug, what happened, what you expected…' : 'Describe your idea — what should it do and why it would help the clan…'}
            className="bg-black/40 border-white/15 text-white"
          />
        </div>
        <Button onClick={submit} disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
          {saving ? 'Submitting…' : type === 'bug' ? 'Report Bug' : 'Send Request'}
        </Button>
      </div>

      <h2 className="font-bold text-lg mt-8 mb-3">My Feedback</h2>
      {loading ? (
        <div className="flex flex-col items-center py-10 text-white/50">
          <Loader2 className="w-7 h-7 animate-pulse mb-2" /> Loading your feedback…
        </div>
      ) : mine.length === 0 ? (
        <p className="text-white/40 text-center py-10">You haven't submitted any feedback yet.</p>
      ) : (
        <div className="space-y-3">
          {mine.map((f) => (
            <div key={f.id} className="p-4 rounded-xl bg-white/5 border border-white/10">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {f.type === 'bug' ? <Bug className="w-4 h-4 text-red-400" /> : <Lightbulb className="w-4 h-4 text-[hsl(var(--voltage-blue))]" />}
                  <span className="font-bold">{f.title}</span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_STYLES[f.status] || STATUS_STYLES.open}`}>
                  {(f.status || 'open').replace('_', ' ')}
                </span>
              </div>
              <p className="text-white/60 text-sm mt-2 whitespace-pre-wrap">{f.description}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}