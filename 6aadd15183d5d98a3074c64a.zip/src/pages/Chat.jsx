const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { Search, CornerUpLeft, Trash2 } from 'lucide-react';
import { containsBadWord, BOT_NAME } from '@/lib/moderation';
import { withRetry } from '@/lib/apiRetry';
import { grantAchievement } from '@/lib/achievements';
import { freeChat } from '@/lib/freeAIClient';
import { getAppSettings, saveAppSetting, saveAppSettings } from '@/lib/appSettings';
import { notifyAnnouncement } from '@/lib/welcomeBot';
import { fromDb } from '@/lib/time';
import { uploadImage, TEST_IMAGE } from '@/lib/imageHost';
import { claimCode } from '@/lib/redeemCodes';
import PollsPanel from '@/components/chat/PollsPanel';
import ChatChannelsPanel from '@/components/chat/ChatChannelsPanel';
import ChatComposer from '@/components/chat/ChatComposer';
import MessageReactions from '@/components/chat/MessageReactions';
import MessageReplies from '@/components/chat/MessageReplies';

const HERO_IMG = 'https://media.db.com/images/public/6aadd15183d5d98a3074c64a/efc6c8fd2_generated_771a3314.jpg';

// VoltBot answers questions even when nobody asks it to
const looksLikeQuestion = (t) =>
  /\?/.test(t) || /^(what|how|why|when|where|who|which|can|should|is|are|do|does|did|any|help|hey voltbot|voltbot)\b/i.test(t.trim());

export default function Chat() {
  const { user } = useAuth();
  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState('general');
  const [messages, setMessages] = useState([]);
  const [reactions, setReactions] = useState([]);
  const [text, setText] = useState('');
  const [member, setMember] = useState(null);
  const [memberMap, setMemberMap] = useState({});
  const [tagColors, setTagColors] = useState({});
  const [teamTags, setTeamTags] = useState({});
  const [headBadges, setHeadBadges] = useState({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [searching, setSearching] = useState(false);
  const [replies, setReplies] = useState([]);
  const [replyTo, setReplyTo] = useState(null);
  const [collapsed, setCollapsed] = useState(() => new Set());
  const [imageFile, setImageFile] = useState(null);
  const [imageLink, setImageLink] = useState('');
  const [sending, setSending] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [chatLocked, setChatLocked] = useState(false);
  const [imgbbKey, setImgbbKey] = useState('');
  // private bot replies for /code claims — these live only in this member's window
  const [codeNotes, setCodeNotes] = useState([]);
  const [testingUploads, setTestingUploads] = useState(false);
  const channelRef = useRef('general');
  const memberRef = useRef(null);
  const lastSentRef = useRef(0);
  const imgbbKeyRef = useRef('');

  const myName = member?.username || user?.full_name || (user?.email || 'player').split('@')[0];
  const isClanAdmin = user?.role === 'admin' || !!member?.is_admin;

  // general also catches older messages that have no channel stored yet.
  // Members who joined later only see messages sent after they joined.
  const queryFor = (channel) => {
    const q = channel === 'general'
      ? { $or: [{ channel: 'general' }, { channel: { $exists: false } }] }
      : { channel };
    const joined = memberRef.current?.created_date;
    if (joined) q.created_date = { $gte: joined };
    return q;
  };

  const loadMessages = async (channel) => {
    setLoading(true);
    setLoadError(false);
    try {
      // messages and reactions arrive together — no artificial waits, so the
      // channel paints in well under a second
      const [page, reactionList] = await Promise.all([
        withRetry(() => db.entities.ChatMessage.filter(queryFor(channel), { sort: '-created_date', limit: 100 })),
        withRetry(() => db.entities.ChatReaction.list('-created_date', 500)),
      ]);
      // replies (messages with reply_to_id) render nested under their original
      const all = page.items;
      setMessages(all.filter((m) => !m.reply_to_id));
      setReplies(all.filter((m) => !!m.reply_to_id).reverse());
      setReactions(reactionList);
    } catch (e) {
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const members = await withRetry(() => db.entities.Member.list());
        // set the join date before loading messages so newer members only
        // see history from after they joined
        const me = members.find((mem) => mem.email?.toLowerCase() === user?.email?.toLowerCase()) || null;
        memberRef.current = me;
        setMember(me);
        await loadMessages('general');
        // everything the side panels need arrives in one parallel round —
        // no request-by-request delays
        const [tagRecords, channelList, teams, settings] = await Promise.all([
          withRetry(() => db.entities.ChatTag.list()),
          withRetry(() => db.entities.ChatChannel.list('name', 50)),
          withRetry(() => db.entities.Team.list()),
          getAppSettings(['chat_cooldown', 'chat_locked', 'imgbb_key']).catch(() => ({})),
        ]);
        const map = {};
        for (const mem of members) {
          if (mem.email) map[mem.email.toLowerCase()] = mem;
          if (mem.username) map[mem.username.toLowerCase()] = mem;
        }
        const colors = {};
        for (const t of tagRecords) if (t.color) colors[t.name] = t.color;
        const tTags = {};
        const ownerTeams = {};
        for (const t of teams) if (t.owner_user_id) ownerTeams[t.owner_user_id] = t;
        for (const t of teams) {
          for (const mid of (t.member_ids || [])) {
            tTags[mid] = [...(tTags[mid] || []), ...(t.tags || [])];
          }
        }
        // owners wear "<their tag> HEAD" — team owners wear their team's tag,
        // website owners (set in the admin panel) wear their own clan tag
        const badges = {};
        for (const mem of members) {
          const labels = [];
          const team = mem.user_id ? ownerTeams[mem.user_id] : null;
          if (team) labels.push(`${(team.tags || [])[0] || ''} HEAD`.trim());
          if (mem.is_owner) labels.push('HEAD');
          if (labels.length) badges[mem.id] = [...new Set(labels)];
        }
        setHeadBadges(badges);
        setMemberMap(map);
        setTagColors(colors);
        setTeamTags(tTags);
        setChannels(channelList);
        // chat admin controls + the Cloudinary upload connection
        const secs = parseInt(settings.chat_cooldown || '0', 10) || 0;
        setCooldown(secs);
        setChatLocked(settings.chat_locked === 'true');
        const k = settings.imgbb_key || '';
        setImgbbKey(k);
        imgbbKeyRef.current = k;
      } catch (e) {
        setLoadError(true);
        setLoading(false);
      }
    })();

    const unsubscribe = db.entities.ChatMessage.subscribe((event) => {
      if (event.type === 'create') {
        if ((event.data.channel || 'general') !== channelRef.current) return;
        if (event.data.reply_to_id) setReplies((prev) => [...prev, event.data]);
        else setMessages((prev) => [event.data, ...prev.filter((m) => m.id !== event.data.id)]);
      } else if (event.type === 'update') {
        const patch = (m) => (m.id === event.data.id ? event.data : m);
        setMessages((prev) => prev.map(patch));
        setReplies((prev) => prev.map(patch));
      } else if (event.type === 'delete') {
        setMessages((prev) => prev.filter((m) => m.id !== event.data.id));
        setReplies((prev) => prev.filter((m) => m.id !== event.data.id));
      }
    });
    const unsubReactions = db.entities.ChatReaction.subscribe((event) => {
      if (event.type === 'create') setReactions((prev) => [...prev, event.data]);
      else if (event.type === 'delete') setReactions((prev) => prev.filter((r) => r.id !== event.data.id));
    });
    return () => {
      unsubscribe();
      unsubReactions();
    };
  }, [user?.email]);

  // live search across the active channel — runs on the server, so it finds
  // messages beyond the newest page too
  useEffect(() => {
    const term = search.trim();
    if (!term) { setSearchResults(null); return; }
    setSearching(true);
    const t = setTimeout(async () => {
      try {
        const page = await db.entities.ChatMessage.filter(
          { ...queryFor(channelRef.current), text: { $regex: term, $options: 'i' } },
          { sort: '-created_date', limit: 50 }
        );
        setSearchResults(page.items);
      } catch {
        toast.error('Search is busy — try again in a moment');
      } finally {
        setSearching(false);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [search]);

  const switchChannel = (name) => {
    channelRef.current = name;
    setActiveChannel(name);
    setSearch('');
    setReplyTo(null);
    loadMessages(name);
  };

  const addChannel = (name) => {
    const clean = (name || '').trim().toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    if (!clean || clean === 'general') { toast.error('Pick another channel name'); return; }
    if (channels.some((c) => c.name === clean)) { toast.error('That channel already exists'); return; }
    withRetry(() => db.entities.ChatChannel.create({ name: clean }))
      .then(() => withRetry(() => db.entities.ChatChannel.list('name', 50)))
      .then((list) => { setChannels(list); switchChannel(clean); toast.success(`#${clean} created`); })
      .catch((e) => toast.error(e.message || 'Could not create the channel — admins only'));
  };

  const delChannel = (name) => {
    const rec = channels.find((c) => c.name === name);
    if (!rec) return;
    withRetry(() => db.entities.ChatChannel.delete(rec.id))
      .then(() => {
        setChannels((prev) => prev.filter((c) => c.name !== name));
        if (channelRef.current === name) switchChannel('general');
        toast.success(`#${name} deleted`);
      })
      .catch(() => toast.error('Could not delete the channel — admins only'));
  };

  const patchChannel = (name, patch) => {
    const rec = channels.find((c) => c.name === name);
    if (!rec) return;
    withRetry(() => db.entities.ChatChannel.update(rec.id, patch))
      .then(() => {
        setChannels((prev) => prev.map((c) => (c.id === rec.id ? { ...c, ...patch } : c)));
        toast.success(`#${name} updated`);
      })
      .catch(() => toast.error('Could not update the channel — try again in a moment'));
  };

  // chat admin controls — wait time between everyone's messages, or a full chat lock
  const saveCooldown = async (input) => {
    const secs = Math.max(0, Math.min(60, parseInt(input || '0', 10) || 0));
    try {
      await saveAppSetting('chat_cooldown', secs);
      setCooldown(secs);
      toast.success(secs > 0 ? `Members now wait ${secs}s between messages` : 'Wait time removed');
    } catch { toast.error('Could not save — try again'); }
  };

  const toggleLock = async () => {
    try {
      await saveAppSetting('chat_locked', !chatLocked);
      setChatLocked(!chatLocked);
      toast.success(!chatLocked ? 'Chat locked for members' : 'Chat unlocked');
    } catch { toast.error('Could not save — try again'); }
  };

  // picture uploads run on ImgBB with one free API key — we prove the key
  // with a real test upload before saving it, so a bad key can never look
  // connected while uploads silently fail in chat
  const saveImgbb = async (input) => {
    const key = (input || '').trim();
    setTestingUploads(true);
    try {
      if (key) await uploadImage(TEST_IMAGE, key);
      await saveAppSetting('imgbb_key', key);
      setImgbbKey(key);
      imgbbKeyRef.current = key;
      toast.success(key ? 'Picture uploads connected' : 'Picture uploads disconnected');
    } catch (err) {
      toast.error(err?.message || 'Could not connect picture uploads — try again');
    } finally {
      setTestingUploads(false);
    }
  };

  // VoltBot now thinks right in the member's browser on free open models —
  // no server or credits needed — then posts its answer into the channel.
  const askVoltBot = async (question, channel) => {
    try {
      const context = messages.slice(0, 6).reverse().map((m) => `${m.username}: ${m.text}`).join('\n');
      const answer = (await freeChat([{
        role: 'user',
        content: `You are VoltBot, the friendly AI helper inside the "Voltage" Fortnite clan's chat. A member asked: "${question}".${context ? ` Recent chat for context:\n${context}` : ''}\nAnswer helpfully in 1-3 short sentences with a casual gamer tone. Fortnite clan vibes. Keep it clean.`,
      }])).slice(0, 500);
      if (!answer) return;
      await withRetry(() => db.entities.ChatMessage.create({ username: BOT_NAME, user_id: user?.id, text: answer, channel }));
    } catch (e) { /* the bot stays silent when it can't answer */ }
  };

  // /code NAME claims a redeem code: the message is never posted to the
  // channel, and the bot's reply renders only for the member who claimed it
  const runCodeCommand = async (cmd) => {
    const stamp = Date.now();
    // the member's own /code message shows privately for them, newest first
    // at the top of the river, right where new messages land
    const echoId = `note-u-${stamp}`;
    const botId = `note-b-${stamp}`;
    setCodeNotes((prev) => [
      { id: echoId, text: cmd, mine: true },
      { id: botId, text: 'Checking code…' },
      ...prev,
    ]);
    const res = await claimCode({ user, member, name: cmd.slice(5).trim() });
    setCodeNotes((prev) => prev.map((n) => (n.id === botId ? { ...n, text: res.text, ok: res.ok } : n)));
    if (res.ok && res.memberPatch) setMember((prev) => (prev ? { ...prev, ...res.memberPatch } : prev));
  };

  const send = async (e) => {
    e.preventDefault();
    const cmd = text.trim();
    if (cmd.toLowerCase().startsWith('/code')) {
      setText('');
      runCodeCommand(cmd);
      return;
    }
    if (!text.trim() && !imageFile && !imageLink.trim()) return;
    if ((readOnly || chatLocked) && !isAdmin) {
      if (chatLocked && !readOnly) toast.error('Chat is locked by an admin right now');
      return;
    }
    const t = text.trim();
    // admin-set wait time between messages — stops spammers without muting anyone
    const waitLeft = cooldown * 1000 - (Date.now() - lastSentRef.current);
    if (cooldown > 0 && waitLeft > 0) {
      toast.error(`Slow down — wait ${Math.ceil(waitLeft / 1000)}s between messages`);
      return;
    }
    setText('');
    setSending(true);
    try {
      let image_url = '';
      if (imageFile) {
        if (!imgbbKeyRef.current) {
          setText(t);
          toast.error('Picture files need ImgBB — an admin can connect it with one free API key in Chat Admin Controls, or paste a picture link');
          return;
        }
        try {
          // straight to the clan's ImgBB — no integration credits
          image_url = await uploadImage(imageFile, imgbbKeyRef.current);
        } catch (err) {
          setText(t);
          toast.error(`The picture did not upload — ${err?.message || 'try again or paste a picture link'}`);
          return;
        }
        setImageFile(null);
      } else if (imageLink.trim()) {
        image_url = imageLink.trim();
        setImageLink('');
      }
      await withRetry(() => db.entities.ChatMessage.create({ username: myName, user_id: user?.id, text: t, channel: activeChannel, image_url, reply_to_id: replyTo?.id || '' }));
      lastSentRef.current = Date.now();
      if (replyTo) grantAchievement(user, 'quick-reply');
      setReplyTo(null);
      if (image_url) grantAchievement(user, 'picture-perfect');
      // posts in #announcements ping every member's notification bell — best-effort
      if (activeChannel === 'announcements') notifyAnnouncement(t, myName, user?.id).catch(() => {});
      // phone pings for members on the installed app — best-effort, never blocks the chat
      db.functions.invoke('pushChatNotification', { channel: activeChannel, username: myName, text: t }).catch(() => {});
      grantAchievement(user, 'first-chat');
      // VoltBot auto-moderation: flag bad language for admin review
      if (containsBadWord(t)) {
        await withRetry(() => db.entities.ModerationAlert.create({ username: myName, user_id: user?.id, text: t }));
      }
      if (looksLikeQuestion(t)) askVoltBot(t, activeChannel);
    } catch (e) {
      setText(t);
      toast.error(/rate limit/i.test(e?.message || '') ? 'Chat is busy — try again in a moment' : (e?.message || 'Could not send the message'));
    } finally {
      setSending(false);
    }
  };

  const del = async (id) => {
    setMessages((prev) => prev.filter((m) => m.id !== id));
    await withRetry(() => db.entities.ChatMessage.delete(id));
  };

  const banned = member?.banned_from_chat;
  const isAdmin = user?.role === 'admin';
  // admins can hide channels from members or make them view-only
  // private channels: only picked members see them; admins always see everything
  const visibleChannels = isAdmin
    ? channels
    : channels.filter((c) => !c.hidden && (!(c.allowed_user_ids || []).length || (c.allowed_user_ids || []).includes(user?.id)));
  const activeRec = channels.find((c) => c.name === activeChannel);
  const readOnly = !!activeRec?.read_only;

  // "2:41 PM" for messages sent today, otherwise "Oct 8, 2:41 PM"
  const timeOf = (m) => {
    if (!m.created_date) return '';
    const d = fromDb(m.created_date);
    if (!d) return '';
    const time = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    const sameDay = new Date().toDateString() === d.toDateString();
    return sameDay ? time : `${d.toLocaleDateString([], { month: 'short', day: 'numeric' })}, ${time}`;
  };

  // resolve a stored username to the member's gamertag (old messages may store an email)
  const displayName = (m) => {
    const u = m.username || 'unknown';
    const rec = memberMap[u.toLowerCase()];
    if (rec) return rec.username;
    return u.includes('@') ? u.split('@')[0] : u;
  };

  return (
    <div className="holo min-h-screen">
      <img className="holo-bg chat-backdrop" src={HERO_IMG} alt="" />
      <div className="holo-scrim chat-backdrop" />
      <div className="holo-wrap">
        <div className="head r" style={{ animationDelay: '.2s' }}>
          <div>
            <h1>Clan <span>Chat</span></h1>
            <div className="sub"><span className="dot" />Real-time — messages, reactions, replies and pictures</div>
          </div>
        </div>

        <div className="chat-grid">
          <ChatChannelsPanel
            channels={[{ name: 'general' }, ...visibleChannels]}
            activeChannel={activeChannel}
            onSwitch={switchChannel}
            isAdmin={isAdmin}
            isClanAdmin={isClanAdmin}
            onAddChannel={addChannel}
            onDeleteChannel={delChannel}
            onPatchChannel={patchChannel}
            cooldown={cooldown}
            chatLocked={chatLocked}
            onSaveCooldown={saveCooldown}
            onToggleLock={toggleLock}
            imgbbKey={imgbbKey}
            onSaveImgbb={saveImgbb}
            testingUploads={testingUploads}
            members={Object.values(memberMap).filter((m) => m.user_id).filter((m, i, arr) => arr.findIndex((x) => x.id === m.id) === i)}
          />

          <div className="r chat-column" style={{ animationDelay: '.5s' }}>
            <div className="chat-top-controls">
              {banned ? (
                <div className="status"><div className="st e">You are banned from chat.</div></div>
              ) : readOnly && !isAdmin ? (
                <div className="status"><div className="st">This channel is view-only — you can read but not post.</div></div>
              ) : (
                <ChatComposer
                  text={text}
                  setText={setText}
                  onSend={send}
                  sending={sending}
                  activeChannel={activeChannel}
                  replyTo={replyTo}
                  clearReply={() => setReplyTo(null)}
                  replyName={replyTo ? displayName(replyTo) : ''}
                  imageFile={imageFile}
                  setImageFile={setImageFile}
                  imageLink={imageLink}
                  setImageLink={setImageLink}
                  cloudConfigured={!!imgbbKey}
                />
              )}
              <div className="search">
                <Search />
                <input
                  className="inp"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={`Search #${activeChannel}…`}
                />
              </div>
            </div>
            <div className="river">
              {codeNotes.map((n) => {
                if (n.mine) return (
                  <div key={n.id} className="msg">
                    {member?.avatar_url ? (
                      <img src={member.avatar_url} alt="" className="av v" />
                    ) : (
                      <div className="av v flex items-center justify-center font-bold text-lg bg-gradient-to-br from-holo-primary to-holo-secondary text-holo-base">{myName[0]?.toUpperCase()}</div>
                    )}
                    <div className="mb">
                      <div className="mh">
                        <span className="nm">{myName}</span>
                        <span className="pill v">Only you see this</span>
                      </div>
                      <p className="tx">{n.text}</p>
                    </div>
                  </div>
                );
                return (
                  <div key={n.id} className="msg">
                    <div className="av flex items-center justify-center font-bold text-lg bg-holo-secondary/30">V</div>
                    <div className="mb">
                      <div className="mh">
                        <span className="nm">{BOT_NAME}</span>
                        <span className="pill">BOT</span>
                        <span className="pill v">Only you see this</span>
                      </div>
                      <p className="tx">{n.text}</p>
                    </div>
                  </div>
                );
              })}
              {(searchResults || messages).map((m) => {
                const rec = memberMap[(m.username || '').toLowerCase()];
                const isBot = m.username === BOT_NAME;
                return (
                  <div key={m.id} className="msg">
                    {rec?.avatar_url ? (
                      <img src={rec.avatar_url} alt="" className={`av ${isBot ? '' : 'v'}`} />
                    ) : (
                      <div className={`av ${isBot ? '' : 'v'} flex items-center justify-center font-bold text-lg ${isBot ? 'bg-holo-secondary/30' : 'bg-gradient-to-br from-holo-primary to-holo-secondary text-holo-base'}`}>
                        {displayName(m)[0]?.toUpperCase()}
                      </div>
                    )}
                    <div className="mb">
                      <div className="mh">
                        <span className="nm">{displayName(m)}</span>
                        {rec?.is_admin && <span className="pill s">ADMIN</span>}
                        {(rec ? [...new Set([...(rec.tags || []), ...(teamTags[rec.id] || [])])].filter((t) => !(rec.hidden_tags || []).includes(t)) : []).map((t) => (
                          <span key={t} className="pill d" style={tagColors[t] ? { backgroundColor: `${tagColors[t]}26`, color: tagColors[t], borderColor: `${tagColors[t]}66` } : undefined}>{t}</span>
                        ))}
                        {(rec ? headBadges[rec.id] || [] : []).map((lbl) => (
                          <span key={lbl} className="pill v">👑 {lbl}</span>
                        ))}
                        {isBot && <span className="pill">BOT</span>}
                        {timeOf(m) && <span className="tm">{timeOf(m)}</span>}
                      </div>
                      {m.text && <p className="tx">{m.text}</p>}
                      {m.image_url && (
                        <a href={m.image_url} target="_blank" rel="noreferrer">
                          <img src={m.image_url} alt="shared picture" className="shot" />
                        </a>
                      )}
                      <div className="acts">
                        <MessageReactions messageId={m.id} user={user} reactions={reactions} myName={myName} />
                        <button onClick={() => setReplyTo(m)} className="mini"><CornerUpLeft />Reply</button>
                        {(isAdmin || m.user_id === user?.id) && (
                          <button onClick={() => del(m.id)} className="mini x" title="Delete"><Trash2 /></button>
                        )}
                      </div>
                      <MessageReplies
                        message={m}
                        replies={replies.filter((r) => r.reply_to_id === m.id)}
                        collapsed={collapsed.has(m.id)}
                        onToggle={() => setCollapsed((prev) => {
                          const next = new Set(prev);
                          if (next.has(m.id)) next.delete(m.id); else next.add(m.id);
                          return next;
                        })}
                        memberMap={memberMap}
                        displayName={displayName}
                        isAdmin={isAdmin}
                        userId={user?.id}
                        onReply={setReplyTo}
                        timeOf={timeOf}
                        onDelete={del}
                      />
                    </div>
                  </div>
                );
              })}
              <div className="status">
                {loading && <div className="st l">Loading messages…</div>}
                {searching && <div className="st l">Searching…</div>}
                {searchResults && !searching && searchResults.length === 0 && (
                  <div className="st">No messages matched &quot;{search}&quot;.</div>
                )}
                {!loading && loadError && (
                  <div className="st e">
                    Chat is busy right now — please try again in a moment.
                    <button className="out" onClick={() => loadMessages(activeChannel)}>Retry</button>
                  </div>
                )}
                {!loading && !loadError && !searchResults && messages.length === 0 && (
                  <div className="st">No messages yet — say hello!</div>
                )}
              </div>

            </div>

          </div>

          <div className="panel r" style={{ animationDelay: '.65s' }}>
            <PollsPanel user={user} myName={myName} isAdmin={isAdmin} />
          </div>
        </div>
      </div>
    </div>
  );
}