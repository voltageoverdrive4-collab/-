import React from 'react';
import { useActiveHoliday } from '@/lib/useHoliday';
import HolidayRoom from '@/components/holiday/HolidayRoom';
import { ROOMS } from '@/lib/holidayRooms';

// Generic seasonal tab for every holiday without its own dedicated route.
export default function HolidayFest() {
  const holiday = useActiveHoliday();
  if (!holiday || !ROOMS[holiday.key]) {
    return <div className="p-10 text-center text-white/50">No holiday fest right now — check back during the next one!</div>;
  }
  return <HolidayRoom holidayKey={holiday.key} />;
}