const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { Store, ShoppingBag, Search, Check, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { withRetry } from '@/lib/apiRetry';
import ShopItemCard from '@/components/shop/ShopItemCard';
import SellerPanel from '@/components/shop/SellerPanel';

const PUBLISHER_TEAM = 'Shop Publisher';

// Clan Shop — members buy what Shop Publishers list (admins publish each
// listing first). No online payments yet: buying places the order with the
// seller, who marks it done once they deliver. Items count down as they
// sell and show Sold Out when the last one goes.
export default function ClanShop() {
  const { user } = useAuth();
  const [cats, setCats] = useState([]);
  const [items, setItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [myMember, setMyMember] = useState(null);
  const [publisherTeam, setPublisherTeam] = useState(null);
  const [cat, setCat] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const isAdmin = user?.role === 'admin';
  const myName = user?.full_name || (user?.email || 'player').split('@')[0];

  // the load reads the live filters through refs so the realtime
  // subscriptions always reload with the search and category applied
  const catRef = useRef(cat);
  const searchRef = useRef(search);
  catRef.current = cat;
  searchRef.current = search;

  const load = async () => {
    setLoading(true);
    setError(false);
    try {
      const query = { status: 'published' };
      if (catRef.current !== 'all') query.category = catRef.current;
      const term = searchRef.current.trim();
      if (term) query.title = { $regex: term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
      const [catPage, itemPage, orderPage, members, teams] = await Promise.all([
        withRetry(() => db.entities.ShopCategory.filter({}, { sort: 'name', limit: 100 })),
        withRetry(() => db.entities.ShopItem.filter(query, { sort: '-created_date', limit: 100 })),
        withRetry(() => db.entities.ShopOrder.filter({ buyer_user_id: user.id }, { sort: '-created_date', limit: 50 })),
        withRetry(() => db.entities.Member.filter({ email: user.email })),
        withRetry(() => db.entities.Team.filter({ name: PUBLISHER_TEAM }, { limit: 10 })),
      ]);
      setCats(catPage.items);
      setItems(itemPage.items);
      setOrders(orderPage.items);
      setMyMember(members[0] || null);
      setPublisherTeam(teams[0] || null);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    load();
    const unsub = db.entities.ShopItem.subscribe(() => load());
    const unsubOrders = db.entities.ShopOrder.subscribe(() => load());
    return () => { unsub(); unsubOrders(); };
  }, [user?.id]);

  // a new search term or category re-runs the shelf filter (debounced)
  useEffect(() => {
    const t = setTimeout(() => load(), 300);
    return () => clearTimeout(t);
  }, [cat, search]);

  // only the Shop Publisher team (or admins) can list items
  const isPublisher = isAdmin || !!(publisherTeam && (publisherTeam.member_ids || []).includes(myMember?.id));

  const buy = async (item) => {
    const left = (item.quantity || 1) - (item.sold || 0);
    if (left <= 0) { toast.error('That one is sold out'); return; }
    try {
      // one goes off the shelf the moment the order is placed
      await withRetry(() => db.entities.ShopItem.update(item.id, { sold: (item.sold || 0) + 1 }));
      await withRetry(() => db.entities.ShopOrder.create({
        item_id: item.id,
        item_title: item.title,
        price: item.price,
        seller_user_id: item.seller_user_id,
        seller_name: item.seller_name,
        buyer_user_id: user.id,
        buyer_username: myName,
        status: 'pending',
      }));
      toast.success(`Order sent to ${item.seller_name || 'the seller'} — they confirm once they deliver`);
      load();
    } catch {
      toast.error('Could not place the order — try again');
    }
  };

  const removeListing = async (item) => {
    try {
      await withRetry(() => db.entities.ShopItem.delete(item.id));
      toast.success('Listing removed from the shop');
      load();
    } catch {
      toast.error('Could not remove the listing — try again');
    }
  };

  return (
    <div className="min-h-screen px-4 sm:px-8 py-10 max-w-6xl mx-auto">
      <div className="volt-rise">
        <h1 className="font-heading text-4xl sm:text-5xl font-black volt-gradient-text leading-none flex items-center gap-3">
          <Store className="w-9 h-9 text-[hsl(var(--voltage-yellow))]" /> Clan Shop
        </h1>
        <p className="text-white/50 text-sm mt-3 tracking-wide">
          Buy from clan sellers{!isPublisher && ' — want to sell? Enroll in the Shop Publisher form'}
        </p>
      </div>

      <div className="relative mt-6 volt-rise" style={{ animationDelay: '.05s' }}>
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--voltage-yellow))]" />
        <input
          className="w-full rounded-2xl bg-black/40 border border-white/15 pl-11 pr-4 py-3 text-sm text-white/90 placeholder:text-white/30 focus:border-[hsl(var(--voltage-yellow))]/60 focus:outline-none"
          placeholder="Search the shop…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {cats.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-4 volt-rise" style={{ animationDelay: '.1s' }}>
          {[{ id: 'all', name: 'All' }, ...cats].map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.name === 'All' ? 'all' : c.name)}
              className={`text-xs font-bold rounded-full px-4 py-1.5 border transition-all ${
                (c.name === 'All' ? cat === 'all' : cat === c.name)
                  ? 'bg-[hsl(var(--voltage-yellow))] text-black border-[hsl(var(--voltage-yellow))]'
                  : 'text-white/60 border-white/15 hover:border-[hsl(var(--voltage-yellow))]/50 hover:text-white'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      )}

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6 animate-pulse">
          {[0, 1, 2].map((i) => <div key={i} className="h-72 bg-white/10 rounded-3xl" />)}
        </div>
      ) : error ? (
        <div className="volt-panel rounded-3xl mt-6 p-8 text-center text-white/60 text-sm">
          The shop is busy right now — try again in a moment.
          <div className="mt-3"><Button variant="outline" onClick={load} className="border-white/20 text-white/80">Retry</Button></div>
        </div>
      ) : items.length === 0 ? (
        <div className="volt-panel rounded-3xl mt-6 p-10 text-center text-white/60 text-sm border-dashed">
          {search ? `Nothing matches "${search}"` : 'Nothing on the shelf yet.'}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
          {items.map((item, i) => (
            <div key={item.id} className="volt-rise" style={{ animationDelay: `${i * 0.05}s` }}>
              <ShopItemCard
                item={item}
                canBuy={item.seller_user_id !== user.id}
                onBuy={() => buy(item)}
                onRemove={isAdmin ? () => removeListing(item) : undefined}
              />
            </div>
          ))}
        </div>
      )}

      {orders.length > 0 && (
        <div className="volt-panel rounded-3xl mt-6 p-4 sm:p-6">
          <div className="text-xs font-bold tracking-[0.2em] uppercase text-[hsl(var(--voltage-yellow))] mb-3 flex items-center gap-2">
            <ShoppingBag className="w-4 h-4" /> My orders
          </div>
          <div className="space-y-2">
            {orders.map((o) => (
              <div key={o.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm text-white/85">{o.item_title} <span className="text-white/40">· ${Number(o.price).toFixed(2)}</span></div>
                  <div className="text-[11px] text-white/40">from {o.seller_name || 'the seller'}</div>
                </div>
                {o.status === 'completed' ? (
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-300 rounded-full border border-emerald-300/30 bg-emerald-300/10 px-3 py-1">
                    <Check className="w-3 h-3" /> Completed
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-300 rounded-full border border-amber-300/30 bg-amber-300/10 px-3 py-1">
                    <Clock className="w-3 h-3 animate-pulse" /> Waiting for the seller
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {isPublisher && <SellerPanel isAdmin={isAdmin} categories={cats} onChanged={load} />}
    </div>
  );
}