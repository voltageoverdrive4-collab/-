const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { Swords, Zap, Award, Check, Gamepad2, Paperclip, Camera, X, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { withRetry } from '@/lib/apiRetry';
import { getAppSettings } from '@/lib/appSettings';
import { uploadProof } from '@/lib/proofHost';
import QuestAdmin from '@/components/quests/QuestAdmin';
import QuestLeaderboard from '@/components/quests/QuestLeaderboard';

const today = () => new Date().toISOString().slice(0, 10);

// Daily Quests tab — the clan's gaming challenge board. Admins set up quests;
// every member completes them once a day to earn XP and badge rewards.
// Quests can demand photo or video proof before they count.
export default function Quests() {
  const { user } = useAuth();
  const [quests, setQuests] = useState([]);
  const [claimedToday, setClaimedToday] = useState([]);
  const [todayStatus, setTodayStatus] = useState({});
  const [xpTotal, setXpTotal] = useState(0);
  const [badges, setBadges] = useState(0);
  const [member, setMember] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [claiming, setClaiming] = useState(null);
  const [proofFiles, setProofFiles] = useState({});
  const [uploadSettings, setUploadSettings] = useState({ imgbb_key: '', cloudinary_cloud: '', cloudinary_preset: '' });
  const isAdmin = user?.role === 'admin';
  const myName = user?.full_name || (user?.email || 'player').split('@')[0];

  const load = async () => {
    setLoading(true);
    setError(false);
    try {
      const [questPage, donePage, xpAgg, badgeCount, members] = await Promise.all([
        withRetry(() => db.entities.DailyQuest.filter({}, { sort: '-created_date', limit: 100 })),
        withRetry(() => db.entities.QuestCompletion.filter({ user_id: user.id, completed_day: today(), status: { $ne: 'rejected' } }, { limit: 100 })),
        withRetry(() => db.entities.QuestCompletion.aggregate({ query: { user_id: user.id, status: 'accepted' }, sum: 'xp_earned' })),
        withRetry(() => db.entities.QuestCompletion.count({ user_id: user.id, status: 'accepted', badge_earned: { $ne: '' } })),
        withRetry(() => db.entities.Member.filter({ email: user.email })),
      ]);
      setQuests(questPage.items);
      setClaimedToday(donePage.items.map((c) => c.quest_id));
      const st = {};
      for (const c of donePage.items) st[c.quest_id] = c.status || 'pending';
      setTodayStatus(st);
      setXpTotal(xpAgg.rows?.[0]?.sum_xp_earned || 0);
      setBadges(badgeCount);
      setMember(members[0] || null);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    load();
    // proof uploads ride the clan's free ImgBB (photos) + Cloudinary (videos)
    getAppSettings(['imgbb_key', 'cloudinary_cloud', 'cloudinary_preset'])
      .then((s) => setUploadSettings({
        imgbb_key: s.imgbb_key || '',
        cloudinary_cloud: s.cloudinary_cloud || '',
        cloudinary_preset: s.cloudinary_preset || '',
      }))
      .catch(() => {});
    const unsub = db.entities.DailyQuest.subscribe(() => load());
    // when an admin accepts a quest, the XP lands here instantly
    const unsubDone = db.entities.QuestCompletion.subscribe(() => load());
    return () => { unsub(); unsubDone(); };
  }, [user?.id]);

  const pickProof = (questId) => (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!/^image\//.test(f.type) && !/^video\//.test(f.type)) {
      toast.error('Only photos and videos count as proof');
      return;
    }
    setProofFiles((prev) => ({ ...prev, [questId]: f }));
  };

  const clearProof = (questId) => setProofFiles((prev) => {
    const next = { ...prev };
    delete next[questId];
    return next;
  });

  const claim = async (q) => {
    if (claimedToday.includes(q.id)) return;
    if (q.proof_required && !proofFiles[q.id]) {
      toast.error('This quest needs proof — attach a photo or video first');
      return;
    }
    setClaiming(q.id);
    try {
      let proof_url = '';
      if (q.proof_required) {
        try {
          proof_url = await uploadProof(
            proofFiles[q.id],
            uploadSettings.imgbb_key,
            uploadSettings.cloudinary_cloud,
            uploadSettings.cloudinary_preset
          );
        } catch (err) {
          toast.error(err?.message || 'The proof did not upload — try again');
          return;
        }
      }
      await withRetry(() => db.entities.QuestCompletion.create({
        user_id: user.id,
        username: myName,
        quest_id: q.id,
        quest_title: q.title,
        xp_earned: q.xp_reward || 0,
        badge_earned: q.reward_badge || '',
        proof_url,
        completed_day: today(),
      }));
      // completions wait for an admin to accept them — XP, badges and the
      // leaderboard only count once the admin approves it
      if (q.proof_required) clearProof(q.id);
      setClaimedToday((prev) => [...prev, q.id]);
      setTodayStatus((prev) => ({ ...prev, [q.id]: 'pending' }));
      toast.success('Quest submitted — it counts once an admin accepts it');
    } catch {
      toast.error('Could not save your quest — try again in a moment');
    } finally {
      setClaiming(null);
    }
  };

  const active = quests.filter((q) => q.active);

  return (
    <div className="min-h-screen px-4 sm:px-8 py-10 max-w-4xl mx-auto">
      <div className="volt-rise">
        <h1 className="font-heading text-4xl sm:text-5xl font-black volt-gradient-text leading-none flex items-center gap-3">
          <Swords className="w-9 h-9 text-[hsl(var(--voltage-yellow))]" /> Daily Quests
        </h1>
        <p className="text-white/50 text-sm mt-3 tracking-wide">Gaming challenges for the whole clan — complete them once a day to earn XP and badges</p>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-6 volt-rise" style={{ animationDelay: '.1s' }}>
        <div className="volt-panel rounded-2xl p-4 text-center">
          <Zap className="w-5 h-5 mx-auto text-[hsl(var(--voltage-yellow))]" />
          <div className="text-2xl font-black text-white mt-1 tabular-nums">{xpTotal}</div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-white/40 mt-1">Total XP</div>
        </div>
        <div className="volt-panel rounded-2xl p-4 text-center">
          <Check className="w-5 h-5 mx-auto text-[hsl(var(--voltage-blue))]" />
          <div className="text-2xl font-black text-white mt-1 tabular-nums">{claimedToday.length}/{active.length}</div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-white/40 mt-1">Today</div>
        </div>
        <div className="volt-panel rounded-2xl p-4 text-center">
          <Award className="w-5 h-5 mx-auto text-[hsl(var(--voltage-yellow))]" />
          <div className="text-2xl font-black text-white mt-1 tabular-nums">{badges}</div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-white/40 mt-1">Badges</div>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3 mt-6 animate-pulse">
          {[0, 1, 2].map((i) => <div key={i} className="h-24 bg-white/10 rounded-3xl" />)}
        </div>
      ) : error ? (
        <div className="volt-panel rounded-3xl mt-6 p-8 text-center text-white/60 text-sm">
          Quests are busy right now — try again in a moment.
          <div className="mt-3"><Button variant="outline" onClick={load} className="border-white/20 text-white/80">Retry</Button></div>
        </div>
      ) : active.length === 0 ? (
        <div className="volt-panel rounded-3xl mt-6 p-10 text-center text-white/60 text-sm border-dashed">
          No quests on the board right now — an admin can add the clan's first challenge below.
        </div>
      ) : (
        <div className="space-y-3 mt-6">
          {active.map((q, i) => {
            const done = claimedToday.includes(q.id);
            return (
              <div
                key={q.id}
                className={`volt-panel volt-card volt-rise rounded-3xl p-4 sm:p-5 flex flex-wrap items-center gap-4 ${done ? 'opacity-75' : ''}`}
                style={{ animationDelay: `${0.15 + i * 0.06}s` }}
              >
                <div className="w-11 h-11 rounded-2xl grid place-items-center bg-gradient-to-br from-[hsl(var(--voltage-yellow))]/25 to-[hsl(var(--voltage-blue))]/25 border border-white/10 shrink-0">
                  {q.game ? <Gamepad2 className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" /> : <Swords className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" />}
                </div>
                <div className="min-w-0 flex-1 basis-52">
                  <div className="text-sm font-bold text-white/90">{q.title}</div>
                  {q.game && <span className="text-[11px] text-[hsl(var(--voltage-blue))] uppercase tracking-wider">{q.game}</span>}
                  {q.description && <p className="text-xs text-white/50 mt-1">{q.description}</p>}
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="text-[11px] font-bold text-[hsl(var(--voltage-yellow))] rounded-full border border-[hsl(var(--voltage-yellow))]/30 bg-[hsl(var(--voltage-yellow))]/10 px-2.5 py-0.5">+{q.xp_reward || 0} XP</span>
                    {q.reward_badge && <span className="text-[11px] font-bold text-[hsl(var(--voltage-blue))] rounded-full border border-[hsl(var(--voltage-blue))]/40 bg-[hsl(var(--voltage-blue))]/10 px-2.5 py-0.5">🏅 {q.reward_badge}</span>}
                    {q.proof_required && (
                      <span className="text-[11px] font-bold text-white/70 rounded-full border border-white/25 bg-white/5 px-2.5 py-0.5 inline-flex items-center gap-1">
                        <Camera className="w-3 h-3" /> Photo/video proof
                      </span>
                    )}
                  </div>
                </div>
                {q.proof_required && !done && (
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer inline-flex items-center gap-2 rounded-2xl border border-white/20 px-4 py-2.5 text-sm text-white/80 hover:border-[hsl(var(--voltage-yellow))]/50 transition-colors max-w-[220px]">
                      <Paperclip className="w-4 h-4 shrink-0 text-[hsl(var(--voltage-yellow))]" />
                      <span className="truncate">{proofFiles[q.id]?.name || 'Attach proof'}</span>
                      <input type="file" accept="image/*,video/*" className="hidden" onChange={pickProof(q.id)} />
                    </label>
                    {proofFiles[q.id] && (
                      <button type="button" onClick={() => clearProof(q.id)} className="text-white/30 hover:text-red-300 transition-colors" title="Remove">
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}
                {done && todayStatus[q.id] === 'accepted' ? (
                  <span className="inline-flex items-center gap-2 text-sm font-bold text-emerald-300 rounded-2xl border border-emerald-300/30 bg-emerald-300/10 px-4 py-2.5">
                    <Check className="w-4 h-4" /> Done today
                  </span>
                ) : done ? (
                  <span className="inline-flex items-center gap-2 text-sm font-bold text-amber-300 rounded-2xl border border-amber-300/30 bg-amber-300/10 px-4 py-2.5">
                    <Clock className="w-4 h-4 animate-pulse" /> Waiting for review…
                  </span>
                ) : (
                  <Button
                    onClick={() => claim(q)}
                    disabled={claiming === q.id}
                    className="bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black font-bold rounded-2xl"
                  >
                    {claiming === q.id ? 'Uploading…' : 'Complete'}
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      )}

      <QuestLeaderboard />

      {isAdmin && <QuestAdmin quests={quests} onReload={load} />}
    </div>
  );
}