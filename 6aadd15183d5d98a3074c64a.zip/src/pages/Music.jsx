const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { Upload, Play, Pause, Music as MusicIcon, Link as LinkIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useMusicPlayer } from '@/lib/MusicPlayer';
import { withRetry } from '@/lib/apiRetry';
import { fromDb } from '@/lib/time';
import { getAppSettings, saveAppSetting } from '@/lib/appSettings';
import { uploadAudio, makeTestAudio } from '@/lib/audioHost';
import ClanBeats from '@/components/music/ClanBeats';

// Music tab — each member's personal song library. Songs are added by pasting
// a direct audio link or uploading through the clan's free Cloudinary
// connection, so the whole tab works without any credits.
export default function Music() {
  const { user } = useAuth();
  const { current, playing, playSong } = useMusicPlayer();
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [link, setLink] = useState('');
  const fileRef = useRef(null);
  const [cloud, setCloud] = useState('');
  const [preset, setPreset] = useState('');
  const [cloudInput, setCloudInput] = useState('');
  const [presetInput, setPresetInput] = useState('');
  const [testing, setTesting] = useState(false);
  const myName = user?.full_name || (user?.email || 'player').split('@')[0];
  const isAdmin = user?.role === 'admin';

  const load = async () => {
    setLoading(true);
    setError(false);
    try {
      const page = await withRetry(() => db.entities.Song.filter({ user_id: user.id }, { sort: '-created_date', limit: 100 }));
      setSongs(page.items);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    load();
    getAppSettings(['cloudinary_cloud', 'cloudinary_preset']).then((s) => {
      setCloud(s.cloudinary_cloud || '');
      setPreset(s.cloudinary_preset || '');
      setCloudInput(s.cloudinary_cloud || '');
      setPresetInput(s.cloudinary_preset || '');
    }).catch(() => {});
    // a song added or removed anywhere refreshes the library instantly
    const unsub = db.entities.Song.subscribe(() => load());
    return unsub;
  }, [user?.id]);

  // admin pastes the free Cloudinary cloud name + upload preset — we prove the
  // connection with a real upload before saving it
  const saveCloudinary = async () => {
    const c = cloudInput.trim();
    const p = presetInput.trim();
    setTesting(true);
    try {
      if (c || p) await uploadAudio(makeTestAudio(), c, p);
      await saveAppSetting('cloudinary_cloud', c);
      await saveAppSetting('cloudinary_preset', p);
      setCloud(c);
      setPreset(p);
      toast.success(c ? 'Song uploads connected' : 'Song uploads disconnected');
    } catch (err) {
      toast.error(err?.message || 'Could not connect song uploads — try again');
    } finally {
      setTesting(false);
    }
  };

  const upload = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!/^audio\//.test(file.type)) { toast.error('Pick an audio file (mp3, wav, m4a…)'); return; }
    if (!cloud || !preset) {
      toast.error('Uploads need a free Cloudinary connection — paste a direct song link instead, or an admin can connect uploads below');
      return;
    }
    setUploading(true);
    try {
      const url = await uploadAudio(file, cloud, preset);
      const title = file.name.replace(/\.[^.]+$/, '') || 'My song';
      await withRetry(() => db.entities.Song.create({ title, user_id: user.id, username: myName, file_url: url }));
      toast.success('Song saved to your library');
    } catch (err) {
      toast.error(err?.message || 'Upload failed — try again in a moment');
    } finally {
      setUploading(false);
    }
  };

  const addLink = async (e) => {
    e.preventDefault();
    const url = link.trim();
    if (!/^https?:\/\//.test(url)) { toast.error('Paste a direct link to an audio file'); return; }
    const title = decodeURIComponent(url.split('/').pop().split('?')[0]).replace(/\.[^.]+$/, '') || 'My song';
    setLink('');
    try {
      await withRetry(() => db.entities.Song.create({ title, user_id: user.id, username: myName, file_url: url }));
      toast.success('Song saved to your library');
    } catch {
      toast.error('Could not save — try again in a moment');
    }
  };

  return (
    <div className="min-h-screen px-4 sm:px-8 py-10 max-w-4xl mx-auto">
      <div className="flex items-start justify-between gap-4 flex-wrap volt-rise">
        <div>
          <h1 className="font-heading text-4xl sm:text-5xl font-black volt-gradient-text leading-none">Music</h1>
          <p className="text-white/50 text-sm mt-3 tracking-wide">Your personal song library — saved forever, playing across every tab</p>
        </div>
        <input ref={fileRef} type="file" accept="audio/*" className="hidden" onChange={upload} />
        <Button onClick={() => fileRef.current?.click()} disabled={uploading} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <Upload className="w-4 h-4 mr-2" /> {uploading ? 'Uploading…' : 'Upload a song'}
        </Button>
      </div>

      {isAdmin && (
        <div className="volt-panel rounded-3xl mt-6 p-4 sm:p-5 volt-rise">
          <div className="text-xs font-bold tracking-[0.2em] uppercase text-[hsl(var(--voltage-yellow))] mb-3">Song upload connection</div>
          <p className="text-xs text-white/50 mb-4">
            Create a free Cloudinary account, make an unsigned upload preset, then paste your cloud name and preset here — uploads are tested with a real file the moment you save. Members without this can still paste song links.
          </p>
          <div className="flex flex-wrap gap-3">
            <input
              className="flex-1 min-w-[160px] rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30"
              placeholder="Cloudinary cloud name"
              value={cloudInput}
              onChange={(e) => setCloudInput(e.target.value)}
            />
            <input
              className="flex-1 min-w-[160px] rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-sm text-white/90 placeholder:text-white/30"
              placeholder="Upload preset name"
              value={presetInput}
              onChange={(e) => setPresetInput(e.target.value)}
            />
            <Button onClick={saveCloudinary} disabled={testing} className="bg-[hsl(var(--voltage-blue))] text-black font-bold">
              {testing ? 'Testing…' : cloud ? 'Save & test' : 'Connect'}
            </Button>
          </div>
          {cloud && <div className="text-[11px] text-white/40 mt-3">Connected to {cloud} — uploads work for every member.</div>}
        </div>
      )}

      <form onSubmit={addLink} className="volt-panel rounded-3xl mt-6 p-4 sm:p-5 flex flex-wrap gap-3 items-center volt-rise">
        <div className="flex-1 min-w-[240px] flex items-center gap-2 rounded-xl bg-black/40 border border-white/15 px-3 py-2">
          <LinkIcon className="w-4 h-4 text-[hsl(var(--voltage-yellow))] shrink-0" />
          <input
            className="flex-1 bg-transparent text-sm text-white/90 placeholder:text-white/30 outline-none"
            placeholder="Paste a direct song link (mp3, wav, m4a…)"
            value={link}
            onChange={(e) => setLink(e.target.value)}
          />
        </div>
        <Button type="submit" variant="outline" className="border-[hsl(var(--voltage-yellow))]/40 text-[hsl(var(--voltage-yellow))] hover:bg-[hsl(var(--voltage-yellow))]/10">Add song</Button>
      </form>

      <ClanBeats />

      <div className="volt-panel rounded-3xl mt-6 p-4 sm:p-6 volt-rise" style={{ animationDelay: '.15s' }}>
        {current && (
          <div className="mb-4 flex items-center gap-3 rounded-2xl bg-[hsl(var(--voltage-yellow))]/10 border border-[hsl(var(--voltage-yellow))]/30 px-4 py-3">
            <MusicIcon className="w-4 h-4 text-[hsl(var(--voltage-yellow))] animate-pulse" />
            <span className="text-sm text-white/85">Now playing: <b>{current.title}</b></span>
          </div>
        )}
        {loading ? (
          <div className="space-y-3 animate-pulse">
            {[0, 1, 2].map((i) => <div key={i} className="h-14 bg-white/10 rounded-2xl" />)}
          </div>
        ) : error ? (
          <div className="text-center text-white/60 text-sm py-8">
            Music is busy right now — try again in a moment.
            <div className="mt-3"><Button variant="outline" onClick={load} className="border-white/20 text-white/80">Retry</Button></div>
          </div>
        ) : songs.length === 0 ? (
          <div className="text-center text-white/60 text-sm py-10 border border-dashed border-white/15 rounded-2xl">
            No songs yet — paste a link or upload your first one and it stays in your library forever.
          </div>
        ) : (
          <div className="space-y-2">
            {songs.map((s) => {
              const isCurrent = current?.id === s.id;
              const d = s.created_date ? fromDb(s.created_date) : null;
              return (
                <div
                  key={s.id}
                  className={`flex items-center gap-3 rounded-2xl border px-4 py-3 transition-all ${isCurrent
                    ? 'border-[hsl(var(--voltage-yellow))] bg-[hsl(var(--voltage-yellow))]/10'
                    : 'border-white/10 bg-white/[0.04] hover:border-[hsl(var(--voltage-yellow))]/40'}`}
                >
                  <button
                    type="button"
                    onClick={() => playSong(s)}
                    className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] text-black shrink-0"
                    title={isCurrent && playing ? 'Pause' : 'Play'}
                  >
                    {isCurrent && playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold text-white/90">{s.title}</div>
                    <div className="text-[11px] text-white/40">Added {d ? d.toLocaleDateString() : ''}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}