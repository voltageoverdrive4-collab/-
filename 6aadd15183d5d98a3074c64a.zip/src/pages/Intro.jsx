const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Zap, ChevronRight } from 'lucide-react';

import StormCanvas from '@/components/intro/StormCanvas';
import BootSequence from '@/components/intro/BootSequence';
import ChargeSequence from '@/components/intro/ChargeSequence';
import StrikeFlash from '@/components/intro/StrikeFlash';
import VoltageTitle, { EnterFlash } from '@/components/intro/VoltageTitle';
import { TypeLine, CountUp } from '@/components/intro/IntroText';

// The 10-second cinematic start page:
// boot (0–2.2s) → volt core charge (2.2–5.2s) → lightning strike (5.2–5.9s)
// → storm reveal: logo letters, typed tagline, counting clan stats, buttons.
export default function Intro() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [phase, setPhase] = useState('boot');

  useEffect(() => {
    (async () => {
      try {
        const [members, games] = await Promise.all([
          db.entities.Member.count(),
          db.entities.Game.count(),
        ]);
        setStats({ members, games });
      } catch { setStats(null); }
    })();
    const timers = [
      setTimeout(() => setPhase('charge'), 2200),
      setTimeout(() => setPhase('strike'), 5200),
      setTimeout(() => setPhase('main'), 5900),
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  const enter = (to = '/dashboard') => {
    if (phase !== 'main') return;
    setPhase('enter');
    setTimeout(() => navigate(to), 800);
  };

  // Enter skips the sequence while it plays, and enters the hub once ready
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Enter') return;
      if (phase !== 'main') setPhase('main');
      else enter();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  return (
    <div className={`relative min-h-screen overflow-hidden bg-black flex items-center justify-center ${phase === 'strike' ? 'intro-shake' : ''}`}>
      <StormCanvas />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.75)_75%)] pointer-events-none" />

      {phase === 'boot' && <BootSequence />}
      {phase === 'charge' && <ChargeSequence />}
      {phase === 'strike' && <StrikeFlash />}
      {phase === 'enter' && <EnterFlash />}

      {(phase === 'main' || phase === 'enter') && (
        <div className={`relative z-10 text-center px-6 max-w-2xl ${phase === 'enter' ? 'intro-zoom' : ''}`}>
          <div className="flex justify-center mb-6 volt-rise">
            <div className="relative">
              <Zap className="w-16 h-16 p-2 text-[hsl(var(--voltage-yellow))]" fill="currentColor" />
              <div className="absolute inset-0 blur-xl text-[hsl(var(--voltage-yellow))] opacity-70 animate-pulse">
                <Zap className="w-16 h-16 p-2" fill="currentColor" />
              </div>
            </div>
          </div>
          <VoltageTitle />
          <p className="mt-4 text-[hsl(var(--voltage-blue))] tracking-[0.45em] text-xs sm:text-sm uppercase volt-rise" style={{ animationDelay: '.6s' }}>
            <TypeLine text="The storm never sleeps" />
          </p>

          {stats && (
            <div className="mt-8 flex items-center justify-center gap-3 volt-rise" style={{ animationDelay: '1.8s' }}>
              <span className="rounded-full border border-[hsl(var(--voltage-yellow))]/30 bg-black/60 px-4 py-1.5 text-xs text-white/80"><CountUp to={stats.members} /> members</span>
              <span className="rounded-full border border-[hsl(var(--voltage-blue))]/30 bg-black/60 px-4 py-1.5 text-xs text-white/80"><CountUp to={stats.games} /> games</span>
            </div>
          )}

          <div className="volt-rise" style={{ animationDelay: '3s' }}>
            <button
              onClick={() => enter('/dashboard')}
              className="mt-10 group inline-flex items-center gap-3 rounded-2xl bg-gradient-to-r from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] px-10 py-4 text-black font-black text-lg tracking-wide shadow-[0_0_40px_hsl(var(--voltage-yellow)/0.5)] hover:shadow-[0_0_60px_hsl(var(--voltage-yellow)/0.8)] transition-all"
            >
              ENTER THE HUB
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="mt-10 volt-rise" style={{ animationDelay: '3.6s' }}>
            <p className="text-white/50 text-sm max-w-md mx-auto">
              Voltage runs on member power. Every donation keeps the servers humming and the giveaways rolling.
            </p>
            <button
              onClick={() => enter('/donate')}
              className="mt-4 inline-flex items-center gap-2 rounded-2xl border border-[hsl(var(--voltage-yellow))]/40 bg-[hsl(var(--voltage-yellow))]/10 px-6 py-3 text-sm font-bold text-[hsl(var(--voltage-yellow))] hover:bg-[hsl(var(--voltage-yellow))]/20 transition-all"
            >
              <Heart className="w-4 h-4 animate-pulse" fill="currentColor" /> Support the clan
            </button>
          </div>
        </div>
      )}
    </div>
  );
}