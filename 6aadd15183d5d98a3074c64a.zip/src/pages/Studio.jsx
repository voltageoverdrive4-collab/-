const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useLocation } from 'react-router-dom';

import { withRetry, delay } from '@/lib/apiRetry';
import { grantAchievement } from '@/lib/achievements';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'react-hot-toast';
import { Code2, Play, Square, Send, Gamepad2, FolderOpen, BookOpen, Rocket } from 'lucide-react';
import { hydrateScene, hydrateNode } from '@/lib/engine/hydrateScene';
import NodeLibraryPanel from '@/components/studio/NodeLibraryPanel';

import { Runtime } from '@/lib/engine/Runtime';
import { compileScript } from '@/lib/gds/interpreter';
import { NODE_TYPES } from '@/lib/engine/registry';
import SceneTreePanel from '@/components/studio/SceneTreePanel';
import InspectorPanel from '@/components/studio/InspectorPanel';
import ViewportPanel from '@/components/studio/ViewportPanel';
import ConsolePanel from '@/components/studio/ConsolePanel';
import CodeEditor from '@/components/studio/CodeEditor';
import {
  defaultScene, makeNode, findNode, findParent, removeNode, addChild, walk, cloneScene, newUid,
} from '@/components/studio/sceneData';
import ProjectsDialog from '@/components/studio/ProjectsDialog';
import {
  listProjects, getProject, saveProject, createProject,
  deleteProject as removeProject, getLastProjectId, setLastProjectId,
  emptyScene, migrateLegacyScene,
} from '@/components/studio/projectStore';

function findFirstWithScript(node) {
  if (node.scriptSource) return node;
  for (const c of node.children) {
    const r = findFirstWithScript(c);
    if (r) return r;
  }
  return null;
}

function initialProjectId() {
  let id = getLastProjectId();
  if (!id && listProjects().length === 0) {
    const migrated = migrateLegacyScene();
    if (migrated) id = migrated.id;
  }
  return id;
}

function scriptTemplate(node) {
  return `extends ${node.type}

func _ready():
\tprint("${node.name} reporting in!")

func _process(delta):
\tpass
`;
}

export default function Studio() {
  const { user } = useAuth();
  const [approved, setApproved] = useState(null);
  const [checking, setChecking] = useState(true);
  const [me, setMe] = useState(null);
  const [publishing, setPublishing] = useState(false);

  const [projectId, setProjectId] = useState(initialProjectId);
  const [showProjects, setShowProjects] = useState(false);
  const [scene, setScene] = useState(() => {
    const p = projectId ? getProject(projectId) : null;
    return hydrateScene(p?.scene ? cloneScene(p.scene) : emptyScene());
  });
  const [selectedUid, setSelectedUid] = useState(null);
  const [codeTargetUid, setCodeTargetUid] = useState(null);
  const [centerTab, setCenterTab] = useState('scene');

  const [playing, setPlaying] = useState(false);
  const [runtime, setRuntime] = useState(null);
  const [frameCount, setFrameCount] = useState(0);

  const [logs, setLogs] = useState([]);
  const [errors, setErrors] = useState([]);
  const [consoleTab, setConsoleTab] = useState('console');

  const location = useLocation();
  const runtimeRef = useRef(null);
  const openProjectRef = useRef(null);

  // admins coming from the Game Hub's Edit button open the published game here;
  // changes go back to the original hub entry when they press Publish
  useEffect(() => {
    const importId = location.state?.importGameId;
    if (!importId) return undefined;
    window.history.replaceState({}, '', '/studio'); // don't re-import on refresh
    let cancelled = false;
    (async () => {
      try {
        const existing = listProjects().find((p) => p.published_game_id === importId);
        if (existing) { openProjectRef.current?.(existing); return; }
        const row = await withRetry(() => db.entities.StudioGame.get(importId));
        if (cancelled || !row) return;
        const p = createProject(row.name);
        p.scene = JSON.parse(row.scene);
        p.published_game_id = row.id;
        saveProject(p);
        openProjectRef.current?.(p);
        toast.success(`Editing "${row.name}" — press Publish to update the Game Hub`);
      } catch (e) {
        toast.error('Could not open that game for editing — try again in a moment');
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // one sequential load instead of parallel bursts — the studio's two lookups
  // fire with a pause between them so the API rate limit isn't tripped
  useEffect(() => {
    if (!user?.email) return undefined;
    let cancelled = false;
    (async () => {
      try {
        const reqs = await withRetry(() => db.entities.StudioRequest.filter({ email: user.email }));
        if (cancelled) return;
        const mine = reqs[0];
        setApproved(mine?.status === 'approved' ? mine : null);
        if (mine?.status === 'approved') grantAchievement(user, 'studio-access');
        await delay(400);
        // members with the Publisher tag (set in the admin panel) can publish games to the hub
        const mem = await withRetry(() => db.entities.Member.filter({ email: user.email }));
        if (!cancelled) setMe(mem[0] || null);
      } catch (e) {
        // rate-limited or offline — the page still opens, publishing is just hidden until reload
      } finally {
        if (!cancelled) setChecking(false);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.email]);
  const myName = me?.username || user?.full_name || (user?.email || 'creator').split('@')[0];
  const canPublish = !!(me?.is_admin || user?.role === 'admin' || (me?.tags || []).some((t) => String(t).toLowerCase() === 'publisher'));

  // persist scene edits into the active project
  useEffect(() => {
    if (!projectId) return;
    const p = getProject(projectId);
    if (!p) return;
    p.scene = scene;
    p.updated = new Date().toISOString();
    saveProject(p);
  }, [scene, projectId]);

  // stop the runtime when leaving the page
  useEffect(() => () => runtimeRef.current?.stop(), []);

  const addLog = useCallback((entry) => {
    setLogs((prev) => [...prev.slice(-499), entry]);
  }, []);

  const selectedNode = selectedUid ? findNode(scene.root, selectedUid) : null;
  const codeTarget = codeTargetUid ? findNode(scene.root, codeTargetUid) : null;
  const nodeMeta = selectedNode ? (NODE_TYPES[selectedNode.type] || NODE_TYPES.Node).PROPS : [];

  // ---- editor ops ---------------------------------------------------------
  const mutateScene = (mutator) => {
    setScene((prev) => {
      const next = cloneScene(prev);
      mutator(next);
      return next;
    });
  };

  const setProp = (propName, value) => {
    if (!selectedNode) return;
    mutateScene((s) => {
      const n = findNode(s.root, selectedUid);
      if (!n) return;
      if (propName === '__name') n.name = value;
      else n.props[propName] = value;
    });
  };

  // used by the viewport for drag-to-move / drag-to-resize
  const updateNodeProps = (uid, patch) => {
    mutateScene((s) => {
      const n = findNode(s.root, uid);
      if (!n) return;
      for (const [k, v] of Object.entries(patch)) {
        if (k === 'position' || k === 'size') n.props[k] = { ...(n.props[k] || {}), ...v };
        else n.props[k] = v;
      }
    });
  };

  const addNode = (type) => {
    const parentId = selectedUid || scene.root.uid;
    const node = makeNode(type, type);
    hydrateNode(node);
    mutateScene((s) => {
      const p = findNode(s.root, parentId);
      if (p) {
        const siblings = p.children.filter((c) => c.name === type).length;
        if (siblings > 0) node.name = `${type}${siblings}`;
        p.children.push(node);
      }
    });
    setSelectedUid(node.uid);
  };

  const deleteNode = () => {
    if (!selectedUid || selectedUid === scene.root.uid) return;
    mutateScene((s) => removeNode(s.root, selectedUid));
    if (codeTargetUid === selectedUid) { setCodeTargetUid(null); setCenterTab('scene'); }
    setSelectedUid(null);
  };

  const toggleUnique = () => {
    if (!selectedNode) return;
    mutateScene((s) => {
      const n = findNode(s.root, selectedUid);
      if (n) n.uniqueName = !n.uniqueName;
    });
  };

  const attachScript = () => {
    if (!selectedNode) return;
    mutateScene((s) => {
      const n = findNode(s.root, selectedUid);
      if (n) n.scriptSource = scriptTemplate(n);
    });
    setCodeTargetUid(selectedUid);
    setCenterTab('script');
  };

  const detachScript = () => {
    if (!selectedNode) return;
    if (playing) return;
    mutateScene((s) => {
      const n = findNode(s.root, selectedUid);
      if (n) n.scriptSource = null;
    });
    if (codeTargetUid === selectedUid) { setCodeTargetUid(null); setCenterTab('scene'); }
  };

  const editScript = () => {
    if (!selectedNode?.scriptSource) return;
    setCodeTargetUid(selectedUid);
    setCenterTab('script');
  };

  const updateScript = (code) => {
    if (!codeTarget) return;
    mutateScene((s) => {
      const n = findNode(s.root, codeTargetUid);
      if (n) n.scriptSource = code;
    });
  };

  // ---- play / stop ----------------------------------------------------------
  const stopPlay = useCallback(() => {
    runtimeRef.current?.stop();
    runtimeRef.current = null;
    setRuntime(null);
    setPlaying(false);
    setFrameCount(0);
  }, []);

  const play = () => {
    if (playing) return;
    // 1. compile all scripts
    const compileErrors = [];
    walk(scene.root, (n) => {
      if (n.scriptSource) {
        try {
          compileScript(n.scriptSource, `${n.name}.gd`);
        } catch (e) {
          compileErrors.push({ kind: 'error', node: `${n.name}.gd`, text: e.message, line: e.line });
        }
      }
    });
    if (compileErrors.length > 0) {
      setErrors((prev) => [...prev, ...compileErrors]);
      setConsoleTab('errors');
      toast.error(`${compileErrors.length} script error${compileErrors.length > 1 ? 's' : ''} — check the Errors panel`);
      return;
    }
    // 2. boot the runtime
    setLogs([]);
    setErrors([]);
    setConsoleTab('console');
    const rt = new Runtime({
      onPrint: (text) => addLog({ kind: 'log', text }),
      onError: (e) => setErrors((prev) => [...prev, { kind: 'error', text: e.message, line: e.line }]),
      onStopRequest: () => stopPlay(),
      onStats: (fc) => { if (fc % 10 === 0) setFrameCount(fc); },
    });
    try {
      rt.loadScene(cloneScene(scene));
    } catch (e) {
      setErrors((prev) => [...prev, { kind: 'error', text: e.message }]);
      setConsoleTab('errors');
      toast.error('Failed to build scene: ' + e.message);
      return;
    }
    runtimeRef.current = rt;
    setRuntime(rt);
    setPlaying(true);
    addLog({ kind: 'system', text: `▶ Scene running — ${rt.allNodes.length} nodes` });
    rt.start();
  };

  // ---- project ops -----------------------------------------------------------
  const openProject = (p) => {
    if (playing) stopPlay();
    setProjectId(p.id);
    setLastProjectId(p.id);
    setScene(hydrateScene(p.scene ? cloneScene(p.scene) : emptyScene()));
    setSelectedUid(null);
    setCodeTargetUid(null);
    setCenterTab('scene');
    setLogs([]);
    setErrors([]);
    setShowProjects(false);
  };
  openProjectRef.current = openProject; // so the import effect above can open projects too

  const handleCreateProject = (name) => {
    openProject(createProject(name));
  };

  const handleDeleteProject = (id) => {
    removeProject(id);
    if (id === projectId) {
      if (playing) stopPlay();
      setProjectId(null);
      setScene(hydrateScene(emptyScene()));
      setSelectedUid(null);
      setCodeTargetUid(null);
      setCenterTab('scene');
    }
  };

  const activeProject = projectId ? getProject(projectId) : null;

  const publish = async () => {
    if (!activeProject) return;
    setPublishing(true);
    try {
      if (activeProject.published_game_id) {
        // editing an already-published game — update the original hub entry in place
        await withRetry(() => db.entities.StudioGame.update(activeProject.published_game_id, {
          name: activeProject.name, scene: JSON.stringify(scene),
        }));
        toast.success(`"${activeProject.name}" updated in the Game Hub`);
      } else {
        await withRetry(() => db.entities.StudioGame.upsert(
          [{ name: activeProject.name, scene: JSON.stringify(scene), username: myName, user_id: user.id, category: 'Studio' }],
          { key: ['user_id', 'name'] }
        ));
        toast.success(`"${activeProject.name}" is live in the Game Hub`);
      }
    } catch (e) {
      toast.error('Could not publish right now — try again in a moment');
    } finally { setPublishing(false); }
  };

  if (checking) return <div className="p-10 text-white/50">Loading studio…</div>;
  if (!approved) return <StudioSignup email={user?.email} />;

  // no project open — force the picker
  if (!projectId) return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-100px)] min-h-[560px] gap-4">
      <FolderOpen className="w-12 h-12 text-[hsl(var(--voltage-yellow))]" />
      <p className="text-white/50">Create or open a project to start building.</p>
      <ProjectsDialog
        open
        onOpenChange={() => {}}
        projects={listProjects()}
        activeProjectId={projectId}
        onOpen={openProject}
        onCreate={handleCreateProject}
        onDelete={handleDeleteProject}
      />
    </div>
  );

  return (
    <div className="hub-tool-surface flex flex-col h-[calc(100vh-100px)] min-h-[560px] gap-3">
      {/* toolbar */}
      <div className="hub-toolbar flex items-center gap-3">
        <h1 className="font-heading text-xl font-black flex items-center gap-2">
          <Code2 className="w-5 h-5 text-[hsl(var(--voltage-yellow))]" /> Voltage Studio
          <span className="text-xs font-normal text-white/40">GDScript Engine</span>
        </h1>
        <Button
          onClick={() => setShowProjects(true)}
          size="sm"
          variant="outline"
          className="border-white/20 bg-transparent text-white/80 hover:bg-white/10"
        >
          <FolderOpen className="w-4 h-4 mr-1" /> Projects
        </Button>
        {activeProject && (
          <span className="text-sm text-white/50 truncate max-w-40">{activeProject.name}</span>
        )}
        {canPublish && activeProject && !playing && (
          <Button onClick={publish} disabled={publishing} size="sm" variant="outline" className="border-white/20 bg-transparent text-white/80 hover:bg-white/10">
            <Rocket className="w-4 h-4 mr-1" /> {publishing ? 'Publishing…' : 'Publish to Hub'}
          </Button>
        )}
        <div className="flex-1" />
        {playing ? (
          <Button onClick={stopPlay} size="sm" variant="destructive" className="font-bold">
            <Square className="w-4 h-4 mr-1" /> Stop
          </Button>
        ) : (
          <Button onClick={play} size="sm" className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
            <Play className="w-4 h-4 mr-1" /> Play Scene
          </Button>
        )}
        <div className="flex rounded-lg border border-white/10 overflow-hidden text-sm">
          <button
            className={`px-3 py-1.5 flex items-center gap-1.5 ${centerTab === 'scene' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]' : 'text-white/50 hover:text-white/80'}`}
            onClick={() => setCenterTab('scene')}
          >
            <Gamepad2 className="w-4 h-4" /> 2D
          </button>
          <button
            className={`px-3 py-1.5 flex items-center gap-1.5 ${centerTab === 'script' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]' : 'text-white/50 hover:text-white/80'}`}
            onClick={() => {
              if (!codeTarget) {
                const target = selectedNode?.scriptSource ? selectedNode : findFirstWithScript(scene.root);
                setCodeTargetUid(target?.uid || null);
              }
              setCenterTab('script');
            }}
          >
            <Code2 className="w-4 h-4" /> Script
          </button>
          <button
            className={`px-3 py-1.5 flex items-center gap-1.5 ${centerTab === 'nodes' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]' : 'text-white/50 hover:text-white/80'}`}
            onClick={() => setCenterTab('nodes')}
          >
            <BookOpen className="w-4 h-4" /> Nodes
          </button>
        </div>
      </div>

      {/* main 3-panel layout */}
      <div className="flex flex-1 min-h-0 gap-3">
        <aside className="w-56 shrink-0 rounded-xl bg-black/40 border border-white/10 p-3 overflow-y-auto">
          <SceneTreePanel
            root={scene.root}
            selectedUid={selectedUid}
            onSelect={setSelectedUid}
            onAddNode={addNode}
            onDeleteNode={deleteNode}
          />
        </aside>

        <main className="flex-1 min-w-0 flex flex-col gap-3">
          {centerTab === 'nodes' ? (
            <div className="flex-1 min-h-0 rounded-xl bg-black/40 border border-white/10 p-3">
              <NodeLibraryPanel />
            </div>
          ) : centerTab === 'script' && codeTarget ? (
            <div className="flex-1 min-h-0 rounded-xl bg-black/50 border border-white/10 overflow-hidden">
              <CodeEditor
                value={codeTarget.scriptSource || ''}
                onChange={updateScript}
                fileName={`${codeTarget.name}.gd`}
              />
            </div>
          ) : (
            <>
              <div className="flex-1 min-h-0 rounded-xl bg-black/40 border border-white/10 p-3">
                <ViewportPanel
                  playing={playing}
                  runtime={runtime}
                  sceneData={scene}
                  frameCount={frameCount}
                  selectedUid={selectedUid}
                  onSelect={setSelectedUid}
                  onUpdateNode={updateNodeProps}
                />
              </div>
              <div className="h-44 shrink-0 rounded-xl bg-black/50 border border-white/10 overflow-hidden">
                <ConsolePanel
                  logs={logs}
                  errors={errors}
                  activeTab={consoleTab}
                  onTabChange={setConsoleTab}
                  onClear={() => (consoleTab === 'errors' ? setErrors([]) : setLogs([]))}
                />
              </div>
            </>
          )}
        </main>

        <aside className="w-64 shrink-0 rounded-xl bg-black/40 border border-white/10 p-3 overflow-y-auto">
          <InspectorPanel
            node={selectedNode || scene.root}
            nodeMeta={selectedNode || scene.root ? (NODE_TYPES[(selectedNode || scene.root).type] || NODE_TYPES.Node).PROPS : []}
            onSetProp={setProp}
            onToggleUnique={toggleUnique}
            onAttachScript={attachScript}
            onEditScript={editScript}
            onDetachScript={detachScript}
          />
        </aside>
      </div>

      <ProjectsDialog
        open={showProjects}
        onOpenChange={setShowProjects}
        projects={listProjects()}
        activeProjectId={projectId}
        onOpen={openProject}
        onCreate={handleCreateProject}
        onDelete={handleDeleteProject}
      />
    </div>
  );
}

function StudioSignup({ email }) {
  const [form, setForm] = useState({ username: '', email: email || '', experience: '' });
  const [done, setDone] = useState(false);
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await db.entities.StudioRequest.create({ ...form, status: 'pending' });
      setDone(true);
    } catch (err) { toast.error(err.message); }
    finally { setSaving(false); }
  };

  if (done) return (
    <div className="p-10 max-w-lg mx-auto text-center">
      <Code2 className="w-12 h-12 mx-auto text-[hsl(var(--voltage-yellow))] mb-4" />
      <h2 className="text-2xl font-bold mb-2">Request sent</h2>
      <p className="text-white/60">An admin will approve your studio access.</p>
    </div>
  );

  return (
    <div className="p-6 sm:p-10 max-w-lg mx-auto">
      <h1 className="font-heading text-3xl font-black mb-2 flex items-center gap-2"><Code2 className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> Studio Access</h1>
      <p className="text-white/50 mb-6">Request access to the Voltage Studio — a Godot-style editor that compiles and runs real GDScript.</p>
      <form onSubmit={submit} className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
        <div className="space-y-2"><Label className="text-white/80">Username</Label><Input required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} className="bg-black/40 border-white/15 text-white" /></div>
        <div className="space-y-2"><Label className="text-white/80">Email</Label><Input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="bg-black/40 border-white/15 text-white" /></div>
        <div className="space-y-2"><Label className="text-white/80">Experience</Label><Textarea value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} rows={4} placeholder="Any game dev or GDScript experience?" className="bg-black/40 border-white/15 text-white" /></div>
        <Button type="submit" disabled={saving} className="w-full bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Send className="w-4 h-4 mr-2" /> Request Access</Button>
      </form>
    </div>
  );
}