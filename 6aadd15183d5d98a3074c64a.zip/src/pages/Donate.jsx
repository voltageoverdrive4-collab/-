const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Heart } from 'lucide-react';

import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'react-hot-toast';
import { grantAchievement } from '@/lib/achievements';

const PRESETS = [5, 10, 25, 50];

// Members support the clan with a real online payment. The pledge (with the
// optional message) is saved first, then the member is sent to the secure
// checkout page — when the payment clears, the donation flips to paid.
export default function Donate() {
  const { user } = useAuth();
  const [amount, setAmount] = useState(10);
  const [custom, setCustom] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  const donate = async () => {
    const value = custom ? Number(custom) : amount;
    if (!value || value < 0.5) { toast.error('Pick a donation amount (minimum $0.50)'); return; }
    setSending(true);
    let record = null;
    try {
      // Save the pledge first so the message survives the payment hop.
      record = await db.entities.Donation.create({
        user_id: user?.id || '',
        username: user?.full_name || (user?.email || 'player').split('@')[0],
        email: user?.email,
        amount: value,
        message: message.trim(),
        status: 'pledged',
      });
    } catch (e) {
      toast.error(e?.message || 'Could not start the donation');
      setSending(false);
      return;
    }
    try {
      const res = await db.functions.invoke('create-checkout', {
        productId: `donation:${record.id}`,
        amount: value,
      });
      const redirectUrl = res?.data?.redirectUrl;
      if (!redirectUrl) throw new Error('missing redirect URL');
      window.location.href = redirectUrl;
    } catch (e) {
      console.error(e);
      toast.error('Could not open checkout — try again in a moment');
      setSending(false);
    }
  };

  return (
    <div className="p-6 sm:p-10 max-w-2xl mx-auto">
      <h1 className="font-heading text-3xl font-black mb-2 flex items-center gap-2">
        <Heart className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" fill="currentColor" /> Support the Clan
      </h1>
      <p className="text-white/50 mb-6">
        Donations fund tournaments, giveaways and server costs. Pay securely online — your donation
        shows up for admins the moment it clears.
      </p>

      <div className="space-y-5 p-6 rounded-2xl bg-white/5 border border-white/10">
        <div className="space-y-2">
          <Label className="text-white/80">Amount (USD)</Label>
          <div className="grid grid-cols-4 gap-2">
            {PRESETS.map((p) => (
              <button
                key={p}
                onClick={() => { setAmount(p); setCustom(''); }}
                className={`py-2.5 rounded-lg font-bold border transition-colors ${
                  !custom && amount === p
                    ? 'bg-[hsl(var(--voltage-yellow))] text-black border-transparent'
                    : 'border-white/15 text-white/70 hover:bg-white/10'
                }`}
              >
                ${p}
              </button>
            ))}
          </div>
          <Input
            type="number" min="0.5" step="0.5" value={custom}
            onChange={(e) => setCustom(e.target.value)}
            placeholder="Custom amount…"
            className="bg-black/40 border-white/15 text-white"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-white/80">Message (optional)</Label>
          <Textarea
            value={message} onChange={(e) => setMessage(e.target.value)} rows={3}
            placeholder="Shoutout, dedication, anything…"
            className="bg-black/40 border-white/15 text-white"
          />
        </div>
        <Button onClick={donate} disabled={sending} className="w-full bg-[hsl(var(--voltage-yellow))] text-black font-bold">
          <Heart className="w-4 h-4 mr-2" /> {sending ? 'Opening secure checkout…' : `Donate $${custom ? Number(custom) : amount}`}
        </Button>
        <p className="text-white/30 text-xs text-center">
          You'll be taken to a secure checkout page — email and card details are collected there.
        </p>
      </div>
    </div>
  );
}