const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { toast } from 'react-hot-toast';
import { Pencil, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { getAppSettings, saveAppSetting } from '@/lib/appSettings';

const DEFAULT_ABOUT = `⚡ Welcome to Voltage!

This is the clan's About Us page. Tell everyone who you are, what you play, and what Voltage stands for.

An admin can rewrite this text anytime with the Edit button.`;

// About Us — a clan page everyone can read and admins can edit.
// The text lives in the AppSetting store (key "about_us") so it saves
// instantly for the whole clan without a new release.
export default function AboutUs() {
  const { user } = useAuth();
  const [about, setAbout] = useState('');
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);
  const [isClanAdmin, setIsClanAdmin] = useState(false);

  const isAdmin = user?.role === 'admin' || isClanAdmin;

  useEffect(() => {
    (async () => {
      try {
        const settings = await getAppSettings(['about_us']);
        setAbout(settings.about_us || DEFAULT_ABOUT);
      } catch {
        setAbout(DEFAULT_ABOUT);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!user?.email) return;
    db.entities.Member.filter({ email: user.email })
      .then((r) => setIsClanAdmin(!!r[0]?.is_admin))
      .catch(() => {});
  }, [user?.email]);

  const save = async () => {
    setSaving(true);
    try {
      await saveAppSetting('about_us', draft);
      setAbout(draft);
      setEditing(false);
      toast.success('About Us updated');
    } catch {
      toast.error('Could not save — try again in a moment');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen px-4 sm:px-8 py-10 max-w-4xl mx-auto">
      <div className="flex items-start justify-between gap-4 flex-wrap r" style={{ animationDelay: '.2s' }}>
        <div>
          <h1 className="font-heading text-4xl sm:text-5xl font-black volt-gradient-text leading-none">About Us</h1>
          <p className="text-white/50 text-sm mt-3 tracking-wide">Who the Voltage clan is — straight from the leaders</p>
        </div>
        {isAdmin && !editing && (
          <Button onClick={() => { setDraft(about); setEditing(true); }} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
            <Pencil className="w-4 h-4 mr-2" /> Edit
          </Button>
        )}
      </div>

      <div className="volt-panel rounded-3xl mt-8 p-6 sm:p-10 r" style={{ animationDelay: '.35s' }}>
        {loading ? (
          <div className="space-y-3 animate-pulse">
            <div className="h-4 bg-white/10 rounded w-3/4" />
            <div className="h-4 bg-white/10 rounded w-full" />
            <div className="h-4 bg-white/10 rounded w-5/6" />
            <div className="h-4 bg-white/10 rounded w-2/3" />
          </div>
        ) : editing ? (
          <div>
            <Textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={14}
              className="bg-black/40 border-white/15 text-white/90"
              placeholder="Write what your clan is about…"
            />
            <div className="flex gap-3 mt-4">
              <Button onClick={save} disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
                <Save className="w-4 h-4 mr-2" /> {saving ? 'Saving…' : 'Save'}
              </Button>
              <Button variant="ghost" onClick={() => setEditing(false)} className="text-white/60 hover:text-white hover:bg-white/5">
                <X className="w-4 h-4 mr-2" /> Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-white/80 leading-relaxed whitespace-pre-wrap text-[15px]">{about}</div>
        )}
      </div>
    </div>
  );
}