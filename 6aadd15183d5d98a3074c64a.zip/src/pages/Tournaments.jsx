const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trophy, Loader2, Plus, Trash2, Users, Swords, Crown } from 'lucide-react';
import { toast } from 'react-hot-toast';
import BracketView from '@/components/tournaments/BracketView';
import { seedBracket, setMatchWinner, isComplete, champion } from '@/lib/bracket';
import { ensureMember } from '@/lib/members';
import { grantAchievement } from '@/lib/achievements';
import { withRetry, delay } from '@/lib/apiRetry';

export default function Tournaments() {
  const { user } = useAuth();
  const [tournaments, setTournaments] = useState([]);
  const [entries, setEntries] = useState([]);
  const [myMember, setMyMember] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ title: '', format: '1v1', slots: 8 });
  const [signups, setSignups] = useState({});

  // loads run one at a time (with retry + small gaps) so the app's
  // API rate limit is never tripped by parallel bursts
  const load = async () => {
    setLoading(true);
    try {
      const ts = await withRetry(() => db.entities.Tournament.list('-created_date', 50));
      await delay(300);
      const es = await withRetry(() => db.entities.TournamentEntry.list());
      setTournaments(ts);
      setEntries(es);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    (async () => {
      try { setMyMember(await ensureMember(user)); } catch (e) { /* member lookup is best-effort */ }
      load();
    })();
  }, [user?.email]);

  const isAdmin = user?.role === 'admin' || !!myMember?.is_admin;
  const entriesFor = (tId) => entries.filter((e) => e.tournament_id === tId);
  const myEntry = (tId) => entriesFor(tId).find((e) => e.created_by_id === user?.id);

  const create = async () => {
    if (!form.title.trim()) { toast.error('Give the tournament a title'); return; }
    setCreating(true);
    try {
      await db.entities.Tournament.create({
        title: form.title.trim(),
        format: form.format,
        slots: Number(form.slots),
      });
      grantAchievement(user, 'tournament-host');
      toast.success('Tournament created — sign-ups open!');
      setShowCreate(false);
      setForm({ title: '', format: '1v1', slots: 8 });
      load();
    } catch (e) {
      toast.error(e.message || 'Could not create the tournament');
    } finally {
      setCreating(false);
    }
  };

  const signUp = async (t) => {
    const name = (signups[t.id] || '').trim();
    if (!name) {
      toast.error(t.format === '2v2' ? 'Enter your team name (e.g. "Storm & Volt")' : 'Enter your gamer tag');
      return;
    }
    setBusy(true);
    try {
      await db.entities.TournamentEntry.create({ tournament_id: t.id, team_name: name });
      grantAchievement(user, 'tournament-debut');
      toast.success("You're in! ⚡");
      load();
    } catch (e) {
      toast.error(e.message || 'Sign-up failed');
    } finally {
      setBusy(false);
    }
  };

  const start = async (t) => {
    const teams = entriesFor(t.id).slice(0, t.slots).map((e) => e.team_name);
    if (teams.length < 2) { toast.error('Need at least 2 sign-ups to start'); return; }
    setBusy(true);
    try {
      const matches = seedBracket(teams);
      await db.entities.Tournament.update(t.id, {
        status: isComplete(matches) ? 'completed' : 'active',
        teams,
        matches,
      });
      toast.success('Bracket is live! ⚡');
      load();
    } catch (e) {
      toast.error(e.message || 'Could not start the tournament');
    } finally {
      setBusy(false);
    }
  };

  const pickWinner = async (t, round, pos, winner) => {
    const matches = setMatchWinner(t.matches || [], round, pos, winner);
    try {
      await db.entities.Tournament.update(t.id, { matches, status: isComplete(matches) ? 'completed' : 'active' });
      load();
    } catch (e) {
      toast.error(e.message || 'Could not record the result');
    }
  };

  const remove = async (t) => {
    if (!window.confirm(`Delete "${t.title}"? This also removes its sign-ups.`)) return;
    try {
      for (const e of entriesFor(t.id)) await db.entities.TournamentEntry.delete(e.id);
      await db.entities.Tournament.delete(t.id);
      toast.success('Tournament deleted');
      load();
    } catch (e) {
      toast.error(e.message || 'Delete failed');
    }
  };

  if (loading) {
    return (
      <div className="p-10 flex flex-col items-center text-white/50">
        <Loader2 className="w-8 h-8 animate-pulse mb-2" /> Loading tournaments…
      </div>
    );
  }

  return (
    <div className="p-6 sm:p-10 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-heading text-3xl font-black flex items-center gap-2">
          <Trophy className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> Tournaments
        </h1>
        {isAdmin && (
          <Button onClick={() => setShowCreate((s) => !s)} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
            <Plus className="w-4 h-4 mr-1" /> {showCreate ? 'Cancel' : 'New Tournament'}
          </Button>
        )}
      </div>

      {isAdmin && showCreate && (
        <div className="max-w-xl space-y-4 p-6 rounded-xl bg-white/5 border border-white/10 mb-8">
          <div className="space-y-2">
            <Label className="text-white/80">Title</Label>
            <Input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Sunday Showdown"
              className="bg-black/40 border-white/15 text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white/80">Format</Label>
              <div className="flex gap-2">
                {['1v1', '2v2'].map((f) => (
                  <Button
                    key={f}
                    size="sm"
                    variant="outline"
                    onClick={() => setForm({ ...form, format: f })}
                    className={form.format === f ? 'border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]' : 'border-white/20 text-white/60'}
                  >
                    {f}
                  </Button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-white/80">Bracket size</Label>
              <div className="flex gap-2">
                {[4, 8, 16].map((s) => (
                  <Button
                    key={s}
                    size="sm"
                    variant="outline"
                    onClick={() => setForm({ ...form, slots: s })}
                    className={form.slots === s ? 'border-[hsl(var(--voltage-yellow))] text-[hsl(var(--voltage-yellow))]' : 'border-white/20 text-white/60'}
                  >
                    {s}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          <Button onClick={create} disabled={creating} className="bg-[hsl(var(--voltage-blue))] text-black font-bold">
            {creating ? 'Creating…' : 'Create Tournament'}
          </Button>
        </div>
      )}

      {tournaments.length === 0 ? (
        <p className="text-white/40 text-center py-10">
          No tournaments yet{isAdmin ? ' — create the first one!' : ' — check back soon!'}
        </p>
      ) : (
        <div className="space-y-6">
          {tournaments.map((t) => {
            const list = entriesFor(t.id);
            const mine = myEntry(t.id);
            const champ = t.status !== 'signup' ? champion(t.matches) : null;
            return (
              <div key={t.id} className="p-6 rounded-2xl bg-white/5 border border-white/10">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="font-bold text-lg">{t.title}</h2>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[hsl(var(--voltage-blue))]/15 text-[hsl(var(--voltage-blue))]">{t.format}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        t.status === 'signup' ? 'bg-white/10 text-white/60'
                        : t.status === 'active' ? 'bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))]'
                        : 'bg-green-500/15 text-green-400'}`}
                      >
                        {t.status === 'signup' ? 'SIGN-UPS OPEN' : t.status === 'active' ? 'LIVE' : 'COMPLETED'}
                      </span>
                    </div>
                    {t.status === 'signup' && (
                      <p className="text-white/50 text-sm mt-1">
                        {list.length}/{t.slots} signed up {t.format === '2v2' ? 'teams' : 'players'}
                      </p>
                    )}
                    {champ && (
                      <p className="flex items-center gap-1.5 text-sm mt-1 font-bold text-[hsl(var(--voltage-yellow))]">
                        <Crown className="w-4 h-4" /> Champion: {champ}
                      </p>
                    )}
                  </div>
                  {isAdmin && (
                    <div className="flex gap-2">
                      {t.status === 'signup' && (
                        <Button size="sm" disabled={busy} onClick={() => start(t)} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold">
                          <Swords className="w-4 h-4 mr-1" /> Start Bracket
                        </Button>
                      )}
                      <Button size="sm" variant="destructive" onClick={() => remove(t)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>

                {t.status === 'signup' && (
                  <div className="mt-4 space-y-3">
                    {list.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {list.map((e) => (
                          <span key={e.id} className="text-xs px-2 py-1 rounded-full bg-white/10 text-white/70 flex items-center gap-1">
                            <Users className="w-3 h-3" /> {e.team_name}
                          </span>
                        ))}
                      </div>
                    )}
                    {mine ? (
                      <p className="text-sm text-[hsl(var(--voltage-yellow))]">
                        You're signed up as "{mine.team_name}" — see you in the bracket!
                      </p>
                    ) : (
                      <div className="flex gap-2 max-w-sm">
                        <Input
                          value={signups[t.id] || ''}
                          onChange={(e) => setSignups({ ...signups, [t.id]: e.target.value })}
                          placeholder={t.format === '2v2' ? 'Team name (e.g. Storm & Volt)' : (myMember?.username || 'Your gamer tag')}
                          className="bg-black/40 border-white/15 text-white"
                        />
                        <Button disabled={busy} onClick={() => signUp(t)} className="bg-[hsl(var(--voltage-blue))] text-black font-bold">
                          Sign Up
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                {t.status !== 'signup' && (
                  <div className="mt-5">
                    <BracketView
                      tournament={t}
                      isAdmin={isAdmin}
                      onSetWinner={(round, pos, winner) => pickWinner(t, round, pos, winner)}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}