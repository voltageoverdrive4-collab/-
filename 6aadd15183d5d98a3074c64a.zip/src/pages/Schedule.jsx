const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { Calendar, ExternalLink } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { grantAchievement } from '@/lib/achievements';

export default function Schedule() {
  const { user } = useAuth();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const list = await db.entities.ScheduledEvent.list('date', 100);
        setEvents(list);
      } finally { setLoading(false); }
    })();
  }, []);

  useEffect(() => {
    if (user?.id) grantAchievement(user, 'event-planner');
  }, [user?.id]);

  return (
    <div className="p-6 sm:p-10 max-w-4xl mx-auto">
      <h1 className="font-heading text-3xl font-black mb-6 flex items-center gap-2"><Calendar className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> Schedule</h1>
      <div className="space-y-4">
        {events.map((e) => (
          <div key={e.id} className="p-5 rounded-2xl bg-white/5 border border-white/10 flex gap-4">
            <div className="w-16 text-center shrink-0">
              <div className="text-[hsl(var(--voltage-yellow))] text-xs uppercase tracking-widest">{new Date(e.date).toLocaleString('en', { month: 'short' })}</div>
              <div className="text-3xl font-black">{new Date(e.date).getDate()}</div>
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-lg">{e.title}</h3>
              {e.time && <p className="text-[hsl(var(--voltage-blue))] text-sm">{e.time}</p>}
              {e.description && <p className="text-white/60 text-sm mt-1">{e.description}</p>}
              {e.meeting_url && (
                <a href={e.meeting_url} target="_blank" rel="noreferrer"
                  className="inline-flex items-center gap-1.5 mt-2 px-3 py-1.5 rounded-lg bg-[hsl(var(--voltage-yellow))]/15 text-[hsl(var(--voltage-yellow))] text-sm font-medium border border-[hsl(var(--voltage-yellow))]/40 hover:bg-[hsl(var(--voltage-yellow))]/25 transition-colors">
                  <ExternalLink className="w-3.5 h-3.5" /> Join meeting
                </a>
              )}
            </div>
          </div>
        ))}
        {events.length === 0 && !loading && <p className="text-white/40 text-center py-10">No events scheduled.</p>}
      </div>
    </div>
  );
}