const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState, useCallback } from 'react';

import { useAuth } from '@/lib/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Check, X, Ban, UserPlus, Trash2, Shield, Send, Crown, Tag, Bot } from 'lucide-react';
import { toast } from 'react-hot-toast';
import ActiveMembersTab from '@/components/admin/ActiveMembersTab';
import WebsitesTab from '@/components/admin/WebsitesTab';
import CreateAccountPanel from '@/components/admin/CreateAccountPanel';
import ActivityInsightsTab from '@/components/admin/ActivityInsightsTab';
import ModerationTab from '@/components/admin/ModerationTab';
import TagColorsPanel from '@/components/admin/TagColorsPanel';
import FeedbackTab from '@/components/admin/FeedbackTab';
import TeamsAdminTab from '@/components/admin/TeamsAdminTab';
import AchievementsAdminTab from '@/components/admin/AchievementsAdminTab';
import VideoAdsTab from '@/components/admin/VideoAdsTab';
import GuiThemeTab from '@/components/admin/GuiThemeTab';
import DonationsTab from '@/components/admin/DonationsTab';
import AnnouncementsTab from '@/components/admin/AnnouncementsTab';
import UpdatesTab from '@/components/admin/UpdatesTab';
import AppControlTab from '@/components/admin/AppControlTab';
import AssetsTab from '@/components/admin/AssetsTab';
import DownloadAppTab from '@/components/admin/DownloadAppTab';
import CodesTab from '@/components/admin/CodesTab';
import { MODERATOR_TAG } from '@/lib/moderation';
import { postWelcome } from '@/lib/welcomeBot';
import { withRetry, delay } from '@/lib/apiRetry';

export default function Admin() {
  const { user } = useAuth();
  const [apps, setApps] = useState([]);
  const [members, setMembers] = useState([]);
  const [studioReqs, setStudioReqs] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);

  // each list has its own loader so an action only refetches what it changed;
  // the first load runs one request at a time (with retry) to stay under the API rate limit
  const loadMembers = useCallback(async () => setMembers(await withRetry(() => db.entities.Member.list('-created_date', 200))), []);
  const loadApps = useCallback(async () => setApps(await withRetry(() => db.entities.Application.list('-created_date', 200))), []);
  const loadStudio = useCallback(async () => setStudioReqs(await withRetry(() => db.entities.StudioRequest.list('-created_date', 200))), []);
  const loadFeedback = useCallback(async () => setFeedback(await withRetry(() => db.entities.Feedback.list('-created_date', 200))), []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      await loadMembers();
      await delay(500);
      await loadApps();
      await delay(500);
      await loadStudio();
      await delay(500);
      await loadFeedback();
    } catch (e) {
      toast.error('The server is busy right now — wait a few seconds and refresh the page');
    } finally {
      setLoading(false);
    }
  }, [loadMembers, loadApps, loadStudio, loadFeedback]);

  useEffect(() => { load(); }, [load]);

  const myMember = members.find((m) => m.email === user?.email) || null;

  const isPlatformAdmin = user?.role === 'admin';
  const isAdmin = isPlatformAdmin || !!myMember?.is_admin;
  const isModerator = (myMember?.tags || []).includes(MODERATOR_TAG);

  // grant access by platform role, the clan-level admin flag, or the moderator tag
  if (!isAdmin && !isModerator) {
    return <div className="p-10 text-center text-white/60">{loading ? 'Checking access…' : 'Admin access only.'}</div>;
  }

  // moderators without admin rights see the chat moderation tab only
  if (!isAdmin) {
    return (
      <div className="p-6 sm:p-10 max-w-6xl mx-auto">
        <h1 className="font-heading text-3xl font-black mb-6 flex items-center gap-2">
          <Shield className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> Chat Moderation
        </h1>
        <ModerationTab members={members} />
      </div>
    );
  }

  const setAppStatus = async (id, status) => {
    await db.entities.Application.update(id, { status });
    toast.success(`Application ${status}`);
    loadApps();
  };
  const moveOn = async (app) => {
    await db.entities.Member.create({ username: app.username, email: app.email, tags: [], banned_from_chat: false, is_admin: false });
    postWelcome(app.username, user.id).catch(() => {});
    await db.entities.Application.update(app.id, { status: 'moved_on' });
    toast.success(`${app.username} added to clan`);
    await loadMembers();
    await loadApps();
  };
  const declineApp = async (id) => {
    await db.entities.Application.delete(id);
    toast.success('Application declined');
    loadApps();
  };

  const kick = async (id) => {
    await db.entities.Member.delete(id);
    toast.success('Member removed');
    loadMembers();
  };
  const toggleBan = async (m) => {
    await db.entities.Member.update(m.id, { banned_from_chat: !m.banned_from_chat });
    loadMembers();
  };
  const toggleAdmin = async (m) => {
    await db.entities.Member.update(m.id, { is_admin: !m.is_admin });
    loadMembers();
  };
  const toggleModerator = async (m) => {
    const tags = m.tags || [];
    const next = tags.includes(MODERATOR_TAG) ? tags.filter((t) => t !== MODERATOR_TAG) : [...tags, MODERATOR_TAG];
    await db.entities.Member.update(m.id, { tags: next });
    toast.success(next.includes(MODERATOR_TAG) ? `${m.username} can now moderate chat` : `${m.username} is no longer a moderator`);
    loadMembers();
  };
  const addTag = async (m, tag) => {
    if (!tag) return;
    const tags = [...(m.tags || []), tag];
    await db.entities.Member.update(m.id, { tags });
    loadMembers();
  };
  const removeTag = async (m, tag) => {
    const tags = (m.tags || []).filter((t) => t !== tag);
    await db.entities.Member.update(m.id, { tags });
    loadMembers();
  };

  const updateStudio = async (id, status) => {
    await db.entities.StudioRequest.update(id, { status });
    toast.success(`Studio request ${status}`);
    loadStudio();
  };

  const pending = apps.filter((a) => a.status === 'pending');
  const accepted = apps.filter((a) => a.status === 'accepted');

  return (
    <div className="p-6 sm:p-10 max-w-6xl mx-auto">
      <div className="hub-page-hero volt-rise relative volt-hero volt-panel rounded-3xl p-6 sm:p-8 mb-8 overflow-hidden">
        <div className="absolute inset-0 voltage-grid opacity-60 pointer-events-none" />
        <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[hsl(var(--voltage-yellow))]/15 blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[hsl(var(--voltage-yellow))] to-[hsl(var(--voltage-blue))] flex items-center justify-center text-black shrink-0 shadow-[0_0_25px_hsl(var(--voltage-yellow)/0.3)]">
            <Shield className="w-7 h-7" />
          </div>
          <div>
            <p className="text-[10px] tracking-[0.35em] text-white/40 mb-1">COMMAND CENTER</p>
            <h1 className="hub-page-title font-heading text-3xl font-black">Admin <span className="volt-gradient-text">Command</span></h1>
          </div>
        </div>
      </div>

      <Tabs defaultValue="apps">
        <TabsList className="volt-panel flex w-full justify-start overflow-x-auto h-auto py-1.5 rounded-2xl gap-1 [&>*]:shrink-0">
          <TabsTrigger value="apps">Applications ({pending.length})</TabsTrigger>
          <TabsTrigger value="members">Members ({members.length})</TabsTrigger>
          <TabsTrigger value="active">Active Members</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="moderation">Moderation</TabsTrigger>
          <TabsTrigger value="studio">Studio ({studioReqs.filter((s) => s.status === 'pending').length})</TabsTrigger>
          <TabsTrigger value="feedback">Feedback ({feedback.filter((f) => f.status === 'open').length})</TabsTrigger>
          <TabsTrigger value="email">Email</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="codes">Codes</TabsTrigger>
          <TabsTrigger value="teams">Teams</TabsTrigger>
          <TabsTrigger value="videoads">Video Ads</TabsTrigger>
          <TabsTrigger value="gui">GUI Theme</TabsTrigger>
          <TabsTrigger value="donations">Donations</TabsTrigger>
          <TabsTrigger value="announcements">Announcements</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="websites">Websites</TabsTrigger>
          <TabsTrigger value="updates">Updates</TabsTrigger>
          <TabsTrigger value="appcontrol">App Control</TabsTrigger>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="download">Download App</TabsTrigger>
        </TabsList>

        <TabsContent value="apps" className="space-y-4 mt-6">
          {pending.map((a) => (
            <div key={a.id} className="p-5 rounded-xl bg-white/5 border border-white/10">
              <div className="flex flex-wrap justify-between gap-4">
                <div>
                  <div className="font-bold text-lg">{a.username}</div>
                  <div className="text-white/50 text-sm">{a.email} {a.age ? `• ${a.age} yrs` : ''}</div>
                  {a.message && <p className="text-white/70 text-sm mt-2 max-w-xl">{a.message}</p>}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" onClick={() => setAppStatus(a.id, 'accepted')} className="bg-[hsl(var(--voltage-yellow))] text-black"><Check className="w-4 h-4 mr-1" /> Accept</Button>
                  <Button size="sm" variant="outline" onClick={() => declineApp(a.id)} className="border-white/20 text-white hover:bg-white/10"><Trash2 className="w-4 h-4 mr-1" /> Decline</Button>
                  <Button size="sm" variant="destructive" onClick={() => setAppStatus(a.id, 'failed')}><Ban className="w-4 h-4 mr-1" /> Fail</Button>
                </div>
              </div>
            </div>
          ))}

          {accepted.length > 0 && (
            <>
              <h3 className="text-white/50 text-sm uppercase tracking-widest mt-8 mb-2">Accepted — awaiting Move On</h3>
              {accepted.map((a) => (
                <div key={a.id} className="p-5 rounded-xl bg-[hsl(var(--voltage-yellow))]/5 border border-[hsl(var(--voltage-yellow))]/20">
                  <div className="flex flex-wrap justify-between gap-4 items-center">
                    <div>
                      <div className="font-bold">{a.username}</div>
                      <div className="text-white/50 text-sm">{a.email}</div>
                    </div>
                    <Button size="sm" onClick={() => moveOn(a)} className="bg-[hsl(var(--voltage-blue))] text-black"><UserPlus className="w-4 h-4 mr-1" /> Move On to Clan</Button>
                  </div>
                </div>
              ))}
            </>
          )}

          {pending.length === 0 && accepted.length === 0 && !loading && (
            <p className="text-white/40 text-center py-10">No applications pending.</p>
          )}
        </TabsContent>

        <TabsContent value="members" className="space-y-3 mt-6">
          <CreateAccountPanel />
          {members.map((m) => (
            <div key={m.id} className="p-4 rounded-xl bg-white/5 border border-white/10">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="font-bold">{m.username}</span>
                  {m.is_admin && <Badge className="bg-[hsl(var(--voltage-yellow))] text-black"><Crown className="w-3 h-3 mr-1" /> Admin</Badge>}
                  {(m.tags || []).includes(MODERATOR_TAG) && <Badge className="bg-[hsl(var(--voltage-blue))] text-black"><Bot className="w-3 h-3 mr-1" /> Moderator</Badge>}
                  {m.banned_from_chat && <Badge variant="destructive">Chat banned</Badge>}
                  {(m.tags || []).map((t) => (
                    <Badge key={t} className="bg-[hsl(var(--voltage-blue))]/20 text-[hsl(var(--voltage-blue))] border border-[hsl(var(--voltage-blue))]/40 cursor-pointer" onClick={() => removeTag(m, t)}>
                      <Tag className="w-3 h-3 mr-1" />{t} ✕
                    </Badge>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2">
                  <TagInput onAdd={(t) => addTag(m, t)} />
                  <Button size="sm" variant="outline" onClick={() => toggleAdmin(m)} className="border-white/20 text-white hover:bg-white/10"><Crown className="w-4 h-4 mr-1" /> {m.is_admin ? 'Revoke' : 'Admin'}</Button>
                  <Button size="sm" variant="outline" onClick={() => toggleModerator(m)} className="border-white/20 text-white hover:bg-white/10"><Bot className="w-4 h-4 mr-1" /> {(m.tags || []).includes(MODERATOR_TAG) ? 'Revoke Mod' : 'Moderator'}</Button>
                  <Button size="sm" variant="outline" onClick={() => toggleBan(m)} className="border-white/20 text-white hover:bg-white/10"><Ban className="w-4 h-4 mr-1" /> {m.banned_from_chat ? 'Unban' : 'Ban chat'}</Button>
                  <Button size="sm" variant="destructive" onClick={() => kick(m.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            </div>
          ))}
          {members.length === 0 && !loading && <p className="text-white/40 text-center py-10">No clan members yet.</p>}
          <TagColorsPanel members={members} />
        </TabsContent>

        <TabsContent value="active" className="mt-6">
          <ActiveMembersTab members={members} myMember={myMember} />
        </TabsContent>

        <TabsContent value="activity" className="mt-6">
          <ActivityInsightsTab members={members} />
        </TabsContent>

        <TabsContent value="moderation" className="mt-6">
          <ModerationTab members={members} />
        </TabsContent>

        <TabsContent value="studio" className="space-y-3 mt-6">
          {studioReqs.map((s) => (
            <div key={s.id} className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-wrap justify-between gap-3 items-center">
              <div>
                <div className="font-bold">{s.username} <Badge className="ml-2">{s.status}</Badge></div>
                <div className="text-white/50 text-sm">{s.email}</div>
                {s.experience && <p className="text-white/70 text-sm mt-1 max-w-xl">{s.experience}</p>}
              </div>
              {s.status === 'pending' && (
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => updateStudio(s.id, 'approved')} className="bg-[hsl(var(--voltage-yellow))] text-black"><Check className="w-4 h-4 mr-1" /> Approve</Button>
                  <Button size="sm" variant="destructive" onClick={() => updateStudio(s.id, 'declined')}><X className="w-4 h-4 mr-1" /> Decline</Button>
                </div>
              )}
            </div>
          ))}
          {studioReqs.length === 0 && !loading && <p className="text-white/40 text-center py-10">No studio requests.</p>}
        </TabsContent>

        <TabsContent value="feedback" className="mt-6">
          <FeedbackTab feedback={feedback} onChanged={loadFeedback} />
        </TabsContent>

        <TabsContent value="email" className="mt-6">
          <EmailSender members={members} />
        </TabsContent>

        <TabsContent value="achievements" className="mt-6">
          <AchievementsAdminTab members={members} />
        </TabsContent>

        <TabsContent value="codes" className="mt-6">
          <CodesTab />
        </TabsContent>

        <TabsContent value="teams" className="mt-6">
          <TeamsAdminTab members={members} />
        </TabsContent>

        <TabsContent value="videoads" className="mt-6">
          <VideoAdsTab />
        </TabsContent>

        <TabsContent value="gui" className="mt-6">
          <GuiThemeTab />
        </TabsContent>

        <TabsContent value="donations" className="mt-6">
          <DonationsTab />
        </TabsContent>

        <TabsContent value="announcements" className="mt-6">
          <AnnouncementsTab />
        </TabsContent>

        <TabsContent value="schedule" className="mt-6">
          <ScheduleCreator members={members} />
        </TabsContent>
        <TabsContent value="websites" className="mt-6">
          <WebsitesTab />
        </TabsContent>

        <TabsContent value="updates" className="mt-6">
          <UpdatesTab />
        </TabsContent>

        <TabsContent value="appcontrol" className="mt-6">
          <AppControlTab />
        </TabsContent>
        <TabsContent value="assets" className="mt-6">
          <AssetsTab />
        </TabsContent>
        <TabsContent value="download" className="mt-6">
          <DownloadAppTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function TagInput({ onAdd }) {
  const [val, setVal] = useState('');
  return (
    <div className="flex gap-1">
      <Input value={val} onChange={(e) => setVal(e.target.value)} placeholder="Tag" className="h-8 w-24 bg-black/40 border-white/15 text-white text-xs" onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); onAdd(val.trim()); setVal(''); } }} />
      <Button size="sm" type="button" className="h-8" onClick={() => { onAdd(val.trim()); setVal(''); }}>Add</Button>
    </div>
  );
}

function EmailSender({ members }) {
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);

  const send = async () => {
    if (!to || !subject) return;
    setSending(true);
    try {
      await db.functions.invoke('sendClanEmail', { to, subject, body });
      toast.success('Email sent');
      setSubject(''); setBody('');
    } catch (e) {
      toast.error(e.message || 'Send failed');
    } finally { setSending(false); }
  };

  return (
    <div className="max-w-xl space-y-4 p-6 rounded-xl bg-white/5 border border-white/10">
      <div className="space-y-2">
        <Label className="text-white/80">Recipient</Label>
        <select value={to} onChange={(e) => setTo(e.target.value)} className="w-full bg-black/40 border border-white/15 rounded-md px-3 py-2 text-white">
          <option value="">Select a member…</option>
          {members.map((m) => <option key={m.id} value={m.email}>{m.username} — {m.email}</option>)}
        </select>
      </div>
      <div className="space-y-2">
        <Label className="text-white/80">Subject</Label>
        <Input value={subject} onChange={(e) => setSubject(e.target.value)} className="bg-black/40 border-white/15 text-white" />
      </div>
      <div className="space-y-2">
        <Label className="text-white/80">Message</Label>
        <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} className="bg-black/40 border-white/15 text-white" />
      </div>
      <Button onClick={send} disabled={sending} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Send className="w-4 h-4 mr-2" /> {sending ? 'Sending…' : 'Send Email'}</Button>
    </div>
  );
}

function ScheduleCreator({ members, onChanged }) {
  const [form, setForm] = useState({ title: '', date: '', time: '', description: '' });
  const [selected, setSelected] = useState([]);
  const [saving, setSaving] = useState(false);
  const [events, setEvents] = useState([]);

  const loadEvents = async () => {
    try {
      const e = await withRetry(() => db.entities.ScheduledEvent.list('-date', 50));
      setEvents(e);
    } catch (e) {
      toast.error('The server is busy right now — wait a few seconds and refresh the page');
    }
  };
  useEffect(() => { loadEvents(); }, []);

  const toggle = (email) => setSelected((s) => s.includes(email) ? s.filter((x) => x !== email) : [...s, email]);

  const create = async () => {
    if (!form.title || !form.date) {
      toast.error('Title and date are required');
      return;
    }
    setSaving(true);
    try {
      await db.entities.ScheduledEvent.create({ ...form, notify_emails: selected });
    } catch (e) {
      toast.error('Could not save the event: ' + (e.message || 'unknown error'));
      setSaving(false);
      return;
    }

    // send notifications one by one so one failure doesn't sink the whole flow
    let failed = 0;
    for (const email of selected) {
      try {
        await db.functions.invoke('sendClanEmail', {
          to: email,
          subject: `Voltage Event: ${form.title}`,
          body: `${form.title}\n${form.date}${form.time ? ' at ' + form.time : ''}\n\n${form.description || ''}\n\n— Voltage Clan`,
        });
      } catch (e) {
        failed += 1;
      }
    }

    if (failed > 0) {
      toast.error(`Event saved, but ${failed} notification${failed > 1 ? 's' : ''} failed to send`);
    } else {
      toast.success(selected.length > 0 ? 'Event created & notifications sent' : 'Event created');
    }
    setForm({ title: '', date: '', time: '', description: '' });
    setSelected([]);
    loadEvents();
    onChanged?.();
    setSaving(false);
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-4 p-6 rounded-xl bg-white/5 border border-white/10">
        <h3 className="font-bold">New Event</h3>
        <div className="space-y-2"><Label className="text-white/80">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-black/40 border-white/15 text-white" /></div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2"><Label className="text-white/80">Date</Label><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="bg-black/40 border-white/15 text-white" /></div>
          <div className="space-y-2"><Label className="text-white/80">Time</Label><Input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="bg-black/40 border-white/15 text-white" /></div>
        </div>
        <div className="space-y-2"><Label className="text-white/80">Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="bg-black/40 border-white/15 text-white" /></div>
        <div className="space-y-2">
          <Label className="text-white/80">Notify members ({selected.length})</Label>
          <div className="max-h-32 overflow-y-auto space-y-1">
            {members.map((m) => (
              <label key={m.id} className="flex items-center gap-2 text-sm text-white/70 cursor-pointer">
                <input type="checkbox" checked={selected.includes(m.email)} onChange={() => toggle(m.email)} className="accent-[hsl(var(--voltage-yellow))]" />
                {m.username} — {m.email}
              </label>
            ))}
          </div>
        </div>
        <Button onClick={create} disabled={saving} className="bg-[hsl(var(--voltage-yellow))] text-black font-bold"><Send className="w-4 h-4 mr-2" /> {saving ? 'Creating…' : 'Create & Notify'}</Button>
      </div>

      <div className="space-y-3">
        <h3 className="font-bold">Upcoming Events</h3>
        {events.map((e) => (
          <div key={e.id} className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="font-bold">{e.title}</div>
            <div className="text-[hsl(var(--voltage-blue))] text-sm">{e.date}{e.time ? ` • ${e.time}` : ''}</div>
            {e.description && <p className="text-white/60 text-sm mt-1">{e.description}</p>}
            <div className="text-white/40 text-xs mt-1">Notifying {e.notify_emails?.length || 0} members</div>
          </div>
        ))}
        {events.length === 0 && <p className="text-white/40">No events yet.</p>}
      </div>
    </div>
  );
}