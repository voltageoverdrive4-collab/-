const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Search, Trophy, Lock } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useAuth } from '@/lib/AuthContext';
import { grantAchievement } from '@/lib/achievements';
import { withRetry } from '@/lib/apiRetry';
import { useGameList } from '@/lib/useGameList';
import StudioGameCard from '@/components/games/StudioGameCard';
import TicTacToe from '@/components/games/TicTacToe';
import MemoryMatch from '@/components/games/MemoryMatch';
import ReactionTest from '@/components/games/ReactionTest';
import NumberGuess from '@/components/games/NumberGuess';
import SimonSays from '@/components/games/SimonSays';
import BrickBreaker from '@/components/games/BrickBreaker';
import Snake from '@/components/games/Snake';
import Pong from '@/components/games/Pong';
import ConnectFour from '@/components/games/ConnectFour';
import Hangman from '@/components/games/Hangman';
import Minesweeper from '@/components/games/Minesweeper';
import TwentyFortyEight from '@/components/games/TwentyFortyEight';
import WhackAMole from '@/components/games/WhackAMole';
import RockPaperScissors from '@/components/games/RockPaperScissors';
import TypingTest from '@/components/games/TypingTest';
import ColorMatch from '@/components/games/ColorMatch';
import HigherLower from '@/components/games/HigherLower';
import MathBlitz from '@/components/games/MathBlitz';
import FlappyVolt from '@/components/games/FlappyVolt';
import WordScramble from '@/components/games/WordScramble';
import Tetris from '@/components/games/Tetris';
import SpaceShooter from '@/components/games/SpaceShooter';
import DotsAndBoxes from '@/components/games/DotsAndBoxes';
import VoltRunner from '@/components/games/VoltRunner';
import SlidePuzzle from '@/components/games/SlidePuzzle';
import Battleship from '@/components/games/Battleship';
import WordGuess from '@/components/games/WordGuess';
import LightsOut from '@/components/games/LightsOut';
import MazeRunner from '@/components/games/MazeRunner';
import TowerOfHanoi from '@/components/games/TowerOfHanoi';
import NimMatch from '@/components/games/NimMatch';
import MiniSudoku from '@/components/games/MiniSudoku';
import SokobanPush from '@/components/games/SokobanPush';
import VoltClicker from '@/components/games/VoltClicker';
import BombDodger from '@/components/games/BombDodger';
import PianoTiles from '@/components/games/PianoTiles';
import Blackjack21 from '@/components/games/Blackjack21';
import PigDice from '@/components/games/PigDice';
import TriviaVolt from '@/components/games/TriviaVolt';
import BullseyeDarts from '@/components/games/BullseyeDarts';
import TugOfWar from '@/components/games/TugOfWar';
import CodeBreaker from '@/components/games/CodeBreaker';
import Mancala from '@/components/games/Mancala';
import VoltReversi from '@/components/games/VoltReversi';
import GridMemory from '@/components/games/GridMemory';
import OddOneOut from '@/components/games/OddOneOut';
import BoltCount from '@/components/games/BoltCount';
import ShellGame from '@/components/games/ShellGame';
import VoltSlots from '@/components/games/VoltSlots';
import DiceDuel from '@/components/games/DiceDuel';
import CoinStreak from '@/components/games/CoinStreak';
import BalloonPop from '@/components/games/BalloonPop';
import FruitCatcher from '@/components/games/FruitCatcher';
import TowerStack from '@/components/games/TowerStack';
import ClayShoot from '@/components/games/ClayShoot';
import ArrowSequence from '@/components/games/ArrowSequence';
import SumTarget from '@/components/games/SumTarget';
import CardWar from '@/components/games/CardWar';
import DicePoker from '@/components/games/DicePoker';
import Plinko from '@/components/games/Plinko';
import Gomoku from '@/components/games/Gomoku';
import StopTheBar from '@/components/games/StopTheBar';
import DigitSpan from '@/components/games/DigitSpan';
import ReactionGrid from '@/components/games/ReactionGrid';
import LuckyWheel from '@/components/games/LuckyWheel';
import MathSequence from '@/components/games/MathSequence';
import MorseDecoder from '@/components/games/MorseDecoder';
import RomanRush from '@/components/games/RomanRush';
import BinaryBlitz from '@/components/games/BinaryBlitz';
import EmojiRiddle from '@/components/games/EmojiRiddle';
import KnightsTour from '@/components/games/KnightsTour';
import SnakesLadders from '@/components/games/SnakesLadders';
import WordChain from '@/components/games/WordChain';
import Bagels from '@/components/games/Bagels';
import ColorDash from '@/components/games/ColorDash';
import AlphaOrder from '@/components/games/AlphaOrder';
import StudioPlayer from '@/components/games/StudioPlayer';
import Calculator from '@/components/games/Calculator';
import TrafficJam from '@/components/games/TrafficJam';
import Nonogram from '@/components/games/Nonogram';
import PegSolitaire from '@/components/games/PegSolitaire';
import WordSearch from '@/components/games/WordSearch';
import VowelDrop from '@/components/games/VowelDrop';
import VideoPoker from '@/components/games/VideoPoker';
import Craps from '@/components/games/Craps';
import ChuckALuck from '@/components/games/ChuckALuck';
import Baccarat from '@/components/games/Baccarat';
import Roulette from '@/components/games/Roulette';
import Keno from '@/components/games/Keno';
import BingoBlitz from '@/components/games/BingoBlitz';
import ChimpTest from '@/components/games/ChimpTest';
import DotEstimate from '@/components/games/DotEstimate';
import PrimeHunter from '@/components/games/PrimeHunter';
import ChangeMaker from '@/components/games/ChangeMaker';
import RoadCross from '@/components/games/RoadCross';
import Bowling from '@/components/games/Bowling';
import DominoMatch from '@/components/games/DominoMatch';
import ClockChallenge from '@/components/games/ClockChallenge';
import EmojiMath from '@/components/games/EmojiMath';
import RedLight from '@/components/games/RedLight';
import WordMemory from '@/components/games/WordMemory';

const components = {
  TicTacToe, MemoryMatch, ReactionTest, NumberGuess, SimonSays, BrickBreaker,
  Snake, Pong, ConnectFour, Hangman, Minesweeper, TwentyFortyEight, WhackAMole,
  RockPaperScissors, TypingTest, ColorMatch, HigherLower, MathBlitz, FlappyVolt, WordScramble,
  Tetris, SpaceShooter, DotsAndBoxes, VoltRunner, SlidePuzzle, Battleship, WordGuess,
  LightsOut, MazeRunner, TowerOfHanoi, NimMatch, MiniSudoku, SokobanPush,
  VoltClicker, BombDodger, PianoTiles, Blackjack21,
  PigDice, TriviaVolt, BullseyeDarts, TugOfWar,
  CodeBreaker, Mancala, VoltReversi, GridMemory, OddOneOut, BoltCount,
  ShellGame, VoltSlots, DiceDuel, CoinStreak, BalloonPop, FruitCatcher,
  TowerStack, ClayShoot, ArrowSequence, SumTarget, CardWar, DicePoker, Plinko, Gomoku,
  StopTheBar, DigitSpan, ReactionGrid, LuckyWheel, MathSequence, MorseDecoder, RomanRush,
  BinaryBlitz, EmojiRiddle, KnightsTour, SnakesLadders, WordChain, Bagels, ColorDash, AlphaOrder,
  Calculator, TrafficJam, Nonogram, PegSolitaire, WordSearch, VowelDrop, VideoPoker, Craps,
  ChuckALuck, Baccarat, Roulette, Keno, BingoBlitz, ChimpTest, DotEstimate, PrimeHunter,
  ChangeMaker, RoadCross, Bowling, DominoMatch, ClockChallenge, EmojiMath, RedLight, WordMemory,
};

export default function Games() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { games, loading, failed, isAdmin, retry } = useGameList(user);
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(null);

  const deleteStudioGame = async (studioId) => {
    try {
      await withRetry(() => db.entities.StudioGame.delete(studioId));
      toast.success('Game deleted from the hub');
      retry();
    } catch (e) {
      toast.error('Could not delete right now — try again in a moment');
    }
  };

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return games.filter((g) => !q || g.name.toLowerCase().includes(q) || g.category?.toLowerCase().includes(q));
  }, [games, query]);

  // games published from Voltage Studio run through the studio player, everything else is a built-in component
  const ActiveGame = active ? (active.component === 'StudioPlayer' ? StudioPlayer : components[active.component]) : null;

  return (
    <div className="p-6 sm:p-10 max-w-6xl mx-auto">
      <h1 className="font-heading text-3xl font-black mb-2 flex items-center gap-2"><Trophy className="w-7 h-7 text-[hsl(var(--voltage-yellow))]" /> Game Hub</h1>
      <p className="text-white/50 mb-6">{games.length} minigames • search by name or category</p>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
        <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search games…" className="pl-10 bg-black/40 border-white/15 text-white" />
      </div>

      {failed && !ActiveGame && (
        <div className="mb-4 flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/70">
          <span>{games.length > 0 ? 'The server is busy — showing saved games, retrying in the background…' : 'The server is busy — retrying in the background…'}</span>
          <Button size="sm" variant="outline" onClick={retry} className="border-white/20 bg-transparent text-white">Retry now</Button>
        </div>
      )}

      {ActiveGame ? (
        <div className="space-y-4">
          <button onClick={() => setActive(null)} className="text-[hsl(var(--voltage-blue))] text-sm hover:underline">← Back to all games</button>
          <div className="p-6 rounded-2xl bg-black/40 border border-white/10">
            <h2 className="font-heading text-2xl font-black mb-4">
              {active.name}
              {active.by && <span className="text-sm font-normal text-white/40 ml-2">by {active.by}</span>}
            </h2>
            {active.component === 'StudioPlayer'
              ? <StudioPlayer name={active.name} sceneJson={active.scene} />
              : <ActiveGame />}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((g) => g.component === 'StudioPlayer' ? (
            <StudioGameCard
              key={g.id}
              game={g}
              isAdmin={isAdmin}
              onPlay={() => { setActive(g); grantAchievement(user, 'game-time'); }}
              onEdit={() => navigate('/studio', { state: { importGameId: g.studioId } })}
              onDelete={() => deleteStudioGame(g.studioId)}
            />
          ) : (
            <button
              key={g.id}
              onClick={() => { if (g.playable) { setActive(g); grantAchievement(user, 'game-time'); } }}
              className={`p-4 rounded-xl text-left transition-all ${g.playable ? 'bg-white/5 border border-white/10 hover:border-[hsl(var(--voltage-yellow))]/50 hover:-translate-y-0.5' : 'bg-white/[0.02] border border-white/5 opacity-50 cursor-not-allowed'}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="font-bold text-sm">{g.name}</span>
                {!g.playable && <Lock className="w-3 h-3 text-white/30" />}
              </div>
              <Badge variant="outline" className="text-[10px] border-white/20 text-white/50">{g.category}</Badge>
            </button>
          ))}
          {games.length === 0 && loading && <p className="text-white/40 col-span-full text-center py-10">Loading games…</p>}
          {filtered.length === 0 && games.length > 0 && <p className="text-white/40 col-span-full text-center py-10">No games match "{query}".</p>}
        </div>
      )}
    </div>
  );
}