import { useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { Toaster as HotToaster } from 'react-hot-toast'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useGuiTheme } from '@/lib/useGuiTheme';
import { useVersionNotify } from '@/lib/useVersionNotify';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Home from '@/pages/Home';
import Dashboard from '@/pages/Dashboard';
import Admin from '@/pages/Admin';
import Chat from '@/pages/Chat';
import AITools from '@/pages/AITools';
import Games from '@/pages/Games';
import Media from '@/pages/Media';
import Schedule from '@/pages/Schedule';
import CalendarPage from '@/pages/CalendarPage';
import Nightmare from '@/pages/Nightmare';
import ChristmasCabin from '@/pages/ChristmasCabin';
import HolidayFest from '@/pages/HolidayFest';
import Teams from '@/pages/Teams';
import Studio from '@/pages/Studio';
import Engine from '@/pages/Engine';
import Aim from '@/pages/Aim';
import Profile from '@/pages/Profile';
import Feedback from '@/pages/Feedback';
import AboutUs from '@/pages/AboutUs';
import ItemShop from '@/pages/ItemShop';
import FortniteNews from '@/pages/FortniteNews';
import Tournaments from '@/pages/Tournaments';
import Giveaways from '@/pages/Giveaways';
import Donate from '@/pages/Donate';
import DonationThankYou from '@/pages/DonationThankYou';
import Meetings from '@/pages/Meetings';
import MeetingRoom from '@/pages/MeetingRoom';
import EmbedSite from '@/pages/EmbedSite';
import SiteTabs from '@/pages/SiteTabs';
import Layout from '@/components/Layout';
import ShutdownGate from '@/components/ShutdownGate';
import { MusicProvider } from '@/lib/MusicPlayer';
import Music from '@/pages/Music';
import Quests from '@/pages/Quests';
import Achievements from '@/pages/Achievements';
import Forms from '@/pages/Forms';
import ClanShop from '@/pages/ClanShop';
import Rules from '@/pages/Rules';
import Intro from '@/pages/Intro';

const AuthenticatedApp = () => {
  useGuiTheme();
  useVersionNotify();
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // the browser's install offer fires once while the hub loads — capture it
  // here so the admin Download App tab can show a one-tap install button
  useEffect(() => {
    const h = (e) => { e.preventDefault(); window.__voltInstallPrompt = e; };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <ShutdownGate>
    <MusicProvider>
    <Routes>
      <Route path="/home" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      {/* public: buyers return here straight from the payment page, often without a session */}
      <Route path="/donate/thanks" element={<DonationThankYou />} />
      {/* new visitors land on the public page with the clan application form instead of login */}
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/home" replace />} />}>
        <Route path="/" element={<Intro />} />
        <Route element={<Layout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/ai" element={<AITools />} />
          <Route path="/games" element={<Games />} />
          <Route path="/media" element={<Media />} />
          <Route path="/music" element={<Music />} />
          <Route path="/quests" element={<Quests />} />
          <Route path="/achievements" element={<Achievements />} />
          <Route path="/forms" element={<Forms />} />
          <Route path="/clan-shop" element={<ClanShop />} />
          <Route path="/rules" element={<Rules />} />
          <Route path="/schedule" element={<Schedule />} />
          <Route path="/calendar" element={<CalendarPage />} />
          <Route path="/nightmare" element={<Nightmare />} />
          <Route path="/winter" element={<ChristmasCabin />} />
          <Route path="/studio" element={<Studio />} />
          <Route path="/engine" element={<Engine />} />
          <Route path="/aim" element={<Aim />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/shop" element={<ItemShop />} />
          <Route path="/news" element={<FortniteNews />} />
          <Route path="/tournaments" element={<Tournaments />} />
          <Route path="/giveaways" element={<Giveaways />} />
          <Route path="/donate" element={<Donate />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/holiday" element={<HolidayFest />} />
          <Route path="/meetings" element={<Meetings />} />
          <Route path="/meetings/room/:id" element={<MeetingRoom />} />
          <Route path="/site/:id" element={<EmbedSite />} />
          <Route path="/tabs" element={<SiteTabs />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </MusicProvider>
    </ShutdownGate>
  );
};

function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
        <HotToaster position="top-center" />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App