# Nova Chat

A modern dark, ChatGPT-style chat app for Godot 4.3+ that talks to any model on OpenRouter.

## Setup
1. Open `scripts/chat.gd` and replace `<open-router-key>` with your key (https://openrouter.ai/keys).
2. Import `project.godot` in Godot 4.3+ and press F5.

Don't share the project or zip after adding your key.

## Scene tree (all visible in the editor)
```
main.tscn
Main (Control, chat.gd)
├─ Background (ColorRect)
├─ Layout (HBoxContainer)
│  ├─ Sidebar -> NewChatButton, chat history (ChatItem scenes)
│  └─ Content
│     ├─ TopBar -> sidebar toggle, ModelPicker, CustomModel, key status
│     ├─ Welcome -> title + suggestion chips
│     ├─ ChatScroll -> Messages (UserMessage / AssistantMessage scenes)
│     └─ InputArea -> TextEdit + send button
└─ Http (HTTPRequest)
scenes/user_message.tscn  scenes/assistant_message.tscn  scenes/chat_item.tscn
theme.tres  (the dark ChatGPT look, applied project-wide)
```

## Using it
- Enter sends, Shift+Enter makes a new line. The send button turns into ■ while waiting (click to cancel).
- Pick a model in the top bar, or choose "Custom model…" and type any OpenRouter id (e.g. `openai/gpt-4o`).
- Edit the model list, system prompt, and history length at the top of `chat.gd`.
- Chats are saved automatically to `user://chats.json`.
- Replies render Markdown (code blocks, bold, headings, lists, links) with a typewriter effect.
